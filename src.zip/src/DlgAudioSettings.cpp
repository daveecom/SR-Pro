// DlgAudioSettings.cpp : implementation file
//

#include "stdafx.h"

#include "DlgAudioSettings.h"
#include "dlgChannel.h"
#include ".\dlgaudiosettings.h"


// CDlgAudioSettings dialog

IMPLEMENT_DYNAMIC(CDlgAudioSettings, CDialog)
CDlgAudioSettings::CDlgAudioSettings(CAudioSettings* pAudioSettings, CWnd* pParent /*= NULL*/)
	: CDialog(CDlgAudioSettings::IDD, pParent)
{
	MMRESULT	mmr;

	ASSERT(pAudioSettings);
	m_pAudioSettings = pAudioSettings;

	m_dwMaxWFSize = 0;
	mmr = acmMetrics(NULL, ACM_METRIC_MAX_SIZE_FORMAT, &m_dwMaxWFSize);
	ASSERTMMR;
	ASSERT(m_dwMaxWFSize > 0);

	m_pwfCapture	= (LPWAVEFORMATEX) new BYTE[m_dwMaxWFSize];
	m_pwfCompress	= (LPWAVEFORMATEX) new BYTE[m_dwMaxWFSize];
}

CDlgAudioSettings::~CDlgAudioSettings()
{
	delete [] m_pwfCapture;
	delete [] m_pwfCompress;
}

void CDlgAudioSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_SAMPLESPERSEC, m_Static_SampleRate);
	DDX_Control(pDX, IDC_STATIC_BITS, m_Static_Bits);
	DDX_Control(pDX, IDC_STATIC_CHANNELS, m_Static_Mode);
	DDX_Control(pDX, IDC_STATIC_FORMAT, m_Static_Format);
	DDX_Control(pDX, IDC_STATIC_FORMATTAG, m_Static_FormatTag);
	DDX_Control(pDX, IDC_COMBO_DEV, m_Combo_Dev);
	DDX_Control(pDX, IDC_CHECK_CMPHQ, m_Check_HQ);
}


BEGIN_MESSAGE_MAP(CDlgAudioSettings, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_AUDIOCAPTUREMODE, OnBnClickedButtonAudiocapturemode)
	ON_BN_CLICKED(IDC_RADIO_COMPRESSION_ON, OnBnClickedRadioCompressionOn)
	ON_BN_CLICKED(IDC_RADIO_COMPRESSION_OFF, OnBnClickedRadioCompressionOff)
	ON_CBN_SELCHANGE(IDC_COMBO_DEV, OnCbnSelchangeComboDev)
	ON_BN_CLICKED(IDC_BUTTON_CHANCVT, OnBnClickedButtonChancvt)
	ON_BN_CLICKED(IDC_CHECK_CMPHQ, OnBnClickedCheckCmphq)
END_MESSAGE_MAP()


void CDlgAudioSettings::OnBnClickedButtonAudiocapturemode()
{
	MMRESULT			mmr;
	ACMFORMATCHOOSE		afc = {0};
	WAVEFORMATEX		wfEnum = {0};
	LPWAVEFORMATEX		pwfCapture;

	pwfCapture		= (LPWAVEFORMATEX) new BYTE[m_dwMaxWFSize];
	ASSERT(pwfCapture);

	CopyMemory(pwfCapture, m_pwfCapture, sizeof(WAVEFORMATEX) + m_pwfCapture->cbSize);

	// Initialize the enum controller wf.
	wfEnum.wFormatTag	= WAVE_FORMAT_PCM;

	afc.cbStruct	= sizeof(ACMFORMATCHOOSE);
	afc.fdwStyle	= ACMFORMATCHOOSE_STYLEF_INITTOWFXSTRUCT;
	afc.hwndOwner	= GetSafeHwnd();
	afc.pwfx		= pwfCapture;
	afc.cbwfx		= sizeof(WAVEFORMATEX);
	afc.pszTitle	= _T("Choose capture format");
	afc.fdwEnum		= ACM_FORMATENUMF_HARDWARE|ACM_FORMATENUMF_INPUT|ACM_FORMATENUMF_WFORMATTAG;
	afc.pwfxEnum	= &wfEnum;

	mmr = acmFormatChoose(&afc);
	if (mmr == MMSYSERR_NOERROR)
	{
		CopyMemory(m_pwfCapture, pwfCapture, sizeof(WAVEFORMATEX) + pwfCapture->cbSize);
		ZeroMemory(m_pwfCompress, m_dwMaxWFSize);	// Remove any previous compression settings.
		m_ChannelParms.Clear();
	}

	Update();

	delete [] pwfCapture;
	
}

BOOL CDlgAudioSettings::OnInitDialog()
{
	UINT		numDevs, i;
	WAVEINCAPS	caps;
	MMRESULT	mmr;

	CDialog::OnInitDialog();

	CWnd*	pParent = GetParent();
	CRect	rect1;

	m_ToolTip.Create(this);

	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_SAMPLESPERSEC),		_T("Shows sample rate"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_BITS),				_T("Shows the # of data bits"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_CHANNELS),			_T("Shows the # of channels"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_AUDIOCAPTUREMODE),	_T("Set the audio capture parameters"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_FORMATTAG),			_T("Shows the compressoror tag"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_FORMAT),			_T("Shows the compressor format"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_COMPRESSION_ON),		_T("Press to set compression"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_COMPRESSION_OFF),	_T("Press to turn compression off."));
	m_ToolTip.AddTool(GetDlgItem(IDOK),							_T("Click to keep settings"));
	m_ToolTip.AddTool(GetDlgItem(IDCANCEL),						_T("Click to exit without keeping settings."));
	m_ToolTip.AddTool(GetDlgItem(IDC_COMBO_DEV),				_T("Choose audio capture input device."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_CHANCVT),			_T("Set channel converter settings."));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_CMPHQ),				_T("Use high quality compression mode. CPU load is increased."));

	pParent->GetWindowRect(rect1);
	//SetWindowPos(&CWnd::wndTop, rect1.left, rect1.bottom, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);

	m_Combo_Dev.ResetContent();

	// Enumerate the audio capture devices on the system and fill out the combo.
	numDevs = waveInGetNumDevs();

	for(i = 0; i < numDevs; i++)
	{
		mmr = waveInGetDevCaps(i, &caps, sizeof(WAVEINCAPS));
		ASSERTMMR;

		m_Combo_Dev.AddString(caps.szPname);		
	}

#ifdef _LITE
	GetDlgItem(IDC_BUTTON_CHANCVT)->EnableWindow(FALSE);
#endif

	Update();

	return TRUE;
}

void CDlgAudioSettings::Update(void)
{
	TCHAR				string[100];
	ACMFORMATDETAILS	formatDetails = {0};
	ACMFORMATTAGDETAILS	formatTagDetails = {0};
	MMRESULT			mmr;
	CString				str;

	_itot_s(m_pwfCapture->nSamplesPerSec, string, sizeof string / sizeof string[0], 10);
	m_Static_SampleRate.SetWindowText(string);
	_itot_s(m_pwfCapture->wBitsPerSample, string, sizeof string / sizeof string[0], 10);
	m_Static_Bits.SetWindowText(string);
	m_Static_Mode.SetWindowText(m_pwfCapture->nChannels == 1 ? _T("Mono"):_T("Stereo"));

	m_Static_Format.SetWindowText(_T("Compression Off"));
	m_Static_FormatTag.SetWindowText(_T("Compression Off"));

	//m_pwfCompress->wFormatTag = WAVE_FORMAT_ADPCM;
	if (m_pwfCompress->wFormatTag != 0)
	{	// Compression is on. Show the details.
		formatDetails.cbStruct		= sizeof(ACMFORMATDETAILS);
		formatDetails.dwFormatTag	= m_pwfCompress->wFormatTag;
		formatDetails.pwfx			= m_pwfCompress;
		formatDetails.cbwfx			= sizeof(WAVEFORMATEX) + m_pwfCompress->cbSize;

		mmr = acmFormatDetails(NULL, &formatDetails, ACM_FORMATDETAILSF_FORMAT);
		ASSERTMMR;

		str = formatDetails.szFormat;
		m_Static_Format.SetWindowText(str);

		formatTagDetails.cbStruct		= sizeof(ACMFORMATTAGDETAILS);
		formatTagDetails.dwFormatTag	= m_pwfCompress->wFormatTag;

		mmr = acmFormatTagDetails(NULL, &formatTagDetails, ACM_FORMATTAGDETAILSF_FORMATTAG);
		ASSERTMMR;

		str = formatTagDetails.szFormatTag;
		m_Static_FormatTag.SetWindowText(str);

		CheckDlgButton(IDC_RADIO_COMPRESSION_ON,	BST_CHECKED);
		CheckDlgButton(IDC_RADIO_COMPRESSION_OFF,	BST_UNCHECKED);
	}
	else
	{
		CheckDlgButton(IDC_RADIO_COMPRESSION_ON,	BST_UNCHECKED);
		CheckDlgButton(IDC_RADIO_COMPRESSION_OFF,	BST_CHECKED);
	}

//TODO	Add indicator to show the channel converter setting.
// hey hey bay bay

	m_Combo_Dev.SetCurSel(m_CaptureDeviceID);

	m_Check_HQ.SetCheck(m_bHQ ? BST_CHECKED:BST_UNCHECKED);

}

void CDlgAudioSettings::OnBnClickedRadioCompressionOn()
{
	MMRESULT			mmr;
	ACMFORMATCHOOSE		afc = {0};
	LPWAVEFORMATEX		pwfCompress, pwfCapture;

	pwfCompress		= (LPWAVEFORMATEX) new BYTE[m_dwMaxWFSize];
	ASSERT(pwfCompress);
	pwfCapture		= (LPWAVEFORMATEX) new BYTE[m_dwMaxWFSize];
	ASSERT(pwfCapture);

	CopyMemory(pwfCompress, m_pwfCompress, sizeof(WAVEFORMATEX) + m_pwfCompress->cbSize);


	if (m_ChannelParms.m_Mode == Channel_MonoToStereo || m_ChannelParms.m_Mode == Channel_StereoToMono)
		m_ChannelParms.ConvertFormat(pwfCapture, m_pwfCapture);
	else
		CopyMemory(pwfCapture, m_pwfCapture, sizeof(WAVEFORMATEX) + m_pwfCompress->cbSize);

	afc.cbStruct	= sizeof(ACMFORMATCHOOSE);
	afc.fdwStyle	= ACMFORMATCHOOSE_STYLEF_INITTOWFXSTRUCT|ACMFORMATCHOOSE_STYLEF_ENABLEHOOK;
	afc.hwndOwner	= GetSafeHwnd();
	afc.pwfx		= pwfCompress;
	afc.cbwfx		= m_dwMaxWFSize;
	afc.pszTitle	= _T("Choose compression format");
	afc.fdwEnum		= ACM_FORMATENUMF_CONVERT;
	afc.pwfxEnum	= pwfCapture;
	afc.pfnHook		= (ACMFORMATCHOOSEHOOKPROC) acmFormatChooseHookProc;
	afc.lCustData	= (LPARAM) this;

	mmr = acmFormatChoose(&afc);
	if (mmr == MMSYSERR_NOERROR)
	{
		// One more item we need to test before committing this format: Try to open the compressor
		// handle. If that fails (and it will) then we don't have to save the bad format.
		HACMSTREAM hStream = NULL;
		mmr = acmStreamOpen(&hStream, NULL, pwfCapture, pwfCompress, NULL, NULL, 0, m_bHQ ? ACM_STREAMOPENF_NONREALTIME : 0);
		if (mmr == MMSYSERR_NOERROR)
		{
			// Copying this new format makes it available to the caller. Otherwise the caller
			// is stuck using the old format.
			CopyMemory(m_pwfCompress, pwfCompress, sizeof(WAVEFORMATEX) + pwfCompress->cbSize);
			acmStreamClose(hStream, 0);
		}
		else
		{
			CString str;
			str.Format(_T("acmStreamOpen Error 0x%04x: ACM indicates that this combination of capture format and\n") \
				_T("compression format cannot be used. Try another combination or notify tech support."),
				mmr);
			AfxMessageBox(str, MB_OK|MB_ICONERROR);
		}		
	}

	Update();

	delete [] pwfCompress;
	delete [] pwfCapture;
}

// Hook to remove PCM from the list of compression formats.
UINT CALLBACK CDlgAudioSettings::acmFormatChooseHookProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == MM_ACM_FORMATCHOOSE)
	if (wParam == FORMATCHOOSE_FORMATTAG_VERIFY)
	if (lParam == WAVE_FORMAT_PCM)	// Remove PCM from the dropdown list.
		return (UINT) TRUE;

	return FALSE;
}

void CDlgAudioSettings::OnBnClickedRadioCompressionOff()
{
	ZeroMemory(m_pwfCompress, m_dwMaxWFSize);

	Update();
}


void CDlgAudioSettings::OnCbnSelchangeComboDev()
{
	m_CaptureDeviceID = m_Combo_Dev.GetCurSel();
}

void CDlgAudioSettings::OnBnClickedButtonChancvt()
{
#ifndef _LITE

	CDlgChannel dlg(this);
	INT_PTR		result;

	dlg.SetChannelParms(m_ChannelParms);
	dlg.SetWFCap(m_pwfCapture);

	result = dlg.DoModal();
	if (result == IDOK)
	{
		m_ChannelParms = dlg.GetChannelParms();
		ZeroMemory(m_pwfCompress, m_dwMaxWFSize);	// Remove any previous compression settings.
	}

	Update();
#endif
}

BOOL CDlgAudioSettings::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgAudioSettings::OnBnClickedCheckCmphq()
{
	m_bHQ = m_Check_HQ.GetCheck() == BST_CHECKED;
}
