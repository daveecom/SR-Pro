#pragma once
#include <afxwin.h>


// CStaticColor2

class CStaticColor2 : public CWnd
{
	DECLARE_DYNAMIC(CStaticColor2)

public:
	CStaticColor2();
	virtual ~CStaticColor2();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
public:
	virtual void	SetTextColor(COLORREF color1, COLORREF color2, BOOL bRedraw = FALSE);
	virtual void	SetTextColor(COLORREF color, BOOL bRedraw = FALSE);
	virtual void	SetBkColor(COLORREF color1, COLORREF color2, BOOL bRedraw = FALSE);
	virtual void	SetBkColor(COLORREF color, BOOL bRedraw = FALSE);
    virtual void	SetWindowText(LPCTSTR lpszString);
    virtual void	GetWindowText(CString& rString) const;
    virtual void	SetFont(CFont* pFont, BOOL bRedraw = TRUE);
	afx_msg BOOL	OnEraseBkgnd(CDC* pDC);
	afx_msg LRESULT	OnSetFont(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT	OnSetText(WPARAM wParam, LPARAM lParam);

protected:
	virtual void	PreSubclassWindow();

	COLORREF		m_colorBk[2];
	COLORREF		m_colorText[2];
	HFONT			m_hFont;
	CString			m_strWindowText;
	UINT			m_fDrawStyle;
	CBitmap			m_bmMem;
	int m_iBlink;
public:
	afx_msg void OnTimer(UINT nIDEvent);
};

