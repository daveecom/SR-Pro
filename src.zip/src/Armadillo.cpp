#define WINVER 0x0501

#include <afx.h>
#include <tchar.h>
#include <crtdbg.h>
#include "armadillo.h"


Armadillo::Armadillo(void)
	:m_hModule(NULL)
{
	// "ARMACCESS.DLL"
	BYTE libname[]	= {0x90, 0x83, 0x9C, 0x90, 0x92, 0x92, 0x94, 0x82, 0x82, 0xFF, 0x95, 0x9D, 0x9D, 0x00};
	m_Crypt.ConvertStringA((char*) &libname, (char*) &libname);	// Update in place

	// "Warning: This executable is not protected."
	BYTE warningMsg1[] = {0x86, 0xB0, 0xA3, 0xBF, 0xB8, 0xBF, 0xB6, 0xEB, 0xF1, 0x85, 0xB9, 0xB8, 0xA2, 0xF1, 0xB4, 0xA9, 0xB4, 0xB2, 0xA4, 0xA5, 0xB0, 0xB3, 0xBD, 0xB4, 0xF1, 0xB8, 0xA2, 0xF1, 0xBF, 0xBE, 0xA5, 0xF1, 0xA1, 0xA3, 0xBE, 0xA5, 0xB4, 0xB2, 0xA5, 0xB4, 0xB5, 0xFF, 0x00};
	// "Software Safety Issue"
	BYTE warningMsg2[] = {0x82, 0xBE, 0xB7, 0xA5, 0xA6, 0xB0, 0xA3, 0xB4, 0xF1, 0x82, 0xB0, 0xB7, 0xB4, 0xA5, 0xA8, 0xF1, 0x98, 0xA2, 0xA2, 0xA4, 0xB4, 0x00};

	m_hModule = LoadLibraryA((LPCSTR) libname);
	m_hModule = HMODULE(((DWORD_PTR) m_hModule) & ~0x10000000);
	TRACE(_T("LoadLibrary returned '%08X'.\r\n"), m_hModule);
	if (m_hModule == NULL)
	{
#ifdef _PROTECTED

		m_Crypt.ConvertStringA((char*) &warningMsg1, (char*) &warningMsg1);	// Update in place
		m_Crypt.ConvertStringA((char*) &warningMsg2, (char*) &warningMsg2);	// Update in place

		MessageBoxA(NULL, (LPCSTR) warningMsg1, (LPCSTR) warningMsg2, MB_ICONINFORMATION|MB_OK);
		exit(10);
#endif
	}
}

Armadillo::~Armadillo(void)
{
	BOOL	rc;

	if (m_hModule != NULL)
	{
		rc = FreeLibrary(m_hModule);
	}
}

bool Armadillo::VerifyKey(const char *name, const char *code)
{
	VerifyKeyFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (VerifyKeyFn) GetProcAddress(m_hModule, "VerifyKey");
		if (pFn != NULL)
			return pFn (name, code);
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::InstallKey(const char *name, const char *code)
{
	InstallKeyFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (InstallKeyFn) GetProcAddress(m_hModule, "InstallKey");
		if (pFn != NULL)
			return pFn (name, code);
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::CheckCode(const char *name, const char *code)
{
	CheckCodeFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (CheckCodeFn) GetProcAddress(m_hModule, "CheckCode");
		if (pFn != NULL)
			return pFn (name, code);
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::InstallKeyLater(const char *name, const char *code)
{
	InstallKeyLaterFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (InstallKeyLaterFn) GetProcAddress(m_hModule, "InstallKeyLater");
		if (pFn != NULL)
			return pFn (name, code);
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::UninstallKey(void)
{
	UninstallKeyFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (UninstallKeyFn) GetProcAddress(m_hModule, "UninstallKey");
		if (pFn != NULL)
			return pFn ();
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::SetDefaultKey(void)
{
	SetDefaultKeyFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (SetDefaultKeyFn) GetProcAddress(m_hModule, "SetDefaultKey");
		if (pFn != NULL)
			return pFn ();
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::UpdateEnvironment(void)
{
	UpdateEnvironmentFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (UpdateEnvironmentFn) GetProcAddress(m_hModule, "UpdateEnvironment");
		if (pFn != NULL)
			return pFn ();
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::IncrementCounter(void)
{
	IncrementCounterFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (IncrementCounterFn) GetProcAddress(m_hModule, "IncrementCounter");
		if (pFn != NULL)
			return pFn ();
		else
			return FALSE;
	}
	else return FALSE;
}

int Armadillo::CopiesRunning(void)
{
	CopiesRunningFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (CopiesRunningFn) GetProcAddress(m_hModule, "CopiesRunning");
		if (pFn != NULL)
			return pFn ();
		else
			return 0;
	}
	else return 0;
}

bool Armadillo::ChangeHardwareLock(void)
{
	ChangeHardwareLockFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (ChangeHardwareLockFn) GetProcAddress(m_hModule, "ChangeHardwareLock");
		if (pFn != NULL)
			return pFn ();
		else
			return FALSE;
	}
	else return FALSE;
}

DWORD Armadillo::GetShellProcessID(void)
{
	GetShellProcessIDFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (GetShellProcessIDFn) GetProcAddress(m_hModule, "GetShellProcessID");
		if (pFn != NULL)
			return pFn ();
		else
			return 0;
	}
	else return 0;
}

bool Armadillo::FixClock(const char *fixclockkey)
{
	FixClockFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (FixClockFn) GetProcAddress(m_hModule, "FixClock");
		if (pFn != NULL)
			return pFn (fixclockkey);
		else
			return FALSE;
	}
	else return FALSE;
}

DWORD Armadillo::RawFingerprintInfo(DWORD item)
{
	RawFingerprintInfoFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (RawFingerprintInfoFn) GetProcAddress(m_hModule, "RawFingerprintInfo");
		if (pFn != NULL)
			return pFn (item);
		else
			return 0;
	}
	else return 0;
}

bool Armadillo::SetUserString(int which, const char *string)
{
	SetUserStringFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (SetUserStringFn) GetProcAddress(m_hModule, "SetUserString");
		if (pFn != NULL)
			return pFn (which, string);
		else
			return FALSE;
	}
	else return FALSE;
}

DWORD Armadillo::GetUserString(int which, char *buffer, DWORD bufferlength)
{
	GetUserStringFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (GetUserStringFn) GetProcAddress(m_hModule, "GetUserString");
		if (pFn != NULL)
			return pFn (which, buffer, bufferlength);
		else
			return 0;
	}
	else return 0;
}

bool Armadillo::WriteHardwareChangeLog(const char *filename)
{
	WriteHardwareChangeLogFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (WriteHardwareChangeLogFn) GetProcAddress(m_hModule, "WriteHardwareChangeLog");
		if (pFn != NULL)
			return pFn (filename);
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::ConnectedToServer(void)
{
	ConnectedToServerFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (ConnectedToServerFn) GetProcAddress(m_hModule, "ConnectedToServer");
		if (pFn != NULL)
			return pFn ();
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::CallBuyNowURL(HWND parent)
{
	CallBuyNowURLFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (CallBuyNowURLFn) GetProcAddress(m_hModule, "CallBuyNowURL");
		if (pFn != NULL)
			return pFn (parent);
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::CallCustomerServiceURL(HWND parent)
{
	CallCustomerServiceURLFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (CallCustomerServiceURLFn) GetProcAddress(m_hModule, "CallCustomerServiceURL");
		if (pFn != NULL)
			return pFn (parent);
		else
			return FALSE;
	}
	else return FALSE;
}

void Armadillo::ShowReminderMessage(HWND parent)
{
	ShowReminderMessageFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (ShowReminderMessageFn) GetProcAddress(m_hModule, "ShowReminderMessage");
		if (pFn != NULL)
			pFn (parent);
	}
}

void Armadillo::ShowReminderMessage2(HWND parent)
{
	ShowReminderMessage2Fn pFn;

	if (m_hModule != NULL)
	{
		pFn = (ShowReminderMessage2Fn) GetProcAddress(m_hModule, "ShowReminderMessage2");
		if (pFn != NULL)
			pFn (parent);
	}
}

bool Armadillo::ExpireCurrentKey(void)
{
	ExpireCurrentKeyFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (ExpireCurrentKeyFn) GetProcAddress(m_hModule, "ExpireCurrentKey");
		if (pFn != NULL)
			return pFn ();
		else
			return FALSE;
	}
	else return FALSE;
}

bool Armadillo::ShowEnterKeyDialog(HWND parent)
{
	ShowEnterKeyDialogFn pFn;

	if (m_hModule != NULL)
	{
		pFn = (ShowEnterKeyDialogFn) GetProcAddress(m_hModule, "ShowEnterKeyDialog");
		if (pFn != NULL)
			return pFn (parent);
		else
			return FALSE;
	}
	else return FALSE;
}


bool Armadillo::IsProtected(void)
{
	return (m_hModule != NULL);
}
