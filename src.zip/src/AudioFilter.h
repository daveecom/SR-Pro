#pragma once

/***************************************************************
CAudioFilter: The building block of the entire audio chain.

Filter States:

	- Ready

		Buffers are accepted, processed and passed downstream.

	- Flushing

		If Receive is called the new data is ignored. Receive has to return FALSE
		to make sure the sender knows the buffer wasn't accepted.

		When the work queue is exhausted, signal the Flush function so it can
		call the downstream's Flush function.

		The Flush function blocks until all downstream work is flushed.

	- Shutting Down

		Incoming buffers are rejected at the receive point.

		All queued buffers are returned to their allocators without
		being processed.

		Flag is set (or signalled) when all queued buffers are returned and all
		locally allocated buffers are deallocated.
		
		Allways flush before shutting down. Then it won't be necessary to wait for buffers
		to come back from the downstream filters.
		
		After all buffers are deallocated, exit the worker thread.
		
***************************************************************/

//#define IsEven(x)       ((x % 2) == 0)		// true if even number
//#define IsOdd(x)        ((x % 2) != 0)		// true if odd number
//#define HINIBBLE(x)     ((UCHAR) ((x >> 4) & 0x0000000fL))      // return hi nibble of input x
//#define LONIBBLE(x)     ((UCHAR) (x & 0x0000000fL))             // return lo nibble of input x
//#define BCD2BIN(x)      ((HINIBBLE(x) * 10) + (LONIBBLE(x)))
//#define BIN2BCD(x)      ((((x % 100) / 10) << 4) + (x % 10))    // convert binary byte to 2 nibble bcd

//#define MAX_ALLOC_COUNT	200

class CAudioFilter;
typedef struct _recbuff				// define the Audio data buffer...which is our wrapper
{									// around the WAVEHDR block.
	DWORD			dataSize;		// Allocated size of the data area (total size - RECBUFF size)
	FILETIME		ftTime;         // This field is stamped at the moment when the buffer is returned frm drvr
	ULONGLONG		nSample;        // Sample number of 1st sample in buffer
	WAVEHDR         wavehdr;        // This is the WAVEHDR passed to waveinAddBuffer
	CAudioFilter*	pAllocator;		// Access to the object that created the RECBUFF
	FILETIME		ftAlloc;		// Allocation time (local FILETIME)
	FILETIME		ftLastUsed;		// Time that this buffer was last reused.
	BOOL			bFirstBuffer;	// This buffer is the first in the stream.
	BOOL			bLastBuffer;	// This buffer is the last in the stream.

	BYTE			databuffer[1];	// Sample data gets stored here. (must be LAST member variable)
}   RECBUFF;

// The helper fills in these fields by scanning the newly arrived data buffers.
typedef struct _scan_info
{
	// for drawing envelopes, VU meters, etc.
	SHORT	wLowLeft;		// Lowest value in buffer left (mono)
	SHORT	wLowRight;		// " right
	SHORT	wHighLeft;		// Highest value in buffer left (mono)
	SHORT	wHighRight;		// " right

	// used by DC offset calibration
	SHORT	nAvgLeft;		// The average left (mono) value
	SHORT	nAvgRight;		// The average right value
	
	// Flags
	BOOL	bStereo;		// The data is stereo

}	SCAN_INFO;

typedef enum _filter_state
{
	Ready = 0,			// Operational state
	Flushing,			// In flushing state
	ShuttingDown		// Object in shutdown state
}	FILTER_STATE;

typedef CTypedPtrList<CPtrList, RECBUFF *> AUDIO_QUEUE;

// Universal sample union.
typedef union _uSample
{
	BYTE	b[4];	// byte access
	SHORT	s[2];	// short access
	DWORD	dw;		// dw access
}	USAMPLE;

class	CAudioRecorder;

class CAudioFilter : public CObject
{
	DECLARE_DYNAMIC(CAudioFilter)

public:

	CAudioFilter(CAudioRecorder* pParent);
	virtual ~CAudioFilter(void);

	virtual BOOL				Receive(RECBUFF * pRB, BOOL bGive = FALSE);	// Called by upstream to add data to the queue.
	virtual BOOL				SetFormat(LPWAVEFORMATEX lpWF);	// Informs us of the current data format.
	virtual BOOL				IsFormatSet();	// TRUE after SetFormat is called.
	virtual void				Shutdown();		// Shut down the worker thread. Block until the worker closes.
	virtual void				Flush();		// Tells this object to stop accepting new input.
	virtual void				EndFlush();		// Used to start the flow of data after a flush op.
	virtual RECBUFF*			AllocRecbuff(DWORD dwDataSize = 0);
	virtual void				FreeRecbuff(RECBUFF* pRB);
	virtual BOOL				Connect(CAudioFilter* pFilter);
	virtual BOOL				StartStreaming();
	virtual BOOL				StopStreaming();
	virtual void				Disconnect(void);
	virtual void				SetPause(BOOL bPause);
	virtual CAudioFilter*		GetNextFilter(void);
	virtual void				SetMaxAllocCount(DWORD dwMax);
	DWORD						GetSampleRate(void);
	virtual void				Dump(void);
	virtual DWORD				GetBufferTimeMS(void);
	virtual DWORD				GetBufferTimeMeasuredMS(void);
	virtual void				GetScanInfo(SCAN_INFO* lpScanInfo);
	static SHORT				_8To16(BYTE In);
	static BYTE					_16To8(SHORT In);
	virtual void				ResetDroppedBufferCount(void);
	virtual DWORD				GetDroppedBufferCount(void);
	int							GetAllocatedBufferCount(void);
	FILETIME					GetTime(void);
	virtual						LPCTSTR GetObjectName(void);

protected:

	virtual	void				SetFilterState(FILTER_STATE eState);
	virtual void				WorkerProc();	// Worker thread processor
	static unsigned int __stdcall WorkerProc(void * arg);	// Worker thread starter.
	virtual void				ProcessDataBuffer(RECBUFF* pRB);
	virtual	BOOL				OnNewFormat();	// Called automatically when the format is set.
	virtual BOOL				OnPreForward(RECBUFF* pRB);	// Called during Receive before forwarded downstream.
	virtual void				PurgeBuffers(void);	// Returns storage of all buffers.
	virtual void				Transmit(RECBUFF * pRB, BOOL bGive = TRUE);
	virtual void				ScanTheBuffer(LPWAVEHDR lpWH, LPWAVEFORMATEX lpWF);
	virtual BOOL				AddByte(const BYTE Value, const DWORD dwSampleIndex, const RECBUFF* pRB);
	virtual UFT					GetTimeOfThisSample(const DWORD SampleIndex, const RECBUFF* pRB);
	virtual void				FlushOutputBuffer(void);
	virtual BOOL				OnPreQueueScan(void);
	virtual void				OnPostQueueScan(void);
	virtual BOOL				OnWorkerFlushComplete(void);

	int							GetBitsPerSample();
	BOOL						IsStereo();
	BOOL						Is8Bit();
	BOOL						IsPaused();

	FILTER_STATE		m_State;			// Current state of this filter.
	CSection			m_csState;			// Lock the state during changes and interrogations.

	BOOL				m_bPaused;			// Filter is paused (ignoring incoming data).

	AUDIO_QUEUE			m_Queue;			// The incoming data queue. Dequeued by worker.
	CSection			m_csQueue;			// Protects the data queue

	LPWAVEFORMATEX		m_pFormat;			// The current data format. Must be set before data can be precessed.
	HANDLE				m_hThread;			// The worker thread.
	HANDLE				m_hEventFlushSync;	// To signal that the worker has an empty queue during flushing state.
	HANDLE				m_hEventWakeWorker;	// To wake the worker after queueing commands or data.
	HANDLE				m_hEventSyncBuffersReturned;	// Signalled when all our own buffers are deallocated.
	DWORD				m_nRBAllocCount;	// # RECBUFFs allocated here.
	CSection			m_csRBAllocCount;	// Protect the integrity of the count
	CAudioFilter*		m_pNextFilter;		// Next stage downstream filter.
	RECBUFF*			m_pOutputBuffer;	// Used to buffer output bytes.
	CSection			m_csOBufferLock;	// Access to m_pOutputBuffer.
	DWORD				m_dwMaxAllocCount;	// Limit of buffers than can be allocated per filter.
	double				m_fTimePerBuffer;	// Default buffer duration. 1 = one second.
	CString				m_strObjectName;	// Our highest derived class name for debug messages
	CAudioRecorder*		m_pParent;			// Access to the parent object.
	DWORD				m_timePerBuffer;	// # ms per buffer calculated from framerate
	DWORD				m_timeMeasured;		// Actual time per buffer in ms.
	SCAN_INFO			m_scanInfo;
	CSection			m_csInfo;
	DWORD				m_dwDroppedBuffers;
};
