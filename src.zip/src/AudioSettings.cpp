// AudioSettings.cpp: implementation of the CAudioSettings class.
//
//////////////////////////////////////////////////////////////////////

#include "StdAfx.h"

#include "audiosettings.h"
#include ".\audiosettings.h"

IMPLEMENT_SERIAL(CAudioSettings, CObject, 0)

CAudioSettings::CAudioSettings()
: m_lpwfCapture(NULL)
, m_lpwfCompress(NULL)
, m_dwWFMaxSize(0)
, m_AudioRecID(0)
, m_AudioPlayID(0)
, m_pDlg(NULL)
{
	TF;		// Trace this function
	MMRESULT rc;

	if (m_pDlg == NULL)
	{
		m_pDlg = new CDlgAudioSettings(this);
	}

	ZeroMemory(&m_cmpDriverDetails, sizeof(ACMDRIVERDETAILS));
	ZeroMemory(&m_waveincaps, sizeof(WAVEINCAPS));

	// Get vital driver info for the audio adapter and the ACM driver.
	rc = acmMetrics(NULL, ACM_METRIC_MAX_SIZE_FORMAT, &m_dwWFMaxSize);
	if (rc != MMSYSERR_NOERROR)
	{
		AfxMessageBox(_T("Fatal Error: Unable to obtain compression metrics.\
			\nMissing hardware is suspected.\n"), MB_OK|MB_ICONERROR);
		ASSERT(0);
	}

	m_nNumDevsIn = waveInGetNumDevs();

    rc = waveInGetDevCaps(m_AudioRecID, &m_waveincaps, sizeof m_waveincaps);

///////////////////////////////////////////
//	rc = MMSYSERR_ALLOCATED;	// Remove after testing error msg.
///////////////////////////////////////////

	if (rc != MMSYSERR_NOERROR)
	{
		CString str, strError;
		switch (rc)
		{
			case MMSYSERR_BADDEVICEID:
				strError = _T("MMSYSERR_BADDEVICEID");
				break;

			case MMSYSERR_NODRIVER:
				strError = _T("MMSYSERR_NODRIVER");
				break;

			case MMSYSERR_NOMEM:
				strError = _T("MMSYSERR_NOMEM");
				break;

			default:
				strError.Format(_T("Unknown-code: '%d'"), rc);
		}

		str.Format(_T("Fatal Error: Unable to obtain audio device capabilities.\r\n") \
			_T("WaveIn Audio Device = %d. NumDevs: = %d.\r\n") \
			_T("waveInGetDevCaps function returned: %s."),
			m_AudioRecID, m_nNumDevsIn, strError);

		AfxMessageBox((str), MB_OK|MB_ICONERROR);
	}

	m_lpwfCapture = (LPWAVEFORMATEX) new BYTE[m_dwWFMaxSize];
	if (m_lpwfCapture == NULL)
	{
		ASSERT(0);	// heap?
	}

	SetDefaults();

}

CAudioSettings::~CAudioSettings()
{
	TF;		// Trace this function

	if (m_lpwfCapture	!= NULL) delete m_lpwfCapture;
	if (m_lpwfCompress	!= NULL) delete m_lpwfCompress;
	if (m_pDlg			!= NULL) delete m_pDlg;
}

void CAudioSettings::SetCaptureFormat(LPWAVEFORMATEX lpWFCap)
{
	TF;		// Trace this function

	*m_lpwfCapture = *lpWFCap;	// Make it global.
}

void CAudioSettings::SetCompressionFormat(LPWAVEFORMATEX lpWFComp)
{
	TF;		// Trace this function

	*m_lpwfCompress = *lpWFComp;	// Make it global.
}

void CAudioSettings::operator =(CAudioSettings& AudioSettngs)
{
	TF;		// Trace this function

	*m_lpwfCapture		= *AudioSettngs.m_lpwfCapture;
	*m_lpwfCompress		= *AudioSettngs.m_lpwfCompress;
	m_AudioRecID		= AudioSettngs.m_AudioRecID;
}

// Note: The archived version of the m_dwWFMaxSize value is only used to read the archived
// compression WAVEFORMATEX. Once read, the archived size is no longer needed. The more current
// version set in the constructor will be observed.
void CAudioSettings::Serialize(CArchive& ar)
{
	TF;		// Trace this function

	DWORD	dwWFMaxSizeLocal;

	if (ar.IsStoring())
	{	// storing
		m_ChannelParms.Serialize(ar);

		ar << m_AudioRecID;
		ar << m_dwWFMaxSize;		// This can change from system to system.
		ar << m_bHQ;		// Use HQ Compression

		ar.Write(m_lpwfCapture,		sizeof(WAVEFORMATEX));
		ar.Write(m_lpwfCompress,	m_dwWFMaxSize);
	}
	else
	{	// loading
		m_ChannelParms.Serialize(ar);

		ar >> m_AudioRecID;
		ar >> dwWFMaxSizeLocal;		// This can change from system to system.
		ar >> m_bHQ;		// Use HQ Compression

		if (dwWFMaxSizeLocal > m_dwWFMaxSize)
		{
			AfxMessageBox(_T("Fatal Error: This profile is not compatible with the current\
				\nsystem. The compression format from the file will be ignored."), MB_OK|MB_ICONERROR);
			return;
		}

		ar.Read(m_lpwfCapture,		sizeof(WAVEFORMATEX));
		ar.Read(m_lpwfCompress,		dwWFMaxSizeLocal);

#ifdef _DEBUG
		AssertValid();
#endif

	}
}

#ifdef _DEBUG

void CAudioSettings::AssertValid() const
{
	//TF;		// Trace this function

	CObject::AssertValid();

	ASSERT(m_dwWFMaxSize > 0);
	ASSERT(m_lpwfCapture	!= NULL);
	ASSERT(m_lpwfCompress	!= NULL);
	//ASSERT(m_cmpDriverDetails.cbStruct > 0);
	ASSERT(m_waveincaps.dwFormats > 0);
}

#endif

void CAudioSettings::SetDefaults(void)
{
	ZeroMemory(m_lpwfCapture, m_dwWFMaxSize);

	{	// Build a default WAVEFORMATEX here.
		m_lpwfCapture->wFormatTag		= WAVE_FORMAT_PCM;
		m_lpwfCapture->nChannels		= 2;				// Stereo
		m_lpwfCapture->nSamplesPerSec	= 8000;
		m_lpwfCapture->wBitsPerSample	= 8;
		m_lpwfCapture->nBlockAlign		= (m_lpwfCapture->wBitsPerSample / 8) * m_lpwfCapture->nChannels;
		m_lpwfCapture->nAvgBytesPerSec	= m_lpwfCapture->nSamplesPerSec * m_lpwfCapture->nBlockAlign;
		m_lpwfCapture->cbSize			= 0;
	}

	if (m_lpwfCompress == NULL)
		m_lpwfCompress = (LPWAVEFORMATEX) new BYTE[m_dwWFMaxSize];
	ZeroMemory(m_lpwfCompress, m_dwWFMaxSize);

	m_bHQ = TRUE;
}


INT_PTR CAudioSettings::DoModal(void)
{
	INT_PTR	rc;

	// Prepare dlg with known values
	CopyMemory(m_pDlg->m_pwfCapture, m_lpwfCapture, sizeof(WAVEFORMATEX) + m_lpwfCapture->cbSize);
	CopyMemory(m_pDlg->m_pwfCompress, m_lpwfCompress, sizeof(WAVEFORMATEX) + m_lpwfCompress->cbSize);

	m_pDlg->m_CaptureDeviceID	= m_AudioRecID;
	m_pDlg->m_ChannelParms		= m_ChannelParms;
	m_pDlg->m_bHQ				= m_bHQ;

	rc = m_pDlg->DoModal();
	if (rc == IDOK)
	{
		CopyMemory(m_lpwfCapture, m_pDlg->m_pwfCapture, sizeof(WAVEFORMATEX) + m_pDlg->m_pwfCapture->cbSize);
		CopyMemory(m_lpwfCompress, m_pDlg->m_pwfCompress, sizeof(WAVEFORMATEX) + m_pDlg->m_pwfCompress->cbSize);

		m_AudioRecID		= m_pDlg->m_CaptureDeviceID;
		m_ChannelParms		= m_pDlg->m_ChannelParms;
		m_bHQ				= m_pDlg->m_bHQ;
	}

	return rc;
}

BOOL CAudioSettings::IsStereoCap(void)
{
	return m_lpwfCapture->nChannels == 2;
}

BOOL CAudioSettings::IsChannelConverted(void)
{
	BOOL bIsConverted = FALSE;

	if (m_ChannelParms.m_Mode == Channel_MonoToStereo	||
		m_ChannelParms.m_Mode == Channel_StereoToMono	||
		m_ChannelParms.m_Mode == Channel_Swap			||
		m_ChannelParms.m_Mode == Channel_LeftToStereo	||
		m_ChannelParms.m_Mode == Channel_RightToStereo)
						bIsConverted = TRUE;

	if (m_ChannelParms.m_bMuteCh1 || m_ChannelParms.m_bMuteCh2)
		bIsConverted = TRUE;

	return bIsConverted;
}

// If stereo cap or converted to stereo, return TRUE.
BOOL CAudioSettings::IsStereo(void)
{
	BOOL			bIsStereo = FALSE;
	LPWAVEFORMATEX	pFormat = NULL;

	pFormat = (LPWAVEFORMATEX) new BYTE[sizeof(WAVEFORMATEX) + m_lpwfCapture->cbSize];
	ASSERT(pFormat != NULL);

	m_ChannelParms.ConvertFormat(pFormat, m_lpwfCapture);
	bIsStereo = pFormat->nChannels == 2;

	delete [] pFormat;

	return bIsStereo;
}
