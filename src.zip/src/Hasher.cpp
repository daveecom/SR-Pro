// Hasher.cpp : implementation file
//

#include "stdafx.h"
#include ".\hasher.h"


// CHasher

CHasher::CHasher()
: m_bCarry(FALSE)
, m_strOut(_T(""))
{
	ClearAll();
}

CHasher::~CHasher()
{
}

//#pragma optimize( "2tgiy", on )
//#pragma check_stack(off)
//#pragma runtime_checks( "s", off)


// Shift the hash accumulator n bits
void CHasher::Shift(int nCount)
{
	int			i, j;
	DWORD		work;
	BOOL		bCarry;

	for (j = 0; j < nCount; j++)
	{
		// Compute the carry flag here.
		bCarry	= ComputeCarry(m_bCarry);

		// Shift the new carry flag into the register.
		for (i = 0; i < PATTERN_SIZE_DWORDS; i++)
		{
			work = m_Pattern.dw[i];

			__asm
			{
				mov		ebx,	bCarry
				or		ebx,	ebx
				jz		ClearIt		// clear carry

				stc
				jmp		ClearIt2	// else set carry
	ClearIt:
				clc
	ClearIt2:

				mov		eax,	work
				rcl		eax,	1
				mov		work,	eax

				// Store carry flag back into the BOOLEAN
				mov		bCarry,	0	// Assume clear
				jnc		Done
				mov		bCarry,	1	// No, carry is set.
	Done:
			}	// _asm

			m_Pattern.dw[i] = work;
		}	// for (i = 0; i < PATTERN_SIZE_DWORDS; i++)

		m_bCarry = bCarry;	// save carry for next shift operation
	}
}

BOOL CHasher::ComputeCarry(BOOL bCarryIn)
{
	BOOL	bWork = (bCarryIn != 0) ? 1:0;

	bWork ^= ((m_Pattern.b[0]	>> 4) & 1);
	bWork ^= ((m_Pattern.b[1]	>> 1) & 1);
	bWork ^= ((m_Pattern.b[2]	>> 7) & 1);
	bWork ^= ((m_Pattern.b[3]	>> 5) & 1);

	bWork ^= ((m_Pattern.b[4]	>> 2) & 1);
	bWork ^= ((m_Pattern.b[5]	>> 5) & 1);
	bWork ^= ((m_Pattern.b[6]	>> 3) & 1);
	bWork ^= ((m_Pattern.b[7]	>> 2) & 1);

	bWork ^= ((m_Pattern.b[8]	>> 0) & 1);
	bWork ^= ((m_Pattern.b[9]	>> 0) & 1);
	bWork ^= ((m_Pattern.b[10] 	>> 4) & 1);
	bWork ^= ((m_Pattern.b[11] 	>> 7) & 1);

	bWork ^= ((m_Pattern.b[12] 	>> 5) & 1);
	bWork ^= ((m_Pattern.b[13] 	>> 7) & 1);
	bWork ^= ((m_Pattern.b[14] 	>> 0) & 1);
	bWork ^= ((m_Pattern.b[15] 	>> 1) & 1);

	bWork ^= ((m_Pattern.b[16] 	>> 2) & 1);
	bWork ^= ((m_Pattern.b[17] 	>> 7) & 1);
	bWork ^= ((m_Pattern.b[18] 	>> 3) & 1);
	bWork ^= ((m_Pattern.b[19] 	>> 4) & 1);

	bWork ^= ((m_Pattern.b[20] 	>> 3) & 1);

	return (bWork == 0);
}

void CHasher::LoadKey(LPCTSTR lpszKeyIn)
{
	CString		strKeyIn = lpszKeyIn;
	CStringA	strKeyInChars = strKeyIn;	// Convert unicode to bytes if necessary
	LPBYTE		pBuffer;
	DWORD		nBufferSizeBytes = strKeyInChars.GetLength();

	pBuffer		= new BYTE[nBufferSizeBytes + 1];
	ZeroMemory(pBuffer, nBufferSizeBytes + 1);
	strncpy((char *) pBuffer, strKeyInChars, nBufferSizeBytes);
	LoadKey(pBuffer, nBufferSizeBytes);
	delete [] pBuffer;
}

void CHasher::LoadKey(LPBYTE lpKeyIn, int nSize)
{
	int		i, j;
	BYTE	keyByte;	// Holds input key one byte at a time.
	BOOL	bKeyBit;	// Used to store bits from key byte as we rotate it

	for (i = 0; i < nSize; i++)
	{

		keyByte = *(lpKeyIn+i);

		for (j = 0; j < 8; j++)
		{
			bKeyBit = ((keyByte >> (7-j)) & 0x01) != 0;
			m_bCarry = ((m_bCarry ? 1:0) ^ (bKeyBit ? 1:0)) != 0;
			Shift(1);
		}
	}
}


void CHasher::ClearAll(void)
{
	ZeroMemory(&m_Pattern, sizeof(m_Pattern));
	m_bCarry = FALSE;
}

LPCTSTR CHasher::GetBufferAsHexString(void)
{
	CString	str;

	m_strOut.Empty();

	for (int i = 0; i < sizeof(m_Pattern); i++)
	{
		str.Format(_T("%02X"), (BYTE) m_Pattern.b[i]);
		m_strOut += str;
	}

	return m_strOut;
}

LPCTSTR CHasher::GetBufferAsHexStringWithBlanks(void)
{
	CString	str;

	m_strOut.Empty();

	for (int i = 0; i < sizeof(m_Pattern); i++)
	{
		str.Format(_T("%02X"), (BYTE) m_Pattern.b[i]);
		m_strOut += str;
		if (i < (sizeof(m_Pattern)-1))
			m_strOut += _T(" ");
	}

	return m_strOut;
}
