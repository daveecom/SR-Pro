#include "StdAfx.h"
#include ".\myfile.h"

CMyFile::CMyFile(void)
{
}

CMyFile::~CMyFile(void)
{
}

LPCTSTR CMyFile::GetLine(void)
{
	CStringA	strLineA;
	BYTE		byteFromFile = 0;;
	UINT		nRead;

	ASSERT(m_hFile != NULL);

	for (;;)
	{
		nRead = Read(&byteFromFile, 1);
		if (nRead == 0)
		{	// End of file reached.
			break;
		}

		if (byteFromFile >= 0x20 && byteFromFile <= 0x7E)
			strLineA += byteFromFile;	// Append character if visible

		if (byteFromFile == 0x0A)	// If end of line
		{
			break;
		}
	}

	m_strLine = strLineA;	// Convert from char to THAR.

	return m_strLine;
}

// nItems must be # items in your empty CString array.
// returns # of tokens read from input string.
int CMyFile::GetRecord(LPCTSTR lpszInput, CString* lpstrToken, int nItems)
{
	int			cTokens = 0;
	CString		strInput, strToken;
	int			index;	// Keeps track of scan position.
	int			len;	// # of chars in input line

	len = (int) _tcslen(lpszInput);

	if (len > 0)
	{	// Parse the input
		strInput = lpszInput;

		// Scan string until eol reached.
		for (index = 0, cTokens = 0; index < len;)
		{
			int	i = strInput.Find(',', index);
			if (i == -1)
			{	// No more commas found
				strToken = strInput.Mid(index, len-index);

				if (cTokens >= nItems) break;	// Array count exceeded.
				
				lpstrToken[cTokens++] = strToken;
				break;
			}
			if (i > 0)
			{
				strToken = strInput.Mid(index, i - index);
				index = i+1;	// 1st char past comma

				if (cTokens >= nItems) break;	// Array count exceeded.
				
				lpstrToken[cTokens++] = strToken;
			}
		}
	}

	return cTokens;
}
