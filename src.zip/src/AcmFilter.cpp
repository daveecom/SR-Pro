#include "StdAfx.h"
#include "audiofilter.h"
#include ".\acmfilter.h"

CAcmFilter::CAcmFilter(CAudioRecorder* pParent)
: CAudioFilter(pParent)
, m_pFormatC(NULL)
, m_hStream(NULL)
, m_nBufferSizeIn(0)
, m_nBufferSizeOut(0)
, m_bCompressorHasData(FALSE)
, m_bHQ(TRUE)
{
	TF;

	m_strObjectName = _T("CAcmFilter");

	ZeroMemory(&m_Header, sizeof(ACMSTREAMHEADER));
}

CAcmFilter::~CAcmFilter(void)
{
	MMRESULT mmr;

	TF;

	DeleteBuffers();

	if (m_pFormatC != NULL) delete [] m_pFormatC;
	if (m_hStream != NULL)
	{
		mmr = acmStreamClose(m_hStream, 0);
		ASSERTMMR;
		m_hStream = NULL;
	}
}

void CAcmFilter::ProcessDataBuffer(RECBUFF* pRB)
{
	MMRESULT	mmr;	
	DWORD		dwFlags;
	RECBUFF*	pBuffer;	// Output buffer to send.
	DWORD		dwResid = 0;
	BOOL		rc;

	CCS			lock(&m_csBuffers);

	//TF;

	// Set the flags based on stream position.
	dwFlags = ACM_STREAMCONVERTF_BLOCKALIGN;
	if (!m_bCompressorHasData) dwFlags |= ACM_STREAMCONVERTF_START;

	// Allocate new buffers here as new data has arrived the first time
	// since the format was set.
	if (m_Header.pbSrc == NULL)
	{
		rc = InitBuffers(pRB->dataSize);
		ASSERT(rc);
	}

	if (!m_bCompressorHasData) m_Header.cbSrcLength = 0;

	// Copy input data into the conversion input buffer.
	ASSERT((m_nBufferSizeIn - m_Header.cbSrcLength) >= pRB->wavehdr.dwBytesRecorded);	// No room in input buffer.

	if (pRB->wavehdr.dwBytesRecorded > 0)
	{
		CopyMemory((m_Header.pbSrc + m_Header.cbSrcLength), pRB->wavehdr.lpData, pRB->wavehdr.dwBytesRecorded);

		// Prepare the header counts.
		m_Header.cbSrcLength += (DWORD) pRB->wavehdr.dwBytesRecorded;
		m_Header.cbSrcLengthUsed	= 0;
		m_Header.cbDstLengthUsed	= 0;

// ************** TRACE THE COMPRESSION ************* //
		CString		strFlags;
		CString		strBefore;
		CString		strAfter;

		if (dwFlags & ACM_STREAMCONVERTF_START)			strFlags += _T("START ");
		if (dwFlags & ACM_STREAMCONVERTF_BLOCKALIGN)	strFlags += _T("BLOCKALIGN ");
		if (dwFlags & ACM_STREAMCONVERTF_END)			strFlags += _T("END ");
		strFlags = strFlags.Left(strFlags.GetLength()-1);	// Remove trailing blank

		strBefore.Format(_T("In=%05d."),
			m_Header.cbSrcLength);

		// Do the conversion.
		mmr = acmStreamConvert(m_hStream, &m_Header, dwFlags);
		ASSERTMMR;

		strAfter.Format(_T("Out=%05d. Unused=%05d."),
			m_Header.cbDstLengthUsed,
			(m_Header.cbSrcLength - m_Header.cbSrcLengthUsed));

		//TRACE(_T("acmStreamConvert(). %s\t%s\tResult = %08X. Flags=(%s)\r\n"),
		//	strBefore, strAfter, (DWORD) mmr, strFlags);
// ************** TRACE THE COMPRESSION ************* //

		if (mmr == MMSYSERR_NOERROR)
		{
			m_bCompressorHasData = TRUE;

			// If there's output data then queue it to the next filter.
			if (m_Header.cbDstLengthUsed > 0)
			{
				pBuffer = AllocRecbuff(m_Header.cbDstLengthUsed);
				ASSERT(pBuffer != NULL);

				CopyMemory(pBuffer->wavehdr.lpData, m_Header.pbDst, m_Header.cbDstLengthUsed);
				pBuffer->wavehdr.dwBytesRecorded = m_Header.cbDstLengthUsed;

				Transmit(pBuffer);
			}

			// If there's still unconverted residual then pack it into front of buffer.
			dwResid = m_Header.cbSrcLength - m_Header.cbSrcLengthUsed;
			if (dwResid > 0)
			{
				CopyMemory(m_Header.pbSrc, m_Header.pbSrc + m_Header.cbSrcLengthUsed, dwResid);
				m_Header.cbSrcLength	= dwResid;
			}
			else
			{	// No residuel
				m_Header.cbSrcLength = 0;	// Reset input count.
			}

		}	// if (mmr == MMSYSERR_NOERROR)
		else
		{	// Error occurred during the compression.
			TRACE(_T("*** %s::ProcessDataBuffer(): .Error %d occurred during compression.\r\n"),
				GetObjectName(), mmr);
		}

		FreeRecbuff(pRB);	// Return the input buffer.
	}	// if (pRB->wavehdr.dwBytesRecorded > 0)
}

BOOL CAcmFilter::SetFormat(LPWAVEFORMATEX lpWF)
{
	MMRESULT	mmr;
	BOOL		rc;

	// Since the format has changed and we should be flushed now,
	// delete the compression buffers because the format change will
	// require the buffer sizes to be changed.
	DeleteBuffers();

	__super::SetFormat(lpWF);	// Set our format but don't allow propagation.

	// Instead of propagation of the PCM format, we'll propagate the compressed
	// format from this filter downstream.
	ASSERT(m_pFormatC				!= NULL);	// Compression not set.
	ASSERT(m_pFormatC->wFormatTag	!= 0);	// CAudioRecorder::Create shouldn't have specified compression

	// Tell ACM the info it needs to know how to convert subsequent data.
	if (m_hStream != NULL)
	{
		mmr = acmStreamClose(m_hStream, 0);
		ASSERTMMR;
		m_hStream = NULL;
	}

	mmr = acmStreamOpen(&m_hStream, NULL, m_pFormat, m_pFormatC, NULL, 0, 0, m_bHQ ? ACM_STREAMOPENF_NONREALTIME : 0);
	if (mmr != MMSYSERR_NOERROR)
	{
		//ASSERT(0); // ACMERR_NOTPOSSIBLE ?
		CString str;
		str.Format(_T("Error 0x%08x from acmStreamOpen"), mmr);
		AfxMessageBox(str, MB_OK|MB_ICONERROR);
		rc = FALSE;
	}
	else
		rc = TRUE;

	// Propagation of the compression format.
	if (rc)
	{
		if (m_pFormatC != NULL)
		if (m_pFormatC->wFormatTag != 0)
		{	// If compression then send the comp format downstream to the file writer.
			//CCS Lock(&m_csNextFilter);

			if (GetNextFilter() != NULL)
				rc = GetNextFilter()->SetFormat(m_pFormatC);
		}
	}

	return rc;
}

// Prevent automatic format propagation so we can do it ourselves
// in CAcmFilter::SetFormat.
BOOL CAcmFilter::OnNewFormat()
{

	return FALSE;
}

// Modified to allow a compression format to be specified
BOOL CAcmFilter::SetFormatC(LPWAVEFORMATEX pWFC, BOOL bUseHQ)
{
	BOOL	rc = TRUE;

	m_bHQ = bUseHQ;

	if (m_pFormatC != NULL) delete [] m_pFormatC;
	m_pFormatC = (LPWAVEFORMATEX) new BYTE[sizeof(WAVEFORMATEX) + pWFC->cbSize];
	ASSERT(m_pFormatC != NULL);
	CopyMemory(m_pFormatC, pWFC, sizeof(WAVEFORMATEX) + pWFC->cbSize);

	if (m_pFormatC->wFormatTag != 0)
	{	// If compression then send the comp format downstream to the file writer.
		//CCS Lock(&m_csNextFilter);

		if (GetNextFilter() != NULL)
			rc = GetNextFilter()->SetFormat(m_pFormatC);
	}

	return rc;
}

BOOL CAcmFilter::Connect(CAudioFilter* pFilter)
{
	BOOL	rc;

	//CCS	Lock(&m_csNextFilter);

	//TF;

	ASSERT(GetNextFilter() == NULL);
	ASSERT(pFilter != NULL);
	ASSERT(m_pFormatC != NULL);

	m_pNextFilter = pFilter;
	rc = m_pNextFilter->SetFormat(m_pFormatC);

	return rc;
}

BOOL CAcmFilter::StartStreaming()
{
	return __super::StartStreaming();
}

BOOL CAcmFilter::StopStreaming()
{
	return __super::StopStreaming();
}

BOOL CAcmFilter::InitBuffers(DWORD dwSizeIn)
{
	MMRESULT	mmr;
	DWORD		dwSizeOut = 0;

	CCS			lock(&m_csBuffers);

	//TF;

	ASSERT(dwSizeIn > 0);

	DeleteBuffers();

	m_nBufferSizeIn = dwSizeIn * 2;	// Input has double the room for one RECBUFF
	//m_nBufferSizeOut = m_nBufferSizeIn;
	mmr	= acmStreamSize(m_hStream, m_nBufferSizeIn, &m_nBufferSizeOut, ACM_STREAMSIZEF_SOURCE);
	ASSERTMMR;

	m_nBufferSizeOut += (m_nBufferSizeOut & 0x01);	// Force even size

	ZeroMemory(&m_Header, sizeof(ACMSTREAMHEADER));
	m_Header.cbStruct		= sizeof(ACMSTREAMHEADER);	
	m_Header.cbDstLength	= m_nBufferSizeOut;
	m_Header.cbSrcLength	= m_nBufferSizeIn;
	m_Header.pbSrc			= (LPBYTE) GlobalAlloc(GPTR, m_nBufferSizeIn);
	m_Header.pbDst			= (LPBYTE) GlobalAlloc(GPTR, m_nBufferSizeOut);

	mmr = acmStreamPrepareHeader(m_hStream, &m_Header, 0);
	ASSERTMMR;

	m_Header.cbSrcLength	= 0;

	if (m_Header.fdwStatus & ACMSTREAMHEADER_STATUSF_PREPARED)
	{
		TRACE(_T("**** Compression Buffers Prepared\r\n"));
		return TRUE;
	}
	else
	{
		DeleteBuffers();
		return FALSE;
	}
}

void CAcmFilter::DeleteBuffers(void)
{
	MMRESULT	mmr;

	TF;

	if (m_Header.pbSrc != NULL)
	{
		m_Header.cbDstLength	= m_nBufferSizeOut;	// Reset lengths
		m_Header.cbSrcLength	= m_nBufferSizeIn;

		if (m_Header.fdwStatus & ACMSTREAMHEADER_STATUSF_PREPARED)
		{
			mmr = acmStreamUnprepareHeader(m_hStream, &m_Header, 0);
			ASSERTMMR;
			TRACE(_T("**** Compression Buffers UnPrepared\r\n"));
		}

		GlobalFree(m_Header.pbSrc);
		GlobalFree(m_Header.pbDst);

		ZeroMemory(&m_Header, sizeof(ACMSTREAMHEADER));
	}
}

// Process last compression buffer, Flush the compressor.
BOOL CAcmFilter::OnWorkerFlushComplete(void)
{
	MMRESULT	mmr;
	RECBUFF*	pBuffer = NULL;
	//DWORD		dwFlags = ACM_STREAMCONVERTF_END;
	DWORD		dwFlags = 0;
	//TF;

	if (m_bCompressorHasData)
	{
		// Squeeze the remaining data from the compressor.
		m_Header.cbSrcLengthUsed	= 0;
		m_Header.cbDstLengthUsed	= 0;

// ************** TRACE THE COMPRESSION ************* //
		CString		strFlags;
		CString		strBefore;
		CString		strAfter;

		if (dwFlags & ACM_STREAMCONVERTF_START)			strFlags += _T("START ");
		if (dwFlags & ACM_STREAMCONVERTF_BLOCKALIGN)	strFlags += _T("BLOCKALIGN ");
		if (dwFlags & ACM_STREAMCONVERTF_END)			strFlags += _T("END ");
		strFlags = strFlags.Left(strFlags.GetLength()-1);	// Remove trailing blank

		strBefore.Format(_T("In=%05d."),
			m_Header.cbSrcLength);

		// Do the conversion.
		mmr = acmStreamConvert(m_hStream, &m_Header, dwFlags);
		ASSERTMMR;

		strAfter.Format(_T("Out=%05d. Unused=%05d."),
			m_Header.cbDstLengthUsed,
			(m_Header.cbSrcLength - m_Header.cbSrcLengthUsed));

		//TRACE(_T("acmStreamConvert(). %s\t%s\tResult = %08X. Flags=(%s)\r\n"),
		//	strBefore, strAfter, (DWORD) mmr, strFlags);
// ************** TRACE THE COMPRESSION ************* //

		if (mmr == MMSYSERR_NOERROR)
		{
			// If there's output data then queue it to the next filter.
			if (m_Header.cbDstLengthUsed > 0)
			{
				pBuffer = AllocRecbuff(m_Header.cbDstLength);
				ASSERT(pBuffer != NULL);

				CopyMemory(pBuffer->wavehdr.lpData, m_Header.pbDst, m_Header.cbDstLengthUsed);
				pBuffer->wavehdr.dwBytesRecorded = m_Header.cbDstLengthUsed;

				Transmit(pBuffer);
				//FreeRecbuff(pBuffer);		diagnostic

				m_Header.cbSrcLength = 0;
			}
		}	// if (mmr == MMSYSERR_NOERROR)
		else
		{	// Error occurred during the compression.
			TRACE(_T("*** %s::ProcessDataBuffer(): .Error %d occurred during compression.\r\n"),
				GetObjectName(), mmr);
		}

		acmStreamReset(m_hStream, 0);	// Attempt to solve mpeg 3 VOX problems

		// At this point, the compressor should be "cleansed".
		m_bCompressorHasData = FALSE;
	}

	return TRUE;
}
