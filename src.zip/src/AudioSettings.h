#pragma once

#include "stdafx.h"

#include "audiosettings.h"
#include "dlgaudiosettings.h"

class CDlgAudioSettings;
class CAudioSettings : public CObject
{
public:
	DECLARE_SERIAL(CAudioSettings)

	CAudioSettings();
	virtual ~CAudioSettings();

	void				SetCaptureFormat(LPWAVEFORMATEX lpWFCap);
	void				SetCompressionFormat(LPWAVEFORMATEX lpWFComp);
	void				SetCompressionFlag(BOOL bValue);
	DWORD				GetSampleRate() {return m_lpwfCapture->nSamplesPerSec;};
	void operator		=(CAudioSettings& AudioSettngs);
	virtual void		Serialize(CArchive& ar);
	void				SetDefaults(void);
	INT_PTR				DoModal(void);
	BOOL				IsStereoCap(void);

#ifdef _DEBUG
	virtual void		AssertValid() const;
#endif

	///////////// Persistant vars to be serialized in this order
	int 				m_AudioRecID;		// Selects the input hardware to use for recording.
	int 				m_AudioPlayID;		// Selects the output hardware to use for preview.
	LPWAVEFORMATEX		m_lpwfCapture;		// WAVEFORMATEX to use for audio capture.
	LPWAVEFORMATEX		m_lpwfCompress;		// WAVEFORMATEX to use for audio compression.
											// If the compression format is zeros then
											// compression is disabled.
	DWORD				m_dwWFMaxSize;		// Maximum WAVEFORMATEX size.
	BOOL				m_bHQ;				// Use HQ Compression
	///////////// end of persistant vars

	WAVEINCAPS			m_waveincaps; 		// recording device capabilities
	ACMDRIVERDETAILS	m_cmpDriverDetails;	// Compressor details.
	UINT				m_MixerID;			// Mixer associated with the waveIn dev
	UINT				m_nNumDevsIn;		// # of input devices.

	CDlgAudioSettings*	m_pDlg;
	CHANNEL_PARMS		m_ChannelParms;		// Channel Converter parms
	BOOL				IsChannelConverted(void);
	BOOL				IsStereo(void);
};
