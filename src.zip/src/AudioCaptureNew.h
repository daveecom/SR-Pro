#pragma once
#include "audiofilter.h"
#include "audiosettings.h"

class CAudioCaptureNew :
	public CAudioFilter
{
public:
	CAudioCaptureNew(CAudioRecorder* pParent);
	~CAudioCaptureNew(void);

	virtual BOOL			StartAudioCapture();
	virtual BOOL			StopAudioCapture();
	virtual RECBUFF*		AllocRecbuff(DWORD dwDataSize = 0);
	virtual void			AddRecbuff();
	virtual void			ProcessDataBuffer(RECBUFF* pRB);
	virtual void			RecycleRecbuff(RECBUFF* pRB);
	virtual void			FreeRecbuff(RECBUFF* pRB);
	virtual BOOL			Receive(RECBUFF * pRB, BOOL bGive = FALSE);	// Our own, to fix dumb problems.
	static void CALLBACK	WaveInProc(HWAVE	hWave, UINT  uMsg, DWORD  dwInstance, DWORD  dwParam1, DWORD  dwParam2);
	void					ResetScanInfo(void);
	BOOL					SetFormat(CAudioSettings* pNewSettings);

protected:
	virtual void			Transmit(RECBUFF * pRB);
	//virtual void			WorkerProc();	// Worker thread processor
	//static unsigned int __stdcall WorkerProc(void * arg);	// Worker thread starter.

	CAudioSettings			m_AudSettings;		// This has all audio settings within.
	UINT					m_DevQCnt;			// keeps track of how deep the device queue is
	BOOL					m_bStreamActive;	// True if incoming audio active
	HWAVEIN					m_hWaveIn;			// handle of open audio capture device.
	ULONGLONG				m_nSample;			// Number of samples received on stream.
	BOOL					m_bFirstBuffer;		// TRUE if no buffers have been sent yet on stream.
};
