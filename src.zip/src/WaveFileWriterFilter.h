#pragma once
#include "filewriterfilter.h"

typedef	enum _eCheckpointMode
{
	CHECKPOINT_MODE_OFF,
	CHECKPOINT_MODE_WAIT_IDLE,
	CHECKPOINT_MODE_WAIT_FORCE
} CHECKPOINT_MODE;

class CWaveFileWriterFilter : public CFileWriterFilter
{
public:
	CWaveFileWriterFilter(CAudioRecorder* pParent);
	~CWaveFileWriterFilter(void);

	virtual BOOL		BeginNewFile(void);
	virtual void		CloseFile(void);
	virtual BOOL		SetFormat(LPWAVEFORMATEX lpWF);
	void				SetCheckpointMode(CHECKPOINT_MODE Mode);

protected:
	virtual BOOL			PerformCheckpoint(void);
	virtual BOOL			UpdateHeaders(void);
	virtual void			OnPostQueueScan(void);
	static BOOL __stdcall	AlarmCB_Idle(CAlarmClock* pThis, DWORD_PTR dwUserData);
	static BOOL __stdcall	AlarmCB_Force(CAlarmClock* pThis, DWORD_PTR dwUserData);
	void					ProcessDataBuffer(RECBUFF* pRB);
	void					SetCheckpointAlarmIdle();
	void					SetCheckpointAlarmForce();

	int					m_nHeaderSize;

	CSection			m_csCheckpoint;		// Protects access to the checkpoint flags
	CHECKPOINT_MODE		m_eCheckpointMode;		// Controls checkpoint processing.
	BOOL				m_bCkptInProgress;	// TRUE while checkpointing active
	BOOL				m_bCkptNeeded;		// File data has been written.

	int					m_nFailSafeTime;	// Failsafe time value (R/O).
	int					m_nCkptIdleTime;	// Idle write ckpt time value. (R/O)
	CAlarmClock			m_clockFailsafe;	// Failsafe timer
	CAlarmClock			m_clockIdle;		// Idle timer
	BOOL				m_bCkptTimerIdle;	// Idle timer has been tripped but not serviced yet.
	BOOL				m_bCkptTimerFailsafe;// Failsafe timer has been tripped but not serviced yet.
};
