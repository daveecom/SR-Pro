// Doc.h : interface of the Doc class
//


#pragma once
#include "audiorecorder.h"
#include "audiosettings.h"
#include "filenameserver.h"
#include "filesettings.h"
#include "logfile.h"
#include "comport.h"
#include "scheduler.h"
#include "channelfilter.h"
#include "radiosettings.h"

class Doc : public CDocument
{
	DECLARE_DYNCREATE(Doc)
	//DECLARE_SERIAL(Doc)
	DECLARE_MESSAGE_MAP()

protected:
	Doc();
	virtual ~Doc();

	CAudioRecorder*		m_pRecorder;	// The recorder module.
	CSection			m_csRecorder;	// Serialize access to the recorder.

	afx_msg void		OnUpdateTestDumpfilterstats(CCmdUI *pCmdUI);
	afx_msg void		OnTestDumpfilterstats();

public:

	void				StartAudioEngine(void);
	void				StopAudioEngine(void);
	virtual				BOOL OnOpenDocument(LPCTSTR lpszPathName);
	void				SetDefaultValues(void);
	virtual BOOL		OnNewDocument();
	virtual void		Serialize(CArchive& ar);
	virtual BOOL		SaveModified();
	CAudioRecorder*		GetRecorder(void);

	// Archiveable //////////////
	BOOL				m_bRecord;			// Record switch
	BOOL				m_bPause;			// Pause switch
	BOOL				m_bAutoSaveFile;	// Autosave file if modified.
	BOOL				m_bTimerRecordArmed;	// Timer record mode on/off

	BOOL				m_bVox1;			// Vox on off ch 1
	BOOL				m_bVox2;			// ch 2
	float				m_VoxVal1_L;		// Vox Left value
	float				m_VoxVal1_R;		// Vox Right value
	DWORD				m_dwHang1;			// Hang time for vox

	CString				m_strScheduleFile;	// Where to store schedule.
	CScheduleController	m_Scheduler;

	CAudioSettings		m_AudioSettings;	// Capture and compression WAVEFORMATEXs.

	CFilenameServer		m_FilenameServer1;	// Preserves the active sequence #

	BOOL				m_bGenerateLogFile;	// Enable VOX log file

	CRadioSettings		m_RadioSettings;	// Settings and radio jobs.
	/////////////////////////////

	UFT					m_uRecordStartTime;	// Time record btn was pressed. Or 0.

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CScheduleController* GetScheduler(void);
	void SetRecord(BOOL bRecord);
	DWORD GetDroppedFrames(void);
	int GetAllocatedBufferCount(void);
	void GetScanInfo(SCAN_INFO* pInfo);
	void CheckpointFile(void);
	afx_msg void OnUpdateTestCheckpointfile(CCmdUI *pCmdUI);
	afx_msg void OnTestCheckpointfile();
	void SetPause(BOOL bPause);
	void SetVox(float fValue);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void SetTitle(LPCTSTR lpszTitle);
    virtual void SetModifiedFlag(BOOL bModified = TRUE);
protected:
	CString m_strDocTitle;
};

class CMyDocTemplate :
	public CSingleDocTemplate
{
public:
	CMyDocTemplate(UINT nIDResource, CRuntimeClass* pDocClass, CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass)
	: CSingleDocTemplate(nIDResource, pDocClass, pFrameClass, pViewClass) {}

	~CMyDocTemplate(void) {}

	virtual enum CDocTemplate::Confidence CMyDocTemplate::MatchDocType(LPCTSTR lpszPathName, CDocument*& rpDocMatch)
	{
		rpDocMatch = NULL;
		return yesAttemptForeign;
	}
};

