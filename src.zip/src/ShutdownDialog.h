#pragma once
#include "staticcolor.h"
#include <afxwin.h>
//#include "alarmclock.h"


// CShutdownDialog dialog

class CShutdownDialog : public CDialog
{
	DECLARE_DYNAMIC(CShutdownDialog)

public:
	CShutdownDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CShutdownDialog();

// Dialog Data
	enum { IDD = IDD_DIALOG_SHUTDOWN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	CStaticColor m_Static_Clock;
public:
	virtual BOOL OnInitDialog();
protected:
	virtual void OnCancel();
	//CAlarmClock m_Clock;

	//static BOOL __stdcall AlarmCB(CAlarmClock* pThis, DWORD_PTR dwUserData);
	//afx_msg LRESULT OnAlarm(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnTimer(UINT nIDEvent);
protected:
	int m_nCountdownValue;
	void UpdateClock(void);
	afx_msg void OnClose();
	afx_msg void OnPreventButton();
	afx_msg void OnAllowButton();
	CFont m_Font_Text;
	CFont m_Font_Clock;
	CStaticColor m_Static_Text;
};
