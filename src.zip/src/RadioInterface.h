#pragma once
#include "radiosettings.h"
#include "comport.h"

class CRadioInterface
{
	#define CACHE_SIZE		1024
	#define MAX_CMD_SIZE	256
public:
	CRadioInterface(void);
	~CRadioInterface(void);

	BOOL	ExecuteCmd(CRadioCommand* pCommand, BOOL bForceRead = TRUE);
	BOOL	Create(CRadioSettings* pSettings);
	void	Destroy(void);
	int		GetCacheData(LPBYTE OUT pBuffer, DWORD dwBufferSize, RADIO_CMD eCmd);
	BOOL	ExecuteJob(CRadioSettings* pRadioSettings);
	CRadioSettings*		GetRadioSettings(void);
	void	StartAsyncJob(void);
	void	PurgeReceiver(void);
	void	ClearCache(void);

protected:
	CComPort*			m_pComPort;
	CRadioSettings*		m_pRadioSettings;
	void				InitCache(void);
	void				DestroyCache(void);
	void KillAsyncWorker(void);
	static unsigned __stdcall AsyncWorker(void *arglist);
	void				AsyncWorker(void);

	LPBYTE				m_pCache[RadioCmd_NumCmds];
	int					m_cCacheDataCount[RadioCmd_NumCmds];

	HANDLE				m_hAsyncExecWorker;
	BOOL				m_bAbortExecThread;
};
