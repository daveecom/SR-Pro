#pragma once
#include "audiofilter.h"

typedef enum _channel_mode
{
	Channel_Normal			= 0,
	Channel_MonoToStereo,
	Channel_StereoToMono,
	Channel_Swap,
	Channel_LeftToStereo,
	Channel_RightToStereo
} CHANNEL_MODE;

// The CHANNEL_PARMS defines the channel converter parameters.
class CHANNEL_PARMS : public CObject
{
public:

	DECLARE_SERIAL(CHANNEL_PARMS)

	CHANNEL_PARMS()
	{
		Clear();
	}

	CHANNEL_PARMS(CHANNEL_PARMS& Parms)
	{
		m_Mode		= Parms.m_Mode;
		m_bMuteCh1	= Parms.m_bMuteCh1;
		m_bMuteCh2	= Parms.m_bMuteCh2;
	}

	void operator =(CHANNEL_PARMS Parms)
	{
		m_Mode		= Parms.m_Mode;
		m_bMuteCh1	= Parms.m_bMuteCh1;
		m_bMuteCh2	= Parms.m_bMuteCh2;
	}

	virtual void Serialize(CArchive& ar)
	{
		if (ar.IsStoring())
		{	// storing code
			ar.Write(&m_Mode, sizeof m_Mode);
			ar << m_bMuteCh1;
			ar << m_bMuteCh2;
		}
		else
		{	// loading code
			ar.Read(&m_Mode, sizeof m_Mode);
			ar >> m_bMuteCh1;
			ar >> m_bMuteCh2;
		}
	}

	///////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////

	CHANNEL_MODE	m_Mode;		// Channel converter mode selector
	BOOL			m_bMuteCh1;	// Mute left channel before converter
	BOOL			m_bMuteCh2;	// Mute right channel before converter

	// Copy input format to output, then convert output to channel-converted format.
	void ConvertFormat(LPWAVEFORMATEX lpWFOut, LPWAVEFORMATEX lpWFIn);
	void Clear(void);
};



class CChannelFilter : public CAudioFilter
{
public:

	CChannelFilter(CAudioRecorder* pParent);
	~CChannelFilter(void);

	void			SetChannelParms(CHANNEL_PARMS Parms);
	CHANNEL_PARMS	GetChannelParms(void);
	virtual BOOL	SetFormat(LPWAVEFORMATEX lpWF);	// Informs us of the current data format.

protected:

	virtual BOOL	OnNewFormat(void);
	virtual void	ProcessDataBuffer(RECBUFF* pRB);

	CHANNEL_PARMS	m_ChannelParms;
	LPWAVEFORMATEX	m_pFormatOld;		// The original format saved here.
										// m_pFormat has the new format now.
};
