// MainView.h : interface of the CMainView class
//


#pragma once
#include "afxcmn.h"
#include "progressstatic.h"
#include "resource.h"
#include "afxwin.h"
#include "StaticColor.h"
#include "StaticColor2.h"
#include "ScrollerCtrl.h"
#include "autobutton.h"

class CMainView : public CFormView
{
private:

	void Nanomite(void);

protected: // create from serialization only

	CMainView();
	DECLARE_DYNCREATE(CMainView)
	DECLARE_MESSAGE_MAP()

public:

	enum{ IDD = IDD_SCANRECPRO_PANEL2};

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	afx_msg int			OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual BOOL		Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	static void __cdecl	DelayedRecorderControlProc(PVOID pUser);
	afx_msg void		OnUpdateOptionsChannelconverter(CCmdUI *pCmdUI);
	afx_msg void		OnOptionsChannelconverter();
	virtual				~CMainView();
	void				MoveFocusAwayFromEditBoxes(void);

protected:

	virtual BOOL		PreCreateWindow(CREATESTRUCT& cs);
	virtual void		DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void		OnInitialUpdate(); // called first time after construct
	afx_msg void		OnTimer(UINT nIDEvent);
	void				PixelToDialog(LPRECT lpRect);
	void				DialogToPixel(LPRECT lpRect);
//	afx_msg void		OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	void				Update(void);
	afx_msg void		OnBnClickedButtonRecord();
	afx_msg void		OnBnClickedButtonPause();
	afx_msg void		OnBnClickedButtonVox();
	afx_msg void		OnClose();
	afx_msg LRESULT		OnTimerRecordStart( WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT		OnTimerRecordStop( WPARAM wParam, LPARAM lParam);
	void				UpdateClocks(void);
	void				UpdateVUMeters(void);
	void				UpdateVoxIndicator();
	void				UpdateRecordingIndicator();
	//afx_msg void		OnBnClickedButtonRadiosettings();
	afx_msg void		OnBnClickedButtonTimerrec();
	afx_msg BOOL		OnEraseBkgnd(CDC* pDC);
	afx_msg void		OnUpdateOptionsFilesettings(CCmdUI *pCmdUI);
	afx_msg void		OnOptionsFilesettings();
	afx_msg void		OnUpdateOptionsAudiosettings(CCmdUI *pCmdUI);
	afx_msg void		OnOptionsAudiosettings();
	//afx_msg void		OnUpdateOptionsRadiosettings(CCmdUI *pCmdUI);
	afx_msg void		OnOptionsRadiosettings();
	afx_msg void		OnUpdateOptionsMisc(CCmdUI *pCmdUI);
	afx_msg void		OnOptionsMisc();
	afx_msg void		OnUpdateOptionsSchedules(CCmdUI *pCmdUI);
	afx_msg void		OnOptionsSchedules();
	afx_msg void		OnBnClickedButtonRollover();
	virtual BOOL		PreTranslateMessage(MSG* pMsg);
	afx_msg void		OnEnKillfocusEditHangtime();
	afx_msg void		OnEnKillfocusEditVox1();
	afx_msg void		OnStnClickedStaticTime();
	afx_msg void		OnUpdateButtonRadiosettings(CCmdUI *pCmdUI);
	afx_msg void		OnButtonRadiosettings();

	/////// Controls ///////
	CProgressVU			m_Progress_L;
	CProgressVU			m_Progress_R;

	CStaticColor2		m_Static_FileDuration;
	CStaticColor2		m_Static_EventStart;
	CStaticColor2		m_Static_EventDur;
	CStaticColor2		m_Static_Time;
	CStaticColor2		m_Static_VoxInd;
	CStaticColor2		m_Static_RecStat;
	CStaticColor2		m_Static_StatusArea;

	CEditColor			m_Edit_Vox1;
	CScrollerCtrl		m_ScrollCtrl;
	CStaticColor 		m_StaticGrp_InputLevel;
	CStaticColor 		m_StaticGrp_Clocks;
	CStaticColor 		m_Static_LocalTimeLabel;
	CStaticColor 		m_StaticGrp_ScopeBorder;
	CStaticColor 		m_StaticGrp_Buttons;
	CStaticColor 		m_Static_EventStartLabel;
	CStaticColor 		m_Static_EventDurLabel;
	CStaticColor 		m_Static_RecordedTimeLabel;
	CStaticColor 		m_StaticLbl_VoxPct;
	CAutoButton 		m_Button_Record;
	CAutoButton 		m_Button_Pause;
	CAutoButton 		m_Button_Vox;
	CAutoButton 		m_Button_TimerRec;
	CAutoButton			m_Button_Rollover;
	CEditColor			m_Edit_HangTime;
	CStaticColor2		m_Static_ChannelCVT;
	CStaticColor2		m_Static_Buffers;
	CStaticColor2		m_Static_Dropped;
	CStaticColor		m_StaticLbl_Hangtime;
	CStaticColor		m_StaticLbl_ChCvt;
	CStaticColor		m_StaticLbl_Buffers;
	CStaticColor2		m_Static_Radio1;
	CStaticColor2		m_Static_Radio2;
	CStaticColor2		m_Static_Radio3;
	CStaticColor2		m_Static_Radio4;
	CStaticColor2		m_Static_Radio5;
	CStaticColor2		m_Static_Radio6;
	/////// Controls ///////

	CBitmap				m_bmBk;		// Background bitmap for panel.
	CString				m_strFilenameRootBkp;	// Save static root here during timer mode.
	CFont				m_Font;				// Medium
	CFont				m_Font2;			// Small
	CFont				m_Font_BigClock;	// Big fixed
	COLORREF			m_colorText;
	COLORREF			m_colorBk;
	CToolTipCtrl		m_ToolTip;

	// Define the clock modes
	typedef enum _clockmode
	{
		Clock_Normal	= 0,
		Clock_Elapsed
	}	CLOCKMODE;

	CLOCKMODE			m_eClockMode;
};
