#pragma once



// StringMatcher command target

class CStringMatcher : public CObject
{
public:
	CStringMatcher(LPCTSTR lpszString);
	virtual ~CStringMatcher();
	BOOL	Matches(TCHAR NextChar);

protected:

	int		m_Index;	// Gets bumped every time a match is found.
	CString	m_strMatch;
};

