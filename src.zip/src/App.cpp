// App.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include <conio.h>

#include "ModuleScanner.h"
#include ".\App.h"
#include "MainFrm.h"

#include "Doc.h"
#include "MainView.h"
#include "afxwin.h"
#include "version.h"
#include "textcrypt.h"
#include "dlgenterkey.h"
#include "ShutdownDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// App

BEGIN_MESSAGE_MAP(App, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)

	ON_UPDATE_COMMAND_UI(ID_TEST_CONVERTTEXT, OnUpdateTestConverttext)
	ON_COMMAND(ID_TEST_CONVERTTEXT, OnTestConverttext)

	ON_UPDATE_COMMAND_UI(ID_HELP_ENTERREGISTRATION, OnUpdateHelpEnterregistration)
	ON_COMMAND(ID_HELP_ENTERREGISTRATION, OnHelpEnterregistration)

END_MESSAGE_MAP()

/*extern */PVOID ZZZZ_EndOfModule(void);
//extern "C" void __stdcall BeepTest(void);

// App construction

App::App()
: m_pDoc(NULL)
, m_bShowConsole(FALSE)
{
	//CString	str;
	//CHasher	h;

	//h.ClearAll();
	//h.LoadKey(_T("This is a new key"));
	//h.Shift(5000);

	//str = h.GetBufferAsHexString();
	//TRACE(_T("%s\r\n"), str);

	//h.ClearAll();
	//h.LoadKey(_T("This is b new key"));
	//h.Shift(5000);

	//str = h.GetBufferAsHexString();
	//TRACE(_T("%s\r\n"), str);

	//BeepTest();

	//SetProcessAffinityMask(GetCurrentProcess(), 0x00000001);

#ifdef _MYTRACE

	BOOL		rc;
	SMALL_RECT	srect = {0, 0, 1280, 1024};
	COORD		ss = {100, 256};
	HANDLE		hConsole;

	rc = AllocConsole();

	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	ASSERT(hConsole != INVALID_HANDLE_VALUE);

	SetConsoleScreenBufferSize(hConsole, ss);
	::ShowWindow(m_hConsole, SW_SHOW|SW_MINIMIZE);

	//m_hConsole = GetConsoleWindow();
	//ASSERT(m_hConsole);

	//if (!m_bShowConsole)
	//{
	//	::ShowWindow(m_hConsole, SW_HIDE);
	//}
	//else
	//{
	//	::ShowWindow(m_hConsole, SW_SHOW|SW_MINIMIZE);
	//}

#endif

	// Visual Styles
	//SetThemeAppProperties(STAP_ALLOW_NONCLIENT|STAP_ALLOW_CONTROLS|STAP_ALLOW_WEBCONTENT);
	//SetThemeAppProperties(STAP_ALLOW_NONCLIENT);


	// Try to get address from end of module
	PVOID	eom = ZZZZ_EndOfModule();

}

App::~App()
{
#ifdef _MYTRACE
	if (IsConsoleEnabled())
	{
		AfxMessageBox(_T("Press Ok to continue."), MB_OK);
	}
	FreeConsole();
#endif


}


// The one and only App object

App theApp;

// App initialization

// Thread proc to issue a warning message about expired certificate
unsigned __stdcall ExpiredProc( void * pv)
{
	AfxMessageBox(_T("Error: Unable to read profile. Code = 0x2F"), MB_OK | MB_ICONERROR);
	_endthreadex(0);
	return 0;
}

BOOL App::InitInstance()
{
	BOOL	bExpired	= TRUE;		// Assume expired certificate.
	CString	strCompanyName;
	CModuleScanner	scanner;
	CVersion		version;

	TF;		// Trace this function

	scanner.CalculateModuleChecksum();

	NANOBEGIN;

	InitCommonControls();

	CWinApp::InitInstance();


	SetRegistryKey(version.GetCompanyName());
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	//AutoLoadSchedule();

	CMyDocTemplate* pDocTemplate;
	pDocTemplate = new CMyDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(Doc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CMainView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);

	// Enable DDE Execute open
	//EnableShellOpen();
	//UnregisterShellFileTypes();
	RegisterShellFileTypes(TRUE);
	Register();

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it

	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	NANOEND;

	SECUREBEGIN_A;
	bExpired = FALSE;	// This stmt is only enabled if the cert is still valid.
	SECUREEND_A;

	//if (m_Armadillo.IsProtected())
	//{
	//	if (bExpired)
	//	{	// Issue expired message (on another thread for security(?))
	//		unsigned int threadID;
	//		HANDLE hThread = (HANDLE) _beginthreadex(NULL, 0, ExpiredProc, this, 0, &threadID);
	//		WaitForSingleObject(hThread, INFINITE);
	//		CloseHandle(hThread);
	//		return FALSE;
	//	}
	//}

	return TRUE;
}

int App::ExitInstance()
{
	TF;		// Trace this function

	//AutoSaveSchedule();

	return CWinApp::ExitInstance();
}

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()

	CStaticColor	m_Static_ProductName;
	CStaticColor	m_Static_Copyright;
	CStaticColor	m_StaticVersion;
	CStaticColor	m_Static_RegLabel;
	CStaticColor	m_Static_KeyLbl;
	CStaticColor	m_Static_Name;
	CStaticColor	m_Static_Key;
	CStaticColor	m_Static_Web;

public:
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

public:
	afx_msg void OnDestroy();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//m_hCursor = ::LoadCursorFromFile(_T("C:\\WINDOWS\\Cursors\\handno.ani"));
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_PRODUCTNAME,	m_Static_ProductName);
	DDX_Control(pDX, IDC_STATIC_COPYRIGHT,		m_Static_Copyright);
	DDX_Control(pDX, IDC_STATIC_NAME,			m_Static_Name);
	DDX_Control(pDX, IDC_STATIC_KEY,			m_Static_Key);
	DDX_Control(pDX, IDC_STATIC_VERSION,		m_StaticVersion);
	DDX_Control(pDX, IDC_STATIC_REGLABEL,		m_Static_RegLabel);
	DDX_Control(pDX, IDC_STATIC_KEYLBL,			m_Static_KeyLbl);
	DDX_Control(pDX, IDC_STATIC_WEB,			m_Static_Web);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	ON_WM_ERASEBKGND()
//	ON_BN_CLICKED(IDC_BUTTON_ENTERKEY, OnBnClickedButtonEnterkey)
	ON_WM_DESTROY()

END_MESSAGE_MAP()

// App command to run the dialog
void App::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

CSection csTrace;	// Keeps the trace messages from interrupting each other.

void trace(LPCTSTR lpszstring, ...)
{
	TCHAR	szstring[255];	// user's string passed to us (after formatting)
	va_list vl;						// variable argument list


	va_start(vl, lpszstring);
	_vsntprintf_s(szstring, sizeof szstring, lpszstring, vl);	  // format the stuff

	{
		//CCS lock(&csTrace);

		OutputDebugStr(szstring);

		if (APP->IsConsoleEnabled()) _cputts(szstring);
	}

}

// Same as trace except doesn't hold lock.
void traceDump(LPCTSTR lpszstring, ...)
{
	TCHAR	szstring[255];	// user's string passed to us (after formatting)
	va_list vl;						// variable argument list

	va_start(vl, lpszstring);
	_vsntprintf_s(szstring, sizeof szstring, lpszstring, vl);	  // format the stuff

	OutputDebugStr(szstring);

	if (APP->IsConsoleEnabled())
	{
		_cputts(szstring);
	}
}

Doc* App::GetDoc(void)
{
	POSITION		pos;
	CDocTemplate*	pTemplate;
	Doc*			pDoc;

	NANOBEGIN;
	if (m_pDoc != NULL) return m_pDoc;

	pos = GetFirstDocTemplatePosition();
	pTemplate = GetNextDocTemplate(pos);
	pos = pTemplate->GetFirstDocPosition();
	pDoc = (Doc*) pTemplate->GetNextDoc(pos);
	m_pDoc = pDoc;

	NANOEND;
	return pDoc;
}

CMainView* App::GetView(void)
{
	POSITION		pos;
	CDocTemplate*	pTemplate;
	CDocument*		pDoc;
	CMainView*		pView;

	pos = GetFirstDocTemplatePosition();
	pTemplate = GetNextDocTemplate(pos);
	pos = pTemplate->GetFirstDocPosition();
	pDoc = pTemplate->GetNextDoc(pos);
	pos = pDoc->GetFirstViewPosition();
	pView = (CMainView*) pDoc->GetNextView(pos);

	return pView;
}

BOOL CAboutDlg::OnInitDialog()
{
	CVersion	v;
	CString		str;
	TCHAR		name[1024]	= {0};
	TCHAR		key[1024]	= {0};

	NANOBEGIN;

	CDialog::OnInitDialog();

#ifndef _LITE
	str.Format(_T("%s"), v.GetProductName());
#else
	str.Format(_T("%s (Lite)"), v.GetProductName());
#endif

	m_Static_ProductName.SetTextColor(RGB(255,255,255));
	m_Static_Copyright.SetTextColor(RGB(255,255,255));
	m_StaticVersion.SetTextColor(RGB(255,255,255));
	m_Static_RegLabel.SetTextColor(RGB(255,255,255));
	m_Static_KeyLbl.SetTextColor(RGB(255,255,255));
	m_Static_Name.SetTextColor(RGB(255,128,128));
	m_Static_Key.SetTextColor(RGB(255,128,128));
	m_Static_Web.SetTextColor(RGB(255,255,255));

	m_Static_ProductName.SetBkColor(RGB(000,000,000));
	m_Static_Copyright.SetBkColor(RGB(000,000,000));
	m_StaticVersion.SetBkColor(RGB(000,000,000));
	m_Static_RegLabel.SetBkColor(RGB(000,000,000));
	m_Static_KeyLbl.SetBkColor(RGB(000,000,000));
	m_Static_Name.SetBkColor(RGB(000,000,000));
	m_Static_Key.SetBkColor(RGB(000,000,000));
	m_Static_Web.SetBkColor(RGB(000,000,000));


	m_Static_ProductName.SetWindowText(str);
	m_Static_Copyright.SetWindowText(v.GetLegalCopyright());
	str.Format(_T("Version %s"), v.GetFileVersion());
	m_StaticVersion.SetWindowText(str);

	GetEnvironmentVariable(_T("ALTUSERNAME"), name, sizeof name / sizeof(TCHAR));
	if (CString(name) != _T("DEFAULT") && _tcslen(name) > 0)
	{
		m_Static_Name.SetWindowText(name);
		GetEnvironmentVariable(_T("USERKEY"), key, sizeof key / sizeof(TCHAR));
		m_Static_Key.SetWindowText(key);
	}
	else
	{	// Env ALTUSERNAME is NULL.
		if (APP->m_Armadillo.IsProtected())
		{	// Protection in effect.
			m_Static_Name.SetWindowText(_T("unregistered"));
			m_Static_Key.SetWindowText(_T(""));
		}
		else
		{	// No protection needed to run this version.
			m_Static_Name.SetWindowText(_T("(non-protected-version)"));
			m_Static_Key.SetWindowText(_T("****"));
		}
	}

	NANOEND;

	return TRUE;
}

BOOL CAboutDlg::OnEraseBkgnd(CDC* pDC)
{
	CRect	rect;

	GetClientRect(&rect);

	pDC->FillSolidRect(&rect, RGB(000,000,000));

	return TRUE;
}

//void CAboutDlg::OnBnClickedButtonEnterkey()
//{
//#ifdef _PROTECTED
//	CDlgEnterKey dlg(this);
//	dlg.DoModal();
//#endif
//
//}

void App::OnUpdateTestConverttext(CCmdUI *pCmdUI)
{
	pCmdUI->Enable();
}

void App::OnTestConverttext()
{
	CDlgConvertText	dlg;

	dlg.DoModal();
}

void App::OnUpdateHelpEnterregistration(CCmdUI *pCmdUI)
{
	TCHAR		name[100]	= {0};
	BOOL		bEnableRegMenu = FALSE;

	GetEnvironmentVariable(_T("ALTUSERNAME"), name, sizeof name / sizeof(TCHAR));

	if (m_Armadillo.IsProtected())
	if (CString(name) == _T("DEFAULT"))
		bEnableRegMenu = TRUE;

	pCmdUI->Enable(bEnableRegMenu);
}

void App::OnHelpEnterregistration()
{
	CDlgEnterKey	dlg;

	dlg.DoModal();

	//m_Armadillo.ShowEnterKeyDialog(NULL);
}

void App::ShowConsole(bool bShow)
{
	if (bShow)
	{	// Show it
		::ShowWindow(m_hConsole, SW_SHOW);
		m_bShowConsole = TRUE;
	}
	else
	{	// Hide it
		::ShowWindow(m_hConsole, SW_HIDE);
		m_bShowConsole = FALSE;
	}
}

BOOL App::IsConsoleEnabled(void)
{
	return (m_bShowConsole == TRUE);
}


void App::ToggleConsole(void)
{
	ShowConsole(!IsConsoleEnabled());
}

void CAboutDlg::OnDestroy()
{
	CDialog::OnDestroy();

}

BOOL App::OnDDECommand(LPTSTR lpszCommand)
{
	CString		str;

	str.Format(_T("DDE Command Received: '%s'."), lpszCommand);
	AfxMessageBox(str);

	return CWinApp::OnDDECommand(lpszCommand);
}

// This doesn't work yet. The messages never seem to arrive.
BOOL App::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_QUERYENDSESSION || pMsg->message == WM_ENDSESSION)
	{
		DebugBreak();
	}

	return CWinApp::PreTranslateMessage(pMsg);
}

// Overrides to eliminate the need to use the section names.
UINT App::GetProfileInt(LPCTSTR lpszEntry, int nDefault)
{
	return __super::GetProfileInt(SECTION_NAME, lpszEntry, nDefault);
}

BOOL App::WriteProfileInt(LPCTSTR lpszEntry, int nValue)
{
	return __super::WriteProfileInt(SECTION_NAME, lpszEntry, nValue);
}

CString App::GetProfileString(LPCTSTR lpszEntry, LPCTSTR lpszDefault)
{
	return __super::GetProfileString(SECTION_NAME, lpszEntry, lpszDefault);
}

BOOL App::WriteProfileString(LPCTSTR lpszEntry, LPCTSTR lpszValue)
{
	return __super::WriteProfileString(SECTION_NAME, lpszEntry, lpszValue);
}

BOOL App::GetProfileBinary(LPCTSTR lpszEntry, LPBYTE* ppData, UINT* pBytes)
{
	return __super::GetProfileBinary(SECTION_NAME, lpszEntry, ppData, pBytes);
}

BOOL App::WriteProfileBinary(LPCTSTR lpszEntry, LPBYTE pData, UINT nBytes)
{
	return __super::WriteProfileBinary(SECTION_NAME, lpszEntry, pData, nBytes);
}


BOOL CAboutDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONUP)
	if (pMsg->hwnd == GetDlgItem(IDC_STATIC_WEB)->GetSafeHwnd())
	{
		HINSTANCE hInst = ShellExecute(GetSafeHwnd(), _T("open"), _T("http://www.davee.com/srpro"), NULL, NULL, SW_SHOWNORMAL);
	}

	return CDialog::PreTranslateMessage(pMsg);
}
