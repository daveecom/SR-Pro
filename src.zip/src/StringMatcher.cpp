// StringMatcher.cpp : implementation file
//

#include "stdafx.h"

#include "StringMatcher.h"

// StringMatcher

CStringMatcher::CStringMatcher(LPCTSTR lpszString)
{
	m_strMatch = lpszString;
	m_Index = 0;
}

CStringMatcher::~CStringMatcher()
{
}


// StringMatcher member functions
BOOL CStringMatcher::Matches(TCHAR NextChar)
{
	TCHAR	testChar;

	testChar = m_strMatch.GetAt(m_Index);

	if (m_strMatch.GetAt(m_Index) == NextChar)
	{
		m_Index++;
		if (m_Index == m_strMatch.GetLength())
		{
			m_Index = 0;	// Reset index for next test
			return TRUE;	// Tell caller a match was found.
		}
	}
	else
	{
		m_Index = 0;	// No match. Reset index.
	}

	return FALSE;
}
