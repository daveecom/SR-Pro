// PropSheetSched.cpp : implementation file
//

#include "stdafx.h"

#include ".\propsheetsched.h"

// CPropSheetSched

IMPLEMENT_DYNAMIC(CPropSheetSched, CPropertySheet)

CPropSheetSched::CPropSheetSched(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	m_uStart.ll = 0;
	m_uDuration .ll = 0;

	// Set up the default repeat parameters
	m_RepeatParms.Type				= Repeat_Off;
	m_RepeatParms.dd				= 1;
	m_RepeatParms.hh				= 0;
	m_RepeatParms.mm				= 0;
	m_RepeatParms.ss				= 0;
	m_RepeatParms.ms				= 0;
	m_RepeatParms.RepeatWD[0]		= TRUE;
	for (int i = 1; i < 7; i++) m_RepeatParms.RepeatWD[i] = FALSE;
	m_RepeatParms.RepeatDOM			= 1;
	m_RepeatParms.nRepeatCount		= 0;
	m_RepeatParms.bRepeatForever	= TRUE;
	m_RepeatParms.tRepeatUntil.ll	= 0;

	m_bRepeats						= FALSE;
	m_strSchedComment				= _T("New Schedule");
}

CPropSheetSched::~CPropSheetSched()
{
}


BEGIN_MESSAGE_MAP(CPropSheetSched, CPropertySheet)
	ON_WM_ERASEBKGND()
//	ON_WM_CLOSE()
END_MESSAGE_MAP()


// CPropSheetSched message handlers


IMPLEMENT_DYNAMIC(CPropPageSchedStart, CPropertyPage)
CPropPageSchedStart::CPropPageSchedStart()
	: CPropertyPage(CPropPageSchedStart::IDD)
{
}

CPropPageSchedStart::~CPropPageSchedStart()
{
}

void CPropPageSchedStart::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_DATETIME_STARTDATE, m_DateTime_Date);
	DDX_Control(pDX, IDC_DATETIME_STARTTIME, m_DateTime_Time);
	DDX_Control(pDX, IDC_EDIT_SCHEDDESCRIPTION, m_Edit_SchedComment);
}


BEGIN_MESSAGE_MAP(CPropPageSchedStart, CPropertyPage)
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnBnClickedButtonReset)
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED(IDC_BUTTON_SETNOW, OnBnClickedButtonSetnow)
END_MESSAGE_MAP()


// CPropPageSchedStart message handlers

BOOL CPropPageSchedStart::OnSetActive()
{
	CPropertySheet* ps = (CPropertySheet*) GetParent();

	ps->SetWizardButtons(PSWIZB_NEXT);

	// Try to prevent the focus landing on the calendar input controls
	m_DateTime_Time.SetFocus();

	return CPropertyPage::OnSetActive();
}

BOOL CPropPageSchedStart::OnInitDialog()
{
	DWORD		dwStyle;

	CPropertyPage::OnInitDialog();

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_SCHEDDESCRIPTION),	_T("Type the description of the schedule here."));
	m_ToolTip.AddTool(GetDlgItem(IDC_DATETIME_STARTDATE),		_T("Set the start date."));
	m_ToolTip.AddTool(GetDlgItem(IDC_DATETIME_STARTTIME),		_T("Set the start time."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_RESET),				_T("Set start time at top of the hour."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_SETNOW),			_T("Set the start time to now."));

	dwStyle = GetWindowLong(m_DateTime_Time.GetSafeHwnd(), GWL_STYLE);
	dwStyle |= DTS_TIMEFORMAT;
	SetWindowLong(m_DateTime_Time.GetSafeHwnd(), GWL_STYLE, dwStyle);

	ResetInputs();

	return TRUE;
}

BOOL CPropSheetSched::OnInitDialog()
{
	SYSTEMTIME	tm;
	UFT			u;
	CAlarmClock	clock;	// To get time

	// Set up the default start date and time if nexessary.
	if (m_uStart.ll == 0)
	{
		// Move current time forward to top of the hour.
		clock.GetTime(&u);

		u.ll += ONE_HOUR;
		FileTimeToSystemTime(&u.ft, &tm);
		tm.wMinute			= 0;
		tm.wSecond			= 0;
		tm.wMilliseconds	= 0;
		SystemTimeToFileTime(&tm, &m_uStart.ft);

		// Set default duration to 59 mins, 59 secs
		m_uDuration.ll = ONE_HOUR - ONE_SECOND;
	}

	return CPropertySheet::OnInitDialog();
}


// CPropPageSchedStop dialog

IMPLEMENT_DYNAMIC(CPropPageSchedStop, CPropertyPage)
CPropPageSchedStop::CPropPageSchedStop()
	: CPropertyPage(CPropPageSchedStop::IDD)
{
}

CPropPageSchedStop::~CPropPageSchedStop()
{
}

void CPropPageSchedStop::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_DATETIME_STARTDATE, m_DateTime_Date);
	DDX_Control(pDX, IDC_DATETIME_STARTTIME, m_DateTime_Time);
	DDX_Control(pDX, IDC_CHECK_REPEAT, m_Check_Repeat);
	DDX_Control(pDX, IDC_SPIN_DAYS, m_Spin_Days);
	DDX_Control(pDX, IDC_SPIN_HOURS, m_Spin_Hours);
	DDX_Control(pDX, IDC_SPIN_MINS, m_Spin_Mins);
	DDX_Control(pDX, IDC_SPIN_SECS, m_Spin_Secs);
}


BEGIN_MESSAGE_MAP(CPropPageSchedStop, CPropertyPage)
//	ON_BN_CLICKED(IDC_CHECK_REPEAT, OnBnClickedCheckRepeat)
ON_BN_CLICKED(IDC_CHECK_REPEAT, OnBnClickedCheckRepeat)
ON_WM_ERASEBKGND()
ON_BN_CLICKED(IDC_BUTTON_RESET, OnBnClickedButtonReset)
//ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATETIME_STARTDATE, OnDtnDatetimechangeDatetimeStartdate)
ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATETIME_STARTDATE, OnDatetimechange)
ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATETIME_STARTTIME, OnDatetimechange)
ON_WM_HSCROLL()
END_MESSAGE_MAP()


// CPropPageSchedStop message handlers

INT_PTR CPropSheetSched::DoModal()
{
	AddPage(&m_pageStart);
	AddPage(&m_pageStop);
	AddPage(&m_pageRepeat);
	AddPage(&m_pageConfirm);
	SetWizardMode();

	return CPropertySheet::DoModal();
}

BOOL CPropPageSchedStop::OnSetActive()
{
	CPropertySheet* ps = (CPropertySheet*) GetParent();

	ps->SetWizardButtons(PSWIZB_BACK|PSWIZB_NEXT);

	Update();

	return CPropertyPage::OnSetActive();
}

BOOL CPropPageSchedStop::OnInitDialog()
{
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();
	DWORD				dwStyle;

	CPropertyPage::OnInitDialog();

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_DAYS),			_T("Duration of show (days)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_DAYS), 			_T("Duration of show (days)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_HOURS),			_T("Duration of show (hours)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_HOURS),			_T("Duration of show (hours)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_MINS), 			_T("Duration of show (minutes)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_MINS), 			_T("Duration of show (minutes)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_SECS), 			_T("Duration of show (seconds)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_SECS), 			_T("Duration of show (seconds)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_REPEAT),			_T("Repeat this schedule."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_RESET),			_T("Reset to default duration."));
	m_ToolTip.AddTool(GetDlgItem(IDC_DATETIME_STARTDATE),	_T("Ending date."));
	m_ToolTip.AddTool(GetDlgItem(IDC_DATETIME_STARTTIME),	_T("Ending time."));

	dwStyle = GetWindowLong(m_DateTime_Time.GetSafeHwnd(), GWL_STYLE);
	dwStyle |= DTS_TIMEFORMAT;
	SetWindowLong(m_DateTime_Time.GetSafeHwnd(), GWL_STYLE, dwStyle);

	m_Spin_Days.SetRange(0, 9999);
	m_Spin_Hours.SetRange(0, 23);
	m_Spin_Mins.SetRange(0, 59);
	m_Spin_Secs.SetRange(0, 59);

	// Set the initial date/time.
	if (pParent->m_uDuration.ll == 0) ResetInputs();

	return TRUE;
}

// CPropPageSchedRepeat dialog

IMPLEMENT_DYNAMIC(CPropPageSchedRepeat, CPropertyPage)
CPropPageSchedRepeat::CPropPageSchedRepeat()
	: CPropertyPage(CPropPageSchedRepeat::IDD)
	, m_Radio_Types(0)
	, m_Radio_EndType(0)
{
}

CPropPageSchedRepeat::~CPropPageSchedRepeat()
{
}

void CPropPageSchedRepeat::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SPIN_DAYS, m_Spin_Days);
	DDX_Control(pDX, IDC_SPIN_HOURS, m_Spin_Hours);
	DDX_Control(pDX, IDC_SPIN_MINUTES, m_Spin_Minutes);
	DDX_Control(pDX, IDC_SPIN_SECONDS, m_Spin_Seconds);
	DDX_Radio(pDX, IDC_RADIO_NOREPEAT, m_Radio_Types);
	DDX_Control(pDX, IDC_SPIN2, m_Spin_DOM);
	DDX_Control(pDX, IDC_CHECK_SUN, m_Check_Sun);
	DDX_Control(pDX, IDC_CHECK_MON, m_Check_Mon);
	DDX_Control(pDX, IDC_CHECK_TUE, m_Check_Tue);
	DDX_Control(pDX, IDC_CHECK_WED, m_Check_Wed);
	DDX_Control(pDX, IDC_CHECK_THU, m_Check_Thu);
	DDX_Control(pDX, IDC_CHECK_FRI, m_Check_Fri);
	DDX_Control(pDX, IDC_CHECK_SAT, m_Check_Sat);
	DDX_Radio(pDX, IDC_RADIO_NEVER, m_Radio_EndType);
	DDX_Control(pDX, IDC_SPIN_REPCOUNT, m_Spin_RepCount);
	DDX_Control(pDX, IDC_DATE_EXPIRES, m_Date_Expires);
}


BEGIN_MESSAGE_MAP(CPropPageSchedRepeat, CPropertyPage)
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED(IDC_RADIO_NOREPEAT, OnBnClickedRadioRepeatTypes)
	ON_BN_CLICKED(IDC_RADIO_REPEAT_INTERVALS, OnBnClickedRadioRepeatTypes)
	ON_BN_CLICKED(IDC_RADIO_REPEATDOW, OnBnClickedRadioRepeatTypes)
	ON_BN_CLICKED(IDC_RADIO_REPEATDOM, OnBnClickedRadioRepeatTypes)
	ON_BN_CLICKED(IDC_RADIO_NEVER, OnBnClickedRadioEndTypes)
	ON_BN_CLICKED(IDC_RADIO_EXPIREDATE, OnBnClickedRadioEndTypes)
	ON_BN_CLICKED(IDC_RADIO_EXPIRENNTIMES, OnBnClickedRadioEndTypes)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_CHECK_SUN, OnBnClickedCheckDOW)
	ON_BN_CLICKED(IDC_CHECK_MON, OnBnClickedCheckDOW)
	ON_BN_CLICKED(IDC_CHECK_TUE, OnBnClickedCheckDOW)
	ON_BN_CLICKED(IDC_CHECK_WED, OnBnClickedCheckDOW)
	ON_BN_CLICKED(IDC_CHECK_THU, OnBnClickedCheckDOW)
	ON_BN_CLICKED(IDC_CHECK_FRI, OnBnClickedCheckDOW)
	ON_BN_CLICKED(IDC_CHECK_SAT, OnBnClickedCheckDOW)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATE_EXPIRES, OnDtnDatetimechangeDateExpires)
END_MESSAGE_MAP()


// CPropPageSchedRepeat message handlers

BOOL CPropPageSchedRepeat::OnSetActive()
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();

	pParent->SetWizardButtons(PSWIZB_BACK|PSWIZB_NEXT);

	Update();

	return CPropertyPage::OnSetActive();
}


LRESULT CPropPageSchedStart::OnWizardNext()
{
	UFT	uToday, u1;
	SYSTEMTIME	st, st1, st2;
	CString str;
	CAlarmClock	clock;	// to get time
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();

	CPropertyPage::OnWizardNext();

	// Store the comment
	m_Edit_SchedComment.GetWindowText(str);
	pParent->m_strSchedComment = str;

	clock.GetTime(&uToday);

	// Read the datetime controls
	m_DateTime_Date.GetTime(&st1);
	m_DateTime_Time.GetTime(&st2);

	// Combine date from one, time from other
	st					= st1;
	st.wHour			= st2.wHour;
	st.wMinute			= st2.wMinute;
	st.wSecond			= st2.wSecond;
	st.wMilliseconds	= st2.wMilliseconds;

	SystemTimeToFileTime(&st, &u1.ft);

	//if (u1.ll <= uToday.ll)
	//{
	//	AfxMessageBox(_T("Input Error: You cannot schedule an event for a date in the past."), MB_OK|MB_ICONEXCLAMATION);
	//	return -1;
	//}
	//else
	//{
		pParent->m_uStart.ft = u1.ft;	// Store the new start date/time
	//}

	return 0;	
}

void CPropPageSchedStart::OnBnClickedButtonReset()
{
	ResetInputs();
}

void CPropPageSchedStart::ResetInputs(void)
{
	SYSTEMTIME	tm;
	CPropSheetSched* ps = (CPropSheetSched*) GetParent();

	// Set the initial date/time.
	FileTimeToSystemTime(&ps->m_uStart.ft, &tm);
	m_DateTime_Date.SetTime(tm);
	m_DateTime_Time.SetTime(tm);

	// Set the previous comment
	m_Edit_SchedComment.SetWindowText(ps->m_strSchedComment);
}

LRESULT CPropPageSchedStop::OnWizardNext()
{
	//UFT	u1;
	//SYSTEMTIME	st, st1, st2;
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();
	//LRESULT idNextPage;

	if ((pParent->m_uDuration.ll) == 0)
	{
		AfxMessageBox(_T("Input Error: Duration = 0 or end date/time preceeds start."), MB_OK|MB_ICONEXCLAMATION);
		return -1;
	}

// Skip the repeats page if repeats are turned off.
//	if (pParent->m_bRepeats)
//		idNextPage = IDD_PROPPAGE_SCHEDULE_REPEATS;
//	else
//		idNextPage = IDD_PROPPAGE_SCHEDULE_CONFIRM;
//
//	return idNextPage;
	return 0;
}

// CPropPageSchedConfirm dialog

IMPLEMENT_DYNAMIC(CPropPageSchedConfirm, CPropertyPage)
CPropPageSchedConfirm::CPropPageSchedConfirm()
	: CPropertyPage(CPropPageSchedConfirm::IDD)
{
}

CPropPageSchedConfirm::~CPropPageSchedConfirm()
{
}

void CPropPageSchedConfirm::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_DURATION, m_Static_Duration);
	DDX_Control(pDX, IDC_STATIC_REPEATS, m_Static_RepeatText);
	DDX_Control(pDX, IDC_STATIC_EVENTNAME, m_Static_EventName);
	DDX_Control(pDX, IDC_STATIC_START, m_Static_Start);
	DDX_Control(pDX, IDC_STATIC_STOP, m_Static_Stop);
}


BEGIN_MESSAGE_MAP(CPropPageSchedConfirm, CPropertyPage)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// CPropPageSchedConfirm message handlers

BOOL CPropPageSchedConfirm::OnSetActive()
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();
	CString		str, str1;
	SYSTEMTIME	tm;
	UFT			u1;
	TCHAR		tszDate[128];
	int			result;
	int			nDays, nHours, nMins, nSecs;

	pParent->SetWizardButtons(PSWIZB_BACK|PSWIZB_FINISH);

	// Display the event name
	m_Static_EventName.SetWindowText(pParent->m_strSchedComment);

	FileTimeToSystemTime(&pParent->m_uStart.ft, &tm);
	result = GetDateFormat(NULL, DATE_LONGDATE, &tm, NULL, tszDate, sizeof tszDate / sizeof(TCHAR));

	str.Format(_T("%s %02d:%02d:%02d"), tszDate, tm.wHour, tm.wMinute, tm.wSecond);
	m_Static_Start.SetWindowText(str);

	u1.ll = pParent->m_uStart.ll + pParent->m_uDuration.ll;
	FileTimeToSystemTime(&u1.ft, &tm);
	result = GetDateFormat(NULL, DATE_LONGDATE, &tm, NULL, tszDate, sizeof tszDate / sizeof(TCHAR));

	str.Format(_T("%s %02d:%02d:%02d"), tszDate, tm.wHour, tm.wMinute, tm.wSecond);
	m_Static_Stop.SetWindowText(str);

	// display the duration
	u1.ll = pParent->m_uDuration.ll;

	nDays	= (int) (u1.ll / ONE_DAY);
	nHours	= (int) (u1.ll / ONE_HOUR)		% 24;
	nMins	= (int) (u1.ll / ONE_MINUTE)	% 60;
	nSecs	= (int) (u1.ll / ONE_SECOND)	% 60;

	str.Format(_T("%d day%s, %d hour%s, %d min%s, %d sec%s."),
		nDays,
		nDays	!= 1 ? _T("s"):_T(""),
		nHours,
		nHours	!= 1 ? _T("s"):_T(""),
		nMins,
		nMins	!= 1 ? _T("s"):_T(""),
		nSecs,
		nSecs	!= 1 ? _T("s"):_T(""));

	m_Static_Duration.SetWindowText(str);

	// Display the repeat parameters
	if (pParent->m_RepeatParms.Type == Repeat_Off)
	{
		str = _T("One time only.");
	}
	else
	{
		switch (pParent->m_RepeatParms.Type)
		{
			case Repeat_Interval:

				str.Format(_T("Repeat every %d day%s, %d hour%s, %d min%s. %d sec%s"),
					pParent->m_RepeatParms.dd,
					pParent->m_RepeatParms.dd != 1 ? _T("s"):_T(""),
					pParent->m_RepeatParms.hh,
					pParent->m_RepeatParms.hh != 1 ? _T("s"):_T(""),
					pParent->m_RepeatParms.mm,
					pParent->m_RepeatParms.mm != 1 ? _T("s"):_T(""),
					pParent->m_RepeatParms.ss,
					pParent->m_RepeatParms.ss != 1 ? _T("s"):_T(""));
				break;

			case Repeat_Monthly:

				// Just for laughs, put the suffix on the DOM value, e.g., '1' = '1st', '2' = '2nd', etc.
				str1.Empty();
				if (pParent->m_RepeatParms.RepeatDOM >= 11 && pParent->m_RepeatParms.RepeatDOM <= 13)
				{
					str1 = _T("th");
				}
				else
				{
					switch ((pParent->m_RepeatParms.RepeatDOM % 10))
					{
						case 1:
							str1 = _T("st");
							break;
						case 2:
							str1 = _T("nd");
							break;
						case 3:
							str1 = _T("rd");
							break;
						default:
							str1 = _T("th");
					}
				}

				str.Format(_T("Repeat on the %d%s day of each month."),
					pParent->m_RepeatParms.RepeatDOM, str1);
					
				break;

			case Repeat_Weekdays:
				str1.Empty();
				if (pParent->m_RepeatParms.RepeatWD[0]) str1 += _T("SUN, ");
				if (pParent->m_RepeatParms.RepeatWD[1]) str1 += _T("MON, ");
				if (pParent->m_RepeatParms.RepeatWD[2]) str1 += _T("TUE, ");
				if (pParent->m_RepeatParms.RepeatWD[3]) str1 += _T("WED, ");
				if (pParent->m_RepeatParms.RepeatWD[4]) str1 += _T("THU, ");
				if (pParent->m_RepeatParms.RepeatWD[5]) str1 += _T("FRI, ");
				if (pParent->m_RepeatParms.RepeatWD[6]) str1 += _T("SAT, ");

				if (str1.GetLength() > 0)	// Remove the last comma-space
				{
					str1 = str1.Left(str1.GetLength() - 2);
				}

				str.Format(_T("Repeat weekly on %s."), str1);
				break;
		}
	}

	// Add the repeat end condition to the message if repeats are active.
	switch (pParent->m_RepeatParms.Type)
	{
		case Repeat_Interval:
		case Repeat_Monthly:
		case Repeat_Weekdays:
		{
			if (pParent->m_RepeatParms.bRepeatForever)
				str1 = _T(" Never Expires.");
			else
			if (pParent->m_RepeatParms.nRepeatCount > 0)
				str1.Format(_T(" Expires after %d time%s."), pParent->m_RepeatParms.nRepeatCount,
					pParent->m_RepeatParms.nRepeatCount > 1 ? _T("s"):_T(""));
			else
			{
				FileTimeToSystemTime(&pParent->m_RepeatParms.tRepeatUntil.ft, &tm);
				str1.Format(_T(" Expires on %d/%d/%04d."),
					tm.wMonth, tm.wDay, tm.wYear);
			}
		}
	}

	if (!str1.IsEmpty())
	str += str1;
	m_Static_RepeatText.SetWindowText(str);

	return CPropertyPage::OnSetActive();
}

LRESULT CPropPageSchedConfirm::OnWizardBack()
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();

	return 0;
	
}

void CPropPageSchedStop::OnBnClickedCheckRepeat()
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();

	pParent->m_bRepeats = (m_Check_Repeat.GetCheck() == BST_CHECKED);
}

BOOL CPropPageSchedRepeat::OnInitDialog()
{
	SYSTEMTIME			tm;
	UFT					u1;
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();

	CPropertyPage::OnInitDialog();

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN2),					_T("Set day of month to repeat"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_REPEATDOM),			_T("Set day of month to repeat"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_REPCOUNT),			_T("Number of repeats"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_REPCOUNT),			_T("Number of repeats"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_DAYS),				_T("Repeat every nn days"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_DAYS),				_T("Repeat every nn days"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_HOURS),				_T("Repeat every nn hours"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_HOURS),				_T("Repeat every nn hours"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_MINUTES),				_T("Repeat every nn minutes"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_MINUTES),				_T("Repeat every nn minutes"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_SECONDS),				_T("Repeat every nn seconds"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_SECONDS),				_T("Repeat every nn seconds"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_SUN),				_T("Repeat on Sundays"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_MON),				_T("Repeat on Mondays"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_TUE),				_T("Repeat on Tuesdays"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_WED),				_T("Repeat on Wednesdays"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_THU),				_T("Repeat on Thursdays"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_FRI),				_T("Repeat on Fridays"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_SAT),				_T("Repeat on Saturdays"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_NOREPEAT),			_T("Run this schedule one time only"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_REPEAT_INTERVALS),	_T("Repeat this schedule at periodic intervals"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_REPEATDOM),			_T("Repeat this schedule once per month"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_REPEATDOW),			_T("Repeat this schedule on days of the week"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_EXPIREDATE),			_T("Repeat until expiration date reached"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_EXPIRENNTIMES),		_T("Repeat this schedule nn times"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_NEVER),				_T("Repeat forever"));
	m_ToolTip.AddTool(GetDlgItem(IDC_DATE_EXPIRES),				_T("Expiration date"));

	m_Spin_Days.SetRange(0, 365);
	m_Spin_Hours.SetRange(0, 24);
	m_Spin_Minutes.SetRange(0, 60);
	m_Spin_Seconds.SetRange(0, 60);
	m_Spin_DOM.SetRange(1, 31);
	m_Spin_RepCount.SetRange(1, 9999);

	// Set the initial expiration date value into the control.
	u1.ll = pParent->m_uStart.ll + pParent->m_uDuration.ll + ONE_DAY;
	FileTimeToSystemTime(&u1.ft, &tm);
	tm.wHour = tm.wMinute = tm.wSecond = tm.wMilliseconds = 0;
	m_Date_Expires.SetTime(&tm);

	return TRUE;
}

BOOL CPropSheetSched::OnEraseBkgnd(CDC* pDC)
{
	CRect rect;

	return __super::OnEraseBkgnd(pDC);	// Use default

	//GetClientRect(&rect);
	//pDC->FillSolidRect(&rect, RGB(128, 64, 64));
	//return TRUE;
}

BOOL CPropPageSchedConfirm::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

BOOL CPropPageSchedRepeat::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

BOOL CPropPageSchedStart::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

BOOL CPropPageSchedStop::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void CPropPageSchedRepeat::Update(void)
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();
	SYSTEMTIME	tm;
	
	switch(pParent->m_RepeatParms.Type)
	{
		case Repeat_Off:
			m_Radio_Types = 0;
			break;

		case Repeat_Interval:
			m_Radio_Types = 1;
			break;

		case Repeat_Weekdays:
			m_Radio_Types = 2;
			break;

		case Repeat_Monthly:
			m_Radio_Types = 3;
			break;
	}

	m_Spin_Days.SetPos(pParent->m_RepeatParms.dd);
	m_Spin_Hours.SetPos(pParent->m_RepeatParms.hh);
	m_Spin_Minutes.SetPos(pParent->m_RepeatParms.mm);
	m_Spin_Seconds.SetPos(pParent->m_RepeatParms.ss);
	m_Spin_DOM.SetPos(pParent->m_RepeatParms.RepeatDOM);

	m_Check_Sun.SetCheck(pParent->m_RepeatParms.RepeatWD[0]);
	m_Check_Mon.SetCheck(pParent->m_RepeatParms.RepeatWD[1]);
	m_Check_Tue.SetCheck(pParent->m_RepeatParms.RepeatWD[2]);
	m_Check_Wed.SetCheck(pParent->m_RepeatParms.RepeatWD[3]);
	m_Check_Thu.SetCheck(pParent->m_RepeatParms.RepeatWD[4]);
	m_Check_Fri.SetCheck(pParent->m_RepeatParms.RepeatWD[5]);
	m_Check_Sat.SetCheck(pParent->m_RepeatParms.RepeatWD[6]);

	if (pParent->m_RepeatParms.bRepeatForever)				m_Radio_EndType = 0;
	if (pParent->m_RepeatParms.tRepeatUntil.ll	!= 0)		m_Radio_EndType = 1;
	if (pParent->m_RepeatParms.nRepeatCount		> 0)		m_Radio_EndType = 2;

	m_Spin_RepCount.SetPos((int) pParent->m_RepeatParms.nRepeatCount);

	FileTimeToSystemTime(&pParent->m_RepeatParms.tRepeatUntil.ft, &tm);
	m_Date_Expires.SetTime(&tm);

	// Disable the parts of the panel depending on the repeat type setting.
	switch(m_Radio_Types)
	{
		case 0:	// No Repeat
			m_Spin_Days.EnableWindow(FALSE);
			m_Spin_Hours.EnableWindow(FALSE);
			m_Spin_Minutes.EnableWindow(FALSE);
			m_Spin_Seconds.EnableWindow(FALSE);

			m_Check_Sun.EnableWindow(FALSE);
			m_Check_Mon.EnableWindow(FALSE);
			m_Check_Tue.EnableWindow(FALSE);
			m_Check_Wed.EnableWindow(FALSE);
			m_Check_Thu.EnableWindow(FALSE);
			m_Check_Fri.EnableWindow(FALSE);
			m_Check_Sat.EnableWindow(FALSE);

			m_Spin_DOM.EnableWindow(FALSE);

			GetDlgItem(IDC_RADIO_NEVER)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_EXPIREDATE)->EnableWindow(FALSE);
			GetDlgItem(IDC_RADIO_EXPIRENNTIMES)->EnableWindow(FALSE);
			m_Spin_RepCount.EnableWindow(FALSE);
			break;
		
		case 1:	// Repeat Interval
			m_Spin_Days.EnableWindow(TRUE);
			m_Spin_Hours.EnableWindow(TRUE);
			m_Spin_Minutes.EnableWindow(TRUE);
			m_Spin_Seconds.EnableWindow(TRUE);

			m_Check_Sun.EnableWindow(FALSE);
			m_Check_Mon.EnableWindow(FALSE);
			m_Check_Tue.EnableWindow(FALSE);
			m_Check_Wed.EnableWindow(FALSE);
			m_Check_Thu.EnableWindow(FALSE);
			m_Check_Fri.EnableWindow(FALSE);
			m_Check_Sat.EnableWindow(FALSE);

			m_Spin_DOM.EnableWindow(FALSE);

			GetDlgItem(IDC_RADIO_NEVER)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_EXPIREDATE)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_EXPIRENNTIMES)->EnableWindow(TRUE);
			m_Spin_RepCount.EnableWindow(TRUE);
			break;

		case 2:	// Repeat DOW
			m_Spin_Days.EnableWindow(FALSE);
			m_Spin_Hours.EnableWindow(FALSE);
			m_Spin_Minutes.EnableWindow(FALSE);
			m_Spin_Seconds.EnableWindow(FALSE);

			m_Check_Sun.EnableWindow(TRUE);
			m_Check_Mon.EnableWindow(TRUE);
			m_Check_Tue.EnableWindow(TRUE);
			m_Check_Wed.EnableWindow(TRUE);
			m_Check_Thu.EnableWindow(TRUE);
			m_Check_Fri.EnableWindow(TRUE);
			m_Check_Sat.EnableWindow(TRUE);

			m_Spin_DOM.EnableWindow(FALSE);

			GetDlgItem(IDC_RADIO_NEVER)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_EXPIREDATE)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_EXPIRENNTIMES)->EnableWindow(TRUE);
			m_Spin_RepCount.EnableWindow(TRUE);
			break;

		case 3:	// Repeat DOM
			m_Spin_Days.EnableWindow(FALSE);
			m_Spin_Hours.EnableWindow(FALSE);
			m_Spin_Minutes.EnableWindow(FALSE);
			m_Spin_Seconds.EnableWindow(FALSE);

			m_Check_Sun.EnableWindow(FALSE);
			m_Check_Mon.EnableWindow(FALSE);
			m_Check_Tue.EnableWindow(FALSE);
			m_Check_Wed.EnableWindow(FALSE);
			m_Check_Thu.EnableWindow(FALSE);
			m_Check_Fri.EnableWindow(FALSE);
			m_Check_Sat.EnableWindow(FALSE);

			m_Spin_DOM.EnableWindow(TRUE);

			GetDlgItem(IDC_RADIO_NEVER)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_EXPIREDATE)->EnableWindow(TRUE);
			GetDlgItem(IDC_RADIO_EXPIRENNTIMES)->EnableWindow(TRUE);
			m_Spin_RepCount.EnableWindow(TRUE);
			break;
	}
	// Handle the special case for the repeat-count-spin-control
	if (m_Radio_Types != 0 && m_Radio_EndType == 2)
		m_Spin_RepCount.EnableWindow(TRUE);
	else
		m_Spin_RepCount.EnableWindow(FALSE);
	
	// And the expiration date control
	if (m_Radio_Types != 0 && m_Radio_EndType == 1)
		m_Date_Expires.EnableWindow(TRUE);
	else
		m_Date_Expires.EnableWindow(FALSE);

	UpdateData(FALSE);
}

void CPropPageSchedRepeat::OnBnClickedRadioRepeatTypes()
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();

	UpdateData();

	switch (m_Radio_Types)
	{
		case 0:	// No repeat
			pParent->m_RepeatParms.Type = Repeat_Off;
			break;

		case 1:	// Repeat Interval
			pParent->m_RepeatParms.Type = Repeat_Interval;
			break;

		case 2:	// Repeat Weekdays
			pParent->m_RepeatParms.Type = Repeat_Weekdays;
			break;

		case 3:	// Repeat Monthly
			pParent->m_RepeatParms.Type = Repeat_Monthly;
			break;
	}

	Update();
}

void CPropPageSchedRepeat::OnBnClickedRadioEndTypes()
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();
	SYSTEMTIME tm;


	UpdateData();

	switch (m_Radio_EndType)
	{
		case 0:	// Repeat forever
			pParent->m_RepeatParms.bRepeatForever	= TRUE;
			pParent->m_RepeatParms.nRepeatCount		= 0;
			pParent->m_RepeatParms.tRepeatUntil.ll	= 0;
			break;

		case 1:	// Repeat until date
			pParent->m_RepeatParms.bRepeatForever = FALSE;
			pParent->m_RepeatParms.nRepeatCount		= 0;
			m_Date_Expires.GetTime(&tm);
			SystemTimeToFileTime(&tm, &pParent->m_RepeatParms.tRepeatUntil.ft);
			break;

		case 2:
			pParent->m_RepeatParms.bRepeatForever = FALSE;
			pParent->m_RepeatParms.nRepeatCount		= m_Spin_RepCount.GetPos();
			pParent->m_RepeatParms.tRepeatUntil.ll	= 0;
			break;
	}

	Update();
}

void CPropPageSchedRepeat::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();

	CPropertyPage::OnHScroll(nSBCode, nPos, pScrollBar);

	pParent->m_RepeatParms.dd			= m_Spin_Days.GetPos();
	pParent->m_RepeatParms.hh			= m_Spin_Hours.GetPos();
	pParent->m_RepeatParms.mm			= m_Spin_Minutes.GetPos();
	pParent->m_RepeatParms.ss			= m_Spin_Seconds.GetPos();
	pParent->m_RepeatParms.RepeatDOM	= m_Spin_DOM.GetPos();
	pParent->m_RepeatParms.nRepeatCount = m_Spin_RepCount.GetPos();
}

void CPropPageSchedRepeat::OnBnClickedCheckDOW()
{
	CPropSheetSched* pParent = (CPropSheetSched*) GetParent();

	UpdateData();

	pParent->m_RepeatParms.RepeatWD[0] = m_Check_Sun.GetCheck() == BST_CHECKED ? TRUE:FALSE;
	pParent->m_RepeatParms.RepeatWD[1] = m_Check_Mon.GetCheck() == BST_CHECKED ? TRUE:FALSE;
	pParent->m_RepeatParms.RepeatWD[2] = m_Check_Tue.GetCheck() == BST_CHECKED ? TRUE:FALSE;
	pParent->m_RepeatParms.RepeatWD[3] = m_Check_Wed.GetCheck() == BST_CHECKED ? TRUE:FALSE;
	pParent->m_RepeatParms.RepeatWD[4] = m_Check_Thu.GetCheck() == BST_CHECKED ? TRUE:FALSE;
	pParent->m_RepeatParms.RepeatWD[5] = m_Check_Fri.GetCheck() == BST_CHECKED ? TRUE:FALSE;
	pParent->m_RepeatParms.RepeatWD[6] = m_Check_Sat.GetCheck() == BST_CHECKED ? TRUE:FALSE;

	Update();
}

void CPropPageSchedStop::ResetInputs(void)
{
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();

	pParent->m_uDuration.ll = ONE_HOUR - ONE_SECOND;
}

void CPropPageSchedStop::OnBnClickedButtonReset()
{
	ResetInputs();
	Update();
}

void CPropPageSchedStop::Update(void)
{
	SYSTEMTIME			tm;
	UFT					u1;
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();

	// Update the duration spin controls
	m_Spin_Days.SetPos((int) (pParent->m_uDuration.ll / ONE_DAY));
	m_Spin_Hours.SetPos((int) ((pParent->m_uDuration.ll / ONE_HOUR) % 24));
	m_Spin_Mins.SetPos((int) ((pParent->m_uDuration.ll / ONE_MINUTE) % 60));
	m_Spin_Secs.SetPos((int) ((pParent->m_uDuration.ll / ONE_SECOND) % 60));

	// Update the date/time controls
	u1.ll = pParent->m_uStart.ll + pParent->m_uDuration.ll;
	FileTimeToSystemTime(&u1.ft, &tm);
	m_DateTime_Date.SetTime(tm);
	m_DateTime_Time.SetTime(tm);

	m_Check_Repeat.SetCheck(pParent->m_bRepeats ? BST_CHECKED : BST_UNCHECKED);
}


void CPropPageSchedStop::OnDatetimechange(NMHDR *pNMHDR, LRESULT *pResult)
{
	SYSTEMTIME			tm1, tm2;
	UFT					u1;
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();

	LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);


	// Read the Date/Time controls
	m_DateTime_Date.GetTime(&tm1);
	m_DateTime_Time.GetTime(&tm2);

	// Merge date and time from the controls
	tm1.wHour			= tm2.wHour;
	tm1.wMinute			= tm2.wMinute;
	tm1.wSecond			= tm2.wSecond;
	tm1.wMilliseconds	= 0;

	SystemTimeToFileTime(&tm1, &u1.ft);

	if (u1.ll < pParent->m_uStart.ll) u1.ll = pParent->m_uStart.ll;	// Prevent underflow.

	u1.ll -= pParent->m_uStart.ll;	// Convert stop date/time into duration
	pParent->m_uDuration.ll = u1.ll;

	Update();

	*pResult = 0;
}

void CPropPageSchedStop::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();
	
	pParent->m_uDuration.ll		=
		(m_Spin_Days.GetPos()	* ONE_DAY) + 
		(m_Spin_Hours.GetPos()	* ONE_HOUR) + 
		(m_Spin_Mins.GetPos()	* ONE_MINUTE) +
		(m_Spin_Secs.GetPos()	* ONE_SECOND);

	Update();
}

BOOL CPropPageSchedConfirm::OnInitDialog()
{
	BOOL				rc;
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();
	CRect				rect;
	int					fontSize;

	CPropertyPage::OnInitDialog();

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_DURATION),	_T("Duration of scheduled show"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_REPEATS),	_T("Indicates the repeat parameters"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_EVENTNAME),	_T("Name of show"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_START),		_T("Start Date/Time"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_STOP),		_T("Ending Date/Time"));

	// Size the bold font based on the static height
	m_Static_Duration.GetClientRect(&rect);
	fontSize = -(rect.Height() - 4);

	if (m_fontLarge.m_hObject == NULL)
	{
		rc = m_fontLarge.CreateFont(fontSize, 0, 0, 0, FW_BOLD, 0, 0, 0,
			DEFAULT_CHARSET,
			OUT_STROKE_PRECIS,
			CLIP_STROKE_PRECIS,
			PROOF_QUALITY,
			VARIABLE_PITCH | FF_DONTCARE,
			_T("ms sans serif"));
		ASSERT(rc);
	}

	m_Static_EventName.SetFont(&m_fontLarge);
	m_Static_Start.SetFont(&m_fontLarge);
	m_Static_Stop.SetFont(&m_fontLarge);
	m_Static_Duration.SetFont(&m_fontLarge);
	m_Static_RepeatText.SetFont(&m_fontLarge);

	return TRUE;
}

BOOL CPropPageSchedConfirm::OnWizardFinish()
{

	return CPropertyPage::OnWizardFinish();
}


// Validate the REPEAT_PARMS
LRESULT CPropPageSchedRepeat::OnWizardNext()
{
	CAlarmClock			clock;
	BOOL				bOkToProceed;
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();
	CString				str;

	bOkToProceed = TRUE;	// Assume the user's input is valid.

	// Tell the user why it failed validation
	try
	{
		if (pParent->m_RepeatParms.bRepeatForever == FALSE &&
			pParent->m_RepeatParms.nRepeatCount == 0 &&
			pParent->m_RepeatParms.tRepeatUntil.ll == 0)
			throw _T("Must have valid end condition.");

		if (pParent->m_RepeatParms.tRepeatUntil.ll > 0)
			if (pParent->m_RepeatParms.tRepeatUntil.ll <= pParent->m_uStart.ll)
			{
				m_Date_Expires.SetFocus();
				throw _T("Repeat expiration date must be later than start date.");
			}

		switch (pParent->m_RepeatParms.Type)
		{
			case Repeat_Interval:
				if (pParent->m_RepeatParms.dd > 365 || pParent->m_RepeatParms.hh > 24 || pParent->m_RepeatParms.mm > 60 || pParent->m_RepeatParms.ss > 60 || /* pParent->m_RepeatParms.ms > 999 || */
					(pParent->m_RepeatParms.dd + pParent->m_RepeatParms.hh + pParent->m_RepeatParms.mm + pParent->m_RepeatParms.ss + pParent->m_RepeatParms.ms == 0) )
				{
					GetDlgItem(IDC_EDIT_DAYS)->SetFocus();
					throw _T("Interval value out of range.");
				}
				break;

			case Repeat_Weekdays:
				int i, count;
				for (i = 0, count = 0; i < 7; i++)
				{
					if (pParent->m_RepeatParms.RepeatWD[i])
						count++;
				}

				if (count == 0)
				{
					m_Check_Sun.SetFocus();
					throw _T("No weekdays were selected.");	// No weekdays were selected.
				}

				break;

			default:
				break;
		}

		if (!clock.SetRepeat(pParent->m_RepeatParms))
			throw _T("Unknown problem with repeat parms.");

	}
	catch (LPCTSTR strReason)
	{
		str.Format(_T("Repeat parameter has a problem: [%s]"), strReason);
		AfxMessageBox(str, MB_OK | MB_ICONEXCLAMATION);

		bOkToProceed = FALSE;
	}

	return bOkToProceed ? 0 : -1;
}

void CPropPageSchedRepeat::OnDtnDatetimechangeDateExpires(NMHDR *pNMHDR, LRESULT *pResult)
{
	CPropSheetSched*	pParent = (CPropSheetSched*) GetParent();
	LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
	SYSTEMTIME	tm;

	m_Date_Expires.GetTime(&tm);
	SystemTimeToFileTime(&tm, &pParent->m_RepeatParms.tRepeatUntil.ft);


	*pResult = 0;
}

LPCTSTR CPropSheetSched::GetScheduleName(void)
{
	return m_strSchedComment;
}

FILETIME CPropSheetSched::GetStartDateTime(void)
{
	return	m_uStart.ft;
}

FILETIME CPropSheetSched::GetStopDateTime(void)
{
	static	UFT	u1;

	u1.ll = m_uStart.ll;
	u1.ll += m_uDuration.ll;

	return u1.ft;
}

REPEAT_PARMS CPropSheetSched::GetRepeatParms(void)
{
	return m_RepeatParms;
}

FILETIME CPropSheetSched::GetDuration(void)
{
	return m_uDuration.ft;
}

void CPropSheetSched::GetSchedule(CScheduleItem* pItem)
{
	pItem->SetName(m_strSchedComment);
	pItem->SetStart(m_uStart.ft);
	pItem->SetDuration(m_uDuration.ft);
	pItem->SetRepeat(m_RepeatParms);
}

void CPropSheetSched::SetSchedule(CScheduleItem* pItem)
{
	m_strSchedComment	= pItem->GetName();
	m_uStart			= pItem->GetStart();
	m_uDuration			= pItem->GetDuration();
	m_RepeatParms		= pItem->GetRepeat();
}

void CPropSheetSched::SetSchedule(LPCTSTR lpszSchedName, FILETIME ftStart, FILETIME ftDuration, REPEAT_PARMS RepeatParms)
{
	m_strSchedComment	= lpszSchedName;
	m_uStart.ft			= ftStart;
	m_uDuration.ft		= ftDuration;
	m_RepeatParms		= RepeatParms;
}

void CPropPageSchedStart::OnBnClickedButtonSetnow()
{
	CAlarmClock	clock;
	SYSTEMTIME	tm;

	FileTimeToSystemTime(&(clock.GetTime().ft), &tm);

	m_DateTime_Date.SetTime(&tm);
	m_DateTime_Time.SetTime(&tm);
}

BOOL CPropPageSchedConfirm::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	return CPropertyPage::PreTranslateMessage(pMsg);
}

BOOL CPropPageSchedRepeat::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	return CPropertyPage::PreTranslateMessage(pMsg);
}

BOOL CPropPageSchedStart::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	return CPropertyPage::PreTranslateMessage(pMsg);
}

BOOL CPropPageSchedStop::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	return CPropertyPage::PreTranslateMessage(pMsg);
}
