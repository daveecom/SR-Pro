#pragma once
#include "resource.h"
#include "afxwin.h"
#include "msacm.h"
#include "channelfilter.h"
#include "audiosettings.h"
#include <afxwin.h>

// CDlgAudioSettings dialog

class CAudioSettings;
class CDlgAudioSettings : public CDialog
{
	DECLARE_DYNAMIC(CDlgAudioSettings)

public:
	CDlgAudioSettings(CAudioSettings* pAudioSettings, CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgAudioSettings();

// Dialog Data
	enum { IDD = IDD_DIALOG_AUDIOSETTINGS };

protected:
	DECLARE_MESSAGE_MAP()

	virtual void		DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg void		OnBnClickedButtonAudiocapturemode();
	static UINT			acmFormatChooseHookProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	afx_msg void		OnBnClickedRadioCompressionOn();
	afx_msg void		OnBnClickedRadioCompressionOff();
	afx_msg void		OnCbnSelchangeComboDev();
	afx_msg void		OnBnClickedButtonChancvt();

public:
	virtual BOOL		OnInitDialog();
	void				Update(void);
	CHANNEL_PARMS		m_ChannelParms;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CButton m_Check_HQ;

	// Archived //
	int					m_CaptureDeviceID;
	DWORD				m_dwMaxWFSize;
	BOOL				m_bHQ;
	LPWAVEFORMATEX		m_pwfCapture;
	LPWAVEFORMATEX		m_pwfCompress;
	//////////////

protected:

	CStatic				m_Static_SampleRate;
	CStatic				m_Static_Bits;
	CStatic				m_Static_Mode;
	CStatic				m_Static_Format;
	CStatic				m_Static_FormatTag;
	CComboBox			m_Combo_Dev;

	CAudioSettings*		m_pAudioSettings;

	CToolTipCtrl		m_ToolTip;
public:
	afx_msg void OnBnClickedCheckCmphq();
};
