#include "StdAfx.h"
#include "logfile.h"
#include ".\logfile.h"

CLogFileWriter::CLogFileWriter(void)
: m_strFilePath(_T(""))
, m_strFreq(_T(""))
, m_strTrigChan(_T(""))
, m_hFile(NULL)
, m_hMiniLog(NULL)
, m_nEventNumber(0)
, m_sMeter(0)
, m_nFileOffset(0)
, m_bEnable(TRUE)
, m_pRadioInterface(NULL)
, m_pRadioSettings(NULL)
, m_nSampleOffset(0)
{
	TF;

	m_tRelative.ll		= 0;
	m_tEvtDur.ll		= 0;
	m_tEvtStart.ll		= 0;
	m_tLogCreated.ll	= 0;
}

CLogFileWriter::~CLogFileWriter(void)
{
	TF;

	CloseLog();

	m_hMiniLog = NULL;
}

BOOL CLogFileWriter::CreateLog(LPCTSTR lpszFilePath)
{
	CStringA	strA;

	TCHAR		header1[]	= _T("Event,  Date,       Time,         Duration,   RelativeTime, VX, FileOffset (H),   SampleOffset (H), TimeOffset (H),   Radio Info\r\n");
	TCHAR		header2[]	= _T("======, ==========, ============, ==========, ============, ==, ================, ================, ================, ==========\r\n");
	TCHAR		header3[]	= _T("000000, 2005/09/21, 13:26:23.307, 000000.000, 00:00:01.561, Mn, 0000000000000000, 0000000000000000, 0000000000000000, xxxxxxxxxx");

	DWORD		dwWritten;
	SYSTEMTIME	tm = {0};

	TF;

	if (m_bEnable)
	{
		ASSERT(m_hFile == NULL);	// File already open
		ASSERT(_tcslen(lpszFilePath) > 0);

		m_strFilePath	= lpszFilePath;

		if (m_hMiniLog != NULL) PostMessage(m_hMiniLog, UWM_RESET_MINILOG, 0, 0);

		try
		{
			m_hFile = CreateFile(m_strFilePath, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
			if (m_hFile == INVALID_HANDLE_VALUE)
				throw(_T("Error: Can't create the log file."));

			GetLocalTime(&tm);
			SystemTimeToFileTime(&tm, &m_tLogCreated.ft);

			strA = (LPCTSTR) header1;
			WriteFile(m_hFile, strA,		(DWORD) strA.GetLength(),	&dwWritten, NULL);
			strA = (LPCTSTR) header2;
			WriteFile(m_hFile, strA,		(DWORD) strA.GetLength(),	&dwWritten, NULL);
			//strA = (LPCTSTR) header3;
			//WriteFile(m_hFile, strA,		(DWORD) strA.GetLength(),	&dwWritten, NULL);

			FlushFileBuffers(m_hFile);
		}
		catch (LPCTSTR string)
		{
			CString str;
			str.Format(_T("%s Result = %d"), string, GetLastError());
			AfxMessageBox(str);
		}

		m_nEventNumber = 0;

		return (m_hFile != NULL);
	}
	else
	{	// Disabled
		return TRUE;
	}
}

void CLogFileWriter::CloseLog(void)
{
	TF;

	if (m_hFile != NULL)
	{	// Log is open
		if (m_tEvtStart.ll != 0 && m_tEvtDur.ll == 0)
		{	// Log entry started but not finished
			//ASSERT(0);	// Someone forgot to write the current log entry.
			WriteEntry();
		}


		if (m_bEnable) CloseHandle(m_hFile);

		m_hFile					= NULL;
		m_tLogCreated.ll		= 0;
		m_tEvtStart.ll			= 0;
		m_tEvtDur.ll			= 0;
		m_tRelative.ll			= 0;
		m_nSampleOffset			= 0;
		m_strFilePath.Empty();
		m_strFreq.Empty();
		m_strTrigChan.Empty();
	}
}

// Begin a new log record. Also begin trying to retrieve info from the recv'r
void CLogFileWriter::NewEntry(FILETIME tTime)
{
	//TF;

	m_tEvtStart.ft			= tTime;
	m_tEvtDur.ll			= 0;
	m_tRelative.ll			= 0;
	m_strFreq.Empty();
	m_strTrigChan.Empty();
	m_sMeter				= 0;
	m_nFileOffset			= 0;
	m_nSampleOffset			= 0;

	if (m_pRadioSettings != NULL)
	{
		if (m_pRadioSettings->IsRadioEnabled())
		{
			if (m_pRadioInterface != NULL)
			{
				// Clear any pending received junk.
				m_pRadioInterface->PurgeReceiver();

				m_pRadioInterface->StartAsyncJob();	// Try to retrieve the radio info.
			}

		}
	}
}

void CLogFileWriter::SetFreq(LPCTSTR lpszFreq)
{
	//TF;

	m_strFreq = lpszFreq;
}

void CLogFileWriter::SetTrigChan(LPCTSTR lpszChannel)
{
	//TF;

	m_strTrigChan = lpszChannel;
}

void CLogFileWriter::SetDuration(FILETIME tDuration)
{
	//TF;

	m_tEvtDur.ft = tDuration;

	// bug trap. Remove when fixed.
	
	if (m_tEvtStart.ll == 0)
	{	// New entry has not been created yet. This must be a bogus duration value.
		DebugBreak();
	}
}

void CLogFileWriter::SetRelativeTime(FILETIME tTime)
{
	//TF;

	m_tRelative.ft = tTime;
}

void CLogFileWriter::WriteEntry(void)
{
	BOOL		rc;
	DWORD		dwWritten;
	CString		str, strRadioInfo;
	CStringA	strA;				// For Unicode to Mbcs
	char		chBuffer[256]	= {0};	// For conversion to mbcs
	int			cCharCount		= 0;	// mbcs string length
	SYSTEMTIME	tmStart			= {0}, tmDur = {0}, tmRelative = {0};
	ULARGE_INTEGER	large;
	int			i, j;

	//TF;

	if (m_pRadioInterface != NULL)
	if (m_pRadioSettings != NULL)
	if ((j = m_pRadioSettings->GetJobItemCount()) != 0)
	{	// Retrieve the radio's info fields.
		for (i = 0; i < j; i++)
		{
			str.Format(_T("%s"),
				m_pRadioSettings->GetJobItem(i)->GetResult());

			strRadioInfo += _T(", ");
			strRadioInfo += str;
		}
		TRACE(_T("Radio Data: %s\r\n"), strRadioInfo);
	}

	//TODO Add radio data to the log after modifying it.

	if (m_bEnable && m_hFile != NULL)
	{
		//ASSERT(m_hFile != NULL);	// File not open

		if (m_tEvtDur.ll == 0)
		{
			//Beep(5000,100);
			//DebugBreak();
		}

		FileTimeToSystemTime(&m_tEvtStart.ft, &tmStart);
		FileTimeToSystemTime(&m_tRelative.ft, &tmRelative);
		FileTimeToSystemTime(&m_tEvtDur.ft, &tmDur);

		//durDays = (int) (m_tEvtDur.ll	/ ONE_DAY);
		//relDays = (int) (m_tRelative.ll	/ ONE_DAY);

		large.QuadPart = m_nFileOffset;
//_T("000000, 2005/09/21, 13:26:23.307, 000000.000, 00:00:01.561, Mn, 0000000000000000, 0000000000000000, 0000000000000000, xxxxxxxxxx");


		str.Format(
			_T("%06d, ")						// 123456 Event ID #
			_T("%04d/%02d/%02d, ")				// 2005/07/17 Event Date
			_T("%02d:%02d:%02d.%03d, ")			// 03:36:24.999 Event start time
			_T("%06d.%03d, ")					// ssssss.mmm Event duration
			_T("%02d:%02d:%02d.%03d, ")			// hh:mm:ss.mmm Relative file time
			_T("%s, ")	 						// Trigger Channel
			_T("%08X%08X, ")					// File offset
			_T("%016I64X, ")					// Sample offset
			_T("%016I64X, ")					// Time offset
			_T("%s")							// Radio data.
			_T("\r\n"),
			m_nEventNumber,
			tmStart.wYear, tmStart.wMonth, tmStart.wDay,
			tmStart.wHour, tmStart.wMinute, tmStart.wSecond, tmStart.wMilliseconds,
			(int) (m_tEvtDur.ll / ONE_SECOND), (int) ((m_tEvtDur.ll / ONE_MILLISECOND) % 1000),
			tmRelative.wHour, tmRelative.wMinute, tmRelative.wSecond, tmRelative.wMilliseconds,
			m_strTrigChan,
			large.HighPart, large.LowPart,
			(ULONGLONG) m_nSampleOffset,
			(ULONGLONG) m_tRelative.ll,
			strRadioInfo
		);

		//TRACE(str);

		// Write entry to the log file.
		strA = str;
		rc = WriteFile(m_hFile, strA, strA.GetLength(), &dwWritten, NULL);
		if (!rc)
		{
			ASSERT(0);
			TRACE(_T("Error: Unable to write to log file: '%s'.\r\n"), m_strFilePath);
		}
	}

	//ASSERT(dwWritten == str.GetLength()/sizeof(TCHAR));
	
	// Clear the record fields to indicate the record was written
	m_strFreq.Empty();
	m_strTrigChan.Empty();
	m_tEvtDur.ll			= 0;
	m_tEvtStart.ll			= 0;
	m_tRelative.ll			= 0;
	m_nSampleOffset			= 0;
	m_nFileOffset			= 0;

	m_nEventNumber++;
}

void CLogFileWriter::SetSMeter(int nValue)
{
	m_sMeter = nValue;
}

void CLogFileWriter::SetFileOffset(ULONGLONG nOffset)
{
	m_nFileOffset = nOffset;
}

void CLogFileWriter::Enable(BOOL bEnabled)
{
	m_bEnable = bEnabled;
}

LPCTSTR CLogFileWriter::GetGreq(void)
{
	return m_strFreq;
}

int CLogFileWriter::GetSMeter(void)
{
	return m_sMeter;
}

UFT CLogFileWriter::GetStart(void)
{
	return m_tEvtStart;
}

void CLogFileWriter::SetRadioInterface(CRadioInterface* pRadio)
{
	m_pRadioInterface = pRadio;
}

void CLogFileWriter::SetRadioSettings(CRadioSettings* pRadioSettings)
{
	ASSERT(pRadioSettings != NULL);

	m_pRadioSettings = pRadioSettings;
}

void CLogFileWriter::SetSampleOffset(ULONGLONG nSamples)
{
	m_nSampleOffset = nSamples;
}
