#pragma once
#include "afxwin.h"
#include "atltypes.h"
#include "avg.h"


// CProgressStatic

class CProgressStatic : public CStatic
{
	DECLARE_DYNAMIC(CProgressStatic)

public:
						CProgressStatic();
	virtual				~CProgressStatic();

protected:
	DECLARE_MESSAGE_MAP()
	BOOL					m_bVert;
	double					m_RangeLow;
	double					m_RangeHigh;
	//DWORD					m_RangeLow;
	//DWORD					m_RangeHigh;
	COLORREF				m_bkColor;
	COLORREF				m_color;
	double					m_Pos;

public:
	virtual void			SetVert(BOOL bVert);
	virtual void			SetRange(double low, double high);
	//virtual void			SetRange(DWORD low, DWORD high);
	virtual void			SetPos(double Pos);
	virtual afx_msg BOOL	OnEraseBkgnd(CDC* pDC);
	virtual afx_msg void	OnPaint();
	void					SetColor(COLORREF Color);
	double					LinearToDb(double fRatio);

protected:

	BOOL m_bScaleDB;
};

class CProgressVU :
	public CProgressStatic
{
public:
							CProgressVU(void);
	virtual					~CProgressVU(void);
	virtual void			SetVoxPos(double Pos);

	DECLARE_MESSAGE_MAP()

protected:
	afx_msg void			OnPaint();
	COLORREF				GetBlendedColor(double fRatio, COLORREF clrLow, COLORREF clrHigh);
	int						Interpolate(double fRatio, int LowVal, int HiVal);

	CAvg					m_MaxMarker;	// Controls max level tick mark
	COLORREF				m_ColorTick;	// Color of tick mark.
	void DrawGrid(CDC* pDC);

	CBitmap					m_bmBuffer;		// For dbl buffer during OnPaint.

	double					m_VoxPos;
	void DrawVoxSetting(CDC* pDC);
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
protected:
	BOOL m_bMouseButtonDown;
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
protected:
	double ConvertMousePosToVoxPos(int nMousePos);
public:
	BOOL m_bMousePosIsValid;
	BOOL IsMousePosValid(void);
	double GetNewVoxPos(void);
};
