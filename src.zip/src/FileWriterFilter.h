#pragma once
#include "FilenameServer.h"
#include "audiofilter.h"
#include "logfile.h"
#include "ccs.h"

class CFileWriterFilter : public CAudioFilter
{
public:
				CFileWriterFilter(CAudioRecorder* pParent);
	virtual		~CFileWriterFilter(void);

	DECLARE_DYNAMIC(CFileWriterFilter)

	//virtual BOOL		SetPathname(LPCTSTR Pathname, BOOL bAppend = FALSE);
	virtual BOOL		BeginNewFile();
	virtual void		ProcessDataBuffer(RECBUFF* pRB);
	virtual void		CloseFile(void);
	virtual void		SetLogFile(CLogFileWriter* pLogfile);
	virtual ULONGLONG	GetBytesWritten(void);
	virtual void		SetWriteInhibit(BOOL bInhibit);
	virtual BOOL		GetWriteInhibit(void);
	void				SetServer(CFilenameServer* lpServer);
	CFilenameServer*	GetServer(void);

protected:

	CString				m_PathName;			// Full path to audio file. BeginNewFile updates it.
	BOOL				m_bAppend;			// Append to existing file if true.
	HANDLE				m_hFile;			// File handle of output file.
	CSection			m_csFileLock;		// Protects the above handle and access to the file.
	ULONGLONG			m_nBytesWritten;	// Bytes written to the main output file.
	CLogFileWriter*		m_pLogFile;			// Access so we can open and close the log file.
	BOOL				m_bWriteInhibit;	// Prevent writing to files if true.
	CFilenameServer*	m_pServer;			// Access to new file names.

};
