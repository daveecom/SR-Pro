#include "StdAfx.h"
#include ".\audiocapturenew.h"

CAudioCaptureNew::CAudioCaptureNew(CAudioRecorder* pParent)
: CAudioFilter(pParent)
, m_bStreamActive(FALSE)
, m_DevQCnt(0)
, m_hWaveIn(NULL)
, m_nSample(0)
//, m_bPause(TRUE)
{
	TF;

	m_strObjectName = _T("CAudioCaptureNew");
}

CAudioCaptureNew::~CAudioCaptureNew(void)
{
	TF;

	//CloseHandle(m_hEventPaused);
}

// Create a new buffer and put it on the audio input queue.
void CAudioCaptureNew::AddRecbuff()
{
	TF;		// Trace this function

	int rc;
	RECBUFF* rb = NULL;
	ASSERT(m_hWaveIn != NULL);

	rb = AllocRecbuff();
	ASSERT(rb);

	// Prepare the header if not already prepared.
	if (!(rb->wavehdr.dwFlags & WHDR_PREPARED))
	{
		rc = waveInPrepareHeader(m_hWaveIn, &(rb->wavehdr), sizeof(WAVEHDR));
		ASSERT(rc == MMSYSERR_NOERROR);	// TODO Add error handler
	}

	rc = waveInAddBuffer(m_hWaveIn, &(rb->wavehdr), sizeof(WAVEHDR));
	ASSERT(rc == MMSYSERR_NOERROR);	// TODO Add Error handler

	m_DevQCnt++;
}

void CALLBACK CAudioCaptureNew::WaveInProc(HWAVE hWave, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	BOOL			rc;
	RECBUFF*		pRB;
	LPWAVEHDR		pWh;
	CAudioCaptureNew*	pThis;
	SYSTEMTIME		localTime;
	FILETIME		ft;
	double			nSecPerBuffer;
	UFT				u1;

	switch(uMsg)
	{
		case WIM_OPEN:
		{
			TRACE(_T("WaveInProc: WIM_OPEN\n"));
			break;
		}

		case WIM_CLOSE:
		{
			TRACE(_T("WaveInProc: WIM_CLOSE\n"));
			break;
		}

		case WIM_DATA:
		{
			pWh = (LPWAVEHDR) (DWORD_PTR) dwParam1;
			pRB = (RECBUFF*) pWh->dwUser;
			pThis = (CAudioCaptureNew*) pRB->pAllocator;

			pThis->m_DevQCnt--;		// account for device queue depth

			//TRACE(_T("WaveInProc: WIM_DATA. RB=%08X, DevQCnt=%d\r\n"),
			//	pRB, pThis->m_DevQCnt);

			// Get the buffer arrival time and convert to the time of the 1st sample.
			GetLocalTime(&localTime);
			SystemTimeToFileTime(&localTime, &ft);	// Buffer end time.

			nSecPerBuffer = (1.0 / pThis->GetSampleRate() *
				(pRB->wavehdr.dwBytesRecorded / pThis->m_pFormat->nBlockAlign));

			// Convert time of last sample to time of 1st sample.
			// End time - Buffer time.
			u1.ft = ft;	// Time of last sample
			// minus the time per buffer.
			u1.ll -= ((ULONGLONG) (nSecPerBuffer * ONE_SECOND));

			pRB->ftTime = u1.ft;

			// Set the beginning sample # of this buffer.
			pRB->nSample = pThis->m_nSample;
			
			// Increment the stream sample counter.
			pThis->m_nSample += (pWh->dwBytesRecorded / pThis->m_pFormat->nBlockAlign);

			rc = pThis->Receive(pRB, TRUE);	// Send new buffer to our own input queue to be pushed later.
			//ASSERT(rc);

			break;
		}
	}
}

BOOL CAudioCaptureNew::StopAudioCapture()
{
	TF;		// Trace this function

	int rc;

	if (m_bStreamActive)
	{
		m_bStreamActive = FALSE;

		rc = waveInStop(m_hWaveIn);
		ASSERT(rc == MMSYSERR_NOERROR);

		rc = waveInReset(m_hWaveIn);
		ASSERT(rc == MMSYSERR_NOERROR);

		// Wait here until all buffers are deallocated.
		SetEvent(m_hEventWakeWorker);
		WaitForSingleObject(m_hEventSyncBuffersReturned, INFINITE);

		rc = waveInClose(m_hWaveIn);
		ASSERT(rc == MMSYSERR_NOERROR);

		//StopStreaming();
		PurgeBuffers();
	}

	return TRUE;
}

// Open the faucet and let the audio flow in. Return value = TRUE if successful.
BOOL CAudioCaptureNew::StartAudioCapture()
{
	TF;		// Trace this function

	CString str;
	MMRESULT rc;

	m_bFirstBuffer = TRUE;	// The next buffer will be designated as the first in the stream.

	if (!m_bStreamActive)
	{
RETRY:
		rc = waveInOpen(&m_hWaveIn, m_AudSettings.m_AudioRecID, m_pFormat, (DWORD_PTR) WaveInProc, (DWORD_PTR) AfxGetInstanceHandle(), CALLBACK_FUNCTION);

		if (rc != MMSYSERR_NOERROR)
		{
			switch(rc)
			{
				case MMSYSERR_ALLOCATED:
					str = "Another application is using this audio adapter.";
					break;
				case MMSYSERR_BADDEVICEID:
					str = "Specified device identifier is out of range.";
					break;
				case MMSYSERR_NODRIVER:
					str = "No device driver is present.";
					break;
				case MMSYSERR_NOMEM:
					str = "Unable to allocate or lock memory.";
					break;
				case WAVERR_BADFORMAT:
					str = "Attempted to open with an unsupported waveform-audio format.";
					break;
				default:
					str = "Undefined error from audio driver.";
			}
			
			int ans = MessageBox(NULL, str, _T("Error during waveInOpen"), MB_RETRYCANCEL | MB_ICONEXCLAMATION);
			if (ans == IDCANCEL)
				return FALSE;
			else
				goto RETRY;
		}

		// Add the initial audio buffers to the driver's queue.
		for (int i = 0; i < 20; i++)
		{
			AddRecbuff();
		}

		m_nSample = 0;

		ZeroMemory(&m_scanInfo, sizeof(SCAN_INFO));

		//StartStreaming();

		rc = waveInStart(m_hWaveIn);
		if (rc != MMSYSERR_NOERROR)
		{
			switch(rc)
			{
				case MMSYSERR_INVALHANDLE:
					str = "Specified device handle is invalid.";	break;
				case MMSYSERR_NODRIVER:
					str = "No device driver is present.";			break;
				case MMSYSERR_NOMEM:
					str = "Unable to allocate or lock memory.";		break;

				default:
					str = "Undefined error.";
			}
			
			int ans = MessageBox(NULL, str, _T("Error during waveInStart"), MB_RETRYCANCEL | MB_ICONEXCLAMATION);
			if (ans == IDCANCEL)
				return FALSE;
			else
				goto RETRY;
		}

		m_bStreamActive = TRUE;
	}

	return TRUE;
}

void CAudioCaptureNew::ResetScanInfo(void)
{
	//TF;		// Trace this function

	// Reset scan info
	ZeroMemory(&m_scanInfo, sizeof(SCAN_INFO));
}

void CAudioCaptureNew::RecycleRecbuff(RECBUFF *rb)
{
	//TF;		// Trace this function

	int rc;

	if (m_bStreamActive)
	{
		// Prepare the header if not already prepared.
		ASSERT(rb->wavehdr.dwFlags & WHDR_PREPARED);

		//TRACE(_T("waveInAddBuffer called to recycle the previous buffer: %08X.\n"), (DWORD_PTR) rb);
		rc = waveInAddBuffer(m_hWaveIn, &rb->wavehdr, sizeof(WAVEHDR));
		ASSERT(rc == MMSYSERR_NOERROR);

		m_DevQCnt++;
	}
	else
	{
		FreeRecbuff(rb);
	}
}

BOOL CAudioCaptureNew::SetFormat(CAudioSettings* pNewSettings)
{
	ASSERT(pNewSettings != NULL);

	m_AudSettings = *pNewSettings;
	return __super::SetFormat(m_AudSettings.m_lpwfCapture);
}

void CAudioCaptureNew::ProcessDataBuffer(RECBUFF* pRB)
{
	ScanTheBuffer(&pRB->wavehdr, m_pFormat);
	Transmit(pRB);
}

void CAudioCaptureNew::Transmit(RECBUFF * pRB)
{
	BOOL			rc;
	//CCS				Lock(&m_csNextFilter);
	CAudioFilter*	pNextFilter = GetNextFilter();

	ASSERT(pRB != NULL);
	ASSERT(pRB->dataSize == pRB->wavehdr.dwBufferLength);

	if (pNextFilter != NULL)
	{
		// If this is the first buffer in the stream, then indicate so.
		if (m_bFirstBuffer)
		{
			pRB->bFirstBuffer	= TRUE;
			m_bFirstBuffer		= FALSE;	// Reset status
		}

		rc = pNextFilter->Receive(pRB, FALSE);
		if (rc)
		{
			RecycleRecbuff(pRB);
		}
		else
		{	// Receive Failed.
			//Beep(9000,20);
			//Beep(8000,20);

			m_dwDroppedBuffers++;

			RecycleRecbuff(pRB);
		}
	}	//if (GetNextFilter()!= NULL)
}

void CAudioCaptureNew::FreeRecbuff(RECBUFF* pRB)
{
	CString	str;

	__super::FreeRecbuff(pRB);

	str.Format(_T("CAudioCaptureNew::FreeRecbuff: RB= %08lX Returned, m_nRBAllocCount= %d.\r\n"),
		pRB, m_nRBAllocCount);
	TRACE(str);

	if (m_nRBAllocCount == 0) SetEvent(m_hEventSyncBuffersReturned); // If all have been returned.
}

RECBUFF* CAudioCaptureNew::AllocRecbuff(DWORD dwDataSize)
{
	RECBUFF* rb;

	rb = __super::AllocRecbuff(dwDataSize);

	TRACE(_T("CAudioCaptureNew::AllocRecbuff: RB= %08lX Allocated, Datasize = %d. m_nRBAllocCount= %d.\n"), rb, rb->dataSize, m_nRBAllocCount);

	return rb;
}


// Our own receive to prevent FreeRecbuff if Paused.
BOOL CAudioCaptureNew::Receive(RECBUFF * pRB, BOOL bGive)
{
	CCS	lock(&m_csQueue);

	if (!IsFormatSet())
	{
		ASSERT(0);		// Bug. Shouldn't have sent buffer until format is set.
		return FALSE;	// Can't accept this buffer. Sorry.
	}

	if (m_State == Flushing || m_State == ShuttingDown)
	{
		RecycleRecbuff(pRB);
		return FALSE;
	}

	if (!IsPaused())
	{
		m_Queue.AddHead(pRB);	// Add caller's buffer into our work queue.
		SetEvent(m_hEventWakeWorker);
	}
	else
	{
		RecycleRecbuff(pRB);
	}

	return TRUE;
}

//// Duplicate of AudioFilter::WorkerProc() so we can debug just this filter's logic.
//unsigned int CAudioCaptureNew::WorkerProc(void * arg)
//{
//	CAudioCaptureNew*	pThis = (CAudioCaptureNew*) arg;
//
//	pThis->WorkerProc();
//
//	return 0;
//}
//
//void CAudioCaptureNew::WorkerProc()
//{
//	TFS;
//
//	RECBUFF*		pRB;
//	DWORD			dwTimeStart, dwTimeEnd;
//	DWORD			dwSamplesPerBuffer;
//	double			fTimePerSample;
//	BOOL			bAbort;
//
//	// Loop until shutdown.
//	for (bAbort = FALSE;!bAbort;)
//	{
//		// Loop until the work queue is empty.
//		for (;;)
//		{
//			pRB = NULL;
//
//			{	///////////////// LOCKED //////////////
//				CCS Lock(&m_csQueue);
//
//				if (m_Queue.GetCount() > 0)
//				{
//					pRB = m_Queue.RemoveTail();
//					ASSERT(pRB != NULL);	// Must not be locked properly.
//				}
//			}	///////////////// LOCKED //////////////
//
//			if (pRB != NULL)
//			{
//				// Calculate the time / buffer based on the sample rate.
//				fTimePerSample = 1000.0 / m_pFormat->nSamplesPerSec;
//				dwSamplesPerBuffer = pRB->wavehdr.dwBytesRecorded / m_pFormat->nBlockAlign;
//				m_timePerBuffer = ((DWORD) ((double)fTimePerSample * (double)dwSamplesPerBuffer));
//				dwTimeStart = GetTickCount();
//
//				ProcessDataBuffer(pRB);		// ProcessDataBuffer will own this buffer from now on.
//
//				dwTimeEnd = GetTickCount();
//				m_timeMeasured = dwTimeEnd - dwTimeStart;
//			}
//
//
//			{	///////////////// LOCKED //////////////
//				CCS Lock(&m_csQueue);
//
//				if (m_Queue.GetCount() == 0)
//				{	// Work queue is now empty.
//					if (m_State == Flushing)
//					{
//						SetEvent(m_hEventFlushSync);
//					}
//
//					break;	// ... out of loop since queue is empty now.
//				}
//			}	///////////////// LOCKED //////////////
//
//
//		}	// Loop until the work queue is empty.
//
//		// Wait here until we receive an attention signal.
//		if (m_State == Ready)
//		{
//			WaitForSingleObject(m_hEventWakeWorker, INFINITE);
//		}
//
//		if (m_State == ShuttingDown) bAbort = TRUE;
//
//	}	// for (bAbort = FALSE;!bAbort;)
//
//	// Must be shutting down if here.
//	TRACE(_T("%s::WorkerProc() Shutdown Occurred.\r\n"), GetObjectName());
//}
