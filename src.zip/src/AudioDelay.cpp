#include "StdAfx.h"
#include ".\audiodelay.h"

CAudioDelay::CAudioDelay(void)
: m_Size(0)
{
}

CAudioDelay::~CAudioDelay(void)
{
	Destroy();
}

void CAudioDelay::Create(DWORD nSamples)
{
	CCS lock(&m_csArray);

	m_Size = nSamples;
}

void CAudioDelay::Destroy()
{
	CCS lock(&m_csArray);

	m_Samples.RemoveAll();
}

void CAudioDelay::SetNewFormat(DWORD nSamples)
{
	Destroy();

	Create(nSamples);
}
BOOL CAudioDelay::NewExchangeSample(USAMPLE* pSample, BOOL bDrainBuffer)
{
	CCS lock(&m_csArray);

	BOOL	bValid		= FALSE;

	if (!bDrainBuffer) m_Samples.AddHead(*pSample);

	if (m_Samples.GetCount() > m_Size)
	{	// FIFO is full
		*pSample = m_Samples.RemoveTail();
		bValid = TRUE;
	}

	return bValid;
}

