// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include ".\App.h"

#include ".\version.h"
#include "stringmatcher.h"
#include ".\mainfrm.h"
#include "ShutdownDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define	TIMER_PANEL			0
#define	TIMER_PANEL_SLOW	1


// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_CLOSE()
	ON_WM_MOVE()
	ON_WM_MOVING()
	ON_WM_DESTROY()
	ON_WM_QUERYENDSESSION()
	ON_WM_ENDSESSION()
	ON_UPDATE_COMMAND_UI(ID_TEST_ENABLECONSOLE, OnUpdateTestEnableconsole)
	ON_UPDATE_COMMAND_UI(ID_FILEWRITEINHIBITMODE, OnUpdateFilewriteinhibitmode)
	ON_COMMAND(ID_FILEWRITEINHIBITMODE, OnFilewriteinhibitmode)
	ON_COMMAND(ID_TEST_ENABLECONSOLE, OnTestEnableconsole)
END_MESSAGE_MAP()

// Status Bar layout:
//	sample rate | stereo-mono | bits | compression | filename

UINT indicators[] =
{
	ID_STATUS_SAMPLERATE,	// sample rate
	ID_STATUS_CHANNELS,		// mono stereo
	ID_STATUS_BITS,			// 8 or 16 bits
	ID_STATUS_COMPRESSION,	// compressor tag
	ID_STATUS_FILE			// output file name
};

// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	CWnd*	pDesktop = CWnd::GetDesktopWindow();
	CRect	rect;

	pDesktop->GetWindowRect(&rect);

	m_bPosLock		= TRUE;	// Unlock after pos loaded.

	m_ScreenSizeX	= rect.Width();
	m_ScreenSizeY	= rect.Height();

	m_pCodeString = new CStringMatcher(_T("WAVWAV"));
}

CMainFrame::~CMainFrame()
{
	delete m_pCodeString;
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	int		x,y;

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Move window back to previously stored position.
	x = APP->GetProfileInt(_T("PosX"), 0);
	y = APP->GetProfileInt(_T("PosY"), 0);

	SetWindowPos(&CWnd::wndTop, x, y, 0, 0, SWP_NOSIZE|SWP_NOSENDCHANGING);
	m_bPosLock = FALSE;	// Allow movement to be stored now.

	//// Status Bar layout:
	////	sample rate | stereo-mono | bits | compression

	//static UINT indicators[] =
	//{
	//	ID_STATUS_SAMPLERATE,	// sample rate
	//	ID_STATUS_CHANNELS,		// mono stereo
	//	ID_STATUS_BITS,			// 8 or 16 bits
	//	ID_STATUS_COMPRESSION	// compressor tag
	//	ID_STATUS_FILE			// output file name
	//};

	m_wndStatusBar.Create(this);
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));
	m_wndStatusBar.SetPaneInfo(0, m_wndStatusBar.GetItemID(0), SBPS_NORMAL, 40);	// smp rate
	m_wndStatusBar.SetPaneInfo(1, m_wndStatusBar.GetItemID(1), SBPS_NORMAL, 50);	// mono / stereo
	m_wndStatusBar.SetPaneInfo(2, m_wndStatusBar.GetItemID(2), SBPS_NORMAL, 45);	// bits
	m_wndStatusBar.SetPaneInfo(3, m_wndStatusBar.GetItemID(3), SBPS_NORMAL, 100);	// compression
	m_wndStatusBar.SetPaneInfo(4, m_wndStatusBar.GetItemID(4), SBPS_STRETCH, 120);	// file name

	SetTimer(TIMER_PANEL, 250, NULL);

	UpdateTitleBar();

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	//  the CREATESTRUCT cs

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		 | WS_MINIMIZEBOX | WS_SYSMENU;

	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers


void CMainFrame::OnTimer(UINT nIDEvent)
{
	Update();
}

void CMainFrame::OnClose()
{
	KillTimer(TIMER_PANEL);

	__super::OnClose();
}

void CMainFrame::Update(void)
{
	CString					str;
	MMRESULT				mmr;
	ACMFORMATTAGDETAILS		tag = {0};
	static DWORD			dwFormatTag = -1;	// -1 allows it to compare diff the 1st time.

	str.Format(_T("%d"), DOC->m_AudioSettings.m_lpwfCapture->nSamplesPerSec);
	m_wndStatusBar.SetPaneText(0, str);

	str.Format(_T("%d Bits"), DOC->m_AudioSettings.m_lpwfCapture->wBitsPerSample);
	m_wndStatusBar.SetPaneText(2, str);

	str = DOC->m_AudioSettings.IsStereo() ? _T("Stereo") : _T("Mono");
	if (DOC->m_AudioSettings.IsChannelConverted())
		str += _T("*");

	m_wndStatusBar.SetPaneText(1, str);

	// Only update the compression format tag if it's different than last time.
	if (dwFormatTag != DOC->m_AudioSettings.m_lpwfCompress->wFormatTag)
	{
		if (DOC->m_AudioSettings.m_lpwfCompress->wFormatTag != 0)
		{
			tag.cbStruct		= sizeof(ACMFORMATTAGDETAILS);
			tag.dwFormatTag		= DOC->m_AudioSettings.m_lpwfCompress->wFormatTag;

			mmr = acmFormatTagDetails(NULL, &tag, ACM_FORMATTAGDETAILSF_FORMATTAG);
			ASSERTMMR;

			m_wndStatusBar.SetPaneText(3, tag.szFormatTag);
		}
		else
		{
			m_wndStatusBar.SetPaneText(3, _T("PCM"));
		}
	}

	dwFormatTag = DOC->m_AudioSettings.m_lpwfCompress->wFormatTag;

	// Set the file name on th status bar.
	str.Empty();
	str = DOC->m_FilenameServer1.GetCurrentFilename();
	m_wndStatusBar.SetPaneText(4, str);
}

void CMainFrame::OnMove(int, int)
{
	CRect	rect, snapRect;
	int		snapDist = 10;	// Snap distance, pixels
	int		x, y;
	
	if (!m_bPosLock)
	{
		GetWindowRect(rect);

		//if (rect.left < 0 || rect.top < 0)
		//{
		//	__super::OnMove(x, y);
		//	return;
		//}

		snapRect.left	= rect.left;
		snapRect.top	= rect.top;
		snapRect.right	= m_ScreenSizeX - rect.right;
		snapRect.bottom	= m_ScreenSizeY - rect.bottom;


		x = rect.left;
		y = rect.top;

		if (snapRect.left < 0)
			x = 0;
			//SetWindowPos(&CWnd::wndTop, 0, rect.top, 0, 0,
			//SWP_NOSIZE|SWP_NOSENDCHANGING);
		//if (snapRect.right < 0)
		//	x = m_ScreenSizeX - rect.Width();
			//SetWindowPos(&CWnd::wndTop, m_ScreenSizeX - (rect.Width()), rect.top, 0, 0,
			//SWP_NOSIZE|SWP_NOSENDCHANGING);
		if (snapRect.top < 0)
			y = 0;
			//SetWindowPos(&CWnd::wndTop, rect.left, 0, 0, 0,
			//SWP_NOSIZE|SWP_NOSENDCHANGING);
		if (snapRect.bottom < 0)
			y = m_ScreenSizeY - rect.Height();
			//SetWindowPos(&CWnd::wndTop, rect.left, m_ScreenSizeY - (rect.Height()), 0, 0,
			//SWP_NOSIZE|SWP_NOSENDCHANGING);

		//SetWindowPos(&CWnd::wndTop, x, y, 0, 0, SWP_NOSIZE|SWP_NOSENDCHANGING);

		if (rect.left >= 0 && rect.top >= 0)
		{
			APP->WriteProfileInt(_T("PosX"), rect.left);
			APP->WriteProfileInt(_T("PosY"), rect.top);
		}
	}
}


void CMainFrame::OnTestEnableconsole()
{
	CMenu*	pMenu		= GetMenu();
	BOOL	bIsEnabled	= APP->IsConsoleEnabled();

	if (bIsEnabled)
	{	// Check is on
		//pMenu->CheckMenuItem(ID_TEST_ENABLECONSOLE, MF_UNCHECKED);
		APP->ShowConsole(FALSE);
	}
	else
	{	// Check is off
		//pMenu->CheckMenuItem(ID_TEST_ENABLECONSOLE, MF_CHECKED);
		APP->ShowConsole(TRUE);
	}
}

void CMainFrame::OnUpdateTestEnableconsole(CCmdUI *pCmdUI)
{
	CMenu*	pMenu		= GetMenu();
	BOOL	bIsEnabled	= APP->IsConsoleEnabled();

	pCmdUI->SetCheck(bIsEnabled);
}

void CMainFrame::OnDestroy()
{
	CMenu*	pMenu	= GetMenu();
	CString	str;
	int		pos;

	if (0)
	{
		pos = 2;

		pMenu->GetMenuString(pos, str, MF_BYPOSITION);
		str.MakeLower();
		if (str == _T("test menu"))
		{
			pMenu->DeleteMenu(pos, MF_BYPOSITION);
		}
	}

	__super::OnDestroy();
}

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	TCHAR	key;

	if (pMsg->message == WM_KEYDOWN)
	{
		key = (TCHAR) pMsg->wParam;
		//TRACE(_T("Key '%04X' Pressed.\r\n"), (TCHAR) key);

		if (m_pCodeString->Matches(key))
		{
			ToggleDbgMenu();
			//Beep(1000,500);
		}
	}

	return __super::PreTranslateMessage(pMsg);
}

void CMainFrame::ToggleDbgMenu(void)
{
	MENUITEMINFO	menuInfo = {0};
	CMenu*			pMenu;
	int				pos = 3;
	CString			strMenu;

	pMenu = GetMenu();

	pMenu->GetMenuString(pos, strMenu, MF_BYPOSITION);

	if (strMenu != _T("DEBUG"))
	{	// Enable the debug menu
		m_MenuDbg.LoadMenu(IDR_MENU_DEBUG);
		pMenu->InsertMenu(pos, MF_BYPOSITION|MF_POPUP, (UINT_PTR) m_MenuDbg.GetSafeHmenu(), _T("DEBUG"));
		m_MenuDbg.Detach();

		// Refresh the menu bar
		ShowWindow(SW_HIDE);
		ShowWindow(SW_SHOW);
	}
	else
	{	// or disable the debug menu
		pMenu->DeleteMenu(pos, MF_BYPOSITION);

		// Refresh the menu bar
		ShowWindow(SW_HIDE);
		ShowWindow(SW_SHOW);
	}
}

void CMainFrame::OnUpdateFilewriteinhibitmode(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(DOC->GetRecorder()->GetWriteInhibit());
}

void CMainFrame::OnFilewriteinhibitmode()
{
	BOOL	bFlag = DOC->GetRecorder()->GetWriteInhibit();

	DOC->GetRecorder()->SetWriteInhibit(!bFlag);	// Invert the setting.

}

BOOL CMainFrame::OnQueryEndSession()
{
	BOOL	bEnd = TRUE;
	CShutdownDialog dlg;
	
	bEnd = (dlg.DoModal() == IDOK);

	return bEnd;
}

void CMainFrame::OnEndSession(BOOL bEnding)
{
	if (bEnding)
	{
		// Shut down the recording if it's in progress right now.
		DOC->SetRecord(FALSE);
	}

	CFrameWnd::OnEndSession(bEnding);
}

void CMainFrame::UpdateTitleBar(void)
{
// Add more info to the title bar.
	CVersion	version;
	CString		str, strDbg, strLite, strMod;
	str.Format(_T("V%s"), version.GetProductVersion());

#ifdef _DEBUG
	strDbg = _T(" (D)");
#endif

#ifdef _LITE
	strLite = _T(" (Lite)");
#endif

	strMod = DOC->IsModified() ? _T("*") : _T("");

	str += strDbg;
	str += strLite;
	m_strTitle.Format(_T("%sSR Pro %s"), strMod, str);
}
