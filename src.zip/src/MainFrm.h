// MainFrm.h : interface of the CMainFrame class
//


#pragma once
#include "stringmatcher.h"
class CMainFrame : public CFrameWnd
{
	
#define MAINFRAME ((CMainFrame*) GetParentFrame())

protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar		m_wndStatusBar;
	CStringMatcher	*m_pCodeString;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClose();
	afx_msg void OnMove(int x, int y);
	BOOL m_bPosLock;
	int m_ScreenSizeX;
	int m_ScreenSizeY;
	void Update(void);
	afx_msg void OnTestEnableconsole();
	afx_msg void OnUpdateTestEnableconsole(CCmdUI *pCmdUI);
	CMenu m_MenuDbg;
//	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnDestroy();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	void ToggleDbgMenu(void);
	afx_msg void OnUpdateHelpTestnewaboutmenu(CCmdUI *pCmdUI);
	afx_msg void OnHelpTestnewaboutmenu();
	afx_msg void OnUpdateFilewriteinhibitmode(CCmdUI *pCmdUI);
	afx_msg void OnFilewriteinhibitmode();
	//void RelayEvent(LPMSG pMsg);
	afx_msg BOOL OnQueryEndSession();
	afx_msg void OnEndSession(BOOL bEnding);
	void UpdateTitleBar(void);
};


