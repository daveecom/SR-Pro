#pragma once
#include "resource.h"
#include <afxwin.h>
#include "afxcmn.h"
//#include "o:\program files\microsoft platform sdk\include\mfc\afxwin.h"
//#include "o:\program files\microsoft platform sdk\include\mfc\afxwin.h"

// This is the maximum number of radio job items to allow if _LITE
#define LITE_MAX_JOB_ITEMS (2)


#define MAX_CMD_DELAY	(500)	// Max MS to wait before execute cmd
#define MAX_COM_TIMEOUT (10000)	// Com timout max user configurable value

typedef enum _eRadioType
{
	RadioType_None,
	RadioType_Icom,
	RadioType_Uniden,

	RadioType_NumTypes

}	RADIO_TYPE;

typedef enum _eRadioCommand
{
	RadioCmd_None,	RadioCmd_GLG,	RadioCmd_GID,
	RadioCmd_STS,	RadioCmd_PWR,	RadioCmd_MDL,
	RadioCmd_VER,	RadioCmd_VOL,	RadioCmd_SQL,
	RadioCmd_P25,	RadioCmd_BAV,	RadioCmd_WIN,

	RadioCmd_BL,		RadioCmd_CC,		RadioCmd_CS,
	RadioCmd_IC,		RadioCmd_LCD,		RadioCmd_LCD01,
	RadioCmd_LCD02,		RadioCmd_LCD03,		RadioCmd_LCD04,
	RadioCmd_LCD05,		RadioCmd_LCD06,		RadioCmd_LCD07,
	RadioCmd_LCD08,		RadioCmd_LCD09,		RadioCmd_LCD10,
	RadioCmd_LCD11,		RadioCmd_LCD12,		RadioCmd_LCD13,
	RadioCmd_LCD14,		RadioCmd_LCD15,		RadioCmd_LCD16,
	RadioCmd_LCD17,		RadioCmd_LCD18,		RadioCmd_LCD19,
	RadioCmd_LCD20,		RadioCmd_LCD21,		RadioCmd_LCD22,
	RadioCmd_LCD23,		RadioCmd_LCD24,		RadioCmd_LCD25,
	RadioCmd_LCD26,		RadioCmd_LCD27,		RadioCmd_LCD28,
	RadioCmd_LCD29,		RadioCmd_LCD30,		RadioCmd_LCD31,
	RadioCmd_LCD32,		RadioCmd_LCD33,		RadioCmd_LCD34,
	RadioCmd_LCD35,		RadioCmd_LCD36,		RadioCmd_LCD37,
	RadioCmd_LCD38,		RadioCmd_LCD39,		RadioCmd_LCD40,
	RadioCmd_LCDBNK,	RadioCmd_LCDCHN,	RadioCmd_LCDCTC,
	RadioCmd_LCDFRQ,	RadioCmd_LCDSMT,	RadioCmd_MA,
	RadioCmd_MD,		RadioCmd_RF,		RadioCmd_RM,
	RadioCmd_SG,		RadioCmd_SQ,		RadioCmd_TB,
	RadioCmd_VR,		RadioCmd_WI,		

	RadioCmd_IcomFrq,	RadioCmd_IcomLvl,

	RadioCmd_NumCmds		// Make sure this item is last.

}	RADIO_CMD;

//#define NUM_RADIO_CMDS (_eRadioCommand::numCmds)

class CRadioCommand : public CObject
{
	DECLARE_SERIAL(CRadioCommand)

public:
	CRadioCommand(RADIO_CMD eCmd, int Index = 0, int Delay = 0);
	CRadioCommand();
	~CRadioCommand();

protected:
	void		Reset(void);

public:

	virtual void	Serialize(CArchive& ar);

	RADIO_CMD		GetCmd(void);
	void			SetCmd(RADIO_CMD Cmd);

	int				GetIndex(void);
	void			SetIndex(int I);
	
	CString&		GetResult(void);
	void			SetResult(LPCTSTR lpszResult);

	void operator	=(CRadioCommand* pNew);

protected:
	////// Archive //////
	RADIO_CMD	m_eCmd;		// GLG, etc.
	int			m_nIndex;	// 0 = GLG[0], n = GLG[n].
	int			m_nDelayMS;	// Pre transmit delay (MS)
	////// Archive //////

	CString		m_strResult;	// Formatted for log
public:
	int GetDelay(void);
	void SetDelay(int nDelay);
};

typedef CArray<CRadioCommand*, CRadioCommand*> FETCH_ARRAY;

class CRadioSettings : public CObject
{
	DECLARE_SERIAL(CRadioSettings)

public:

			CRadioSettings();
	virtual ~CRadioSettings();

	void	Reset(void);

	void			AddJobItem(CRadioCommand* pNewItem);		// Create new fetch item and append it.
	void			DeleteJobItem(int iItem);
	void			SetJobItem(int iItem, CRadioCommand* pNewItem);	// Change the fetch setting for item(n)
	CRadioCommand*	GetJobItem(int iItem);
	BOOL			SwapJobItems(int iItem1, int iItem2); // Used to help move an item up or down in the list.

	int				GetJobItemCount(void);	// Gets # items in array
	void			ClearJobList(void);

	void			SetPort(int nPort);
	int				GetPort(void);

	void			SetBaud(DWORD dwBaud);
	DWORD			GetBaud(void);

	void			SetRadioType(RADIO_TYPE Type);
	RADIO_TYPE		GetRadioType(void);

	void			EnableRadio(BOOL bEnable);
	BOOL			IsRadioEnabled(void);

	void			SetHexMode(BOOL bEnable);
	BOOL			GetHexMode(void);

	DWORD			GetTimeout(void);
	void			SetTimeout(DWORD dwTimeout);



	virtual void	Serialize(CArchive& ar);

	void operator	=(CRadioSettings* pFrom);

protected:
	// Serial port
	DWORD			m_dwBaud;			// Baud rate
	RADIO_TYPE		m_eRadioType;		// Icom, Uniden, and maybe more some day.
	int				m_nPort;			// 1 = COM1, 2 = COM2, etc.
	BOOL			m_bRadioEnabled;	// Enables retrieval during record
	BOOL			m_bShowHex;			// Hex mode on/off (panel)
	DWORD			m_dwTimeout;		// COM timeout value (ms).
	BOOL			m_bCache;			// TRUE=Use reply caching.
	FETCH_ARRAY		m_JobList;
};

// CDlgRadioSettings dialog

class	CRadioInterface;

class CDlgRadioSettings : public CDialog
{
	DECLARE_DYNAMIC(CDlgRadioSettings)

public:
			CDlgRadioSettings(CWnd* pParent = NULL);   // standard constructor
	virtual	~CDlgRadioSettings();

// Dialog Data
	enum { IDD = IDD_DIALOG_RADIOSETTINGS };

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL	OnInitDialog();

	CRadioSettings*	GetRadioSettings(void);
	void			SetRadioSettings(CRadioSettings* pRadioSettings);
	void			SetRadioInterface(CRadioInterface* pInterface);

protected:
	virtual void	DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void	OnOK();

	void	UpdateCmdCombo(void);
	void	InitCombos(void);
	void	UpdateJobListbox(void);
	void	UpdateButtonStatus(void);

	afx_msg void	OnCbnSelchangeComboRadiotype();
	afx_msg void	OnBnClickedButtonAddtoJob();
	afx_msg void	OnBnClickedButtonDeleteall();
	afx_msg void	OnBnClickedButtonDelete();
	afx_msg void	OnBnClickedCheckAutofetch();
	afx_msg void	OnBnClickedCheckHex();
	afx_msg void	OnBnClickedButtonMoveup();
	afx_msg void	OnBnClickedButtonMovedown();
	afx_msg void	OnCbnSelchangeComboRadiocmd();
	afx_msg void	OnLbnSelchangeListLoglist();
	afx_msg void	OnBnClickedButtonTest();
	afx_msg void	OnCbnSelchangeComboComport();
	afx_msg void	OnCbnSelchangeComboBaud();
	afx_msg void	OnBnClickedButtonTestjob();
	virtual BOOL	PreTranslateMessage(MSG* pMsg);

	CListBox			m_Listbox_Job;
	CSpinButtonCtrl 	m_Spin_ReplyItemNumber;
	CStatic				m_Static_ReplyItemNumber;
	CEdit				m_Edit_ReplyArea;
	CButton				m_Check_Hex;
	CButton				m_Check_AutoFetch;
	CButton				m_Button_MoveUp;
	CButton				m_Button_MoveDn;
	CButton				m_Button_Delete;
	CButton				m_Button_DeleteAll;
	CButton				m_Button_TestCmd;
	CButton				m_Button_AddToJob;
	CButton				m_Check_Continuous;
	CButton				m_Button_Abort;
	CButton				m_Button_TestJob;
	CComboBox			m_Combo_ComPortNumber;
	CComboBox			m_Combo_RadioType;
	CRadioSettings		m_RadioSettings;
	CComboBox			m_Combo_BaudRate;
	CComboBox			m_Combo_RadioCmd;

	CRadioInterface*	m_pInterface;

	CToolTipCtrl		m_ToolTip;
	CEdit m_Edit_Delay;
public:
	void UpdateDelayIndicator(void);
protected:
	int m_nDelay;
public:
	afx_msg void OnEnKillfocusEditPredelay();
protected:
	CEdit m_Edit_Timeout;
public:
	afx_msg void OnEnKillfocusEditTimeout();
protected:
	void UpdateTimeoutControl();
	CEdit m_Edit_Reply_Parsed;
};
