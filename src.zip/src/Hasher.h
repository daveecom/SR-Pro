#pragma once



class CHasher : public CObject
{
public:
	CHasher();
	virtual ~CHasher();

protected:

#define PATTERN_SIZE_BYTES	128
#define PATTERN_SIZE_WORDS	(PATTERN_SIZE_BYTES		/ 2)
#define PATTERN_SIZE_DWORDS	(PATTERN_SIZE_WORDS		/ 2)
#define PATTERN_SIZE_ULL	(PATTERN_SIZE_DWORDS	/ 2)

typedef union	_uPattern
	{
		ULONGLONG	ull[PATTERN_SIZE_ULL];
		DWORD		dw[PATTERN_SIZE_DWORDS];
		WORD		wd[PATTERN_SIZE_WORDS];
		BYTE		b[PATTERN_SIZE_BYTES];

	}				PATTERN_BUFFER;

	PATTERN_BUFFER	m_Pattern;

	BOOL			m_bCarry;

public:
	// Shift the hash accumulator n bits
	void Shift(int nCount);
protected:
	BOOL ComputeCarry(BOOL bCarryIn);
public:
	void LoadKey(LPCTSTR lpszKeyIn);
	void LoadKey(LPBYTE lpKeyIn, int nSize);
	void ClearAll(void);
	LPCTSTR GetBufferAsHexString(void);
	LPCTSTR GetBufferAsHexStringWithBlanks(void);
protected:
	CString m_strOut;
};

