#pragma once
#include "audiofilter.h"

class CBufferFilter :
	public CAudioFilter
{
public:
	CBufferFilter(CAudioRecorder* pParent);
	~CBufferFilter(void);

	//virtual BOOL		Receive(RECBUFF * pRB, BOOL bGive = FALSE);
	virtual void		Flush();
	virtual void		PurgeBuffers(void);	// Returns storage of all buffers.

protected:
	RECBUFF*			m_pFillBuffer;		// Large fill buffer. Hold here until full or flushed.

	virtual void		ProcessDataBuffer(RECBUFF* pRB);
};
