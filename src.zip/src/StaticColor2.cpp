// StaticColor2.cpp : implementation file
//

#include "stdafx.h"

#include ".\StaticColor2.h"


// CStaticColor2

IMPLEMENT_DYNAMIC(CStaticColor2, CWnd)
CStaticColor2::CStaticColor2()
{
	m_strWindowText.Empty();

	m_iBlink		= 0;
	m_colorBk[0]	= GetSysColor(COLOR_BTNFACE);
	m_colorBk[1]	= GetSysColor(COLOR_BTNFACE);
	m_colorText[0]	= GetSysColor(COLOR_BTNTEXT);
	m_colorText[1]	= GetSysColor(COLOR_BTNTEXT);

	//m_Font.CreateFont(-12, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
	//	OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
	//	_T("Sans Serif"));

}

CStaticColor2::~CStaticColor2()
{
}


BEGIN_MESSAGE_MAP(CStaticColor2, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_MESSAGE(WM_SETFONT, OnSetFont)
	ON_MESSAGE(WM_SETTEXT, OnSetText)
	ON_WM_TIMER()
END_MESSAGE_MAP()

// CStaticColor2 message handlers


void CStaticColor2::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CRect		rect;
	CString		str;
	GetClientRect(rect);
	GetWindowText(str);
	CDC*		pDC;
	CDC			dcMem;

	if (!IsWindowEnabled()) return;	// prevent drawing if disabled

	pDC			= GetDC();
	dcMem.CreateCompatibleDC(pDC);
	ReleaseDC(pDC);
	GetClientRect(&rect);

	dcMem.SaveDC();

	dcMem.SelectObject(&m_bmMem);
	if (m_hFont != NULL) dcMem.SelectObject(m_hFont);
	dcMem.SetBkMode(TRANSPARENT);

	dcMem.FillSolidRect(rect, m_colorBk[m_iBlink]);

	dcMem.SetTextColor(m_colorText[m_iBlink]);
	dcMem.DrawText(str, rect  , m_fDrawStyle);
	dc.BitBlt(0, 0, rect.Width(), rect.Height(), &dcMem, 0, 0, SRCCOPY);

	dcMem.RestoreDC(-1);
}

void CStaticColor2::SetTextColor(COLORREF color1, COLORREF color2, BOOL bRedraw)
{
	m_colorText[0] = color1;
	m_colorText[1] = color2;

	if (bRedraw) Invalidate();
}

void CStaticColor2::SetBkColor(COLORREF color1, COLORREF color2, BOOL bRedraw)
{
	m_colorBk[0] = color1;
	m_colorBk[1] = color2;

	if (bRedraw) Invalidate();
}

void CStaticColor2::SetTextColor(COLORREF color, BOOL bRedraw)
{
	m_colorText[0] = color;
	m_colorText[1] = color;

	if (bRedraw) Invalidate();
}

void CStaticColor2::SetBkColor(COLORREF color, BOOL bRedraw)
{
	m_colorBk[0] = color;
	m_colorBk[1] = color;

	if (bRedraw) Invalidate();
}

void CStaticColor2::SetWindowText(LPCTSTR lpszString)
{
	if (_tcscmp(lpszString, m_strWindowText) != 0)
	{
		m_strWindowText = lpszString;
		__super::SetWindowText(lpszString);
		Invalidate();
	}
}

void CStaticColor2::GetWindowText(CString& rString) const
{
	rString = m_strWindowText;
}

void CStaticColor2::SetFont(CFont* pFont, BOOL bRedraw)
{
	if (pFont != NULL)
	if (pFont->GetSafeHandle() != NULL)
	m_hFont = (HFONT) pFont->GetSafeHandle();
}

BOOL CStaticColor2::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void CStaticColor2::PreSubclassWindow()
{
	DWORD	dwStyle;
	BOOL	bLeft;
	BOOL	bCenter;
	BOOL	bRight;
	BOOL	bWrap;
	CRect	rect;

	// Disable double click sensitivity
	SetClassLong(GetSafeHwnd(), GCL_STYLE, GetClassLong(GetSafeHwnd(), GCL_STYLE) & ~CS_DBLCLKS);

	GetClientRect(&rect);
	dwStyle	= ::GetWindowLong(GetSafeHwnd(), GWL_STYLE);

	bLeft	= (dwStyle & SS_LEFT)		!= 0;
	bCenter	= (dwStyle & SS_CENTER)		!= 0;
	bRight	= (dwStyle & SS_RIGHT)		!= 0;
	bWrap	= (dwStyle & SS_LEFTNOWORDWRAP)	!= SS_LEFTNOWORDWRAP;

	m_fDrawStyle	= 0;
	m_fDrawStyle	|= bCenter	? DT_CENTER		:	0;
	m_fDrawStyle	|= bWrap	? DT_WORDBREAK	:	0;

	// Create a new memory bitmap to use for dbl buffering.
	CDC*		pDC		= GetDC();

	m_bmMem.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());

	ReleaseDC(pDC);

	SetTimer(0, 400, NULL);

	__super::PreSubclassWindow();
}

//#define SS_LEFT             0x00000000L
//#define SS_CENTER           0x00000001L
//#define SS_RIGHT            0x00000002L
//#define SS_SIMPLE           0x0000000BL
//#define SS_LEFTNOWORDWRAP   0x0000000CL
//#define SS_CENTERIMAGE      0x00000200L
//#define SS_RIGHTJUST        0x00000400L
//#define SS_SUNKEN           0x00001000L
//#define SS_EDITCONTROL      0x00002000L
//#define SS_ENDELLIPSIS      0x00004000L
//#define SS_PATHELLIPSIS     0x00008000L
//#define SS_WORDELLIPSIS     0x0000C000L
//#define SS_ELLIPSISMASK     0x0000C000L

//#define DT_TOP                      0x00000000
//#define DT_LEFT                     0x00000000
//#define DT_CENTER                   0x00000001
//#define DT_RIGHT                    0x00000002
//#define DT_VCENTER                  0x00000004
//#define DT_BOTTOM                   0x00000008
//#define DT_WORDBREAK                0x00000010
//#define DT_SINGLELINE               0x00000020
//#define DT_EXPANDTABS               0x00000040
//#define DT_TABSTOP                  0x00000080
//#define DT_NOCLIP                   0x00000100
//#define DT_EXTERNALLEADING          0x00000200
//#define DT_CALCRECT                 0x00000400
//#define DT_NOPREFIX                 0x00000800
//#define DT_INTERNAL                 0x00001000

LRESULT	CStaticColor2::OnSetFont(WPARAM wParam, LPARAM lParam)
{
	m_hFont = (HFONT) wParam;

	return 0;
}

LRESULT	CStaticColor2::OnSetText(WPARAM wParam, LPARAM lParam)
{
	return TRUE;
}


void CStaticColor2::OnTimer(UINT nIDEvent)
{
	m_iBlink = (++m_iBlink % 2);
	if (m_colorBk[0] != m_colorBk[1] ||
		m_colorText[0] != m_colorText[1])
	{
		Invalidate();
	}
}
