#pragma once
#include "audiocapturenew.h"
#include "audiofilter.h"
#include "filewriterfilter.h"
#include "wavefilewriterfilter.h"
#include "voxfilter.h"
#include "filenameserver.h"
#include "acmfilter.h"
#include "bufferfilter.h"
#include "logfile.h"
#include "comport.h"
#include "channelfilter.h"
#include "miscfilters.h"
#include "ccs.h"
#include "RadioInterface.h"

typedef enum _eRecorderState
{
	Stopped		= 0,		// Not recording
	Recording				// Recording
}	RECORDER_STATE;

typedef enum _ePauseState
{
	Running		= 0,		// Not paused
	Paused					// Paused
}	PAUSE_STATE;

class CAudioRecorder
{

friend class Doc;

public:

	CAudioRecorder(void);
	~CAudioRecorder(void);

	void				GetScanInfo(SCAN_INFO* lpScanInfo);

	// Create a recorder for recording mono and stereo to an output file.
	BOOL Create(CAudioSettings* pAudioSettings,	// For Capture/Preview, compress
		CFilenameServer*	pFilenameServer,	// Use this to set our internal server.
		BOOL				bRecord,			// Start recording immediately
		BOOL				bPause,				// Start paused. Ignored if VOX active.
		BOOL				bVox,				// Activate VOX mode.
		float				VoxValue_L,			// Initial Vox setting. 0 - 100
		DWORD				dwHangtime			// Vox 1 hang time.
	);

	BOOL				Destroy();	// Called by destructor or in case mode change is needed.
	void				StartCapture(void);
	void				StopCapture(void);

	void				SetPause(BOOL bPause);
	void				SetNewFormat(CAudioSettings* pAudioSettings);
	void				SetVox(float Left);
	void				SetVoxOn(BOOL bVoxOn);	// Turn vox on or off. Off bypasses vox logic.
	void				SetRolloverVoxMode(bool bEnable);
	void				SetRolloverElapsedTime(int HH, int MM, int SS, BOOL bTODSync = FALSE);
	void				SetRolloverRelativeTime(int HH, int MM, int SS = 0);
	void				SetRolloverRelativeSamples(ULONGLONG nSamples);
	void				SetChannelParms(CHANNEL_PARMS Parms);
	void				SetHangTime1(DWORD dwHangtime);

	BOOL				IsVoxGateOpen(void);
	BOOL				IsInit(void);

	ULONGLONG			GetStoredSampleCount(void);
	FILETIME			GetEventStart(void);
	//FILETIME			GetEventEnd(void);
	FILETIME			GetEventDuration(void);
	FILETIME			GetStoredTime(void);
	DWORD				GetBufferTimeMeasuredMS(void);
	DWORD				GetBufferTimeMS(void);
	CFilenameServer*	GetFilenameServer(void);
	BOOL				GetRolloverVoxMode(void);
	CHANNEL_PARMS		GetChannelParms(void);
	DWORD				GetDroppedFrames(void);
	int					GetAllocatedBufferCount(void);

	void				Nukedownstream(CAudioFilter * pFilter);
	void				Dump(void);
	void				ResetDroppedFrames(void);
	BOOL				GetWriteInhibit(void);
	void				SetWriteInhibit(BOOL bInhibit);
	void				SplitterNeedToSplit(void);
	void				StartRolloverTimer(void);
	void				KillRolloverTimer(void);
	RECORDER_STATE		GetRecorderState(void);
	void				SetRolloverVoxSync(BOOL bEnable);
	BOOL				GetSplitterState(void);
	void				EnableLogfile(BOOL bEnable);
	void				SetRadioSettings(CRadioSettings* pSettings);

protected:
	void				SplitterHandler(void);
	BOOL				SetRecord(BOOL bRecord);	// Only callable from Document.
	BOOL				Reset();	// Called by contructor. Puts the object in pre-create state.
	static void __cdecl SplitterProc( void * p);
	static BOOL __stdcall AlarmCB(CAlarmClock* pThis, DWORD_PTR dwUserData);

	BOOL				m_bInit;				// Indicates this object is ready to use. (Created)
	DWORD				m_dwValid;				// Used to validate this object (see IsInit()

	// Filters //
	CAudioCaptureNew*	m_pCaptureFilter;		// Audio capture
	CChannelFilter*		m_pChannelFilter;		// Channel Converter
	CAudioFilter*		m_pMeterFilter;			// Collects scan info
	CVoxFilter*			m_pVoxFilter;			// Vox filter
	CAudioFilter*		m_pDummyFilter1;		// Pre - RGF for bug isolation.
	CRecordGateFilter*	m_pRecordGateFilter;	// Recorder Gate
	CAudioFilter*		m_pDummyFilter2;		// Post - RGF for bug isolation.
	CBufferFilter*		m_pBufferFilter;		// Buffer filter.
	CAcmFilter*			m_pCompressor;			// Compressor
	CFileWriterFilter*	m_pFileWriter;			// File writer used for output.
	/////////////

	//CFilenameServer*	m_pFilenameServer;
	CAudioSettings*		m_pAudioSettings;		// Current audio settings.

	RECORDER_STATE		m_State;				// Recorder state
	CHANNEL_PARMS		m_ChannelParms;

	BOOL				m_bSplitStarted;
	CSection			m_csSplitterLock;

	CAlarmClock			m_RolloverTimer;		// Used with elapsed time rollover mode.

	UFT					m_uRolloverElapsed;		// split file using elapsed timer.
	BOOL				m_bRolloverTODSync;		// split file based on top of hour sync
	BOOL				m_bRolloverVoxSync;		// Sync to VOX if VOX is on.

	CLogFileWriter		m_LogFile;

	CRadioInterface		m_RadioInterface;
	CRadioSettings*		m_pRadioSettings;
};
