#pragma once
#include "afxcmn.h"
#include "afxwin.h"
#include "doc.h"

// CDlgOptions dialog

class CDlgOptions : public CDialog
{
	DECLARE_DYNAMIC(CDlgOptions)

public:
	CDlgOptions(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgOptions();
	virtual BOOL OnInitDialog();

	Doc *m_pDoc;

protected:
	enum { IDD = IDD_DIALOG_VOXSETTINGS };
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//afx_msg void OnEnKillfocusEditHangtime();

	DECLARE_MESSAGE_MAP()

	CSpinButtonCtrl m_Spin_Hangtime;
	CEdit m_Edit_Hangtime;
	void Update(void);
	BOOL m_bDirty;
	virtual void OnOK();
public:
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
protected:
	CButton m_Check_EnableLog;

protected:
	CToolTipCtrl	m_ToolTip;
public:
	afx_msg void OnBnClickedCheckEnablelog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDeltaposSpinHangtime(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnKillfocusEditHangtime();
};
