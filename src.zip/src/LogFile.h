#pragma once

#include "radiointerface.h"

#define		UWM_ADD_MINILOG		WM_USER + 10
#define		UWM_RESET_MINILOG	WM_USER + 11

class CLogFileWriter
{

public:

	CLogFileWriter(void);
	~CLogFileWriter(void);

	BOOL		CreateLog(LPCTSTR lpszFilePath);
	void		CloseLog(void);
	void		NewEntry(FILETIME tTime);
	void		SetFreq(LPCTSTR lpszFreq);
	void		SetTrigChan(LPCTSTR lpszChannel);
	void		SetDuration(FILETIME tDuration);
	void		WriteEntry(void);
	void		SetRelativeTime(FILETIME tTime);
	void		SetHWND(HWND hMiniLog);
	void		SetSMeter(int nValue);
	void		SetFileOffset(ULONGLONG nOffset);
	void		Enable(BOOL bEnabled = TRUE);

protected:

	UFT			m_tLogCreated;
	CString		m_strFilePath;
	HANDLE		m_hFile;
	CString		m_strFreq;
	CString		m_strTrigChan;
	CString		m_strMiniLog;
	HWND		m_hMiniLog;
	UFT			m_tEvtStart;
	UFT			m_tEvtDur;
	UFT			m_tRelative;
	ULONGLONG	m_nSampleOffset;
	DWORD		m_nEventNumber;
	int			m_sMeter;
	ULONGLONG	m_nFileOffset;

	BOOL		m_bEnable;		// Log file is authorized to write to disk file.
public:
	LPCTSTR GetGreq(void);
	int GetSMeter(void);
	UFT GetStart(void);
protected:
	CRadioInterface* m_pRadioInterface;
public:
	void SetRadioInterface(CRadioInterface* pRadio);
	void SetRadioSettings(CRadioSettings* pRadioSettings);
protected:
	CRadioSettings* m_pRadioSettings;
public:
	void SetSampleOffset(ULONGLONG nSamples);
};
