// DlgChannel.cpp : implementation file
//

#include "stdafx.h"
#include "DlgChannel.h"
#include ".\dlgchannel.h"


// CDlgChannel dialog

IMPLEMENT_DYNAMIC(CDlgChannel, CDialog)
CDlgChannel::CDlgChannel(CWnd* pParent /*=NULL*/)
: CDialog(CDlgChannel::IDD, pParent)
, m_Radio_Mode(0)
, m_lpwfCapture(NULL)
{
}

CDlgChannel::~CDlgChannel()
{
	if (m_lpwfCapture != NULL)
	{
		delete [] m_lpwfCapture;
		m_lpwfCapture = NULL;
	}
}

void CDlgChannel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO_CONVERTEROFF, m_Radio_Mode);
	DDX_Control(pDX, IDC_CHECK_MUTECH1, m_Check_MuteCh1);
	DDX_Control(pDX, IDC_CHECK_MUTECH2, m_Check_MuteCh2);
	DDX_Control(pDX, IDC_STATIC_DIAGRAM, m_Static_Diagram);
}


BEGIN_MESSAGE_MAP(CDlgChannel, CDialog)
	ON_BN_CLICKED(IDC_RADIO_CONVERTEROFF, OnBnClickedRadioMode)
	ON_BN_CLICKED(IDC_RADIO_CONVERTERM2S, OnBnClickedRadioMode)
	ON_BN_CLICKED(IDC_RADIO_CONVERTERS2M, OnBnClickedRadioMode)
	ON_BN_CLICKED(IDC_RADIO_CONVERTERSWAP, OnBnClickedRadioMode)
	ON_BN_CLICKED(IDC_RADIO_CONVERTERL2S, OnBnClickedRadioMode)
	ON_BN_CLICKED(IDC_RADIO_CONVERTERR2S, OnBnClickedRadioMode)
	ON_BN_CLICKED(IDC_CHECK_MUTECH1, OnBnClickedCheckMute)
	ON_BN_CLICKED(IDC_CHECK_MUTECH2, OnBnClickedCheckMute)
END_MESSAGE_MAP()



BOOL CDlgChannel::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_ToolTip.Create(this);

	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_CONVERTEROFF),	_T("Turn off the channel converter"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_CONVERTERM2S),	_T("Convert mono input to stereo"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_CONVERTERS2M),	_T("Convert stereo input to mono"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_CONVERTERSWAP),	_T("Swap left and right channels"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_CONVERTERL2S),	_T("Copy left channel to both channels"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_CONVERTERR2S),	_T("Copy right channel to both channels"));

	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_MUTECH1),		_T("Mute the left/mono channel before conversion"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_MUTECH2),		_T("Mute the right channel before conversion"));

	Update();

	return TRUE;
}

void CDlgChannel::OnOK()
{
	// User wants to keep the current parms.
	UpdateData();
	m_ChannelParms.m_Mode = (CHANNEL_MODE) m_Radio_Mode;
	m_ChannelParms.m_bMuteCh1 = (m_Check_MuteCh1.GetCheck() == BST_CHECKED);
	m_ChannelParms.m_bMuteCh2 = (m_Check_MuteCh2.GetCheck() == BST_CHECKED);

	CDialog::OnOK();
}

CHANNEL_PARMS CDlgChannel::GetChannelParms(void)
{
	return m_ChannelParms;
}

void CDlgChannel::SetChannelParms(CHANNEL_PARMS Parms)
{
	m_ChannelParms = Parms;
}

void CDlgChannel::Update(void)
{
	m_Radio_Mode = m_ChannelParms.m_Mode;
	m_Check_MuteCh1.SetCheck(m_ChannelParms.m_bMuteCh1 ? BST_CHECKED:BST_UNCHECKED);
	m_Check_MuteCh2.SetCheck(m_ChannelParms.m_bMuteCh2 ? BST_CHECKED:BST_UNCHECKED);

	GetDlgItem(IDC_RADIO_CONVERTERM2S)->EnableWindow(m_lpwfCapture->nChannels == 1);
	GetDlgItem(IDC_RADIO_CONVERTERS2M)->EnableWindow(m_lpwfCapture->nChannels == 2);
	GetDlgItem(IDC_RADIO_CONVERTERSWAP)->EnableWindow(m_lpwfCapture->nChannels == 2);
	GetDlgItem(IDC_RADIO_CONVERTERL2S)->EnableWindow(m_lpwfCapture->nChannels == 2);
	GetDlgItem(IDC_RADIO_CONVERTERR2S)->EnableWindow(m_lpwfCapture->nChannels == 2);

	m_Check_MuteCh2.EnableWindow(m_lpwfCapture->nChannels == 2);

	if (m_BM_Channel.GetSafeHandle() != NULL)
		m_BM_Channel.DeleteObject();

	switch(m_Radio_Mode)
	{
		case Channel_Normal:
			m_BM_Channel.LoadBitmap(IDB_BITMAP_CHANNEL_OFF);
			m_Static_Diagram.SetBitmap(m_BM_Channel);
			break;

		case Channel_MonoToStereo:
			m_BM_Channel.LoadBitmap(IDB_BITMAP_CHANNEL_M2S);
			m_Static_Diagram.SetBitmap(m_BM_Channel);
			break;

		case Channel_StereoToMono:
			m_BM_Channel.LoadBitmap(IDB_BITMAP_CHANNEL_S2M);
			m_Static_Diagram.SetBitmap(m_BM_Channel);
			break;

		case Channel_Swap:
			m_BM_Channel.LoadBitmap(IDB_BITMAP_CHANNEL_SWAP);
			m_Static_Diagram.SetBitmap(m_BM_Channel);
			break;

		case Channel_LeftToStereo:
			m_BM_Channel.LoadBitmap(IDB_BITMAP_CHANNEL_L2S);
			m_Static_Diagram.SetBitmap(m_BM_Channel);
			break;

		case Channel_RightToStereo:
			m_BM_Channel.LoadBitmap(IDB_BITMAP_CHANNEL_R2S);
			m_Static_Diagram.SetBitmap(m_BM_Channel);
			break;
	}

	// Overlay the mask image onto the converter image.
	CDC			*pDC, dcSrc, dcDst;
	CBitmap		bmMask;
	BITMAP		bitmap = {0};

	m_BM_Channel.GetObject(sizeof(BITMAP), &bitmap);
	pDC = GetDC();
	dcSrc.CreateCompatibleDC(pDC);
	dcDst.CreateCompatibleDC(pDC);
	ReleaseDC(pDC);
	dcSrc.SaveDC();
	dcDst.SaveDC();

	if (m_ChannelParms.m_bMuteCh1)
	{
		bmMask.DeleteObject();

		if (m_ChannelParms.m_Mode == Channel_MonoToStereo)
			bmMask.LoadBitmap(IDB_BITMAP_CHANNEL_MASKCENTER);
		else
			bmMask.LoadBitmap(IDB_BITMAP_CHANNEL_MASKLEFT);

		dcSrc.SelectObject(&bmMask);
		dcDst.SelectObject(&m_BM_Channel);
		dcDst.BitBlt(0, 0, bitmap.bmWidth, bitmap.bmHeight, &dcSrc, 0, 0, SRCAND);
	}
	if (m_ChannelParms.m_bMuteCh2)
	{
		bmMask.DeleteObject();
		bmMask.LoadBitmap(IDB_BITMAP_CHANNEL_MASKRIGHT);
		dcSrc.SelectObject(&bmMask);
		dcDst.SelectObject(&m_BM_Channel);
		dcDst.BitBlt(0, 0, bitmap.bmWidth, bitmap.bmHeight, &dcSrc, 0, 0, SRCAND);
	}

	dcDst.RestoreDC(-1);
	dcSrc.RestoreDC(-1);

	UpdateData(FALSE);
	m_Static_Diagram.Invalidate();
}

// By getting the WF, we can decide how to restrict radio button choioces.
void CDlgChannel::SetWFCap(LPWAVEFORMATEX lpWFIn)
{
	if (m_lpwfCapture != NULL)
	{
		delete [] m_lpwfCapture;
		m_lpwfCapture = NULL;
	}

	m_lpwfCapture = (LPWAVEFORMATEX) new BYTE[sizeof(WAVEFORMATEX) + lpWFIn->cbSize];
	ASSERT(m_lpwfCapture != NULL);

	CopyMemory(m_lpwfCapture, lpWFIn, sizeof(WAVEFORMATEX) + lpWFIn->cbSize);
}

BOOL CDlgChannel::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
		m_ToolTip.RelayEvent(pMsg);

	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgChannel::OnBnClickedRadioMode()
{
	UpdateData(TRUE);

	m_ChannelParms.m_Mode = (CHANNEL_MODE) m_Radio_Mode;

	Update();
}

void CDlgChannel::OnBnClickedCheckMute()
{
	m_ChannelParms.m_bMuteCh1 = m_Check_MuteCh1.GetCheck() == BST_CHECKED;
	m_ChannelParms.m_bMuteCh2 = m_Check_MuteCh2.GetCheck() == BST_CHECKED;

	Update();
}
