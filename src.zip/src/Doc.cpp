// Doc.cpp : implementation of the Doc class
//

#include "stdafx.h"
#include "App.h"

#include "MainView.h"
#include ".\doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Doc

IMPLEMENT_DYNCREATE(Doc, CDocument)

BEGIN_MESSAGE_MAP(Doc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_TEST_DUMPFILTERSTATS, OnUpdateTestDumpfilterstats)
	ON_COMMAND(ID_TEST_DUMPFILTERSTATS, OnTestDumpfilterstats)
	ON_UPDATE_COMMAND_UI(ID_TEST_CHECKPOINTFILE, OnUpdateTestCheckpointfile)
	ON_COMMAND(ID_TEST_CHECKPOINTFILE, OnTestCheckpointfile)
END_MESSAGE_MAP()


// Doc construction/destruction

Doc::Doc()
: m_pRecorder(NULL)
{
	SetDefaultValues();

	m_uRecordStartTime.ll = 0;
}

Doc::~Doc()
{
	if (m_pRecorder->IsInit())
		StopAudioEngine();

	//CloseComPort();
}

BOOL Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	SetDefaultValues();

	m_RadioSettings.Reset();


	if (m_pRecorder->IsInit()) StopAudioEngine();
	StartAudioEngine();

	m_Scheduler.ClearArray();

	// Move the focus away from the vox or hang time indicators. This allows the
	// Initial updating of the edit controllers to their proper values.
	POSITION pos = GetFirstViewPosition();
	((CMainView*) GetNextView(pos))->MoveFocusAwayFromEditBoxes();

	return TRUE;
}

void Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_bRecord;
		ar << m_bPause;
		//ar << m_bAutoSaveFile;
		ar << FALSE;	// Force autosave to be off....for now.
		ar << m_bTimerRecordArmed;

		ar << m_bVox1;
		ar << m_bVox2;
		ar << m_VoxVal1_L;
		ar << m_VoxVal1_R;
		ar << m_dwHang1;

		ar << m_strScheduleFile;
		m_Scheduler.SetFile(m_strScheduleFile);
		m_Scheduler.Save();

		m_AudioSettings.Serialize(ar);

		m_FilenameServer1.Serialize(ar);

		ar << m_bGenerateLogFile;

		m_RadioSettings.Serialize(ar);
	}
	else	// loading
	{
		ar >> m_bRecord;
		ar >> m_bPause;
		ar >> m_bAutoSaveFile;
		ar >> m_bTimerRecordArmed;

		ar >> m_bVox1;
		ar >> m_bVox2;			// placeholder
		ar >> m_VoxVal1_L;
		ar >> m_VoxVal1_R;		// placeholder
		ar >> m_dwHang1;

		ar >> m_strScheduleFile;
		m_Scheduler.SetFile(m_strScheduleFile);
		m_Scheduler.Load();

		m_AudioSettings.Serialize(ar);

		m_FilenameServer1.Serialize(ar);

		ar >> m_bGenerateLogFile;

		m_RadioSettings.Serialize(ar);
	}


	// If timer recording is enabled and the record button is
	// saved in the down position, turn the record button off.
	// Let the timer record logic decide if the record button
	// should be down or not.
	if (ar.IsLoading() && m_bTimerRecordArmed && m_bRecord)
	{
		m_bRecord = FALSE;
	}

#ifdef _LITE
	m_bRecord = FALSE;	// Auto start recording not avail on LITE version
#endif

}

void Doc::StartAudioEngine(void)
{
	BOOL	rc;

	CCS		Lock(&m_csRecorder);

	if (m_pRecorder == NULL)
		m_pRecorder = new CAudioRecorder;

	//rc = m_pRecorder->Create(&m_AudioSettings, &m_FilenameServer1, m_bRecord, m_bPause, m_bVox1, m_VoxVal1_L, /*m_VoxVal1_R, */&m_LogFile, &m_PortIcom, m_dwHang1);
	rc = m_pRecorder->Create(&m_AudioSettings, &m_FilenameServer1, m_bRecord, m_bPause, m_bVox1, m_VoxVal1_L, m_dwHang1);
	if (rc)
	{
		switch(m_FilenameServer1.GetFileSettings()->m_eLimMode)
		{
			case lim_Off:
				GetRecorder()->SetRolloverVoxMode(FALSE);
				GetRecorder()->SetRolloverVoxSync(FALSE);
				break;

			case lim_event:
				GetRecorder()->SetRolloverVoxMode(TRUE);
				GetRecorder()->SetRolloverVoxSync(FALSE);
				break;

			case lim_duration:
				GetRecorder()->SetRolloverRelativeTime(m_FilenameServer1.GetFileSettings()->m_LimHH, m_FilenameServer1.GetFileSettings()->m_LimMM);
				GetRecorder()->SetRolloverVoxSync(m_FilenameServer1.GetFileSettings()->m_bVoxSync);
				break;

			case lim_clock:
				GetRecorder()->SetRolloverElapsedTime(m_FilenameServer1.GetFileSettings()->m_LimHH,
					m_FilenameServer1.GetFileSettings()->m_LimMM,
					0,	// Seconds
					m_FilenameServer1.GetFileSettings()->m_bLimSyncTOD);
				GetRecorder()->SetRolloverVoxSync(m_FilenameServer1.GetFileSettings()->m_bVoxSync);
				break;
		}	// switch

		// Give the radio settings pointer to the engine.
		GetRecorder()->SetRadioSettings(&m_RadioSettings);
	}
	else
	{
		StopAudioEngine();
	}
	
}

void Doc::StopAudioEngine(void)
{
	CCS		Lock(&m_csRecorder);

	if (m_pRecorder != NULL)
	{
		delete m_pRecorder;
		m_pRecorder = NULL;
	}
}

// Doc diagnostics

#ifdef _DEBUG
void Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// Doc commands

BOOL Doc::OnOpenDocument(LPCTSTR lpszPathName)
{

	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	//if (m_bRadioEnable)
	//	OpenComPort();
	//else
	//	CloseComPort();

	if (m_pRecorder->IsInit()) StopAudioEngine();

	StartAudioEngine();

	SetPause(m_bPause);
	SetRecord(m_bRecord);

	// Move the focus away from the vox or hang time indicators. This allows the
	// Initial updating of the edit controllers to their proper values.
	POSITION pos = GetFirstViewPosition();
	((CMainView*) GetNextView(pos))->MoveFocusAwayFromEditBoxes();

	return TRUE;
}

BOOL Doc::SaveModified()
{
	CString name;
	CString prompt;
	CString	unsaved;

	if (!IsModified())
		return TRUE;        // ok to continue

	unsaved.LoadString(AFX_IDS_UNTITLED);

	// get name/title of document
	if (m_strPathName.IsEmpty())
	{
		// get name based on caption
		name = m_strTitle;
		if (name.IsEmpty())
			VERIFY(name.LoadString(AFX_IDS_UNTITLED));
	}
	else
	{
		// get name based on file title of path name
		name = m_strPathName;
		GetFileTitle(m_strPathName, name.GetBuffer(_MAX_PATH), _MAX_PATH);
		name.ReleaseBuffer();
	}

	if (m_bAutoSaveFile)
	{
		if (name != unsaved)
		{
			return DoFileSave();
		}
	}

	AfxFormatString1(prompt, AFX_IDP_ASK_TO_SAVE, name);
	switch (AfxMessageBox(prompt, MB_YESNOCANCEL, AFX_IDP_ASK_TO_SAVE))
	{
	case IDCANCEL:
		return FALSE;       // don't continue

	case IDYES:
		// If so, either Save or Update, as appropriate
		if (!DoFileSave())
			return FALSE;       // don't continue
		break;

	case IDNO:
		// If not saving changes, revert the document
		break;

	default:
		ASSERT(FALSE);
		break;
	}
	return TRUE;    // keep going
}

void Doc::SetDefaultValues(void)
{
	CCS Lock(&m_csRecorder);

	m_bRecord			= FALSE;
	m_bPause			= FALSE;
	m_bAutoSaveFile		= FALSE;
	m_bTimerRecordArmed	= FALSE;

	m_AudioSettings.SetDefaults();
	m_FilenameServer1.SetDefaults();

	m_bVox1				= FALSE;
	m_bVox2				= FALSE;
	m_VoxVal1_L			= 10;
	m_VoxVal1_R			= 0;
	m_dwHang1			= 500;

	m_bGenerateLogFile	= TRUE;

	m_strScheduleFile	= _T(".\\Default.SRSchedule");
}

void Doc::OnUpdateTestDumpfilterstats(CCmdUI *pCmdUI)
{
	CCS Lock(&m_csRecorder);

	pCmdUI->Enable(m_pRecorder->IsInit());
}

void Doc::OnTestDumpfilterstats()
{
	CCS Lock(&m_csRecorder);

	m_pRecorder->Dump();
}

CAudioRecorder* Doc::GetRecorder(void)
{
	return m_pRecorder;
}

CScheduleController* Doc::GetScheduler(void)
{
	return &m_Scheduler;
}

// Call this function to start/stop recordings.
void Doc::SetRecord(BOOL bRecord)
{
	CAlarmClock	clock;
	CAudioRecorder*	pRecorder = GetRecorder();
	ASSERT(pRecorder != NULL);

	CCS	Lock(&m_csRecorder);

	if (pRecorder->IsInit())
	{
		pRecorder->EnableLogfile(m_bGenerateLogFile);
		pRecorder->SetRecord(bRecord);
		if (bRecord)
			m_uRecordStartTime = clock.GetTime();
		else
			m_uRecordStartTime.ll = 0;

	}
}

DWORD Doc::GetDroppedFrames(void)
{
	DWORD	dwDropped = 0;

	CCS Lock(&m_csRecorder);

	if (GetRecorder()->IsInit())
		dwDropped = GetRecorder()->GetDroppedFrames();

	return dwDropped;
}

int Doc::GetAllocatedBufferCount(void)
{
	int	nAlloc = 0;

	CCS Lock(&m_csRecorder);

	if (GetRecorder()->IsInit())
		nAlloc = GetRecorder()->GetAllocatedBufferCount();

	return nAlloc;
}

void Doc::GetScanInfo(SCAN_INFO* pInfo)
{
	CCS Lock(&m_csRecorder);

	if (GetRecorder()->IsInit())
		GetRecorder()->GetScanInfo(pInfo);
	else
		ZeroMemory(pInfo, sizeof(SCAN_INFO));
}

void Doc::CheckpointFile(void)
{
	CCS Lock(&m_csRecorder);

	if (GetRecorder()->IsInit())
		if (GetRecorder()->GetRecorderState() == Recording)
			GetRecorder()->SplitterNeedToSplit();
}

void Doc::OnUpdateTestCheckpointfile(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetRecorder()->IsInit());
}

void Doc::OnTestCheckpointfile()
{
	CheckpointFile();
}

void Doc::SetPause(BOOL bPause)
{
	CCS	Lock(&m_csRecorder);

	if (GetRecorder()->IsInit())
	{
		GetRecorder()->SetPause(bPause);
	}
}

void Doc::SetVox(float fValue)
{
	CCS	Lock(&m_csRecorder);

	if (GetRecorder()->IsInit())
	{
		m_VoxVal1_L = fValue;
		GetRecorder()->SetVox(fValue);
		SetModifiedFlag();
	}
}

BOOL Doc::OnSaveDocument(LPCTSTR lpszPathName)
{
	// For now, set the default schedule name to our file name.

	m_strScheduleFile = lpszPathName;
	m_strScheduleFile = m_strScheduleFile.Left(m_strScheduleFile.ReverseFind('.'));
	m_strScheduleFile += _T(".SRSchedule");

	m_Scheduler.SetFile(m_strScheduleFile);

	return CDocument::OnSaveDocument(lpszPathName);
}

void Doc::SetTitle(LPCTSTR lpszTitle)
{
	// Save the title given to us by the framewrk.
	m_strDocTitle = lpszTitle;

	__super::SetTitle(lpszTitle);
}

void Doc::SetModifiedFlag(BOOL bModified)
{
	CString	str;

	str = m_strDocTitle;
	if (bModified) str += _T("*");
	__super::SetTitle(str);

	__super::SetModifiedFlag(bModified);
}
