#pragma once
#include "afxwin.h"
#include "afxcmn.h"

// CDlgFrequencyLogging dialog

class CDlgFrequencyLogging : public CDialog
{
	DECLARE_DYNAMIC(CDlgFrequencyLogging)

public:
						CDlgFrequencyLogging(CWnd* pParent = NULL);   // standard constructor
	virtual				~CDlgFrequencyLogging();

// Dialog Data
	enum { IDD = IDD_DIALOG_CIV };

protected:
	virtual void		DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	Doc *m_pDoc;
	virtual BOOL		OnInitDialog();

protected:
	CEdit				m_Edit_Port;
	CSpinButtonCtrl		m_Spin_Port;
	CComboBox			m_Combo_Baud;
	CButton				m_Check_Enable;
	CEdit				m_Edit_IcomAddr;
	CSpinButtonCtrl		m_Spin_IcomAddr;
	CEdit				m_Edit_IcomType;
	CEdit				m_Edit_TestAddress;
	CEdit				m_Edit_TestSMeter;
	void				Update(void);
	BOOL				m_bDirty;

public:
	afx_msg void		OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void		OnCbnSelchangeComboBaud();
	afx_msg void		OnBnClickedCheckEnable();
	afx_msg void		OnBnClickedRadioRadiotypeIcom();
	afx_msg void		OnBnClickedRadioRadiotypeAor();
	afx_msg void		OnBnClickedRadioRadiotypeUniden();
	afx_msg void		OnBnClickedRadioRadiotypeRs();
protected:
	virtual void		OnOK();
public:
	afx_msg void		OnBnClickedButtonTestreceiver();

protected:
	CToolTipCtrl		m_ToolTip;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
