// RadioSettings.cpp : implementation file
//

#include "stdafx.h"
#include ".\comport.h"
#include ".\radiointerface.h"
#include ".\radiosettings.h"

///////////////////////////////////////////////////////////////////
// CRadioCommand Class
//
// Zero or more objects of this class are stored in the m_JobList
// (of the CRadioSettings object). Each of these objects contain
// the radio retrieval instructions for the user's log items. The
// radio results are stored into the CRadioCommand objects. The
// actual I/O operations are handled by using this object for the
// parameters that are passed to the CRadioInterface object.
///////////////////////////////////////////////////////////////////

DWORD	dwBaudTbl[] = 
{
	CBR_110,	CBR_300,	CBR_600,	CBR_1200,	CBR_2400,
	CBR_4800,	CBR_9600,	CBR_14400,	CBR_19200,	CBR_38400,
	CBR_56000,	CBR_57600,	CBR_115200, CBR_128000, CBR_256000
};
#define sizeBaudTbl (sizeof (dwBaudTbl) / sizeof(dwBaudTbl[0]))

#define sizeRadioTypeTbl (RadioType_NumTypes)	// # items
RADIO_TYPE RadioTbl[sizeRadioTypeTbl] =
{
	RadioType_None, RadioType_Icom, RadioType_Uniden
};

LPCTSTR	strRadioTbl[sizeRadioTypeTbl] =
{	// Entries in this tbl must match RADIO_TYPE
	_T("None"), _T("Icom"), _T("Uniden")
};

LPCTSTR	lpszCommandTbl[] =
{
	// XT and T series commands
	_T("None"),			_T("GLG"),			_T("GID"),
	_T("STS"),			_T("PWR"),			_T("MDL"),
	_T("VER"),			_T("VOL"),			_T("SQL"),
	_T("P25"),			_T("BAV"),			_T("WIN"),

	//BC898T
	_T("BL"),		_T("CC"),		_T("CS"),		_T("IC"),
	_T("LCD"),		_T("LCD 01"),	_T("LCD 02"),	_T("LCD 03"),
	_T("LCD 04"),	_T("LCD 05"),	_T("LCD 06"),	_T("LCD 07"),
	_T("LCD 08"),	_T("LCD 09"),	_T("LCD 10"),	_T("LCD 11"),
	_T("LCD 12"),	_T("LCD 13"),	_T("LCD 14"),	_T("LCD 15"),
	_T("LCD 16"),	_T("LCD 17"),	_T("LCD 18"),	_T("LCD 19"),
	_T("LCD 20"),	_T("LCD 21"),	_T("LCD 22"),	_T("LCD 23"),
	_T("LCD 24"),	_T("LCD 25"),	_T("LCD 26"),	_T("LCD 27"),
	_T("LCD 28"),	_T("LCD 29"),	_T("LCD 30"),	_T("LCD 31"),
	_T("LCD 32"),	_T("LCD 33"),	_T("LCD 34"),	_T("LCD 35"),
	_T("LCD 36"),	_T("LCD 37"),	_T("LCD 38"),	_T("LCD 39"),
	_T("LCD 40"),	_T("LCD BNK"),	_T("LCD CHN"),	_T("LCD CTC"),
	_T("LCD FRQ"),	_T("LCD SMT"),	_T("MA"),		_T("MD"),
	_T("RF"),		_T("RM"),		_T("SG"),		_T("SQ"),
	_T("TB"),		_T("VR"),		_T("WI"),

	// Icom
	_T("IcomFrq"),		_T("IcomLvl")
};

///////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(CRadioCommand, CObject, 0)

void CRadioCommand::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar.Write(&m_eCmd,	sizeof(RADIO_CMD));
		ar.Write(&m_nIndex, sizeof(int));
		ar << m_nDelayMS;
	}
	else
	{	// loading code
		ar.Read(&m_eCmd,	sizeof(RADIO_CMD));
		ar.Read(&m_nIndex,	sizeof(int));
		ar >> m_nDelayMS;
	}
}

CRadioCommand::CRadioCommand(RADIO_CMD eCmd, int Index, int Delay)
{
	Reset();

	m_eCmd		= eCmd;
	m_nIndex	= Index;
	m_nDelayMS	= Delay;
}

CRadioCommand::CRadioCommand()
{
	Reset();
}
CRadioCommand::~CRadioCommand()
{
}

void CRadioCommand::Reset(void)
{
	m_eCmd		= RadioCmd_None;
	m_nIndex	= 0;
	m_nDelayMS	= 0;

	m_strResult.Empty();

}

RADIO_CMD CRadioCommand::GetCmd(void)
{
	return m_eCmd;
}

void CRadioCommand::SetCmd(RADIO_CMD Cmd)
{
	m_eCmd = Cmd;
}

int CRadioCommand::GetIndex(void)
{
	return m_nIndex;
}

void CRadioCommand::SetIndex(int I)
{
	m_nIndex = I;
}

void CRadioCommand::operator =(CRadioCommand * pNew)
{
	Reset();
	SetCmd(pNew->GetCmd());
	SetIndex(pNew->GetIndex());
	SetResult(pNew->GetResult());
	SetDelay(pNew->GetDelay());
}

void CRadioCommand::SetResult(LPCTSTR lpszResult)
{
	if (lpszResult == NULL || _tcslen(lpszResult) == 0)
		m_strResult.Empty();

	m_strResult.Format(_T("%s"), lpszResult);
}

int CRadioCommand::GetDelay(void)
{
	return m_nDelayMS;
}

void CRadioCommand::SetDelay(int nDelay)
{
	m_nDelayMS = nDelay;
}

///////////////////////////////////////////////////////////////////
// CRadioSettings Class
///////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(CRadioSettings, CObject, 0)

CRadioSettings::CRadioSettings()
{
	Reset();
}

CRadioSettings::~CRadioSettings()
{
	Reset();
}

void CRadioSettings::Serialize(CArchive& ar)
{
	int				i, j;
	CRadioCommand*	pCmd;

	if (ar.IsStoring())
	{	// storing code
		ar << m_dwBaud;
		ar.Write(&m_eRadioType, sizeof(RADIO_TYPE));
		ar << m_nPort;
		ar << m_bRadioEnabled;
		ar << m_bShowHex;
		ar << m_dwTimeout;
		ar << m_bCache;

		j = (int) m_JobList.GetCount();

		// Save job list
		ar << j;	// Save items
		for (i = 0; i < j; i++)
		{
			pCmd = m_JobList.GetAt(i);
			ASSERT(pCmd != NULL);

			pCmd->Serialize(ar);
		}
	}
	else
	{	// loading code
		ar >> m_dwBaud;
		ar.Read(&m_eRadioType, sizeof(RADIO_TYPE));
		ar >> m_nPort;
		ar >> m_bRadioEnabled;
		ar >> m_bShowHex;
		ar >> m_dwTimeout;
		ar >> m_bCache;

		// Load job list
		ar >> j;	// get # items
		ClearJobList();

		for (i = 0; i < j; i++)
		{
			pCmd = new CRadioCommand;
			ASSERT(pCmd != NULL);

			pCmd->Serialize(ar);

#ifdef _LITE
			if (i < LITE_MAX_JOB_ITEMS) AddJobItem(pCmd);	// Only allow lite item(s) to load.
			else delete pCmd;
#else
			AddJobItem(pCmd);
#endif

		}
	}
}

void CRadioSettings::Reset(void)
{
	m_dwBaud		= CBR_115200;
	m_eRadioType	= RadioType_None;
	m_nPort			= 1;
	m_bRadioEnabled	= FALSE;
	m_bShowHex		= FALSE;
	m_dwTimeout		= 1000;
	m_bCache		= FALSE;

	ClearJobList();
}

void CRadioSettings::AddJobItem(CRadioCommand* pNewItem)
{
	ASSERT(pNewItem != NULL);

	m_JobList.Add(pNewItem);
}

void CRadioSettings::DeleteJobItem(int iItem)
{
	CRadioCommand* pItem = NULL;

	if (m_JobList.GetCount() > iItem)
	{
		pItem = m_JobList.GetAt(iItem);
		ASSERT(pItem != NULL);

		m_JobList.RemoveAt(iItem);
		delete pItem;
	}
}

void CRadioSettings::SetJobItem(int iItem, CRadioCommand* pNewItem)
{
	CRadioCommand* pItem = NULL;

	ASSERT(GetJobItemCount() > iItem);

	pItem = m_JobList[iItem];
	ASSERT(pItem != NULL);

	*pItem = pNewItem;
}

CRadioCommand* CRadioSettings::GetJobItem(int iItem)
{
	CRadioCommand* pItem = NULL;

	if (GetJobItemCount() <= iItem)
	{
		ASSERT(0);	// Array is empty.
		return NULL;
	}

	pItem = m_JobList[iItem];
	ASSERT(pItem != NULL);

	return pItem;
}

BOOL CRadioSettings::SwapJobItems(int iItem1, int iItem2)
{
	CRadioCommand* pTemp = NULL;

	if (!(GetJobItemCount() > max(iItem1, iItem2) && iItem1 != iItem2))
	{
		ASSERT(0);
		return FALSE;
	}

	// Perform the swappage.
	pTemp = m_JobList[iItem1];
	m_JobList[iItem1] = m_JobList[iItem2];
	m_JobList[iItem2] = pTemp;

	return TRUE;
}

int	CRadioSettings::GetJobItemCount(void)
{
	return (int) m_JobList.GetCount();
}

void CRadioSettings::ClearJobList(void)
{
	while (m_JobList.GetCount() > 0)
	{
		DeleteJobItem(0);
	}
}

void CRadioSettings::SetPort(int nPort)
{
	m_nPort = nPort;
}

int	CRadioSettings::GetPort(void)
{
	return m_nPort;
}

void CRadioSettings::SetBaud(DWORD dwBaud)
{
	m_dwBaud = dwBaud;
}

DWORD CRadioSettings::GetBaud(void)
{
	return m_dwBaud;
}

void CRadioSettings::SetRadioType(RADIO_TYPE Type)
{
	m_eRadioType = Type;
}

RADIO_TYPE CRadioSettings::GetRadioType(void)
{
	return m_eRadioType;
}

void CRadioSettings::operator =(CRadioSettings* pFrom)
{
	int		i, j;
	CRadioCommand*	pNewCmd;

	ASSERT(pFrom != NULL);

	SetBaud(pFrom->GetBaud());
	SetRadioType(pFrom->GetRadioType());
	SetPort(pFrom->GetPort());
	EnableRadio(pFrom->IsRadioEnabled());
	SetHexMode(pFrom->GetHexMode());
	SetTimeout(pFrom->GetTimeout());

	// Copy one list to the other
	ClearJobList();	// Output list
	j = pFrom->GetJobItemCount();
	for (i = 0; i < j; i++)
	{
		pNewCmd = new CRadioCommand;
		*pNewCmd = pFrom->GetJobItem(i);

		AddJobItem(pNewCmd);
	}
}

BOOL CRadioSettings::IsRadioEnabled(void)
{
	return m_bRadioEnabled;
}

void CRadioSettings::EnableRadio(BOOL bEnable)
{
	m_bRadioEnabled = bEnable;
}

BOOL CRadioSettings::GetHexMode(void)
{
	return m_bShowHex;
}

void CRadioSettings::SetHexMode(BOOL bEnable)
{
	m_bShowHex = bEnable;
}

DWORD CRadioSettings::GetTimeout(void)
{
	return m_dwTimeout;
}

void CRadioSettings::SetTimeout(DWORD dwTimeout)
{
	m_dwTimeout = dwTimeout;
}

///////////////////////////////////////////////////////////////////
// CDlgRadioSettings dialog class
///////////////////////////////////////////////////////////////////


IMPLEMENT_DYNAMIC(CDlgRadioSettings, CDialog)
CDlgRadioSettings::CDlgRadioSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgRadioSettings::IDD, pParent)
//	, m_pInterface(NULL)
, m_nDelay(0)
{
}

CDlgRadioSettings::~CDlgRadioSettings()
{
}

void CDlgRadioSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_COMPORT, m_Combo_ComPortNumber);
	DDX_Control(pDX, IDC_COMBO_RADIOTYPE, m_Combo_RadioType);
	DDX_Control(pDX, IDC_COMBO_BAUD, m_Combo_BaudRate);
	DDX_Control(pDX, IDC_COMBO_RADIOCMD, m_Combo_RadioCmd);
	DDX_Control(pDX, IDC_LIST_LOGLIST, m_Listbox_Job);
	DDX_Control(pDX, IDC_SPIN_ITEMNUMBER, m_Spin_ReplyItemNumber);
	DDX_Control(pDX, IDC_STATIC_ITEMNUMBER, m_Static_ReplyItemNumber);
	DDX_Control(pDX, IDC_EDIT_REPLYAREA, m_Edit_ReplyArea);
	DDX_Control(pDX, IDC_CHECK_HEX, m_Check_Hex);
	DDX_Control(pDX, IDC_CHECK_AUTOFETCH, m_Check_AutoFetch);
	DDX_Control(pDX, IDC_BUTTON_MOVEUP, m_Button_MoveUp);
	DDX_Control(pDX, IDC_BUTTON_MOVEDOWN, m_Button_MoveDn);
	DDX_Control(pDX, IDC_BUTTON_DELETE, m_Button_Delete);
	DDX_Control(pDX, IDC_BUTTON_DELETEALL, m_Button_DeleteAll);
	DDX_Control(pDX, IDC_BUTTON_TEST, m_Button_TestCmd);
	DDX_Control(pDX, IDC_BUTTON_ADDTOLOG, m_Button_AddToJob);
	//DDX_Control(pDX, IDC_CHECK_CONTINUOUS, m_Check_Continuous);
	//DDX_Control(pDX, IDC_BUTTON_ABORT, m_Button_Abort);
	DDX_Control(pDX, IDC_BUTTON_TESTJOB, m_Button_TestJob);
	DDX_Control(pDX, IDC_EDIT_PREDELAY, m_Edit_Delay);
	DDX_Control(pDX, IDC_EDIT_TIMEOUT, m_Edit_Timeout);
	DDX_Control(pDX, IDC_EDIT_REPLY_PARSED, m_Edit_Reply_Parsed);
}

BEGIN_MESSAGE_MAP(CDlgRadioSettings, CDialog)
	ON_CBN_SELCHANGE(IDC_COMBO_RADIOTYPE,	OnCbnSelchangeComboRadiotype)
	ON_BN_CLICKED(IDC_BUTTON_ADDTOLOG,		OnBnClickedButtonAddtoJob)
	ON_BN_CLICKED(IDC_BUTTON_DELETEALL,		OnBnClickedButtonDeleteall)
	ON_BN_CLICKED(IDC_BUTTON_DELETE,		OnBnClickedButtonDelete)
	ON_BN_CLICKED(IDC_CHECK_AUTOFETCH,		OnBnClickedCheckAutofetch)
	ON_BN_CLICKED(IDC_CHECK_HEX,			OnBnClickedCheckHex)
	ON_BN_CLICKED(IDC_BUTTON_MOVEUP,		OnBnClickedButtonMoveup)
	ON_BN_CLICKED(IDC_BUTTON_MOVEDOWN,		OnBnClickedButtonMovedown)
	ON_CBN_SELCHANGE(IDC_COMBO_RADIOCMD, OnCbnSelchangeComboRadiocmd)
	ON_LBN_SELCHANGE(IDC_LIST_LOGLIST, OnLbnSelchangeListLoglist)
	ON_BN_CLICKED(IDC_BUTTON_TEST, OnBnClickedButtonTest)
	ON_CBN_SELCHANGE(IDC_COMBO_COMPORT, OnCbnSelchangeComboComport)
	ON_CBN_SELCHANGE(IDC_COMBO_BAUD, OnCbnSelchangeComboBaud)
	ON_BN_CLICKED(IDC_BUTTON_TESTJOB, OnBnClickedButtonTestjob)
	ON_EN_KILLFOCUS(IDC_EDIT_PREDELAY, OnEnKillfocusEditPredelay)
	ON_EN_KILLFOCUS(IDC_EDIT_TIMEOUT, OnEnKillfocusEditTimeout)
END_MESSAGE_MAP()

BOOL CDlgRadioSettings::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_Spin_ReplyItemNumber.SetRange(0, 99);
	m_Spin_ReplyItemNumber.SetPos(0);

	InitCombos();
	UpdateJobListbox();
	UpdateDelayIndicator();
	UpdateTimeoutControl();

	m_Check_AutoFetch.SetCheck(m_RadioSettings.IsRadioEnabled() ? BST_CHECKED:BST_UNCHECKED);
	m_Check_Hex.SetCheck(m_RadioSettings.GetHexMode() ? BST_CHECKED:BST_UNCHECKED);

	UpdateButtonStatus();

	m_ToolTip.Create(this);
	m_ToolTip.SetDelayTime(TTDT_AUTOPOP, 20000);
	m_ToolTip.SetMaxTipWidth(400);

	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_ADDTOLOG),
		_T("Adds the current radio command to the job list."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_DELETE),
		_T("Delete the current item from the job list."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_DELETEALL),
		_T("Clear the job list."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_MOVEDOWN),
		_T("Move the selected job item down in the list."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_MOVEUP),
		_T("Move the selected job item up in the list."));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_TEST),
		_T("Execute the radio command and display the result in the test reply area"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_TESTJOB),
		_T("Execute the job list contents and display the result in the test reply area"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_AUTOFETCH),
		_T("This is the main On/Off switch for the radio logging feature.\n\n") \
		_T("On enables the job list to be executed automatically during a recording.\n\n") \
		_T("If this switch is off, the radio will not be accessed during the recording."));
	m_ToolTip.AddTool(GetDlgItem(IDC_COMBO_BAUD),
		_T("Baud rate"));
	m_ToolTip.AddTool(GetDlgItem(IDC_COMBO_COMPORT),
		_T("Com Port"));
	m_ToolTip.AddTool(GetDlgItem(IDC_COMBO_RADIOCMD),
		_T("Command to be sent to the radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_COMBO_RADIOTYPE),
		_T("Radio type"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_REPLYAREA),
		_T("This is where the reply received from the radio appears for your inspection."));
	m_ToolTip.AddTool(GetDlgItem(IDC_LIST_LOGLIST),
		_T("This is the job list. It contains the items to be retrieved\n") \
		_T("from the radio during the VOX event period. The results from items in the job\n") \
		_T("will appear in the log file at the right side of each log entry."));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_ITEMNUMBER),
		_T("This number selectes which sub-item from the Uniden reply is\n") \
		_T("placed in the log. A Sub-Item is a part of the reply delimited ") \
		_T("by commas (as in a CSV file)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_PREDELAY),
		_T("Pre delay (in milliseconds) for serial commands.\n")
		_T("Note: Too many commands with delays slow down the entire job."));

	return TRUE;
}

void CDlgRadioSettings::InitCombos(void)
{
	int	i,j,k;
	CComPort	port;	// To access the list of ports.
	CString		str;

	// Set the com port combo
	m_Combo_ComPortNumber.ResetContent();
	j = port.GetHighestPortNumber();
	for (i = 0; i <= j; i++)
	{
		str.Format(_T("COM%d"), i+1);
		k = m_Combo_ComPortNumber.AddString(str);
		m_Combo_ComPortNumber.SetItemData(k, i+1);	// Add port # to item
	}
	m_Combo_ComPortNumber.SetCurSel(m_RadioSettings.GetPort()-1);

	// Set the baud rate combo
	m_Combo_BaudRate.ResetContent();
	for (i = 0, j = 0; i < sizeBaudTbl; i++)
	{
		str.Format(_T("%d"), dwBaudTbl[i]);
		k = m_Combo_BaudRate.AddString(str);
		m_Combo_BaudRate.SetItemData(k, dwBaudTbl[i]);
		if (m_RadioSettings.GetBaud() == dwBaudTbl[i]) j = i;	// This is going to be the index to use.
	}
	m_Combo_BaudRate.SetCurSel(j);	

	// Set the radio type combo
	m_Combo_RadioType.ResetContent();
	for (i = 0, j = 0; i < sizeRadioTypeTbl; i++)
	{
		k = m_Combo_RadioType.AddString(strRadioTbl[i]);
		m_Combo_RadioType.SetItemData(k, RadioTbl[i]);
		if (m_RadioSettings.GetRadioType() == RadioTbl[i]) j = i;
	}
	m_Combo_RadioType.SetCurSel(j);

	UpdateCmdCombo();
}

void CDlgRadioSettings::SetRadioSettings(CRadioSettings* pRadioSettings)
{
	m_RadioSettings = pRadioSettings;
}

CRadioSettings* CDlgRadioSettings::GetRadioSettings(void)
{
	return &m_RadioSettings;
}

void CDlgRadioSettings::OnOK()
{
	INT_PTR result;

	m_RadioSettings.SetBaud((DWORD) m_Combo_BaudRate.GetItemData(m_Combo_BaudRate.GetCurSel()));
	m_RadioSettings.SetPort((DWORD) m_Combo_ComPortNumber.GetItemData(m_Combo_ComPortNumber.GetCurSel()));
	m_RadioSettings.SetRadioType((RADIO_TYPE)
		m_Combo_RadioType.GetItemData(m_Combo_RadioType.GetCurSel()));

	// Warn user if not enabled and job queued.
	if (!m_RadioSettings.IsRadioEnabled() && m_RadioSettings.GetJobItemCount() != 0)
	{
		result = AfxMessageBox(
			_T("Warning: Automatic radio logging is disabled.\r\n") \
			_T("Choose (Yes) to turn on radio logging and continue.\r\n") \
			_T("Choose (No) to leave radio logging off and continue.\r\n") \
			_T("(Cancel) returns to the Radio Settings panel."),
			MB_YESNOCANCEL|MB_ICONEXCLAMATION);

		switch (result)
		{
			case IDYES:
				m_RadioSettings.EnableRadio(TRUE);
				CDialog::OnOK();
				break;

			case IDNO:
				CDialog::OnOK();
				return;

			case IDCANCEL:
				break;
		}
	}
	else
	{
		CDialog::OnOK();
	}
}

// Update the radio command list combo.
void CDlgRadioSettings::UpdateCmdCombo(void)
{
	int	i;
	RADIO_TYPE eType = (RADIO_TYPE) m_Combo_RadioType.GetItemData(m_Combo_RadioType.GetCurSel());
	m_Combo_RadioCmd.ResetContent();

	i = m_Combo_RadioCmd.AddString(lpszCommandTbl[RadioCmd_None]);
	m_Combo_RadioCmd.SetItemData(i, RadioCmd_None);

	switch (eType)
	{
		case RadioType_None:
			break;

		case RadioType_Icom:
			//i = m_Combo_RadioCmd.AddString(lpszCommandTbl[RadioCmd_IcomFrq]);
			//m_Combo_RadioCmd.SetItemData(i, RadioCmd_IcomFrq);
			//i = m_Combo_RadioCmd.AddString(lpszCommandTbl[RadioCmd_IcomLvl]);
			//m_Combo_RadioCmd.SetItemData(i, RadioCmd_IcomLvl);

			for (int a = RadioCmd_IcomFrq; a <= RadioCmd_IcomLvl; a++)
			{
				i = m_Combo_RadioCmd.AddString(lpszCommandTbl[a]);
				m_Combo_RadioCmd.SetItemData(i, a);
			}
			break;

		case RadioType_Uniden:

			for (int a = RadioCmd_GLG; a < RadioCmd_IcomFrq; a++)
			{
				i = m_Combo_RadioCmd.AddString(lpszCommandTbl[a]);
				m_Combo_RadioCmd.SetItemData(i, a);
			}
			break;
	}	

	m_Combo_RadioCmd.SetCurSel(0);
}

void CDlgRadioSettings::OnCbnSelchangeComboRadiotype()
{
	m_RadioSettings.SetRadioType((RADIO_TYPE)
		m_Combo_RadioType.GetItemData(m_Combo_RadioType.GetCurSel()));

	m_Spin_ReplyItemNumber.SetPos(0);
	UpdateCmdCombo();
	UpdateButtonStatus();
}

void CDlgRadioSettings::UpdateJobListbox(void)
{
	CString			str, strCmd, strDelay;
	CRadioCommand*	pItem;
	int				i, j/*, sel*/;

	m_Listbox_Job.ResetContent();

	for (i = 0, j = m_RadioSettings.GetJobItemCount(); i < j; i++)
	{
		pItem = m_RadioSettings.GetJobItem(i);
		ASSERT(pItem != NULL);

		strCmd = lpszCommandTbl[pItem->GetCmd()];

		strDelay.Empty();
		if (pItem->GetDelay() != 0)
			strDelay.Format(_T("\tDelay(%03d) ms"), pItem->GetDelay());

		str.Format(_T("%02d: %8s[%d]%s"),
			i+1, strCmd, pItem->GetIndex(), strDelay);

		m_Listbox_Job.AddString(str);
	}
}

void CDlgRadioSettings::OnBnClickedButtonAddtoJob()
{
	int				nCmdPos, index, nDelay;
	RADIO_CMD		eCmd;
	CRadioCommand*	pCmd;

#ifdef _LITE
	// Lite version: safeguard to prevent more items than lite max in job list.
	if (m_RadioSettings.GetJobItemCount() >= LITE_MAX_JOB_ITEMS) return;
#endif

	nCmdPos = m_Combo_RadioCmd.GetCurSel();
	eCmd	= (RADIO_CMD) m_Combo_RadioCmd.GetItemData(nCmdPos);
	index	= m_Spin_ReplyItemNumber.GetPos();
	nDelay	= m_nDelay;

	if (eCmd != RadioCmd_None)
	{
		pCmd	= new CRadioCommand(eCmd, index, nDelay);

		m_RadioSettings.AddJobItem(pCmd);

		UpdateJobListbox();
	}

	UpdateButtonStatus();
}

void CDlgRadioSettings::OnBnClickedButtonDeleteall()
{
	if (m_RadioSettings.GetJobItemCount() != 0)
	{
		m_RadioSettings.ClearJobList();
		UpdateJobListbox();
	}

	UpdateButtonStatus();
}

void CDlgRadioSettings::OnBnClickedButtonDelete()
{
	int		sel, j;
	
	sel = m_Listbox_Job.GetCurSel();

	if (sel != -1 && sel < m_Listbox_Job.GetCount())
	{	// delete it
		m_RadioSettings.DeleteJobItem(sel);
		UpdateJobListbox();
	}

	// Update the listbox selection pos.
	j = m_Listbox_Job.GetCount();
	if (j != 0)
	{
		if (sel < j)
			m_Listbox_Job.SetCurSel(sel);
		else
			m_Listbox_Job.SetCurSel(j-1);	// Move sel to last item in listbx
	}

	UpdateButtonStatus();
}

void CDlgRadioSettings::OnBnClickedCheckAutofetch()
{
	m_RadioSettings.EnableRadio(m_Check_AutoFetch.GetCheck() == BST_CHECKED);
}

void CDlgRadioSettings::OnBnClickedCheckHex()
{
	m_RadioSettings.SetHexMode(m_Check_Hex.GetCheck() == BST_CHECKED);
}

void CDlgRadioSettings::OnBnClickedButtonMoveup()
{
	int		sel, j;

	sel = m_Listbox_Job.GetCurSel();
	j	= m_Listbox_Job.GetCount();

	// We need at least 2 items in order to move something.
	if (j >= 2)
	{
		// If something is selected and it's not first item.
		if (sel > 0)
		{	// Perform the swappage
			m_RadioSettings.SwapJobItems(sel, sel-1);
			UpdateJobListbox();
			m_Listbox_Job.SetCurSel(sel-1);
		}
	}
}

void CDlgRadioSettings::OnBnClickedButtonMovedown()
{
	int		sel, j;

	sel = m_Listbox_Job.GetCurSel();
	j	= m_Listbox_Job.GetCount();

	// We need at least 2 items in order to move something.
	if (j >= 2)
	{
		// If something is selected and it's not last item.
		if (sel < j-1)
		{	// Perform the swappage
			m_RadioSettings.SwapJobItems(sel, sel+1);
			UpdateJobListbox();
			m_Listbox_Job.SetCurSel(sel+1);
		}
	}
}

// Controls the enabled states
void CDlgRadioSettings::UpdateButtonStatus(void)
{
	// Lock the radio type if there are entries in the job list
	m_Combo_RadioType.EnableWindow(m_Listbox_Job.GetCount() == 0);

	// Only allow the spin control if using a uniden radio.
	m_Spin_ReplyItemNumber.EnableWindow(m_Combo_RadioType.GetItemData(m_Combo_RadioType.GetCurSel()) == RadioType_Uniden);

	// Enable the cmd combo if there is a radio type.
	m_Combo_RadioCmd.EnableWindow(m_Combo_RadioType.GetCurSel() > 0);

	// Enable the test button if there is a valid cmd.
	m_Button_TestCmd.EnableWindow(m_Combo_RadioCmd.GetCurSel() > 0);

	// Enable the add button if there is a valid cmd.
#ifdef _LITE
	// Lite allowed item(s) in the job list.
	m_Button_AddToJob.EnableWindow(m_Combo_RadioCmd.GetCurSel() > 0 && m_RadioSettings.GetJobItemCount() < LITE_MAX_JOB_ITEMS);
#else
	m_Button_AddToJob.EnableWindow(m_Combo_RadioCmd.GetCurSel() > 0);
#endif

	// Enable the move and delete buttons.
	m_Button_Delete.EnableWindow(m_Listbox_Job.GetCurSel() != -1);
	m_Button_MoveDn.EnableWindow(m_Listbox_Job.GetCurSel() != -1);
	m_Button_MoveUp.EnableWindow(m_Listbox_Job.GetCurSel() != -1);

	// The Delete All button.
	m_Button_DeleteAll.EnableWindow(m_Listbox_Job.GetCount() != 0);

	// The delay edit box
	m_Edit_Delay.EnableWindow(m_Combo_RadioCmd.GetCurSel() > 0);
}

void CDlgRadioSettings::OnCbnSelchangeComboRadiocmd()
{
	UpdateButtonStatus();
}

void CDlgRadioSettings::OnLbnSelchangeListLoglist()
{
	UpdateButtonStatus();
}

void CDlgRadioSettings::OnBnClickedButtonTest()
{
	CRadioCommand*	pCommand;
	int				nSel, nReplyIndex;
	CStringA		strA;		// mbcs string
	CString			strT;		// converted to unicode if required
	CString			strReplyCache;	// Unparsed (cache) output.
	CString			strReply;	// Parsed output.
	CString			strOutput;	// Formatted output for the test area.
	//LPBYTE			pReply		= NULL;
	LPBYTE			pReplyCache = NULL;
	int				/*nReplyLen = 0, */nReplyCacheLen = 0;
	BOOL			bResultOkay, rc;
	CRadioInterface	radio;

	rc = radio.Create(&m_RadioSettings);
	if (!rc)
	{
		AfxMessageBox(_T("Unable to open the COM port"), MB_OK);
		return;
	}

	// Allocate the stuff
	//pReply		= new BYTE[CACHE_SIZE];
	pReplyCache = new BYTE[CACHE_SIZE];
	//ZeroMemory(pReply,		CACHE_SIZE);
	ZeroMemory(pReplyCache,	CACHE_SIZE);

	nSel		= m_Combo_RadioCmd.GetCurSel();

	nReplyIndex	= m_Spin_ReplyItemNumber.GetPos();
	pCommand	= new CRadioCommand((RADIO_CMD) m_Combo_RadioCmd.GetItemData(nSel), nReplyIndex, m_nDelay);

	if (nSel != -1)
	{	// If command is selected in the droplist...

		bResultOkay = radio.ExecuteCmd(pCommand);

		// Post execution formatting for the test reply area.
		switch (m_RadioSettings.GetRadioType())
		{
			case RadioType_None:
				ASSERT(0);		// hmm... Should not have been allowed.
				break;

			case RadioType_Icom:
				strOutput = _T("Icom hasn't been finished yet.");
				break;

			case RadioType_Uniden:
				// Get the cache contents...
				nReplyCacheLen = radio.GetCacheData(pReplyCache, CACHE_SIZE, pCommand->GetCmd());

				strA = pReplyCache;
				strReplyCache = strA;

				// and also the formatted reply value
				strReply = pCommand->GetResult();

				strOutput.Format(_T("Raw: \"%s\"\r\n\r\nResult: \"%s\""),
					strReplyCache, strReply);

				break;
		}
	}

	m_Edit_ReplyArea.SetWindowText(strOutput);

	if (pCommand		!= NULL)	delete		pCommand;
	//if (pReply			!= NULL)	delete []	pReply;
	if (pReplyCache		!= NULL)	delete []	pReplyCache;
}

void CDlgRadioSettings::SetRadioInterface(CRadioInterface* pInterface)
{
	ASSERT(pInterface != NULL);

	m_pInterface = pInterface;
}

///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////


void CDlgRadioSettings::OnCbnSelchangeComboComport()
{
	m_RadioSettings.SetPort((DWORD) m_Combo_ComPortNumber.GetItemData(m_Combo_ComPortNumber.GetCurSel()));
}

void CDlgRadioSettings::OnCbnSelchangeComboBaud()
{
	m_RadioSettings.SetBaud((DWORD) m_Combo_BaudRate.GetItemData(m_Combo_BaudRate.GetCurSel()));
}

void CDlgRadioSettings::OnBnClickedButtonTestjob()
{
	CRadioInterface	radio;
	BOOL	rc;
	int		i, nJobItems;
	CString	strOutput, str;
	CString strT;

	nJobItems = m_RadioSettings.GetJobItemCount();
	if (nJobItems != 0)
	{
		rc = radio.Create(&m_RadioSettings);
		if (!rc)
		{
			AfxMessageBox(_T("Unable to open the COM port"), MB_OK);
			return;
		}

		rc = radio.ExecuteJob(&m_RadioSettings);

		if (rc)
		{
			// Loop to format the results.
			for (i = 0; i < nJobItems; i++)
			{
				strT = m_RadioSettings.GetJobItem(i)->GetResult();
				str.Format(_T("Item[%d];\t%s\r\n"),
					i+1, strT);
				strOutput += str;
			}

			m_Edit_ReplyArea.SetWindowText(strOutput);
		}
		else
		{
			m_Edit_ReplyArea.SetWindowText(_T("Job failed."));
		}
	}
	else
	{
		m_Edit_ReplyArea.SetWindowText(_T("Job list empty."));
	}
}

CString& CRadioCommand::GetResult(void)
{
	return m_strResult;
}

BOOL CDlgRadioSettings::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
		m_ToolTip.RelayEvent(pMsg);
	
	if (pMsg->message	== WM_KEYDOWN && pMsg->wParam	== VK_RETURN)
	{
		if (pMsg->hwnd == m_Edit_Delay.GetSafeHwnd())
		{	// ENTER Pressed in Delay edit control. Capture the value.
			OnEnKillfocusEditPredelay();
		}
		else
		if (pMsg->hwnd == m_Edit_Timeout.GetSafeHwnd())
		{	// timeout ctrl
			OnEnKillfocusEditTimeout();
		}
		
		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgRadioSettings::OnEnKillfocusEditPredelay()
{
	CString str;

	// Read the edit box and save as int
	m_Edit_Delay.GetWindowText(str);
	m_nDelay	= _ttoi(str);
	m_nDelay	= min(m_nDelay, MAX_CMD_DELAY);	// Limit value

	// Reformat it and write it back
	UpdateDelayIndicator();
}

void CDlgRadioSettings::UpdateDelayIndicator(void)
{
	CString str;

	str.Format(_T("%d"), m_nDelay);
	m_Edit_Delay.SetWindowText(str);
}

void CDlgRadioSettings::OnEnKillfocusEditTimeout()
{
	CString str;

	// Read the edit box and save as int
	m_Edit_Timeout.GetWindowText(str);
	m_RadioSettings.SetTimeout(_ttoi(str));
	m_RadioSettings.SetTimeout(min(m_RadioSettings.GetTimeout(), MAX_COM_TIMEOUT));

	// Reformat it and write it back
	UpdateTimeoutControl();
}

void CDlgRadioSettings::UpdateTimeoutControl()
{
	CString str;

	str.Format(_T("%d"), m_RadioSettings.GetTimeout());
	m_Edit_Timeout.SetWindowText(str);
}
