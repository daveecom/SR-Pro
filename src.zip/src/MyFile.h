#pragma once
#include "afx.h"

class CMyFile :
	public CFile
{
public:
	CMyFile(void);
	virtual ~CMyFile(void);
protected:
	CString m_strLine;
public:

	LPCTSTR GetLine(void);
	int GetRecord(LPCTSTR strInput, CString* lpString, int nItems);
};
