#include "StdAfx.h"
#include ".\bufferfilter.h"
#include "audiorecorder.h"

CBufferFilter::CBufferFilter(CAudioRecorder* pParent)
: CAudioFilter(pParent)
, m_pFillBuffer(NULL)
{
	TF;

	m_strObjectName = _T("CBufferFilter");
}

CBufferFilter::~CBufferFilter(void)
{
	TF;
}

void CBufferFilter::Flush()
{
	//TRACE(_T("++++++++ %s::Flush() Entered.\r\n"), GetObjectName());

	//if (m_State != Flushing)
	//{
	//	SetFilterState(Flushing);

	//	SetEvent(m_hEventWakeWorker);	// Wake up worker to process remaining data.

	//	WaitForSingleObject(m_hEventFlushSync, INFINITE);	// Wait for worker to exhaust buffers.

	//	TRACE(_T("/\\/\\/\\/\\ %s::Flush() Synced.\r\n"), GetObjectName());

	//	// If there's pending data in the fill buffer then flush the buffer.
	//	if (m_pFillBuffer != NULL)
	//	{
	//		Transmit(m_pFillBuffer);
	//		m_pFillBuffer = NULL;
	//	}

	//	if (GetNextFilter() != NULL)
	//	{
	//		GetNextFilter()->Flush();		// Block here until all downstream work is done.
	//	}
	//}	// if (m_State != Flushing)
	//TRACE(_T("++++++++ %s::Flush() Entered.\r\n"), GetObjectName());
	
	if (m_State == Flushing)
	{
		TRACE(_T("******** %s::Flush() Already in Flushing State.\r\n"), GetObjectName());
		m_pParent->Dump();

		//DebugBreak();	// Ummmm.... should we already be in flush????
						// I don't think so...
		//Beep(9000,1);
	}

	{
		CCS	Lock(&m_csQueue);
		CCS	Lock2(&m_csState);

		//SetFilterState(Flushing);
		m_State = Flushing;				// Can't call SetFilterState because of the lock.
		ResetEvent(m_hEventFlushSync);	// Clear before we kick the worker.
		SetEvent(m_hEventWakeWorker);	// Wake up worker to process remaining data.
	}

	WaitForSingleObject(m_hEventFlushSync, INFINITE);	// Wait for worker to exhaust buffers.

	ASSERT(m_State == Flushing);	// Make sure state didn't change unexpectedly

	//TRACE(_T("/\\/\\/\\/\\ %s::Flush() Synced.\r\n"), GetObjectName());

	// If there's pending data in the fill buffer then flush the buffer.
	if (m_pFillBuffer != NULL)
	{
		Transmit(m_pFillBuffer);
		m_pFillBuffer = NULL;
	}

	{
		if (GetNextFilter() != NULL)
		{
			GetNextFilter()->Flush();		// Block here until all downstream work is done.
		}
	}
	//TRACE(_T("+-+-+-+- %s::Flush() Exit.\r\n"), GetObjectName());
}

void CBufferFilter::ProcessDataBuffer(RECBUFF* pRB)
{
	if (pRB->wavehdr.dwBytesRecorded == 0)
	{	// No data. Pass this buffer onto next filter as is.
		Transmit(pRB);
	}
	else
	{	// incoming buffer not empty. Xfer data to the fill bfr.

		// First - if fill buffer doesn't have enough room left, then
		// push it downstream.
		if (m_pFillBuffer != NULL)
		{
			if (pRB->wavehdr.dwBytesRecorded > (m_pFillBuffer->dataSize - m_pFillBuffer->wavehdr.dwBytesRecorded))
			{
				Transmit(m_pFillBuffer);
				m_pFillBuffer = NULL;
			}
		}

		if (m_pFillBuffer == NULL)
		{	// Allocate a new fill buffer
			m_pFillBuffer = AllocRecbuff(pRB->dataSize * 4);
			ASSERT(m_pFillBuffer != NULL);

			m_pFillBuffer->ftTime = pRB->ftTime;
			m_pFillBuffer->nSample = pRB->nSample;
		}

		if (m_pFillBuffer == NULL)
		{
			m_pParent->Dump();
			ASSERT(0);
		}

		// Fill buffer has enough room left now. Copy the incoming buffer
		// content to the fill buffer.
		CopyMemory((m_pFillBuffer->databuffer+m_pFillBuffer->wavehdr.dwBytesRecorded), pRB->databuffer, pRB->wavehdr.dwBytesRecorded);
		m_pFillBuffer->wavehdr.dwBytesRecorded += pRB->wavehdr.dwBytesRecorded;

		// Reflect the first/last flags to the new buffer if necessary.
		// (sigh...) I hope this works without a lot of fuss...
		if (pRB->bFirstBuffer) m_pFillBuffer->bFirstBuffer = TRUE;
		if (pRB->bLastBuffer)
		{
			m_pFillBuffer->bLastBuffer = TRUE;
			if (m_State != Flushing)
			{
				ASSERT(0);	// Confusion on timing. Should we check for this condition?
			}
		}

		FreeRecbuff(pRB);

	}	// incoming buffer not empty. Xfer data to the fill bfr.
}

void CBufferFilter::PurgeBuffers(void)
{
	if (m_pFillBuffer != NULL)
		FreeRecbuff(m_pFillBuffer);
	
	__super::PurgeBuffers();
}
