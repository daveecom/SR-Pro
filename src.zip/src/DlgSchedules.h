#pragma once
// CDlgSchedules dialog

class CScheduleListBox : public CListBox
{
	DECLARE_DYNAMIC(CScheduleListBox)

public:
	CScheduleListBox();
	virtual ~CScheduleListBox();

protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT /*lpDrawItemStruct*/);
protected:
	virtual void PreSubclassWindow();
};


class CDlgSchedules : public CDialog
{
	DECLARE_DYNAMIC(CDlgSchedules)

public:
	CDlgSchedules(CWnd* pParent, CScheduleController* pController);   // standard constructor
	virtual ~CDlgSchedules() {};

// Dialog Data
	enum { IDD = IDD_DIALOG_SCHEDULES };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	CScheduleListBox m_lbSchedList;
public:
	virtual BOOL OnInitDialog();

protected:
	CScheduleController*	m_pController;		// Our scheduler
	void RebuildListbox(void);
	afx_msg void OnBnClickedButtonNew();
	afx_msg void OnBnClickedButtonEdit();
	afx_msg void OnBnClickedButtonEnable();
	afx_msg void OnBnClickedButtonDisable();
	afx_msg void OnBnClickedButtonDelete();
	afx_msg void OnLbnDblclkListSchedules();
protected:
	CToolTipCtrl	m_ToolTip;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

