#pragma once
#include "afxwin.h"
#include "resource.h"

class CTextCrypt
{
public:
	CTextCrypt(void);
	~CTextCrypt(void);
protected:
	BYTE m_mask8;
	WORD m_mask16;
public:
	void ConvertString(CString& strOutput, LPCTSTR lpszInput);	// multi-single
	void ConvertString(LPTSTR lpszOutput, LPCTSTR lpszInput);	// multi-single
	void ConvertStringA(LPSTR lpszOutput, LPCSTR lpszInput);		// single byte
	void ConvertStringW(LPWSTR lpszOutput, LPCWSTR lpszInput);	// multi byte
};
#pragma once


// CDlgConvertText dialog

class CDlgConvertText : public CDialog
{
	DECLARE_DYNAMIC(CDlgConvertText)

public:
	CDlgConvertText(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgConvertText();

// Dialog Data
	enum { IDD = IDD_DIALOG_CVT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	CEdit m_Edit_In;
	CEdit m_Edit_Out;
public:
	afx_msg void OnBnClickedButtonSubmit();
};
