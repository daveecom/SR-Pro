#include "StdAfx.h"
#include "voxfilter.h"
#include "filewriterfilter.h"
#include "filenameserver.h"
#include "audiorecorder.h"
#include "miscfilters.h"
#include ".\voxfilter.h"

CVoxFilter::CVoxFilter(CAudioRecorder* pParent)
: CAudioFilter(pParent)
, m_bForceGateOpen(TRUE)
, m_VoxValue_L(0)
, m_VoxValue_R(0)
, m_cHangTimer(0)
, m_cAntiClipTimer(0)
, m_nAntiClipTimeMS(40)
, m_nHangTimeMS(1000)
, m_VoxState(Gate_Closed)
, m_pLogFile(NULL)
, m_pPort(NULL)
, m_hThreadLogger(NULL)
, m_nFileOffset(0)
, m_bRolloverMode(FALSE)
, m_bRolloverOnce(FALSE)
, m_nDuration(0)
, m_nStart(0)
, m_nEnd(0)
{
	TF;

	m_strObjectName = _T("CVoxFilter");
	m_hEventRolloverSync = CreateEvent(NULL, TRUE, FALSE, NULL);

	ResetCounters();
}

CVoxFilter::~CVoxFilter(void)
{
	TF;

	if (m_hThreadLogger != NULL)
	{
		WaitForSingleObject(m_hThreadLogger, 1000);	// Allow logger thread to close.
		CloseHandle(m_hThreadLogger);
		m_hThreadLogger = NULL;
	}

	CloseHandle(m_hEventRolloverSync);
}

void CVoxFilter::ProcessDataBuffer(RECBUFF* pRB)
{
	ASSERT(IsFormatSet());

	if (m_bForceGateOpen)
	{	// Vox is off. Pass all data through.

		// Account for stored data. ProcessVoxSample increments this while vox is on.
		m_nSamplesStored += (pRB->wavehdr.dwBytesRecorded / m_pFormat->nBlockAlign);

		__super::ProcessDataBuffer(pRB);
	}
	else
	{	// Vox is on. Use the vox processor to pass the data.
		ScanTheBuffer(&pRB->wavehdr, m_pFormat);

		ProcessVoxBuffer(pRB);
		FreeRecbuff(pRB);
	}
}


void CVoxFilter::SetVox(float Left, float Right)
{
	m_VoxValue_L = (WORD) (32768.0 * ((double) Left  / 100.0));
	m_VoxValue_R = (WORD) (32768.0 * ((double) Right / 100.0));
}

// TRUE effectively turns off the vox and opens the flood gates.
void CVoxFilter::ForceGateOpen(bool bForceOpen)
{
	if (bForceOpen)
	{
		m_bForceGateOpen = TRUE;
		m_VoxState = Gate_Closed;

		ResetCounters();
	}
	else
	{
		m_bForceGateOpen = FALSE;
	}
}

BOOL CVoxFilter::OnNewFormat()
{
	m_fSamplesPerMS = m_pFormat->nSamplesPerSec / 1000.0;
	m_DelayAntiClip.SetNewFormat((DWORD) (m_fSamplesPerMS * m_nAntiClipTimeMS));

	return __super::OnNewFormat();
}

void CVoxFilter::ProcessVoxBuffer(RECBUFF* pRB)
{
	DWORD		i, j;
	LPBYTE		pSample;
	USAMPLE		Sample;

	//m_tBufferStamp.ft = pRB->ftTime;

	// Compute the time per buffer
	m_tBuffer.ll = ((pRB->wavehdr.dwBytesRecorded / m_pFormat->nBlockAlign) / m_pFormat->nSamplesPerSec) * ONE_SECOND;

	j = pRB->wavehdr.dwBytesRecorded / m_pFormat->nBlockAlign;	// # samples in buffer
	for (i = 0; i < j; i++)
	{
		// Get offset to current sample
		pSample = ((LPBYTE) pRB->wavehdr.lpData) + (i * m_pFormat->nBlockAlign);

		Sample.dw = 0;
		// Copy the sample (1 byte at a time)
		for (int x = 0, y = m_pFormat->nBlockAlign; x < y; x++)
			Sample.b[x] = pSample[x];

		// Pass the sample to the vox processor.
		ProcessVoxSample(Sample, i, pRB);
	}
}

#pragma optimize( "tgf", on)

void CVoxFilter::ProcessVoxSample(const USAMPLE Sample, const DWORD SampleIndex, const RECBUFF* pRB)
{
	USAMPLE		sample = Sample;	// Current sample	// Converted to 16 bits.
	USAMPLE		dSample;			// Delayed sample
	BOOL		bSigLvl;			// TRUE if audio level is at or above the threshold
	//UFT			uAC;				// Used to adjust the duration
	UFT			uRelative1, uRelative2;
	ULONGLONG	nSampleOffset;
	CString		strTrig;			// Store trigger channel name
	BOOL		bDelayAntiClip_Valid;	// Anticlip delay output value is valid.
	double		fTimePerSample;
	
	// Convert 8 bit sample to 16 if necessary.
	if (Is8Bit())
	{
		sample.s[0] = _8To16(Sample.b[0]);
		sample.s[1] = _8To16(Sample.b[1]);
	}

	// Obtain the delayed sample.
	dSample = sample;
	bDelayAntiClip_Valid = m_DelayAntiClip.NewExchangeSample(&dSample, FALSE);

	// Measure the audio level and compare it with the vox sliders. Result in bSigLvl.
	bSigLvl = FALSE;
	if (m_pFormat->nChannels == 2)
	{	// Stereo
		if (abs(sample.s[0]) > m_VoxValue_L || abs(sample.s[1]) > m_VoxValue_R)
		{
			bSigLvl = TRUE;
			if (abs(sample.s[0]) > m_VoxValue_L && abs(sample.s[1]) > m_VoxValue_R)
				strTrig = _T("LR");
			else if (abs(sample.s[0]) > m_VoxValue_L)
				strTrig = _T("LE");
			else
				strTrig = _T("RI");
		}
		else
			strTrig.Empty();
	}
	else
	{	// Mono
		if (abs(sample.s[0]) > m_VoxValue_L)
		{
			bSigLvl = TRUE;
			strTrig = _T("MO");
		}
		else
			strTrig.Empty();
	}

	//uAC.ll = m_nAntiClipTimeMS * ONE_MILLISECOND;

	// Manage the states and VOX timers here.
	switch (m_VoxState)
	{
		case Gate_Closed:
			if (bSigLvl)
			{	// Above thresh

				m_VoxState			= Gate_Open;
				TRACE(_T("Vox state change: Gate_Open. SampleIndex = %d.\r\n"), SampleIndex);

				m_nStart			= m_nSamplesScanned;
				m_nDuration			= 0;

				m_tStart			= GetTimeOfThisSample(SampleIndex, pRB);
				//m_tStart.ll			-= uAC.ll;	// Adjust for anti-clip

				if (m_pLogFile != NULL) 
				{
					m_pLogFile->NewEntry(m_tStart.ft);
					m_pLogFile->SetTrigChan(strTrig);

					uRelative1.ft = GetStoredTimeFromRecordGate();
					nSampleOffset = GetStoredSampleCountFromRecordGate();

					fTimePerSample = ((double) ONE_SECOND) / ((double) m_pFormat->nSamplesPerSec);
					uRelative2.ll = (ULONGLONG) ((double) nSampleOffset * (double) fTimePerSample);

					//m_pLogFile->SetRelativeTime(uRelative1.ft);
					m_pLogFile->SetRelativeTime(uRelative2.ft);

					m_pLogFile->SetSampleOffset(nSampleOffset);

					m_pLogFile->SetFileOffset(m_nFileOffset);

					//if (m_pPort != NULL) TryToGetFreq();	// Log the freq, etc.
				}

				GetNextFilter()->StartStreaming();
			}
			else
			{	// Below thresh
			}

			break;

		case Gate_Open:

			if (bDelayAntiClip_Valid) m_nDuration++;

			if (bSigLvl)
			{	// Above thresh
			}
			else
			{	// Below thresh
				m_VoxState			= Hang_Wait;
				//TRACE(_T("Vox state change: Hang_Wait\r\n"));

				m_cHangTimer		= (DWORD) (m_nHangTimeMS		* m_fSamplesPerMS);
			}
			break;

		case Hang_Wait:

			if (bDelayAntiClip_Valid) m_nDuration++;

			if (bSigLvl)
			{	// Above thresh
				m_VoxState			= Gate_Open;
				//TRACE(_T("Vox state change: Gate_Open\r\n"));
			}
			else
			{	// Below thresh
				if (m_cHangTimer > 0)
				{
					m_cHangTimer--;
				}
				else
				{	// We reached the end of the hang state time.

///////////////////////////// Formerly part of the "Anticlip_Wait" state

					m_nEnd = m_nSamplesScanned;

					// Obtain the file offset to the next event since we
					// already wrote the last sample of the current event.

					if (m_pLogFile != NULL)
					{
						//m_pLogFile->SetDuration(m_tDuration.ft);

						if (m_nDuration == 0)
						{
							DebugBreak();
						}

						m_pLogFile->SetDuration(GetEventDuration());
						m_nFileOffset = GetFileOffset();	// Get offset to next event
						m_pLogFile->WriteEntry();
					}

					GetNextFilter()->StopStreaming();

					if (m_bRolloverMode || m_bRolloverOnce)
					{
						RolloverFile();
						if (m_bRolloverOnce)
						{
							m_bRolloverOnce = FALSE;
							SetEvent(m_hEventRolloverSync);	// Unblocks wait thread in CAudioRecorder::CheckPointHandler().
						}
					}
/////////////////////////////

					m_VoxState			= Gate_Closed;
					TRACE(_T("Vox state change: Gate_Closed\r\n"));
				}
			}	// Below thresh

			break;

	}	// switch

	// Transmit the delayed sample downstream.
	if (m_VoxState != Gate_Closed)
	{
		if (bDelayAntiClip_Valid)	// Sample must be valid from anti-clip delay line.
		{
			m_nSamplesStored++;

			if (Is8Bit())
			{
				USAMPLE tempSample = {0};
				tempSample.b[0] = _16To8(dSample.s[0]);
				tempSample.b[1] = _16To8(dSample.s[1]);
				dSample.dw		= tempSample.dw;
			}

			for (int i = 0; i < m_pFormat->nBlockAlign; i++)
			{
				AddByte(dSample.b[i], SampleIndex, pRB);
			}
		}
	}

	m_nSamplesScanned++;
}

#pragma optimize( "tgf", off )

BOOL CVoxFilter::IsGateOpen(void)
{
	return m_VoxState != Gate_Closed;
}

void CVoxFilter::ResetCounters(void)
{
	m_nSamplesStored	= 0;

	m_nSamplesScanned	= 0;
	m_nStart			= 0;
	m_nEnd				= 0;
	m_nDuration			= 0;

	m_tStart.ll			= 0;

	m_nFileOffset		= 0;
}

FILETIME CVoxFilter::GetEventStart(void)
{
	return m_tStart.ft;
}

FILETIME CVoxFilter::GetEventDuration(void)
{
	double	fTime;
	UFT		u1 = {0};

	fTime	= (double) m_nDuration;				// duration in samps
	fTime	/= m_pFormat->nSamplesPerSec;		// Get # seconds stored
	fTime	*= ONE_SECOND;						// Convert to time units.
	u1.ll	= (ULONGLONG) fTime;

	return u1.ft;
}

void CVoxFilter::SetLogFile(CLogFileWriter* pLogFile)
{
	m_pLogFile = pLogFile;
}

// This routine is....well.....an afterthought.
FILETIME CVoxFilter::GetStoredTimeFromRecordGate(void)
{
	UFT					u1 = {0};
	CAudioFilter		*pFilter, *pNextFilter;
	CRecordGateFilter*	pRecordGate = NULL;

	if (this != NULL)
	{
		{
			//CCS Lock(&m_csNextFilter);

			pNextFilter = GetNextFilter();
			ASSERT(pNextFilter != NULL);

			for (pFilter = GetNextFilter(); pFilter != NULL; pFilter = pFilter->GetNextFilter())
			{
				if (pFilter->IsKindOf(RUNTIME_CLASS(CRecordGateFilter)))
				{
					pRecordGate = (CRecordGateFilter*) pFilter;
					break;
				}
			}
		}

		ASSERT(pRecordGate != NULL);

		if (pRecordGate != NULL)
		{
			// Flushing shouldn't be necessary because we already flushed when the
			// gate was prevously closed. but, for some reason, we
			// are short by one buffer if we don't do the flush here.

			FlushOutputBuffer();
			
			pNextFilter->Flush();
			u1.ft	= pRecordGate->GetStoredTime();
			pNextFilter->EndFlush();
		}
	}

	return u1.ft;
}

// This routine is....well.....an afterthought.
ULONGLONG CVoxFilter::GetStoredSampleCountFromRecordGate(void)
{
	ULONGLONG			nSamples = 0;
	CAudioFilter		*pFilter, *pNextFilter;
	CRecordGateFilter*	pRecordGate = NULL;

	if (this != NULL)
	{
		{
			//CCS Lock(&m_csNextFilter);

			pNextFilter = GetNextFilter();
			ASSERT(pNextFilter != NULL);

			for (pFilter = GetNextFilter(); pFilter != NULL; pFilter = pFilter->GetNextFilter())
			{
				if (pFilter->IsKindOf(RUNTIME_CLASS(CRecordGateFilter)))
				{
					pRecordGate = (CRecordGateFilter*) pFilter;
					break;
				}
			}
		}

		ASSERT(pRecordGate != NULL);

		if (pRecordGate != NULL)
		{
			FlushOutputBuffer();
			
			pNextFilter->Flush();
			nSamples = pRecordGate->GetSampleCount();
			pNextFilter->EndFlush();
		}
	}

	return nSamples;
}

void CVoxFilter::SetHangTimeMS(DWORD dwHangtime)
{
	m_nHangTimeMS = dwHangtime;
}

ULONGLONG CVoxFilter::GetFileOffset(void)
{
	CAudioFilter*		pFilter		= NULL;
	CFileWriterFilter*	pFileWriter = NULL;
	ULONGLONG			nBytesWritten = 0;

	// Search downstream for the file writer.
	for (pFilter = GetNextFilter();pFilter != NULL;pFilter = pFilter->GetNextFilter())
	{
		if (pFilter->IsKindOf(RUNTIME_CLASS(CFileWriterFilter)))
		{	// We are now pointing to our downstream file writer.
			pFileWriter = (CFileWriterFilter*) pFilter;
		}
	}

	ASSERT(pFileWriter != NULL);

	// If we're not already flushing then we need to flush downstream from here
	// in order to get the correct file offset value from the file writer.
	if (m_State != Flushing)
	{
		FlushOutputBuffer();	// Push our own content downstream first.

		//TRACE(_T("Next Flush was initiated by %s::GetFileOffset().\r\n"), GetObjectName());

		GetNextFilter()->Flush();	// Now the file offset should be valid.
	}


	nBytesWritten = pFileWriter->GetBytesWritten();

	if (m_State != Flushing)
	{
		GetNextFilter()->EndFlush();
	}

	return nBytesWritten;
}

BOOL CVoxFilter::StartStreaming()
{
	if (m_bForceGateOpen) __super::StartStreaming();

	return TRUE;
}

BOOL CVoxFilter::StopStreaming()
{
	{
		CCS ccs(&m_csInfo);

		ZeroMemory(&m_scanInfo, sizeof(SCAN_INFO));
	}

	if (m_bForceGateOpen) __super::StopStreaming();

	return TRUE;
}

void CVoxFilter::RolloverFile()
{
	CAudioFilter*		pFilter				= NULL;
	CFileWriterFilter*	pFileWriter			= NULL;
	CRecordGateFilter*	pRecordGate			= NULL;
	CFilenameServer*	pFilenameServer		= NULL;

	pFilenameServer = m_pParent->GetFilenameServer();
	ASSERT(pFilenameServer != NULL);

	// Search downstream for the file writer.
	for (pFilter = GetNextFilter();pFilter != NULL;pFilter = pFilter->GetNextFilter())
	{
		//if (pFilter->IsKindOf(RUNTIME_CLASS(CFileWriterFilter)))
		if (_tcscmp(pFilter->GetObjectName(), _T("CFileWriterFilter")) == 0)
			pFileWriter = (CFileWriterFilter*) pFilter;
		if (_tcscmp(pFilter->GetObjectName(), _T("CWaveFileWriterFilter")) == 0)
			pFileWriter = (CFileWriterFilter*) pFilter;
		if (_tcscmp(pFilter->GetObjectName(), _T("CRecordGateFilter")) == 0)
			pRecordGate = (CRecordGateFilter*) pFilter;
	}

	ASSERT(pFileWriter	!= NULL);
	ASSERT(pRecordGate	!= NULL);

	ResetCounters();

	if (m_pParent->GetRecorderState() == Recording)
	{
		GetNextFilter()->Flush();
		pFileWriter->BeginNewFile();
		pRecordGate->ResetSampleCount();
		GetNextFilter()->EndFlush();
	}
}

void CVoxFilter::SetRolloverMode(bool bEnable)
{
	m_bRolloverMode = bEnable;
}

void CVoxFilter::SetRolloverOnce(void)
{
	if (m_VoxState == Gate_Closed)
	{	// If gate closed then split file now.
		m_bRolloverOnce = FALSE;
		RolloverFile();
		SetEvent(m_hEventRolloverSync);
	}
	else
	{	// Gate not closed. Use vox sync to allow WaitForRolloverSync to
		// block.
		ResetEvent(m_hEventRolloverSync);
		m_bRolloverOnce = TRUE;
	}
}

/////// UNTESTED ///////

// Used in vox sync splitter modes where the vox gate
// controls the splice point during timed or size splitter modes.

// Wait for vox file splitter to finish before unblocking. Called
// externally by the CAudioRecorder container.
void CVoxFilter::WaitForRolloverSync(void)
{
	DWORD	dwResult;

	if (m_VoxState != Gate_Closed)
	{
		dwResult = WaitForSingleObject(m_hEventRolloverSync, INFINITE);
		m_bRolloverOnce = FALSE;	// Already closed. No need to wait.
		ResetEvent(m_hEventRolloverSync);
	}
}

BOOL CVoxFilter::GetRolloverMode(void)
{
	return m_bRolloverMode;
}

void CVoxFilter::SetVoxState(VOX_STATE State)
{
	m_VoxState = State;
}

// Called by recorder object to write the last logged entry to the file before
// stopping recording. This is a fix for the zero duration log problem that occurs
// whenever recording is stopped when the vox gate is closed.
void CVoxFilter::StoreLogDataManualStop(void)
{
	if (m_nDuration != 0)
	{
		if (m_pLogFile->GetStart().ll != 0)	// Prevent bogus log entry
		{
			m_pLogFile->SetDuration(GetEventDuration());
			m_nFileOffset = GetFileOffset();	// Get offset to next event
			m_pLogFile->WriteEntry();
		}
	}
	else
	{
		;
	}
}

BOOL CVoxFilter::IsForceGateOpen(void)
{
	return m_bForceGateOpen;
}
