// Place functions in here that need to be protected by encryption.

#include "stdafx.h"

//#pragma optimize("agpswy", off)


extern "C" void __stdcall BeepTest(void)
{
	__asm
	{
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
	}


	Beep(1000, 100);




}
