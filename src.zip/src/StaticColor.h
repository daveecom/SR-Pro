#pragma once
#include "afxwin.h"


// CStaticColor

class CStaticColor : public CStatic
{
	//DECLARE_DYNAMIC(CStaticColor)

public:
	CStaticColor();
	virtual ~CStaticColor();

protected:
	DECLARE_MESSAGE_MAP()
public:
//	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
protected:
	COLORREF	m_TextColor[2];
	COLORREF	m_BkColor[2];
	CBrush		m_Brush[2];
	BOOL		m_bTransparent[2];
public:
	afx_msg HBRUSH CtlColor(CDC* /*pDC*/, UINT /*nCtlColor*/);
	afx_msg void OnTimer(UINT nIDEvent);
protected:
	virtual void PreSubclassWindow();
public:
	void SetTextColor(COLORREF Color0, COLORREF Color1, BOOL bRedraw = FALSE);
	void SetBkColor(COLORREF Color0, COLORREF Color1, BOOL bRedraw = FALSE);
protected:
	int m_ColorIndex;
	CString	m_strOldText;
public:
	void SetTextColor(COLORREF Color, BOOL bRedraw = FALSE);
	void SetBkColor(COLORREF Color, BOOL bRedraw = FALSE);
	void ResetColors(void);
	void SetWindowText(LPCTSTR lpszString, BOOL bRedraw = FALSE);
	void SetTransparent(BOOL bTrans1, BOOL bTrans2);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
//	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
//	virtual void DrawItem(LPDRAWITEMSTRUCT /*lpDrawItemStruct*/);
};

#pragma once


// CEditColor

class CEditColor : public CEdit
{
	DECLARE_DYNAMIC(CEditColor)

public:
	CEditColor();
	virtual ~CEditColor();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg HBRUSH CtlColor(CDC* /*pDC*/, UINT /*nCtlColor*/);
protected:
	COLORREF m_colorText;
	COLORREF m_colorBk;
	CBrush m_brushBk;
public:
	void SetTextColor(COLORREF Color);
	void SetBkColor(COLORREF Color);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};


