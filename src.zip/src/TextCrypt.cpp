#include "StdAfx.h"
#include "textcrypt.h"

CTextCrypt::CTextCrypt(void)
: m_mask8(0xd1)
, m_mask16(0xd298)
{
}

CTextCrypt::~CTextCrypt(void)
{
}

// This is my attempt to cover up some text to prevent hackers from seeing the text in a dump
void CTextCrypt::ConvertString(LPTSTR lpszOutput, LPCTSTR lpszInput)
{
	size_t	count;	// # chars in string.
	UINT	i;

	count = _tcsclen(lpszInput) + 1;

	for (i = 0; i < count; i++)
	{

#ifdef _UNICODE

		WCHAR	w;
		w = lpszInput[i];
		if (w != 0)
			w ^= m_mask16;
		lpszOutput[i] = w;

#else

		BYTE	b;
		b = lpszInput[i];
		if (b != 0)
			b ^= m_mask8;
		lpszOutput[i] = b;

#endif

	}
}

void CTextCrypt::ConvertStringA(LPSTR lpszOutput, LPCSTR lpszInput)
{
	size_t	count;	// # chars in string.
	UINT	i;

	count = strlen(lpszInput) + 1;

	for (i = 0; i < count; i++)
	{
		BYTE	b;
		b = lpszInput[i];
		if (b != 0)
			b ^= m_mask8;
		lpszOutput[i] = b;
	}
}

void CTextCrypt::ConvertStringW(LPWSTR lpszOutput, LPCWSTR lpszInput)
{
	size_t	count;	// # chars in string.
	UINT	i;

	count = wcslen(lpszInput) + 1;

	for (i = 0; i < count; i++)
	{
		WCHAR	w;
		w = lpszInput[i];
		if (w != 0)
			w ^= m_mask16;
		lpszOutput[i] = w;
	}
}

void CTextCrypt::ConvertString(CString& strOutput, LPCTSTR lpszInput)
{
	size_t	count;	// # chars in string.
	UINT	i;

	count = _tcsclen(lpszInput) + 1;

	strOutput.Empty();

	for (i = 0; i < count; i++)
	{
#ifdef _UNICODE
		WCHAR	w;
		w = lpszInput[i];
		if (w != 0)
			w ^= m_mask16;
		strOutput += w;
#else
		BYTE	b;
		b = lpszInput[i];
		if (b != 0)
			b ^= m_mask8;
		strOutput += b;
#endif
	}
}
// TextCrypt.cpp : implementation file
//

#include "stdafx.h"
#include "TextCrypt.h"

// CDlgConvertText dialog

IMPLEMENT_DYNAMIC(CDlgConvertText, CDialog)
CDlgConvertText::CDlgConvertText(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgConvertText::IDD, pParent)
{
}

CDlgConvertText::~CDlgConvertText()
{
}

void CDlgConvertText::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_IN, m_Edit_In);
	DDX_Control(pDX, IDC_EDIT_OUT, m_Edit_Out);
}


BEGIN_MESSAGE_MAP(CDlgConvertText, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_SUBMIT, OnBnClickedButtonSubmit)
END_MESSAGE_MAP()


// Perform the magic text hiding conversion.
void CDlgConvertText::OnBnClickedButtonSubmit()
{
	CString		strIn;
	CString		strOut;
	CString		strFmt, strFmt2;
	CTextCrypt	crypt;
	int			count, i;

	m_Edit_In.GetWindowText(strIn);
	count = strIn.GetLength();
	if (count > 0)
	{
		crypt.ConvertString(strOut, strIn);

		for (i = 0; i < count; i++)
		{
#ifdef _UNICODE
			strFmt2.Format(_T("0x%04X, "), (WORD) strOut[i]);
#else
			strFmt2.Format(_T("0x%02X, "), (BYTE) strOut[i]);
#endif
			strFmt += strFmt2;
		}
	}

	m_Edit_Out.Clear();
	m_Edit_Out.SetWindowText(strFmt);
}
