// DlgOptions.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "DlgOptions.h"
#include ".\dlgoptions.h"


// CDlgOptions dialog

IMPLEMENT_DYNAMIC(CDlgOptions, CDialog)
CDlgOptions::CDlgOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOptions::IDD, pParent)
	, m_bDirty(FALSE)
	, m_pDoc(NULL)
{
}

CDlgOptions::~CDlgOptions()
{
}

void CDlgOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SPIN_HANGTIME, m_Spin_Hangtime);
	DDX_Control(pDX, IDC_EDIT_HANGTIME, m_Edit_Hangtime);
	DDX_Control(pDX, IDC_CHECK_ENABLELOG, m_Check_EnableLog);
}


BEGIN_MESSAGE_MAP(CDlgOptions, CDialog)
	//ON_EN_KILLFOCUS(IDC_EDIT_HANGTIME, OnEnKillfocusEditHangtime)
	ON_WM_VSCROLL()
//	ON_BN_CLICKED(IDC_CHECK_ENABLELOG, OnBnClickedCheckEnablelog)
ON_BN_CLICKED(IDC_CHECK_ENABLELOG, OnBnClickedCheckEnablelog)
ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_HANGTIME, OnDeltaposSpinHangtime)
ON_EN_KILLFOCUS(IDC_EDIT_HANGTIME, OnEnKillfocusEditHangtime)
END_MESSAGE_MAP()


// CDlgOptions message handlers

BOOL CDlgOptions::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_ENABLELOG),	_T("Enable VOX event logging."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_HANGTIME),	_T("Specify VOX hang delay time."));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_HANGTIME),	_T("Specify VOX hang delay time."));

	CWnd*	pParent = GetParent();
	CRect	rect1;
	pParent->GetWindowRect(rect1);
	//SetWindowPos(&CWnd::wndTop, rect1.left, rect1.bottom, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);

	ASSERT(m_pDoc != NULL);
	//m_Spin_Hangtime.SetRange(50, 20 * 1000);
	m_Spin_Hangtime.SetRange(MIN_HANGTIME, MAX_HANGTIME);

	Update();
	//m_Spin_Hangtime.SetPos(m_pDoc->m_dwHang1);

	//m_Check_EnableLog.SetCheck(m_pDoc->m_bGenerateLogFile ? BST_CHECKED:BST_UNCHECKED);

	return TRUE;
}

//void CDlgOptions::OnEnKillfocusEditHangtime()
//{
//	CString	str;
//	int		hangTime, rangeLow, rangeHigh, pos;
//
//	// Validate the edit string
//	m_Spin_Hangtime.GetRange(rangeLow, rangeHigh);
//	pos = m_Spin_Hangtime.GetPos();
//	m_Edit_Hangtime.GetWindowText(str);
//	hangTime = _ttoi(str);
//	if (str.IsEmpty() || hangTime > rangeHigh || hangTime < rangeLow)
//	{	// hangtime is not valid
//		m_Spin_Hangtime.SetPos(pos);
//		m_Spin_Hangtime.RedrawWindow();
//	}
//	else
//	{	// Valid hangTime value
//		m_Spin_Hangtime.SetPos(hangTime);
//		m_bDirty = TRUE;
//	}
//	
//}
//
void CDlgOptions::Update(void)
{
	m_Spin_Hangtime.SetPos(m_pDoc->m_dwHang1);
	m_Check_EnableLog.SetCheck(m_pDoc->m_bGenerateLogFile ? BST_CHECKED:BST_UNCHECKED);
}

void CDlgOptions::OnOK()
{
	ASSERT(m_pDoc != NULL);

	if (m_bDirty)
	{
		m_pDoc->m_dwHang1 = m_Spin_Hangtime.GetPos();
		m_pDoc->m_bGenerateLogFile = m_Check_EnableLog.GetCheck() == BST_CHECKED;
	}

	CDialog::OnOK();
}

void CDlgOptions::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	m_bDirty = TRUE;
}


void CDlgOptions::OnBnClickedCheckEnablelog()
{
	m_bDirty = TRUE;
}

BOOL CDlgOptions::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN &&
		GetFocus() == GetDlgItem(IDC_EDIT_HANGTIME))
	{	// Enter key pressed in edit control.
		OnEnKillfocusEditHangtime();
		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgOptions::OnDeltaposSpinHangtime(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	*pResult = 0;
}

void CDlgOptions::OnEnKillfocusEditHangtime()
{
	int		nHangValue;
	CString	str;

	if (m_Edit_Hangtime.GetSafeHwnd() != NULL)
	{
		m_Edit_Hangtime.GetWindowText(str);

		nHangValue = _ttoi(str);

		// Force the new value to fit into the range we want.
		nHangValue = max(min(nHangValue, MAX_HANGTIME), MIN_HANGTIME);

		m_Spin_Hangtime.SetPos(nHangValue);

		m_bDirty = TRUE;
	}
}
