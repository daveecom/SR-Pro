#include "StdAfx.h"
#include ".\miscfilters.h"
#include "audiorecorder.h"

IMPLEMENT_DYNAMIC(CRecordGateFilter, CObject)

CRecordGateFilter::CRecordGateFilter(CAudioRecorder* pParent)
: CAudioFilter(pParent)
, m_nSampleNumber(0)
, m_nTriggerSamples(0)
{
	m_strObjectName = _T("CRecordGateFilter");
	SetPause(TRUE);
}

CRecordGateFilter::~CRecordGateFilter(void)
{
}

//void CRecordGateFilter::SetPause(BOOL bPause)
//{
//	__super::SetPause(bPause);
//}

void CRecordGateFilter::ProcessDataBuffer(RECBUFF* pRB)
{
	// Increment the sample count in order to track # of samples written to file.
	m_nSampleNumber += (pRB->wavehdr.dwBytesRecorded / m_pFormat->nBlockAlign);

	if (m_nTriggerSamples != 0)
	{
		if (m_nSampleNumber >= m_nTriggerSamples)
		{
			RolloverFile();		// Split the file by # samples (or relative time)
		}
	}

	__super::ProcessDataBuffer(pRB);
}

void CRecordGateFilter::ResetSampleCount(void)
{
	m_nSampleNumber = 0;
}

ULONGLONG CRecordGateFilter::GetSampleCount(void)
{
	return m_nSampleNumber;
}

FILETIME CRecordGateFilter::GetStoredTime(void)
{
	double	fTime;
	UFT		u1 = {0};

	if (this == NULL) return u1.ft;

	fTime	= (double) GetSampleCount();		// Get # samples stored
	fTime	/= m_pFormat->nSamplesPerSec;		// Get # seconds stored
	fTime	*= ONE_SECOND;						// Convert to time units.
	u1.ll	= (ULONGLONG) fTime;

	return u1.ft;
}

// Start an async thread that issues a checkpoint call from the
// CAudioRecorder object.
void CRecordGateFilter::RolloverFile()
{
	m_pParent->SplitterNeedToSplit();
}

// 0 = disable the trigger.
void CRecordGateFilter::SetTriggerSamples(ULONGLONG nCount)
{
	m_nTriggerSamples = nCount;
}

void CRecordGateFilter::SetTriggerTime(int HH, int MM, int SS)
{
	UFT	time = {0};

	time.ll	=	HH * ONE_HOUR;
	time.ll +=	MM * ONE_MINUTE;
	time.ll +=	SS * ONE_SECOND;

	if (m_pFormat->nSamplesPerSec > 0)
	{
		SetTriggerSamples((time.ll / ONE_SECOND) * m_pFormat->nSamplesPerSec);
	}
}
