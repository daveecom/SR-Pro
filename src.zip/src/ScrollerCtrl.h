#pragma once
#include "afxwin.h"
#include "avg.h"
#include "AudioRecorder.h"
#include "alarmclock.h"

// CScrollerCtrl

class CAudioRecorder;

class CScrollerCtrl : public CStatic
{
	//DECLARE_DYNAMIC(CScrollerCtrl)

public:
	CScrollerCtrl();
	virtual ~CScrollerCtrl();

protected:
	DECLARE_MESSAGE_MAP()

	// Main bitmap used to store the persistant image for drawing.
	CBitmap m_bmImage;
	CBitmap m_bmImage2;

	virtual void PreSubclassWindow();
	void ScrollBitmap(CDC* pDC);

public:
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void DrawValue(CDC* pDC, SCAN_INFO Scan);
	//virtual void PaintGrid(CDC* pDC);
	void SetRange(DWORD Range);
	//void SetVideoObject(CVideoEngine* pVideo);
	virtual SCAN_INFO FetchValue(void);

protected:
	DWORD			m_Range;		// Vertical range of the bitmap.

	//CVideoEngine*	m_pVideo;
	CStatic			m_Static_Overlay;
	CButton			m_Button_Clear;

	COLORREF		m_colorBK;		// Background Color
	COLORREF		m_colorFG;		// Foreground Color
	COLORREF		m_colorGrid;	// Grid color
	void			GetBitmapSize(CSize& size, HBITMAP hBitmap);
	CFont m_Font;
	CFont m_Font2;	// Used for L/R labels
//	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual void ClearButton(void);
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	//void ConnectToRecorder(CAudioRecorder* pRecorder);
protected:
	//CAudioRecorder* m_pRecorder;

	DWORD			m_dwTimePerBuffer;
	DWORD			m_dwTimePerBufferMeasured;
	DWORD			m_dwPercentCompressorLoad;	// 0 - 100

public:
	void DrawGrid(CDC* pDC);
protected:
	void DrawStats(CDC * pDC);
	CString m_strFreq;
	int		m_nSMeter;
	double m_fScrollFreq;
	CAlarmClock m_ScrollTimer;
	afx_msg LRESULT OnAlarmClockMsg( WPARAM, LPARAM );
	BOOL m_bGotRecorded;
	CToolTipCtrl		m_ToolTip;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	CLogFileWriter* m_pLogFile;
	int m_cRefreshCounter;
};

