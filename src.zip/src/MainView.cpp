// MainView.cpp : implementation of the CMainView class
//

#include "stdafx.h"
#include "App.h"

#include "Doc.h"
#include "dlgaddresslogging.h"
#include "dlgoptions.h"
#include "propSheetsched.h"
#include "dlgschedules.h"
#include "scheduler.h"
#include "dlgchannel.h"
#include ".\mainfrm.h"
#include ".\mainview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define	TIMER_PANEL		0
#define TIMER_NANO		1
#define TIMER_VU		2
#define TIMER_CLOCKS	3

// CMainView

IMPLEMENT_DYNCREATE(CMainView, CFormView)

BEGIN_MESSAGE_MAP(CMainView, CFormView)
	ON_WM_TIMER()
	ON_BN_CLICKED(ID_BUTTON_RECORD, OnBnClickedButtonRecord)
	ON_BN_CLICKED(ID_BUTTON_PAUSE, OnBnClickedButtonPause)
	ON_BN_CLICKED(ID_BUTTON_VOX, OnBnClickedButtonVox)
	ON_WM_CLOSE()
	ON_BN_CLICKED(ID_BUTTON_TIMERREC, OnBnClickedButtonTimerrec)
	ON_MESSAGE(UWM_CONTROL_RECORDSTART, OnTimerRecordStart)
	ON_MESSAGE(UWM_CONTROL_RECORDSTOP, OnTimerRecordStop)
	ON_WM_ERASEBKGND()
	ON_WM_CREATE()
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_FILESETTINGS, OnUpdateOptionsFilesettings)
	ON_COMMAND(ID_OPTIONS_FILESETTINGS, OnOptionsFilesettings)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_AUDIOSETTINGS, OnUpdateOptionsAudiosettings)
	ON_COMMAND(ID_OPTIONS_AUDIOSETTINGS, OnOptionsAudiosettings)
	//ON_UPDATE_COMMAND_UI(ID_OPTIONS_RADIOSETTINGS, OnUpdateOptionsRadiosettings)
	ON_COMMAND(ID_OPTIONS_RADIOSETTINGS, OnOptionsRadiosettings)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_MISC, OnUpdateOptionsMisc)
	ON_COMMAND(ID_OPTIONS_MISC, OnOptionsMisc)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_SCHEDULES, OnUpdateOptionsSchedules)
	ON_COMMAND(ID_OPTIONS_SCHEDULES, OnOptionsSchedules)
	ON_BN_CLICKED(ID_BUTTON_ROLLOVER, OnBnClickedButtonRollover)
	ON_EN_KILLFOCUS(IDC_EDIT_HANGTIME, OnEnKillfocusEditHangtime)
	ON_EN_KILLFOCUS(IDC_EDIT_VOX1, OnEnKillfocusEditVox1)
	ON_STN_CLICKED(IDC_STATIC_TIME, OnStnClickedStaticTime)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_RADIOSETTINGS, OnUpdateButtonRadiosettings)
	ON_COMMAND(ID_BUTTON_RADIOSETTINGS, OnButtonRadiosettings)
END_MESSAGE_MAP()

// CMainView construction/destruction

CMainView::CMainView()
	: CFormView(CMainView::IDD)
{
	//m_colorBk = GetSysColor(COLOR_3DFACE);
	//m_colorText	= GetSysColor(COLOR_BTNTEXT);

	m_colorBk = RGB(000, 000, 000);
	m_colorText	= RGB(255, 255, 255);

	m_bmBk.LoadBitmap(IDB_BITMAP_BK3);

	m_eClockMode = 	(CLOCKMODE) APP->GetProfileInt(_T("ClockMode"), Clock_Normal);
}

CMainView::~CMainView()
{
}

void CMainView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS_L, m_Progress_L);
	DDX_Control(pDX, IDC_PROGRESS_R, m_Progress_R);
	DDX_Control(pDX, IDC_STATIC_TIME, m_Static_Time);
	DDX_Control(pDX, IDC_STATIC_VOXIND, m_Static_VoxInd);
	DDX_Control(pDX, IDC_STATIC_RECSTAT, m_Static_RecStat);
	DDX_Control(pDX, IDC_STATIC_FILEDURATION, m_Static_FileDuration);
	DDX_Control(pDX, IDC_STATIC_EVENTSTART, m_Static_EventStart);
	DDX_Control(pDX, IDC_STATIC_EVENTDUR, m_Static_EventDur);
	DDX_Control(pDX, IDC_EDIT_VOX1, m_Edit_Vox1);
	DDX_Control(pDX, IDC_STATIC_STATUSAREA, m_Static_StatusArea);
	DDX_Control(pDX, IDC_STATIC_WAVE, m_ScrollCtrl);
	DDX_Control(pDX, IDC_STATIC_GRP_INPUTLEVEL, m_StaticGrp_InputLevel);
	DDX_Control(pDX, IDC_STATIC_GRP_BUTTONS, m_StaticGrp_Buttons);
	DDX_Control(pDX, IDC_STATIC_EVENTSTARTLABEL, m_Static_EventStartLabel);
	DDX_Control(pDX, IDC_STATIC_EVENTDURLABEL, m_Static_EventDurLabel);
	DDX_Control(pDX, IDC_STATIC_RECTIMELABEL, m_Static_RecordedTimeLabel);
	DDX_Control(pDX, ID_BUTTON_TIMERREC, m_Button_TimerRec);
	DDX_Control(pDX, ID_BUTTON_RECORD, m_Button_Record);
	DDX_Control(pDX, ID_BUTTON_PAUSE, m_Button_Pause);
	DDX_Control(pDX, ID_BUTTON_VOX, m_Button_Vox);
	DDX_Control(pDX, ID_BUTTON_ROLLOVER, m_Button_Rollover);
	DDX_Control(pDX, IDC_EDIT_HANGTIME, m_Edit_HangTime);
	DDX_Control(pDX, IDC_STATIC_CONVERTSTAT, m_Static_ChannelCVT);
	DDX_Control(pDX, IDC_STATIC_BUFFERS, m_Static_Buffers);
	DDX_Control(pDX, IDC_STATIC_DROPPED, m_Static_Dropped);
	DDX_Control(pDX, IDC_STATIC_BUFFERSLABEL, m_StaticLbl_Buffers);
	DDX_Control(pDX, IDC_STATIC_RADIO1, m_Static_Radio1);
	DDX_Control(pDX, IDC_STATIC_RADIO2, m_Static_Radio2);
	DDX_Control(pDX, IDC_STATIC_RADIO3, m_Static_Radio3);
	DDX_Control(pDX, IDC_STATIC_RADIO4, m_Static_Radio4);
	DDX_Control(pDX, IDC_STATIC_RADIO5, m_Static_Radio5);
	DDX_Control(pDX, IDC_STATIC_RADIO6, m_Static_Radio6);
}

BOOL CMainView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFormView::PreCreateWindow(cs);
}

void CMainView::OnInitialUpdate()
{
	CRect	rect;

	__super::OnInitialUpdate();

	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	// Try to get the size of the buttons
	rect.SetRect(0,0,41,41);
	PixelToDialog(&rect);
	DialogToPixel(&rect);

	if (m_Font.GetSafeHandle() == NULL)
	{
		m_Font.CreateFont(-18, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
			OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
			_T("Sans Serif"));

		m_Font2.CreateFont(-12, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
			OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
			_T("Sans Serif"));

		m_Static_Time.GetWindowRect(rect);

		m_Font_BigClock.CreateFont(-rect.Height(), rect.Width() / 9, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
			OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, PROOF_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
			_T("Serif"));


		this->SendMessageToDescendants(WM_SETFONT, (WPARAM) m_Font2.GetSafeHandle(), (LPARAM) FALSE);

		m_Static_Time.SetFont(&m_Font_BigClock);
		m_Static_StatusArea.SetFont(&m_Font);

		m_Progress_L.SetRange(0, 32768);
		m_Progress_L.SetVert(TRUE);
		m_Progress_R.SetRange(0, 32768);
		m_Progress_R.SetVert(TRUE);

		// Set some colors

		m_Static_EventDur.SetBkColor(m_colorBk);
		m_Static_EventDur.SetTextColor(m_colorText);
		m_Static_EventStart.SetBkColor(m_colorBk);
		m_Static_EventStart.SetTextColor(m_colorText);
		m_Static_FileDuration.SetBkColor(m_colorBk);
		m_Static_FileDuration.SetTextColor(m_colorText);
		m_Static_StatusArea.SetBkColor(m_colorBk);
		m_Static_StatusArea.SetTextColor(m_colorText);
		m_Static_Time.SetBkColor(m_colorBk);
		m_Static_Time.SetTextColor(m_colorText);
		m_Static_Buffers.SetBkColor(m_colorBk);
		m_Static_Buffers.SetTextColor(m_colorText);
		m_Static_Radio1.SetBkColor(m_colorBk);
		m_Static_Radio1.SetTextColor(m_colorText);
		m_Static_Radio2.SetBkColor(m_colorBk);
		m_Static_Radio2.SetTextColor(m_colorText);
		m_Static_Radio3.SetBkColor(m_colorBk);
		m_Static_Radio3.SetTextColor(m_colorText);
		m_Static_Radio4.SetBkColor(m_colorBk);
		m_Static_Radio4.SetTextColor(m_colorText);
		m_Static_Radio5.SetBkColor(m_colorBk);
		m_Static_Radio5.SetTextColor(m_colorText);
		m_Static_Radio6.SetBkColor(m_colorBk);
		m_Static_Radio6.SetTextColor(m_colorText);

		m_Static_Dropped.SetBkColor(m_colorBk);
		m_Static_Dropped.SetTextColor(m_colorText);

		m_Static_LocalTimeLabel.SetBkColor(m_colorBk);
		m_Static_LocalTimeLabel.SetTextColor(m_colorText);
		m_Static_EventDurLabel.SetBkColor(m_colorBk);
		m_Static_EventDurLabel.SetTextColor(m_colorText);
		m_Static_EventStartLabel.SetBkColor(m_colorBk);
		m_Static_EventStartLabel.SetTextColor(m_colorText);
		m_Static_RecordedTimeLabel.SetBkColor(m_colorBk);
		m_Static_RecordedTimeLabel.SetTextColor(m_colorText);
		m_StaticLbl_Hangtime.SetBkColor(m_colorBk);
		m_StaticLbl_Hangtime.SetTextColor(m_colorText);
		m_StaticLbl_VoxPct.SetBkColor(m_colorBk);
		m_StaticLbl_VoxPct.SetTextColor(m_colorText);
		m_StaticLbl_VoxPct.SetBkColor(m_colorBk);
		m_StaticLbl_Buffers.SetTextColor(m_colorText);
		m_StaticLbl_Buffers.SetBkColor(m_colorBk);
		m_StaticLbl_ChCvt.SetTextColor(m_colorText);
		m_StaticLbl_ChCvt.SetBkColor(m_colorBk);

		m_StaticGrp_InputLevel.SetBkColor(m_colorBk);
		m_StaticGrp_InputLevel.SetTextColor(m_colorText);
		m_StaticGrp_Buttons.SetBkColor(m_colorBk);
		m_StaticGrp_Buttons.SetTextColor(m_colorText);
		m_StaticGrp_Clocks.SetBkColor(m_colorBk);
		m_StaticGrp_Clocks.SetTextColor(m_colorText);
		m_StaticGrp_ScopeBorder.SetBkColor(m_colorBk);
		m_StaticGrp_ScopeBorder.SetTextColor(m_colorText);

		m_Edit_Vox1.SetBkColor(m_colorBk);
		m_Edit_Vox1.SetTextColor(m_colorText);
		
		m_Edit_HangTime.SetBkColor(m_colorBk);
		m_Edit_HangTime.SetTextColor(m_colorText);

		m_StaticLbl_VoxPct.SetBkColor(m_colorBk);
		m_StaticLbl_VoxPct.SetTextColor(m_colorText);

		m_Button_Record.SetFocus();
	}

	KillTimer(TIMER_PANEL);
	KillTimer(TIMER_NANO);
	KillTimer(TIMER_VU);
	KillTimer(TIMER_CLOCKS);

	SetTimer(TIMER_PANEL,	250,	NULL);
	SetTimer(TIMER_NANO,	5000,	NULL);
	SetTimer(TIMER_VU,		50,		NULL);
	//SetTimer(TIMER_VU,		100,		NULL);
	//SetTimer(TIMER_CLOCKS,	45,		NULL);
	SetTimer(TIMER_CLOCKS,	100,		NULL);

	// Reconnect the schedule controller to our control panel
	DOC->GetScheduler()->SetControlHwnd(GetSafeHwnd());

	// If timer mode on, then let'er rip.
	if (DOC->m_bTimerRecordArmed)
	{
		DOC->GetScheduler()->ActivateSchedules();
	}

	m_ToolTip.AddTool(GetDlgItem(ID_BUTTON_RECORD),			_T("Start or stop recording"));
	m_ToolTip.AddTool(GetDlgItem(IDC_PROGRESS_L),			_T("Left (or mono) VU Meter"));
	m_ToolTip.AddTool(GetDlgItem(IDC_PROGRESS_R),			_T("Right VU Meter"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_FILEDURATION),	_T("Shows how much time has been recorded into the current file."));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_EVENTSTART),	_T("Shows time last VOX event started."));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_EVENTDUR),		_T("Shows the duration of the VOX event."));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_TIME),			_T("Local Time (or click for elapsed recording time)."));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_VOXIND),		_T("VOX gate status"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_RECSTAT),		_T("Record mode indicator"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_STATUSAREA),	_T("Shows info on the next (or current) scheduled recording."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_VOX1),			_T("VOX threshold %"));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_WAVE),			_T("Displays peak input levels and status"));
	m_ToolTip.AddTool(GetDlgItem(ID_BUTTON_PAUSE),			_T("Pause the recording."));
	m_ToolTip.AddTool(GetDlgItem(ID_BUTTON_VOX),			_T("Enable or disable VOX recording mode."));
	m_ToolTip.AddTool(GetDlgItem(ID_BUTTON_TIMERREC),		_T("Enable or disable scheduled recording."));
	m_ToolTip.AddTool(GetDlgItem(ID_BUTTON_ROLLOVER),		_T("Split recording output file on-the-fly."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_HANGTIME),		_T("VOX hang time."));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_CONVERTSTAT),	_T("Shows whether the channel converter is on."));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_BUFFERS),		_T("Number of audio buffers in use throughout the recorder."));
	m_ToolTip.AddTool(GetDlgItem(IDC_STATIC_DROPPED),		_T("Number of dropped buffers. Should always be zero or the audio will have gaps."));
}


// CMainView diagnostics

#ifdef _DEBUG
void CMainView::AssertValid() const
{
	CFormView::AssertValid();
}

void CMainView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

#endif //_DEBUG


void CMainView::OnTimer(UINT nIDEvent)
{
	switch (nIDEvent)
	{
		case TIMER_PANEL:	// Panel refresh (medium speed)
			Update();
			break;

		case TIMER_NANO:	// Nanomite time (low speed)
			Nanomite();
			break;

		case TIMER_VU:		// Refresh the VU meters (high speed).
			UpdateVUMeters();
			UpdateVoxIndicator();
			UpdateRecordingIndicator();
			break;

		case TIMER_CLOCKS:	// Refresh the panel clocks (high speed)
			UpdateClocks();
			break;
	}

}

//void CMainView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
//{
//	int			nVoxVal, nHangVal;
//	CString		str;
//
//	if (GetFocus() == &m_Edit_HangTime)
//	{
//		GetWindowText(str);
//		nHangVal = _ttoi(str);
//		if (nSBCode == SB_LINEUP || nSBCode == SB_LINEDOWN)
//		{
//			++nHangVal = min(MIN_HANGTIME, max(MAX_HANGTIME, nHangVal));
//			str.Format(_T("%d"), (int) nHangVal);
//			m_Edit_HangTime.SetWindowText(str);
//		}
//	}
//	else
//	if (GetFocus() == &m_Edit_Vox1)
//	{
//		GetWindowText(str);
//		nVoxVal = _ttoi(str);
//		if (nSBCode == SB_LINEUP || nSBCode == SB_LINEDOWN)
//		{
//			++nVoxVal = min(0, max(100, nVoxVal));
//			str.Format(_T("%d"), (int) nVoxVal);
//			m_Edit_Vox1.SetWindowText(str);
//		}
//	}
//}

// Fetch all external values and refresh the control panel.
void CMainView::Update(void)
{
	BOOL			bInit;
	CString			str;
	CScheduleItem*	pItem;
	UFT				u1, uDelta;
	CAlarmClock		clock;	// Used to get local time.
	DWORD			dwDropped	= 0;
	int				nAllocated	= 0;

	bInit = DOC->GetRecorder()->IsInit();

	// Why did I do this? We'll see what happens now that I commented it out...
	//GetParentFrame()->GetMenu()->EnableMenuItem(ID_BUTTON_AUDIOSETTINGS, (!DOC->m_bTimerRecordArmed) ? MF_ENABLED : MF_GRAYED);
	//GetParentFrame()->GetMenu()->EnableMenuItem(ID_BUTTON_FILESETTINGS, (!DOC->m_bTimerRecordArmed) ? MF_ENABLED : MF_GRAYED);
	//GetParentFrame()->GetMenu()->EnableMenuItem(ID_BUTTON_OPTIONS, (!DOC->m_bTimerRecordArmed) ? MF_ENABLED : MF_GRAYED);
	//GetParentFrame()->GetMenu()->EnableMenuItem(ID_BUTTON_SCHEDULE, (!DOC->m_bTimerRecordArmed) ? MF_ENABLED : MF_GRAYED);
	//GetParentFrame()->GetMenu()->EnableMenuItem(ID_BUTTON_RADIOSETTINGS, (!DOC->m_bTimerRecordArmed) ? MF_ENABLED : MF_GRAYED);

	m_Button_Record.EnableWindow(bInit && !DOC->m_bTimerRecordArmed);
	m_Button_Vox.EnableWindow(bInit && !DOC->m_bRecord & !DOC->m_bTimerRecordArmed);
	m_Button_Pause.EnableWindow(bInit && !DOC->m_bTimerRecordArmed);
	m_Button_Rollover.EnableWindow(bInit);

	m_Button_Record.SetCheck(DOC->m_bRecord);
	m_Button_Pause.SetCheck(DOC->m_bPause);
	m_Button_Vox.SetCheck(DOC->m_bVox1);
	m_Button_TimerRec.SetCheck(DOC->m_bTimerRecordArmed);

	// Disable some controls if mono
	if (DOC->m_AudioSettings.IsStereo())
	{
		if (!m_Progress_R.IsWindowEnabled())
		{
			m_Progress_R.EnableWindow(TRUE);
			Invalidate();
		}
	}
	else
	{
		if (m_Progress_R.IsWindowEnabled())
		{
			m_Progress_R.EnableWindow(FALSE);
			Invalidate();
		}
	}

	// Show the time until the next scheduled show starts or the time
	// until the in-progress show ends.
	pItem = DOC->GetScheduler()->GetNextScheduledItem();
	if (pItem == NULL)
		m_Static_StatusArea.SetWindowText(_T(""));
	else
	{
		clock.GetTime(&u1);

		if (pItem->IsShowOnNow())
		{	// Show is on now.
			uDelta.ll = (pItem->GetStart().ll + pItem->GetDuration().ll) - u1.ll;

			uDelta.ll += ONE_SECOND;	// Correction??

			str.Format(_T("'%s' ends in %d:%02d"),
				pItem->GetName(),
				(int) ((uDelta.ll / ONE_MINUTE)),
				(int) ((uDelta.ll / ONE_SECOND) % 60));
		}
		else
		{	// Show is off.
			uDelta.ll = pItem->GetStart().ll - u1.ll;

			uDelta.ll += ONE_SECOND;	// Correction??

			str.Format(_T("'%s' starts in %d:%02d:%02d"),
				pItem->GetName(),
				(int) ((uDelta.ll / ONE_HOUR)),
				(int) ((uDelta.ll / ONE_MINUTE) % 60),
				(int) ((uDelta.ll / ONE_SECOND) % 60));
		}

		m_Static_StatusArea.SetWindowText(str);
	}

	// Handle the hang time edit box.
	if (GetFocus() != &m_Edit_HangTime)
	{
		str.Format(_T("%d"), DOC->m_dwHang1);
		m_Edit_HangTime.SetWindowText(str);
	}

	// Show some basic perf stats.
	nAllocated = DOC->GetAllocatedBufferCount();
	dwDropped = DOC->GetDroppedFrames();
	
	str.Format(_T("%d"), nAllocated);
	m_Static_Buffers.SetWindowText(str);

	str.Format(_T("%d"), dwDropped);
	m_Static_Dropped.SetWindowText(str);

	if (dwDropped > 0)
	{
		m_Static_Dropped.SetBkColor(RGB(255,000,000), m_colorBk, TRUE);
		m_Static_Dropped.SetTextColor(RGB(255,255,255), TRUE);
	}
	else
	{
		m_Static_Dropped.SetBkColor(m_colorBk, TRUE);
		m_Static_Dropped.SetTextColor(m_colorText, TRUE);
	}

	// Show the channel converter status
	if (DOC->m_AudioSettings.IsChannelConverted())
	{
		m_Static_ChannelCVT.SetBkColor(RGB(255,255,000));
		m_Static_ChannelCVT.SetTextColor(RGB(000,000,000));
		m_Static_ChannelCVT.SetWindowText(_T("Cvt On"));
	}
	else
	{
		m_Static_ChannelCVT.SetBkColor(m_colorBk);
		m_Static_ChannelCVT.SetTextColor(m_colorText);
		m_Static_ChannelCVT.SetWindowText(_T("Cvt Off"));
	}

	// Display some radio returns.
	if (DOC->m_RadioSettings.IsRadioEnabled())
	{
		if (DOC->m_RadioSettings.GetJobItemCount() >= 1)
		m_Static_Radio1.SetWindowText(DOC->m_RadioSettings.GetJobItem(0)->GetResult());
		if (DOC->m_RadioSettings.GetJobItemCount() >= 2)
		m_Static_Radio2.SetWindowText(DOC->m_RadioSettings.GetJobItem(1)->GetResult());
		if (DOC->m_RadioSettings.GetJobItemCount() >= 3)
		m_Static_Radio3.SetWindowText(DOC->m_RadioSettings.GetJobItem(2)->GetResult());
		if (DOC->m_RadioSettings.GetJobItemCount() >= 4)
		m_Static_Radio4.SetWindowText(DOC->m_RadioSettings.GetJobItem(3)->GetResult());
		if (DOC->m_RadioSettings.GetJobItemCount() >= 5)
		m_Static_Radio5.SetWindowText(DOC->m_RadioSettings.GetJobItem(4)->GetResult());
		if (DOC->m_RadioSettings.GetJobItemCount() >= 6)
		m_Static_Radio6.SetWindowText(DOC->m_RadioSettings.GetJobItem(5)->GetResult());
	}
	else
	{
		// TODO blank the radio fields
	}
}

void CMainView::UpdateRecordingIndicator()
{
	BOOL			bRecord;
	BOOL			bVox;
	BOOL			bVoxGateOpen;
	BOOL			bTimerArmed;
	CString			str;

	bRecord			= DOC->m_bRecord;
	bVox			= DOC->m_bVox1;
	bVoxGateOpen	= DOC->GetRecorder()->IsVoxGateOpen();
	bTimerArmed		= DOC->m_bTimerRecordArmed;

	if (bTimerArmed)
	{
		if (bRecord)
		{	// Timer recording now.
			m_Static_RecStat.SetWindowText(_T("T-Rec"));
			m_Static_RecStat.SetTextColor(RGB(255, 255, 255));
			m_Static_RecStat.SetBkColor(RGB(255, 000, 000), TRUE);
		}
		else
		{	// Timer recording armed.
			m_Static_RecStat.SetWindowText(_T("T-Stby"));
			m_Static_RecStat.SetTextColor(RGB(000, 000, 000), m_colorText);
			m_Static_RecStat.SetBkColor(RGB(255, 255, 000), m_colorBk, TRUE);
		}
	}
	else
	if (!bRecord)
	{	// Recording disabled.
		m_Static_RecStat.SetWindowText(_T("Rec"));
		m_Static_RecStat.SetTextColor(m_colorText);
		m_Static_RecStat.SetBkColor(m_colorBk, TRUE);
	}
	else
	{	// Recording
		if (bVox)
		{	// Vox mode on
			if (bVoxGateOpen)
			{
				m_Static_RecStat.SetWindowText(_T("Rec"));
				m_Static_RecStat.SetTextColor(RGB(255, 255, 255));
				m_Static_RecStat.SetBkColor(RGB(255, 000, 000), TRUE);
			}
			else
			{
				m_Static_RecStat.SetWindowText(_T("V-StdBy"));
				m_Static_RecStat.SetTextColor(RGB(000, 000, 000));
				m_Static_RecStat.SetBkColor(RGB(255,255,000), TRUE);
			}
		}
		else
		{
			m_Static_RecStat.SetWindowText(_T("Rec"));
			m_Static_RecStat.SetTextColor(RGB(255, 255, 255));
			m_Static_RecStat.SetBkColor(RGB(255, 000, 000), TRUE);
		}
	}
}

void CMainView::UpdateVoxIndicator()
{
	// Update vox status display
	m_Static_VoxInd.SetWindowText(_T("Vox"));

	if (!DOC->m_bVox1)
	{
		m_Static_VoxInd.SetTextColor(m_colorText);
		m_Static_VoxInd.SetBkColor(m_colorBk, TRUE);
	}
	else
	{
		if (DOC->GetRecorder()->IsInit())
		if (DOC->GetRecorder()->IsVoxGateOpen())
		{	// Vox open
			m_Static_VoxInd.SetTextColor(RGB(255,255,255));
			m_Static_VoxInd.SetBkColor(RGB(255,000,000), TRUE);
		}
		else
		{	// Vox closed
			m_Static_VoxInd.SetTextColor(RGB(000,000,000));
			m_Static_VoxInd.SetBkColor(RGB(000,255,000), TRUE);
		}
	}
}

void CMainView::UpdateClocks(void)
{
	SYSTEMTIME		tm;
	CString			str;
	UFT				u1 = {0};
	int				hours, mins, secs, msecs, tsecs;
	CAlarmClock		clock;

	GetLocalTime(&tm);

	switch (m_eClockMode)
	{
		case Clock_Normal:
			str.Format(_T("%02d:%02d:%02d"), tm.wHour, tm.wMinute, tm.wSecond);
			m_Static_Time.SetWindowText(str);
			break;

		case Clock_Elapsed:


			if (DOC->m_uRecordStartTime.ll == 0)
			{
				ZeroMemory(&tm, sizeof(SYSTEMTIME));
				str.Format(_T("+%02d:%02d:%02d"), tm.wHour, tm.wMinute, tm.wSecond);
				m_Static_Time.SetWindowText(str);
			}
			else
			{
				u1		= clock.GetTime();
				u1.ll	-= DOC->m_uRecordStartTime.ll;
				FileTimeToSystemTime(&u1.ft, &tm);
				str.Format(_T("+%02d:%02d:%02d"), tm.wHour, tm.wMinute, tm.wSecond);
				m_Static_Time.SetWindowText(str);
			}
			
			break;
	}

	// Stored duration in file
	u1.ll = 0;
	if (DOC->GetRecorder() != NULL)
		u1.ft = DOC->GetRecorder()->GetStoredTime();

	hours	= ((int) (u1.ll / ONE_HOUR));
	mins	= ((int) (u1.ll / ONE_MINUTE % 60));
	secs	= ((int) (u1.ll / ONE_SECOND % 60));
	msecs	= ((int) (u1.ll / ONE_MILLISECOND % 1000));
	tsecs	= ((int) (u1.ll / (ONE_MILLISECOND * 100) % 10));

	str.Format(_T("%03d:%02d:%02d.%1d"), hours, mins, secs, tsecs);
	m_Static_FileDuration.SetWindowText(str);

	if (!DOC->GetRecorder()->GetSplitterState())
	{
		m_Static_FileDuration.SetTextColor(m_colorText, TRUE);
	}
	else
	{
		m_Static_FileDuration.SetTextColor(RGB(255,000,000), m_colorText);
	}

	// Event start time indicator
	u1.ll = 0;
	if (DOC->GetRecorder() != NULL)
		u1.ft = DOC->GetRecorder()->GetEventStart();

	FileTimeToSystemTime(&u1.ft, &tm);
	str.Format(_T("%02d:%02d:%02d"), tm.wHour, tm.wMinute, tm.wSecond);
	m_Static_EventStart.SetWindowText(str);

	// Event duration indicator
	u1.ll = 0;
	if (DOC->GetRecorder() != NULL)
		u1.ft = DOC->GetRecorder()->GetEventDuration();

	hours	= ((int) (u1.ll / ONE_HOUR));
	mins	= ((int) (u1.ll / ONE_MINUTE % 60));
	secs	= ((int) (u1.ll / ONE_SECOND % 60));
	msecs	= ((int) (u1.ll / ONE_MILLISECOND % 1000));
	tsecs	= ((int) (u1.ll / (ONE_MILLISECOND * 100) % 10));

	str.Format(_T("%03d:%02d:%02d.%1d"), hours, mins, secs, tsecs);
	m_Static_EventDur.SetWindowText(str);
}

void CMainView::OnBnClickedButtonRecord()
{
	BOOL	bEnableRecorder = FALSE;

	SECUREBEGIN_A;
	bEnableRecorder = TRUE;
	SECUREEND_A;

	if (DOC->GetRecorder() != NULL)
	{
		DOC->m_bRecord = (IsDlgButtonChecked(ID_BUTTON_RECORD) == BST_CHECKED);

		////////////////////////////////////////
		// Prevent recording if timed version has expired.
		////////////////////////////////////////
		if (!bEnableRecorder)
		{
			CheckDlgButton(ID_BUTTON_RECORD, BST_UNCHECKED);
			DOC->m_bRecord = FALSE;
		}
		////////////////////////////////////////

		else
		{
			DOC->SetModifiedFlag(TRUE);
			DOC->SetRecord(DOC->m_bRecord);
			m_Static_Radio1.SetWindowText(_T(""));
			m_Static_Radio2.SetWindowText(_T(""));
			m_Static_Radio3.SetWindowText(_T(""));
			m_Static_Radio4.SetWindowText(_T(""));
			m_Static_Radio5.SetWindowText(_T(""));
			m_Static_Radio6.SetWindowText(_T(""));
		}
	}
}

void CMainView::OnBnClickedButtonPause()
{
	if (DOC->GetRecorder() != NULL)
	{
		DOC->m_bPause = m_Button_Pause.GetCheck() == BST_CHECKED;
		DOC->SetModifiedFlag(TRUE);

		DOC->GetRecorder()->SetPause(DOC->m_bPause);
	}

	//Update();
}

void CMainView::OnBnClickedButtonVox()
{
	if (DOC->GetRecorder() != NULL)
	{
		DOC->m_bVox1 = (IsDlgButtonChecked(ID_BUTTON_VOX) == BST_CHECKED);
		DOC->SetModifiedFlag();

		DOC->GetRecorder()->SetVoxOn(DOC->m_bVox1);
	}

}

void CMainView::OnClose()
{
	KillTimer(TIMER_PANEL);
	KillTimer(TIMER_NANO);

	__super::OnClose();
}

void CMainView::Nanomite(void)
{
	double	a, b, c;

	NANOBEGIN;

	a	= 1.02334;
	c	= 2.0002;
	b	= sqrt(a*a + c*c);

	NANOEND;
}

void CMainView::OnBnClickedButtonTimerrec()
{
#ifndef _LITE

	BOOL bState;	// Button State on/off

	//bState = SendDlgItemMessage(ID_BUTTON_TIMERREC, BM_GETCHECK) == BST_CHECKED;
	bState = m_Button_TimerRec.GetCheck() == BST_CHECKED;
	DOC->m_bTimerRecordArmed = bState;	
	DOC->SetModifiedFlag();

	if (bState)	// turn off recording in progress if timer mode activated.
	{
		DOC->m_bRecord = FALSE;
		DOC->SetRecord(FALSE);

		// If timer mode turned on, force unpause.
		DOC->m_bPause = FALSE;
		DOC->SetPause(FALSE);

		// tell scheduler that we want to auto-record,
		DOC->GetScheduler()->ActivateSchedules();
	}
	else
	{
		// Disable auto-record.
		DOC->GetScheduler()->AbortSchedules();
	}
#endif
}

LRESULT CMainView::OnTimerRecordStart(WPARAM wParam, LPARAM lParam)
{
	CScheduleItem*	pItem	= (CScheduleItem*) wParam;

	m_strFilenameRootBkp = DOC->m_FilenameServer1.GetFilenameRoot();
	DOC->m_FilenameServer1.SetFilenameRoot(pItem->GetName());

	_beginthread(DelayedRecorderControlProc, 0, (PVOID) TRUE);

	return TRUE;
}

LRESULT CMainView::OnTimerRecordStop(WPARAM wParam, LPARAM lParam)
{
	_beginthread(DelayedRecorderControlProc, 0, (PVOID) FALSE);

	DOC->m_FilenameServer1.SetFilenameRoot(m_strFilenameRootBkp);

	return TRUE;
}

// This allows the message handler to start or stop the recorder without
// delaying the message loop itself, making the clocks look smoother.
void __cdecl CMainView::DelayedRecorderControlProc( PVOID pUser)
{
	BOOL	bParm	= (BOOL) ((DWORD_PTR) pUser);

	DOC->m_bRecord = bParm;
	DOC->SetRecord(bParm);
}

BOOL CMainView::OnEraseBkgnd(CDC* pDC)
{
	CRect		rect;
	CBrush		brush;
	CPen		pen;

	if (0)
	{
		BITMAP		bm;
		CDC			dcBm;
		dcBm.CreateCompatibleDC(pDC);

		m_bmBk.GetObject(sizeof(BITMAP), &bm);
		GetClientRect(&rect);

		dcBm.SaveDC();

		dcBm.SelectObject(&m_bmBk);
		pDC->BitBlt(0, 0, bm.bmWidth, bm.bmHeight, &dcBm, 0, 0, SRCCOPY);

		dcBm.RestoreDC(-1);
	}

	if (1)
	{
		GetClientRect(&rect);
		//pDC->SetBkColor(m_colorBk);

		brush.CreateSolidBrush(m_colorBk);

		pDC->FillRect(&rect, &brush);

	}

	if (0)
	{
		__super::OnEraseBkgnd(pDC);
	}


	return TRUE;
}

int CMainView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (__super::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_ToolTip.Create(this);

	return 0;
}

BOOL CMainView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	__super::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);

	m_Button_Record.LoadBitmaps(IDB_BITMAP_REC_UP, IDB_BITMAP_REC_DN);
	m_Button_Record.SetToggleMode(TRUE);

	m_Button_Pause.LoadBitmaps(IDB_BITMAP_PAUSE_UP, IDB_BITMAP_PAUSE_DN);
	m_Button_Pause.SetToggleMode(TRUE);

	m_Button_Vox.LoadBitmaps(IDB_BITMAP_VOX_UP, IDB_BITMAP_VOX_DN);
	m_Button_Vox.SetToggleMode(TRUE);

	m_Button_TimerRec.LoadBitmaps(IDB_BITMAP_TIMER_UP, IDB_BITMAP_TIMER_DN);
	m_Button_TimerRec.SetToggleMode(TRUE);

	m_Button_Rollover.LoadBitmaps(IDB_BITMAP_ROLLOVER_UP, IDB_BITMAP_ROLLOVER_DN);

	return TRUE;
}

void CMainView::OnUpdateOptionsFilesettings(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!DOC->m_bRecord && !DOC->m_bTimerRecordArmed);
}

void CMainView::OnOptionsFilesettings()
{
	INT_PTR rc;
	
	rc = DOC->m_FilenameServer1.GetFileSettings()->DoModal();
	if (rc == IDOK)
	{
		DOC->SetModifiedFlag();

		if (DOC->GetRecorder() != NULL)
		{
			DOC->StopAudioEngine();
			DOC->StartAudioEngine();
		}
	}
}

void CMainView::OnUpdateOptionsAudiosettings(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!DOC->m_bRecord && !DOC->m_bTimerRecordArmed);
}

void CMainView::OnOptionsAudiosettings()
{
	INT_PTR rc;
	
	if (DOC->GetRecorder() != NULL)
	{
		DOC->StopAudioEngine();
	}

	rc = DOC->m_AudioSettings.DoModal();
	if (rc == IDOK)
	{
		DOC->SetModifiedFlag();
	}

	DOC->StartAudioEngine();

	Invalidate();
}

void CMainView::OnOptionsRadiosettings()
{
#ifndef _LITE
	//INT_PTR	result;
	//CDlgFrequencyLogging	dlg(this);

	//dlg.m_pDoc = DOC;
	//result = dlg.DoModal();
#endif
}

void CMainView::OnUpdateOptionsMisc(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!DOC->m_bRecord && !DOC->m_bTimerRecordArmed);
}

void CMainView::OnOptionsMisc()
{
	INT_PTR result;
	CDlgOptions dlg(this);

	dlg.m_pDoc = DOC;
	result = dlg.DoModal();
	if (result == IDOK)
	{
		DOC->GetRecorder()->SetHangTime1(DOC->m_dwHang1);
	}
}

void CMainView::OnUpdateOptionsSchedules(CCmdUI *pCmdUI)
{
	BOOL	bEnable = !DOC->m_bRecord && !DOC->m_bTimerRecordArmed;

#ifdef _LITE
	pCmdUI->Enable(FALSE);
#else
	pCmdUI->Enable(bEnable);
#endif

}

void CMainView::OnOptionsSchedules()
{
	CScheduleController*	pController = DOC->GetScheduler();
	CDlgSchedules			dlgSched(this, pController);

	dlgSched.DoModal();
}

// Convert from pixel units to dialog template units. Opposite of MapDialogRect().
void CMainView::PixelToDialog(LPRECT lpRect)
{
	CRect base(0,0,4,8);

	// Get the base units.
	MapDialogRect(GetSafeHwnd(), &base);

	// Convert to template units.
	lpRect->right	= MulDiv(lpRect->right,		4, base.right);
	lpRect->bottom	= MulDiv(lpRect->bottom,	8, base.bottom);
}

void CMainView::DialogToPixel(LPRECT lpRect)
{
	MapDialogRect(GetSafeHwnd(), lpRect);
}


void CMainView::OnBnClickedButtonRollover()
{
	DOC->CheckpointFile();
}

void CMainView::UpdateVUMeters(void)
{
	CString			str;
	SCAN_INFO		scan = {0};

	DOC->GetScanInfo(&scan);
	m_Progress_L.SetPos(scan.wHighLeft);
	m_Progress_R.SetPos(scan.wHighRight);

	// If the mouse was used to change the vox setting then we have to
	// update the control variable.
	if (m_Progress_L.IsMousePosValid())
	{
		DOC->SetVox((float) m_Progress_L.GetNewVoxPos() / 32768 * 100);
	}

	if (m_Progress_R.IsMousePosValid())
	{
		DOC->SetVox((float) m_Progress_R.GetNewVoxPos() / 32768 * 100);
	}

	if (GetFocus() != &m_Edit_Vox1)
	{
		str.Format(_T("%d"), (int) (DOC->m_VoxVal1_L + .5));
		m_Edit_Vox1.SetWindowText(str);
	}

	m_Progress_L.SetVoxPos(((double) DOC->m_VoxVal1_L / 100.0) * 32768);
	m_Progress_R.SetVoxPos(((double) DOC->m_VoxVal1_L / 100.0) * 32768);
}


BOOL CMainView::PreTranslateMessage(MSG* pMsg)
{
	int			nVoxVal, nHangVal;
	CString		str;

	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
		m_ToolTip.RelayEvent(pMsg);

	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN &&
		GetFocus() == GetDlgItem(IDC_EDIT_HANGTIME))
	{	// Enter key pressed in edit control.
		OnEnKillfocusEditHangtime();
	}

	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN &&
		GetFocus() == GetDlgItem(IDC_EDIT_VOX1))
	{	// Enter key pressed in edit control.
		OnEnKillfocusEditVox1();
	}

	if (pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_UP || pMsg->wParam == VK_DOWN))
	{

		if (GetFocus() == &m_Edit_HangTime)
		{
			m_Edit_HangTime.GetWindowText(str);
			nHangVal = _ttoi(str);

			if (pMsg->wParam == VK_UP)
				++nHangVal;
			else
				--nHangVal;

			nHangVal = min(MAX_HANGTIME, max(MIN_HANGTIME, nHangVal));

			DOC->m_dwHang1 = nHangVal;
			DOC->SetModifiedFlag();

			str.Format(_T("%d"), (int) nHangVal);
			m_Edit_HangTime.SetWindowText(str);
		}

		if (GetFocus() == &m_Edit_Vox1)
		{
			m_Edit_Vox1.GetWindowText(str);
			nVoxVal = _ttoi(str);

			if (pMsg->wParam == VK_UP)
				++nVoxVal;
			else
				--nVoxVal;

			nVoxVal = min(100, max(0, nVoxVal));
			DOC->SetVox((float) nVoxVal);

			str.Format(_T("%d"), (int) nVoxVal);
			m_Edit_Vox1.SetWindowText(str);
		}
	}

	return __super::PreTranslateMessage(pMsg);
}

void CMainView::OnEnKillfocusEditHangtime()
{
	int		nHangValue;
	CString	str;

	if (m_Edit_HangTime.GetSafeHwnd() != NULL)
	{
		m_Edit_HangTime.GetWindowText(str);

		nHangValue = _ttoi(str);

		// Force the new value to fit into the range we want.
		nHangValue = max(min(nHangValue, MAX_HANGTIME), MIN_HANGTIME);

		str.Format(_T("%d"), nHangValue);
		m_Edit_HangTime.SetWindowText(str);

		if (DOC->GetRecorder()->IsInit())
			DOC->GetRecorder()->SetHangTime1(nHangValue);

		DOC->m_dwHang1 = nHangValue;
		DOC->SetModifiedFlag();
	}
}

void CMainView::OnEnKillfocusEditVox1()
{
	double	nVoxValue;
	CString	str;

	if (m_Edit_Vox1.GetSafeHwnd() != NULL)
	{
		m_Edit_Vox1.GetWindowText(str);

		nVoxValue = _tstof(str);

		// Force the new value to fit into the range we want.
		nVoxValue = max(min(nVoxValue, 100), 0);

		if (DOC->GetRecorder()->IsInit())
			DOC->GetRecorder()->SetVox((float) nVoxValue);

		DOC->m_VoxVal1_L = (float) nVoxValue;

		DOC->SetModifiedFlag();

		str.Format(_T("%d"), (int) nVoxValue);
		m_Edit_Vox1.SetWindowText(str);

		UpdateData(FALSE);
	}
}

void CMainView::MoveFocusAwayFromEditBoxes(void)
{
	// Move the focus away from the vox or hang time indicators
	if (m_Button_Record.GetSafeHwnd() != NULL) m_Button_Record.SetFocus();
}

// Main clock was clicked.
void CMainView::OnStnClickedStaticTime()
{
	// Roll the clock mode to the next logical value.
	if (m_eClockMode	== Clock_Elapsed)
		m_eClockMode	= Clock_Normal;
	else
		m_eClockMode	= Clock_Elapsed;

	APP->WriteProfileInt(_T("ClockMode"), (int) m_eClockMode);
}

void CMainView::OnUpdateButtonRadiosettings(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!DOC->m_bRecord && !DOC->m_bTimerRecordArmed);
}

void CMainView::OnButtonRadiosettings()
{
	CDlgRadioSettings dlg(this);
	INT_PTR	result;
	//Doc*	doc	= DOC;	// 4 debugggg

	dlg.SetRadioSettings(& DOC->m_RadioSettings);

	// Disable the audio recorder to prevent conflict using the COM port
	DOC->StopAudioEngine();

	result = dlg.DoModal();

	if (result == IDOK)
	{
		DOC->m_RadioSettings = dlg.GetRadioSettings();
		DOC->SetModifiedFlag();
	}

	DOC->StartAudioEngine();
}
