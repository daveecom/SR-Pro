#pragma once

#include "resource.h"
#include "afxcmn.h"
#include "afxwin.h"
//#include "o:\program files\microsoft platform sdk\include\mfc\afxwin.h"

typedef enum _lim_mode
{
	lim_Off		= 0,				// File limiter off
	lim_event,						// Limit file to one per event.
	lim_duration,					// Limit file by recorded duration.
	lim_clock						// Limit file based on the time of day.
}	LIM_MODE;

typedef enum _seq_mode
{
	seq_counter,					// append a unique count number			fn_NNNN
	seq_date						// append event date/time to filename	fn_YYMMDDHHMMSSMS
}	SEQ_MODE;


class			CFileSettings;

// Handle the file settings dialog.
class CDlgFileSettings : public CDialog
{
	DECLARE_DYNAMIC(CDlgFileSettings)

public:
	CDlgFileSettings(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgFileSettings();

	CFileSettings*		m_pParent;		// owner object
	HWND				m_hParent;		// parent dlg window

	// Copy of vars to be used by parent if IDOK pressed.
	CString		m_strFolder;		// Folder name (without trailing slash)
	CString		m_strFilenameRoot;	// Name part of filename without seq #
	CString		m_strExt;			// Extension to use
	int			m_nSeqDigits;		// # of sequence digits to append to the name
	SEQ_MODE	m_eSeqMode;			// Type of stuff to append to name.
	LIM_MODE	m_eLimMode;			// File chopping mode.
	int			m_LimHH;			// HH used with limit mode
	int			m_LimMM;			// MM used with limit mode
	BOOL		m_bLimSyncTOD;		// Sync with Top Of previous Day.
	BOOL		m_bVoxSync;			// use vox to prevent speech chop at end of period.

protected:
	enum { IDD = IDD_DIALOG_FILESETTINGS };
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL		OnInitDialog();

	CSpinButtonCtrl		m_Spin_SeqDigits;
	CEdit				m_Edit_SeqDigits;

	CSpinButtonCtrl		m_Spin_HH;
	CEdit				m_Edit_HH;

	CSpinButtonCtrl		m_Spin_MM;
	CEdit				m_Edit_MM;

	CEdit				m_Edit_FilenameRoot;
	CEdit				m_Edit_Folder;

	void Update(void);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedRadioFileappendseq();
	afx_msg void OnBnClickedRadioFileappenddate();
protected:
	BOOL m_bDirty;
public:
	afx_msg void OnBnClickedRadioWav();
	afx_msg void OnBnClickedRadioRaw();
	afx_msg void OnBnClickedRadioLimiteroff();
	afx_msg void OnBnClickedRadioLimitbyevent();
	afx_msg void OnBnClickedRadioLimitrectime();
	afx_msg void OnBnClickedRadioLimittod();
	afx_msg void OnEnKillfocusEditFilename();
	afx_msg void OnBnClickedButtonBrowse();
protected:
	virtual void OnOK();
	CButton m_Check_TODSync;
	afx_msg void OnBnClickedCheckTodsync();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	CToolTipCtrl	m_ToolTip;
	CButton m_Check_UseVoxSync;
public:
	afx_msg void OnBnClickedCheckSplittervoxsync();
	afx_msg void OnBnClickedButtonResetseq();
};



// This is where the settings are saved for archival.
class CFileSettings : public CObject
{
	DECLARE_SERIAL(CFileSettings)
public:
	CFileSettings();
	virtual ~CFileSettings();

	virtual void	Serialize(CArchive& ar);
	void			SetDefaults(void);
	INT_PTR			DoModal(void);
	BOOL			IsRestartNecessary();	// Because the extension was changed.

	BOOL			m_bNeedsRestart;	// The CAudioRecorder object needs to be restarted since we
										// changed the extension of the output file.

	// Archived //
	CString			m_strFolder;		// Folder name (without trailing slash)
	CString			m_strFilenameRoot;	// Name part of filename without seq #
	CString			m_strExt;			// Extension to use
	int				m_nSeqDigits;		// # of sequence digits to append to the name
	SEQ_MODE		m_eSeqMode;			// Type of stuff to append to name.
	LIM_MODE		m_eLimMode;			// File chopping mode.
	int				m_LimHH;			// HH used with limit mode
	int				m_LimMM;			// MM used with limit mode
	BOOL			m_bLimSyncTOD;		// Sync with Top Of previous Day.
	BOOL			m_bVoxSync;			// use vox to prevent speech chop at end of period.
	//////////////
protected:

	CDlgFileSettings m_Dlg;
};

