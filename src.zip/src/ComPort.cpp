////////////////////////////////////////////////////////////////
//
// CComPort:    SR Pro win32 Comm Interface Module
//
// Copyright � 2005  Dave Jacobs. All rights reserved.
//
////////////////////////////////////////////////////////////////

// ComPort.cpp : implementation file
#include "stdafx.h"
#include <process.h>
#include <winspool.h>
#include ".\ComPort.h"

CComPort::CComPort()
: m_cRxCount(0)
, m_pRxBuffer(NULL)
, m_hFile(NULL)
, m_hReaderThread(NULL)
, m_bAbort(FALSE)
, m_dwStatus(0)
, m_nSyncCount(0)
, m_nSyncNeeded(0)
, m_SyncChar('\r')
, m_nPorts(0)
, m_nHighestPortNumber(0)
{
	m_hEventSync	= CreateEvent(NULL, FALSE, FALSE, NULL);
	m_hEventAbort	= CreateEvent(NULL, FALSE, FALSE, NULL);

	ZeroMemory(&m_dcb,				sizeof(DCB));
	ZeroMemory(&m_OverlappedRx,		sizeof(OVERLAPPED));
	ZeroMemory(&m_OverlappedTx,		sizeof(OVERLAPPED));
	ZeroMemory(&m_OverlappedStatus,	sizeof(OVERLAPPED));

	CalculatePortCount();
}

CComPort::~CComPort()
{
	Destroy();

	CloseHandle(m_hEventSync);
	CloseHandle(m_hEventAbort);
}

BOOL CComPort::Destroy()
{
	BOOL	rc;

	m_bAbort = TRUE;

	if (IsPortOpen())
	{
		SetCommMask(m_hFile, 0);

		SetEvent(m_OverlappedTx.hEvent);		// Kill any pending TX waits.
		SetEvent(m_OverlappedStatus.hEvent);	// Kill any pending status waits

		if (m_OverlappedRx.hEvent != 0)
		{
			SetEvent(m_OverlappedRx.hEvent);	// Wake up the worker.
		}

		if (m_hReaderThread != NULL)
		{
			// TODO Multiple
			WaitForSingleObject(m_hReaderThread, INFINITE);	// Wait for thread to close
			CloseHandle(m_hReaderThread);
			m_hReaderThread = NULL;
		}

		rc = PurgeComm(m_hFile, PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
		ASSERT(rc);

		SetEvent(m_hEventSync);	// Abort sync if it's pending.

		CloseHandle(m_hFile);
		m_hFile = NULL;
	}

	if (m_OverlappedRx.hEvent != NULL)
	{
		CloseHandle(m_OverlappedRx.hEvent);
		m_OverlappedRx.hEvent = NULL;
	}

	if (m_OverlappedTx.hEvent != NULL)
	{
		CloseHandle(m_OverlappedTx.hEvent);
		m_OverlappedTx.hEvent = NULL;
	}

	if (m_OverlappedStatus.hEvent != NULL)
	{
		CloseHandle(m_OverlappedStatus.hEvent);
		m_OverlappedStatus.hEvent = NULL;
	}

	if (m_pRxBuffer != NULL)
	{
		CCS	Lock(&m_csRXBuffer);

		delete [] m_pRxBuffer;
		m_pRxBuffer = NULL;
	}

	return TRUE;
}

BOOL CComPort::Create(int nPort, DWORD nBaudRate)
{
	CString			strPort, strOut;
	DWORD			nErrorCode;
	BOOL			rc;
	COMMTIMEOUTS	to = {0};
	unsigned int	threadid;

	ASSERT(nPort >= 1 && nPort <= 9);
	ASSERT(!IsPortOpen());

	strPort.Format(_T("COM%d"), nPort);

	// If the port was left open, log it in the tracefile and close it.
	if (IsPortOpen())
	{
		Destroy();

		TRACE(_T("Comm port was already opened when Create was called.\r\n"));
		TRACE(_T("I closed it myself so all should be okay now or there\r\n"));
		TRACE(_T("could be a bug.\r\n"));
	}

	ZeroMemory(&m_dcb,				sizeof(DCB));
	ZeroMemory(&m_OverlappedRx,		sizeof(OVERLAPPED));
	ZeroMemory(&m_OverlappedTx,		sizeof(OVERLAPPED));
	ZeroMemory(&m_OverlappedStatus,	sizeof(OVERLAPPED));

	m_bAbort = FALSE;

	try
	{
		m_hFile = CreateFile(strPort, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0);
		if (m_hFile == INVALID_HANDLE_VALUE)
		{
			m_hFile = NULL;
			throw(_T("Can't open communications port."));
		}

		ZeroMemory(&m_OverlappedRx, sizeof(OVERLAPPED));
		ZeroMemory(&m_OverlappedTx, sizeof(OVERLAPPED));
		ZeroMemory(&m_OverlappedStatus, sizeof(OVERLAPPED));

		m_OverlappedRx.hEvent		= CreateEvent(NULL, TRUE, FALSE, NULL);
		ASSERT(m_OverlappedRx.hEvent != NULL);

		m_OverlappedTx.hEvent		= CreateEvent(NULL, TRUE, FALSE, NULL);
		ASSERT(m_OverlappedTx.hEvent != NULL);

		m_OverlappedStatus.hEvent	= CreateEvent(NULL, TRUE, FALSE, NULL);
		ASSERT(m_OverlappedStatus.hEvent != NULL);

		m_hEventAbort = CreateEvent(NULL, TRUE, FALSE, NULL);

		ZeroMemory(&m_dcb, sizeof(DCB));

		rc = GetCommState(m_hFile, &m_dcb);
		m_dcb.BaudRate				= nBaudRate;
		m_dcb.fBinary				= TRUE;
		m_dcb.fParity				= FALSE;
		m_dcb.fOutxCtsFlow			= FALSE;
		m_dcb.fOutxDsrFlow			= FALSE;
		m_dcb.fDtrControl			= DTR_CONTROL_ENABLE;
		m_dcb.fDsrSensitivity		= FALSE;
		m_dcb.fTXContinueOnXoff		= FALSE;
		m_dcb.fOutX					= FALSE;
		m_dcb.fInX					= FALSE;
		m_dcb.fErrorChar			= FALSE;
		m_dcb.fNull					= FALSE;
		m_dcb.fRtsControl			= RTS_CONTROL_ENABLE;
		m_dcb.fAbortOnError			= FALSE;
		m_dcb.XonLim				= 100;
		m_dcb.XoffLim				= 100;
		m_dcb.ByteSize				= 8;
		m_dcb.Parity				= NOPARITY;
		m_dcb.StopBits				= ONESTOPBIT;
		m_dcb.XonChar				= 'Q' - 0x40;
		m_dcb.XoffChar				= 'S' - 0x40;
		m_dcb.ErrorChar				= (char) 0xAA;
		m_dcb.EofChar				= (char) 0xBB;
		m_dcb.EvtChar				= (char) 0xCC;

		rc = SetCommState(m_hFile, &m_dcb);
		ASSERT(rc);

		rc = EscapeCommFunction(m_hFile, SETDTR|SETRTS);
		ASSERT(rc);

		m_pRxBuffer = new BYTE[RX_BUFFER_SIZE];
		if (m_pRxBuffer == NULL)
			throw(_T("Error: Comm port memory allocation shortage. Contact support."));

		m_cRxCount = 0;		// Receive buffer is empty and ready to use.

		ZeroMemory(&to, sizeof(COMMTIMEOUTS));

		rc = SetCommTimeouts(m_hFile, &to);
		ASSERT(rc);

	}
	catch(LPCTSTR lpszError)
	{
		nErrorCode = GetLastError();
		strOut.Format(_T("Error: %s Code = %d. Port = %s."), lpszError, nErrorCode, strPort);
		//AfxMessageBox(strOut, MB_OK|MB_ICONERROR);

		if (m_hFile != NULL)
		{
			Destroy();
		}

		return FALSE;
	}

	// Start the worker thread.
	m_hReaderThread		= (HANDLE) _beginthreadex(0, 0, StartReaderThread, this, 0, &threadid);

	return TRUE;
}

unsigned int CComPort::StartReaderThread(LPVOID pUser)
{
	((CComPort*) pUser)->ReaderThread();

	return 0;
}

// Get RX Data and return the # of bytes read.
// If pBuffer or dwBufferSize are zero then return the # of bytes received
// and ignore the bPurge flag.
DWORD CComPort::GetRxData(LPBYTE pBuffer, DWORD dwBufferSize, BOOL bPurge)
{
	DWORD	size = 0;

//	TF;

	CCS		Lock(&m_csRXBuffer);

	if (!IsPortOpen()) return 0;

	if (pBuffer != NULL && dwBufferSize != 0)
	{
		size = min(dwBufferSize, m_cRxCount);
		if (size > 0)
			CopyMemory(pBuffer, m_pRxBuffer, size);

		if (bPurge)
		{
			m_cRxCount = 0;
			ZeroMemory(m_pRxBuffer, RX_BUFFER_SIZE);
		}
	}
	else
		size = m_cRxCount;

	return	size;
}

BOOL CComPort::TransmitData(LPBYTE pBuffer, DWORD dwCount)
{
	BOOL	rc;
	DWORD	dwWritten = 0, dwWritten1 = 0;
	DWORD	errCode;
	BOOL	bPending;
	CString	str;

	ASSERT(pBuffer != NULL);
	ASSERT(dwCount > 0);

	if (!IsPortOpen()) return FALSE;

	//rc = PurgeComm(m_hFile, PURGE_RXCLEAR);
	//ASSERT(rc);

	bPending = FALSE;

	// Send the data to the serial port.
	rc = WriteFile(m_hFile, pBuffer, dwCount, &dwWritten1, &m_OverlappedTx);
	if (rc)
	{	// I/O finished right away.
		ASSERT(dwWritten1 == dwCount);
		return TRUE;
	}
	else
	{
		errCode = GetLastError();
		if (errCode == ERROR_IO_PENDING)
		{
			bPending = TRUE;
		}
		else
		{
			str.Format(_T("Error: WriteFile returned '%d' while\ntrying to send data to the serial port."), errCode);
			AfxMessageBox(str, MB_OK|MB_ICONERROR);
			return FALSE;
		}
	}

	if (bPending)
	{
		rc = GetOverlappedResult(m_hFile, &m_OverlappedTx, &dwWritten, TRUE);
		ASSERT(rc);
		ASSERT(dwWritten == dwCount);
	}

	return (dwWritten == dwCount);	// True if something got sent.
}

void CComPort::ReaderThread(void)
{
	BOOL	rc;
	DWORD	dwRead, dwRead1;				// # bytes read.
	BOOL	bReadPending;
	BYTE	dataIn;				// Received byte value
	DWORD	dwError;

	for (;;)
	{
		bReadPending = FALSE;

		if (m_bAbort) break;
		
		m_OverlappedRx.Internal		= 0;
		m_OverlappedRx.InternalHigh	= 0;
		m_OverlappedRx.Offset		= 0;
		m_OverlappedRx.OffsetHigh	= 0;
		m_OverlappedRx.Pointer		= 0;

		dwRead = dwRead1 = 0;

		rc = ReadFile(m_hFile, &dataIn, 1, &dwRead1, &m_OverlappedRx);
		if (rc)
		{	// Read finished.
			ASSERT(dwRead1 == 1);

			if (dwRead1 > 0)
			{
				CCS	Lock(&m_csRXBuffer);

				if (m_cRxCount < RX_BUFFER_SIZE)
				{
					m_pRxBuffer[m_cRxCount++] = dataIn;		// Store the new char
					//Beep(9000,10);
				}
			}
		}
		else
		{	// Read not complete
			DWORD err = GetLastError();
			ASSERT(err == ERROR_IO_PENDING);
			bReadPending = TRUE;
		}

		if (bReadPending)
		{
			// Wait here until our read data is finished.
			rc = GetOverlappedResult(m_hFile, &m_OverlappedRx, &dwRead, TRUE);
			if (!rc)
			{
				dwError = GetLastError();
				if (dwError != ERROR_IO_PENDING &&
					dwError != ERROR_OPERATION_ABORTED)
				{
					ASSERT(0);	// Unkn0wn error and how to handle it.
				}
			}

			if (m_bAbort) break;

			if (dwRead > 0)
			{
				CCS	Lock(&m_csRXBuffer);

				if (m_cRxCount < RX_BUFFER_SIZE)
				{
					m_pRxBuffer[m_cRxCount++] = dataIn;		// Store the new char
					//Beep(8000,10);
				}
			}
		}

		if (dwRead > 0 || dwRead1 > 0)
		{
			//TRACE(_T("%02X"), dataIn);	// Show last char recv'd
			//Beep(10000,10);

			if (dataIn == m_SyncChar)
			{

				//Beep(7000,20);

				if (++m_nSyncCount >= m_nSyncNeeded)
				{
					//Beep(8000,20);

					SetEvent(m_hEventSync);
					//TRACE(_T("SetEvent(m_hEventSync)\r\n"));
				}
			}
		}
	}	// End of main loop

	// Here if abort was signalled Exit and let this thread expire.
	rc = CancelIo(m_hFile);
}

BOOL CComPort::IsPortOpen(void)
{
	return (m_hFile != NULL);
}

void CComPort::ResetSync()
{
	m_nSyncCount = 0;
	//TRACE(_T("ResetEvent(&m_hEventSync)\r\n"));
	ResetEvent(&m_hEventSync);
}

BOOL CComPort::WaitForSync(DWORD dwTimeout)
{
	DWORD	dwResult;

//	TF;

	// TODO
	dwResult = WaitForSingleObject(m_hEventSync, dwTimeout);

	if (dwResult != WAIT_OBJECT_0)
		return FALSE;
	else
		return TRUE;
}

void CComPort::SetSyncChar(BYTE SyncValue, int nSyncNeeded)
{
	m_SyncChar		= SyncValue;
	m_nSyncNeeded	= nSyncNeeded;
	m_nSyncCount	= 0;
}

// Convert the icom ID to the name.
void CComPort::IcomGetDeviceNameFromID(BYTE nID, CString & strOut)
{
	switch (nID)
	{
		case 0x20:
			strOut = _T("271");
			break;

		case 0x10:
			strOut = _T("275");
			break;

		case 0x12:
			strOut = _T("375");
			break;

		case 0x22:
			strOut = _T("471");
			break;

		case 0x14:
			strOut = _T("475");
			break;

		case 0x16:
			strOut = _T("575");
			break;

		case 0x68:
			strOut = _T("703");
			break;

		case 0x48:
			strOut = _T("706");
			break;

		case 0x4E:
			strOut = _T("706MkII");
			break;

		case 0x58:
			strOut = _T("706MkII-G");
			break;

		case 0x3e:
			strOut = _T("707");
			break;

		case 0x5E:
			strOut = _T("718");
			break;

		case 0x28:
			strOut = _T("725");
			break;

		case 0x30:
			strOut = _T("726");
			break;

		case 0x38:
			strOut = _T("728");
			break;

		case 0x3A:
			strOut = _T("729");
			break;

		case 0x04:
			strOut = _T("735");
			break;

		case 0x40:
			strOut = _T("736");
			break;

		case 0x3C:
			strOut = _T("737");
			break;

		case 0x44:
			strOut = _T("738");
			break;

		case 0x56:
			strOut = _T("746");
			break;

		case 0x66:
			strOut = _T("746Pro");
			break;

		case 0x1C:
			strOut = _T("751A");
			break;

		case 0x50:
			strOut = _T("756");
			break;

		case 0x5C:
			strOut = _T("756Pro");
			break;

		case 0x64:
			strOut = _T("756ProII");
			break;

		case 0x1E:
			strOut = _T("761");
			break;

		case 0x2C:
			strOut = _T("765");
			break;

		case 0x46:
			strOut = _T("775");
			break;

		case 0x62:
			strOut = _T("78");
			break;

		case 0x26:
			strOut = _T("781");
			break;

		case 0x42:
			strOut = _T("820");
			break;

		case 0x4C:
			strOut = _T("821");
			break;

		case 0x60:
			strOut = _T("910");
			break;

		case 0x2E:
			strOut = _T("970");
			break;

		case 0x24:
			strOut = _T("1271");
			break;

		case 0x18:
			strOut = _T("1275");
			break;

		case 0x52:
			strOut = _T("R-10");
			break;

		case 0x1A:
			strOut = _T("R71");
			break;

		case 0x32:
			strOut = _T("R72");
			break;

		case 0x5A:
			strOut = _T("R75");
			break;

		case 0x08:
			strOut = _T("R7000");
			break;

		case 0x34:
			strOut = _T("R7100");
			break;

		case 0x4A:
			strOut = _T("R8500");
			break;

		case 0x2A:
			strOut = _T("R9000");
			break;

		case 0xE0:
			strOut = _T("Controller/PC");
			break;

		case 0x94:
			strOut = _T("Mini Scout");
			break;

		case 0x80:
			strOut = _T("Optoscan 456/535");
			break;

		case 0x01:
			strOut = _T("ID-1");
			break;

		default:
			strOut = _T("Undefined");
	}
}

// nItems must be # items in your empty CString array.
// returns # of tokens read from input string.
int CComPort::ParseRecord(LPCTSTR lpszInput, CString* lpstrToken, int nItems)
{
	int			cTokens = 0;
	CString		strInput, strToken;
	int			index;	// Keeps track of scan position.
	int			len;	// # of chars in input line

	// Clear the caller's token array.
	for (int i = 0; i < nItems; i++)
		lpstrToken[i].Empty();

	len = (int) _tcslen(lpszInput);

	if (len > 0)
	{	// Parse the input
		strInput = lpszInput;

		// Scan string until eol reached.
		for (index = 0, cTokens = 0; index < len;)
		{
			int	i = strInput.Find(',', index);
			if (i == -1)
			{	// No more commas found



				// Strip the line end character if present.
				if ((strInput[len-1] == 0x0D) ||
					(strInput[len-1] == 0x0A))
				{
					strInput = strInput.Left(len-1);
					len--;
				}



				strToken = strInput.Mid(index, len-index);

				if (cTokens >= nItems) break;	// Array count exceeded.
				
				lpstrToken[cTokens++] = strToken;
				break;
			}
			if (i > 0)
			{
				strToken = strInput.Mid(index, i - index);
				index = i+1;	// 1st char past comma

				if (cTokens >= nItems) break;	// Array count exceeded.
				
				lpstrToken[cTokens++] = strToken;
			}
		}
	}

	return cTokens;
}

void CComPort::CalculatePortCount(void)
{
	BOOL			rc;
	int				errorcode = 0;
	DWORD			dwBytesNeeded = 0, dwPorts = 0;
	PORT_INFO_2*	pInfo2 = NULL;
	int				i, nComPorts = 0;
	CString			str, str1;

	m_nHighestPortNumber	= 0;
	m_nPorts				= 0;

	// Get # of bytes needed for the buffer.
	rc = EnumPorts(NULL, 2, NULL, 0, &dwBytesNeeded, &dwPorts);
	errorcode = GetLastError();
	ASSERT(errorcode == ERROR_INSUFFICIENT_BUFFER);
	ASSERT(dwBytesNeeded != 0);

	// Allocate the buffer.
	pInfo2 = (PORT_INFO_2*) new BYTE[dwBytesNeeded];
	ASSERT(pInfo2 != NULL);

	rc = EnumPorts(NULL, 2, (LPBYTE) pInfo2, dwBytesNeeded, &dwBytesNeeded, &dwPorts);
	ASSERT(rc);
	ASSERT(dwPorts != 0);
	//ASSERT(dwBytesNeeded / sizeof(PORT_INFO_2) == dwPorts);

	// Scan the buffer and count the number of ports that have this format:
	//  COMnn:
	//		where nn = the port number from 1 to 99

	for (i = 0; i < (int) dwPorts; i++)
	{
		str = (pInfo2+i)->pPortName;

		if (str.Left(3) == _T("COM"))
		{
			str.Delete(0, 3);

			if (str.Mid(str.GetLength()-1) == _T(":"))
			{
				str.Delete(str.GetLength()-1);

				// At this point, the string must be a number.
				if (str.GetLength() != 0)
				{
					str1 = str.SpanExcluding(_T("0123456789"));

					if (str1.GetLength() == 0)
					{
						// We found a qualified port.
						m_nPorts++;

						// Get the number and keep it if it's the highest.
						int newValue = _ttol(str);
						m_nHighestPortNumber = max(m_nHighestPortNumber, newValue);
					}
				}
			}
		}
	}

	delete pInfo2;
}

int CComPort::GetHighestPortNumber(void)
{
	return m_nHighestPortNumber;
}

// Used to end the reply wait period.
void CComPort::AbortSyncWait(void)
{
	SetEvent(&m_hEventSync);
}

void CComPort::PurgeRxBuffer(void)
{
	CCS	Lock(&m_csRXBuffer);

	m_cRxCount = 0;
	ZeroMemory(m_pRxBuffer, RX_BUFFER_SIZE);
}

// Kill any I/O operation.
void CComPort::AbortIO(void)
{
	BOOL	rc;

	
	rc = PurgeComm(m_hFile, PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
}
