#include "StdAfx.h"
#include ".\audiorecorder.h"


CAudioRecorder::CAudioRecorder(void)
: m_bSplitStarted(FALSE)
, m_bRolloverTODSync(FALSE)
, m_bRolloverVoxSync(FALSE)
, m_pRadioSettings(NULL)
{
	TF;		// Trace this function

	m_dwValid = 0xa5a55a5a;

	Reset();
}

CAudioRecorder::~CAudioRecorder(void)
{
	TF;		// Trace this function

	Destroy();
}

void CAudioRecorder::GetScanInfo(SCAN_INFO* lpScanInfo)
{
	ASSERT(m_bInit);
	ASSERT(m_pCaptureFilter != NULL);

	m_pMeterFilter->GetScanInfo(lpScanInfo);
}

// Create a single output recorder.
BOOL CAudioRecorder::Create(CAudioSettings* pAudioSettings, CFilenameServer* pFilenameServer, BOOL bRecord, BOOL bPause, BOOL bVox, float VoxValue_L, DWORD dwHangtime)
{
	BOOL	bWaveFile;
	BOOL	rc;

	//TF;		// Trace this function

	ASSERT(!m_bInit);	// Already initialized. Can't comply now.
	ASSERT(pAudioSettings	!= NULL);
	m_pAudioSettings		= pAudioSettings;
	ASSERT(pFilenameServer	!= NULL);
	//m_pFilenameServer		= pFilenameServer;

	// Create the filters
	m_pCaptureFilter	= new CAudioCaptureNew(this);
	m_pChannelFilter	= new CChannelFilter(this);
	m_pMeterFilter		= new CAudioFilter(this);
	m_pVoxFilter		= new CVoxFilter(this);
	//m_pDummyFilter1		= new CAudioFilter(this);
	m_pRecordGateFilter	= new CRecordGateFilter(this);
	//m_pDummyFilter2		= new CAudioFilter(this);
	m_pBufferFilter		= new CBufferFilter(this);
	m_pCompressor		= new CAcmFilter(this);

	if (_tcsicmp(pFilenameServer->GetExt(), _T("wav")) == 0)
	{
		bWaveFile = TRUE;
		m_pFileWriter = new CWaveFileWriterFilter(this);	// Use .wav output file.
	}
	else
	{
		bWaveFile = FALSE;
		m_pFileWriter = new CFileWriterFilter(this);		// or use .raw instead.
	}
	m_pFileWriter->SetServer(pFilenameServer);	// Tell the file writer where to
												// get the new file names.

	m_pChannelFilter->SetChannelParms(pAudioSettings->m_ChannelParms);
	m_pCaptureFilter->SetFormat(pAudioSettings);
	m_pCaptureFilter->SetPause(TRUE);	// Prevent downstream flow....for now.

	try	// to build an audio chain
	{
		if (pAudioSettings->m_lpwfCompress->wFormatTag == 0 || !bWaveFile)
		{	// No compression. Exclude the compressor module (etc.) from the chain.
			rc = m_pCaptureFilter->Connect(m_pChannelFilter);
			if (!rc) throw(0x01);

			rc = m_pChannelFilter->Connect(m_pMeterFilter);
			if (!rc) throw(0x02);

			rc = m_pMeterFilter->Connect(m_pVoxFilter);
			if (!rc) throw(0x03);

			rc = m_pVoxFilter->Connect(m_pRecordGateFilter);
			if (!rc) throw(0x04);

			rc = m_pRecordGateFilter->Connect(m_pFileWriter);
			if (!rc) throw(0x06);
		}
		else
		{	// Build a chain with a compressor
			rc = m_pCompressor->SetFormatC(pAudioSettings->m_lpwfCompress, pAudioSettings->m_bHQ);
			if (!rc) throw(0x11);

			rc = m_pCaptureFilter->Connect(m_pChannelFilter);
			if (!rc) throw(0x12);

			rc = m_pChannelFilter->Connect(m_pMeterFilter);
			if (!rc) throw(0x13);

			rc = m_pMeterFilter->Connect(m_pVoxFilter);
			if (!rc) throw(0x14);

			rc = m_pVoxFilter->Connect(m_pRecordGateFilter);
			if (!rc) throw(0x15);

			rc = m_pRecordGateFilter->Connect(m_pBufferFilter);
			if (!rc) throw(0x16);

			rc = m_pBufferFilter->Connect(m_pCompressor);
			if (!rc) throw(0x17);

			rc = m_pCompressor->Connect(m_pFileWriter);
			if (!rc) throw(0x18);
		}
	}
	catch (int errNum)
	{
		CString	str;
		str.Format(_T("Audio recorder initialization failed.\r\n")
			_T("Reason code: %02X"),
			errNum);
		AfxMessageBox(str, MB_OK);

		Destroy();
		return FALSE;
	}

	m_pVoxFilter->SetHangTimeMS(dwHangtime);
	m_pVoxFilter->SetVox(VoxValue_L, VoxValue_L);
	m_pVoxFilter->ForceGateOpen(!bVox);	// Activate the VOX if desired.

	m_pVoxFilter->SetLogFile(&m_LogFile);
	m_pFileWriter->SetLogFile(&m_LogFile);
	//m_pVoxFilter->SetComPort(pPort);

	m_pRecordGateFilter->SetPause(TRUE);
	m_pRecordGateFilter->ResetSampleCount();
	m_pCaptureFilter->StartAudioCapture();
	m_pCaptureFilter->StartStreaming();
	m_pCaptureFilter->SetPause(FALSE);

	m_bInit = TRUE;

	m_pRecordGateFilter->SetTriggerTime(0, 1);

	return TRUE;
}

// Called by contructor. Also used to put the object in post-constructor state without
// having to delete the recorder object.
BOOL CAudioRecorder::Reset()
{
	//TF;		// Trace this function

	//ASSERT(m_bInit);				// Already init? Why?
	m_bInit					= FALSE;

	m_pCaptureFilter		= NULL;
	m_pChannelFilter		= NULL;
	m_pMeterFilter			= NULL;
	m_pVoxFilter			= NULL;
	//m_pDummyFilter1		= NULL;
	m_pRecordGateFilter		= NULL;
	//m_pDummyFilter2		= NULL;
	m_pBufferFilter			= NULL;
	m_pCompressor			= NULL;
	m_pFileWriter			= NULL;

	//m_pFilenameServer		= NULL;
	m_pAudioSettings		= NULL;

	m_uRolloverElapsed.ll	= 0;

	m_State					= Stopped;

	return TRUE;
}

// Clean up everything and return all buffers. Reset needs to be called again before reuse.
BOOL CAudioRecorder::Destroy()
{
	//TF;		// Trace this function

	if (m_bInit)
	{
		SetRecord(FALSE);

		// If the radio interface is enabled then stop the mother fucker
		if (m_pRadioSettings != NULL)
		{
			//if (m_pRadioSettings->IsRadioEnabled())
			{
				m_LogFile.SetRadioInterface(NULL);
				m_RadioInterface.Destroy();
			}
		}

		m_pCaptureFilter->StopAudioCapture();
		m_pCaptureFilter->StopStreaming();
		m_pCaptureFilter->Flush();		// For good measure?
		TRACE(_T("********** ALL DATA MUST BE FLUSHED AT THIS POINT. ***********\r\n"));
		Dump();
		Nukedownstream(m_pCaptureFilter);
	}


	if (m_pCaptureFilter	!= NULL)	delete m_pCaptureFilter;
	if (m_pChannelFilter	!= NULL)	delete m_pChannelFilter;
	if (m_pMeterFilter		!= NULL)	delete m_pMeterFilter;
	if (m_pVoxFilter		!= NULL)	delete m_pVoxFilter;
	//if (m_pDummyFilter1		!= NULL)	delete m_pDummyFilter1;
	if (m_pRecordGateFilter	!= NULL)	delete m_pRecordGateFilter;
	//if (m_pDummyFilter2		!= NULL)	delete m_pDummyFilter2;
	if (m_pBufferFilter		!= NULL)	delete m_pBufferFilter;
	if (m_pCompressor		!= NULL)	delete m_pCompressor;
	if (m_pFileWriter		!= NULL)	delete m_pFileWriter;

	Reset();	// Return the recorder to initial dormant state.

	return TRUE;
}

BOOL CAudioRecorder::SetRecord(BOOL bRecord)
{
	//BOOL	rc;
	//TF;

	// Handle the input flag.
	if (bRecord)
	{	// Input: Record on

		switch (m_State)
		{
			case Stopped:
				ResetDroppedFrames();

				m_pVoxFilter->SetVoxState(Gate_Closed);
				m_pVoxFilter->ResetCounters();

				m_pFileWriter->BeginNewFile();

				//// If the radio interface is enabled then start the mother fucker.
				//if (m_pRadioSettings != NULL)
				//{
				//	m_LogFile.SetRadioSettings(m_pRadioSettings);

				//	if (m_pRadioSettings->IsRadioEnabled())
				//	{
				//		rc = m_RadioInterface.Create(m_pRadioSettings);	// This activates the serial interface
				//		if (rc)
				//		{	// Radio port is online and ready to use.
				//			m_LogFile.SetRadioInterface(&m_RadioInterface);
				//		}
				//		else
				//		{	// Problem. Keep log from using the port.
				//			m_LogFile.SetRadioInterface(NULL);
				//		}
				//	}
				//}

				//	((CWaveFileWriterFilter*) m_pFileWriter)->SetCheckpointMode(CHECKPOINT_MODE_WAIT_IDLE);

				m_pRecordGateFilter->ResetSampleCount();

				m_pRecordGateFilter->StartStreaming();	// Currently does nothing useful.

				m_pRecordGateFilter->SetPause(FALSE);	// Open the flood gates

				if (m_uRolloverElapsed.ll > 0)
				{	// Rollover elapsed mode set.
					StartRolloverTimer();
				}

				m_State = Recording;
				break;

			case Recording:	// Already recording. Change the file name
				m_pFileWriter->BeginNewFile();
				break;
		}
	}
	else
	{	// Input: Record off
		switch (m_State)
		{
			case Stopped:
				break;

			case Recording:

				if (m_uRolloverElapsed.ll != 0)
				{	// Rollover elapsed mode set.
					KillRolloverTimer();
				}

				m_pCaptureFilter->SetPause(TRUE);
				m_pCaptureFilter->Flush();

				// Now that we're flushed and ready, allow the acm filter to purge via StopStreaming
				m_pRecordGateFilter->StopStreaming();

				//m_pCaptureFilter->EndFlush();
				//m_pCaptureFilter->SetPause(FALSE);

				m_pVoxFilter->StoreLogDataManualStop();
				m_pVoxFilter->ResetCounters();
				m_pVoxFilter->SetVoxState(Gate_Closed);

				m_pRecordGateFilter->SetPause(TRUE);
				m_pRecordGateFilter->ResetSampleCount();

				m_pFileWriter->CloseFile();

				m_pCaptureFilter->EndFlush();
				m_pCaptureFilter->SetPause(FALSE);

				//((CWaveFileWriterFilter*) m_pFileWriter)->SetCheckpointMode(CHECKPOINT_MODE_OFF);

				//// If the radio interface is enabled then stop the mother fucker
				//if (m_pRadioSettings != NULL)
				//{
				//	if (m_pRadioSettings->IsRadioEnabled())
				//	{
				//		m_LogFile.SetRadioInterface(NULL);
				//		m_RadioInterface.Destroy();
				//	}
				//}

				m_State = Stopped;
				break;
		}
	}

	return TRUE;
}

void CAudioRecorder::SetPause(BOOL bPause)
{
	TF;

	m_pVoxFilter->SetPause(bPause);
}

void CAudioRecorder::SetVox(float Left)
{
	//TF;

	m_pVoxFilter->SetVox(Left, Left);
}

void CAudioRecorder::StartCapture(void)
{
	TF;

	m_pCaptureFilter->StartAudioCapture();
}

void CAudioRecorder::StopCapture(void)
{
	TF;

	m_pCaptureFilter->StopAudioCapture();
}

void CAudioRecorder::SetNewFormat(CAudioSettings* pAudioSettings)
{
	TF;

	SetRecord(FALSE);
	StopCapture();

	m_pCaptureFilter->SetFormat(pAudioSettings);	// Ripple the new format down the entire chain.

	StartCapture();
}

void CAudioRecorder::SetVoxOn(BOOL bVoxOn)
{
	m_pVoxFilter->ForceGateOpen(!bVoxOn);
}

BOOL CAudioRecorder::IsVoxGateOpen(void)
{
	if (!IsInit())		return FALSE;
	return m_pVoxFilter->IsGateOpen();
}

BOOL CAudioRecorder::IsInit(void)
{
	if (this == NULL) return FALSE;
	if (m_dwValid != 0xa5a55a5a) return FALSE;

	return m_bInit;
}

// Needs rewiring after we add stored count to record gate filter.
ULONGLONG CAudioRecorder::GetStoredSampleCount(void)
{
	if (!IsInit())		return FALSE;

	return m_pRecordGateFilter->GetSampleCount();
}

FILETIME CAudioRecorder::GetEventStart(void)
{
	if (!IsInit())
	{
		FILETIME ft = {0};
		return ft;
	}

	return m_pVoxFilter->GetEventStart();
}

//FILETIME CAudioRecorder::GetEventEnd(void)
//{
//	if (!IsInit())
//	{
//		FILETIME ft = {0};
//		return ft;
//	}
//
//	return m_pVoxFilter->GetEventEnd();
//}
//
FILETIME CAudioRecorder::GetEventDuration(void)
{
	if (!IsInit())
	{
		FILETIME ft = {0};
		return ft;
	}

	return m_pVoxFilter->GetEventDuration();
}

// Needs rewiring after we add stored count to record gate filter.
FILETIME CAudioRecorder::GetStoredTime(void)
{
	if (!IsInit())
	{
		FILETIME ft = {0};
		return ft;
	}

	return m_pRecordGateFilter->GetStoredTime();
}

void CAudioRecorder::Nukedownstream(CAudioFilter * pFilter)
{
	TF;

	if (pFilter->GetNextFilter() != NULL)
	{
		Nukedownstream(pFilter->GetNextFilter());
	}
	pFilter->Disconnect();
}

void CAudioRecorder::SetHangTime1(DWORD dwHangtime)
{
	ASSERT(IsInit());	// Can't call this before create

	m_pVoxFilter->SetHangTimeMS(dwHangtime);
}

extern CSection csTrace;	// Defined in App.cpp

void CAudioRecorder::Dump(void)
{
	CAudioFilter*	pFilter;
	TRACE(_T("Dumping all filters\r\n"));

	CCS Lock(&csTrace);

	if (m_bInit)
	{
		pFilter = m_pCaptureFilter;
		while (pFilter != NULL)
		{
			pFilter->Dump();
			pFilter = pFilter->GetNextFilter();
		}
	}
	else
	{
		TRACE(_T("CAudioRecorder has not been intialized yet.\r\n"));
	}
}

DWORD CAudioRecorder::GetBufferTimeMeasuredMS(void)
{
	DWORD	dwTime = NULL;

	if (IsInit())
	{
		if (m_pCompressor != NULL) dwTime = m_pCompressor->GetBufferTimeMeasuredMS();
	}

	return dwTime;
}

DWORD CAudioRecorder::GetBufferTimeMS(void)
{
	DWORD	dwTime = NULL;

	if (IsInit())
	{
		if (m_pCompressor != NULL) dwTime = m_pCompressor->GetBufferTimeMS();
	}

	return dwTime;
}

CFilenameServer* CAudioRecorder::GetFilenameServer(void)
{
	return m_pFileWriter->GetServer();
}

void CAudioRecorder::SetRolloverVoxMode(bool bEnable)
{
	if (IsInit())
	{
		m_pVoxFilter->SetRolloverMode(bEnable);
		m_uRolloverElapsed.ll = 0;
		m_pRecordGateFilter->SetTriggerSamples(0);
	}
}

BOOL CAudioRecorder::GetRolloverVoxMode(void)
{
	if (IsInit())
	{
		if (m_pVoxFilter != NULL)
		{
			return m_pVoxFilter->GetRolloverMode();
		}
	}

	return FALSE;
}

void CAudioRecorder::SetChannelParms(CHANNEL_PARMS Parms)
{
	if (IsInit())
	{
		ASSERT(m_pChannelFilter != NULL);
		m_pChannelFilter->SetChannelParms(Parms);
	}
}

CHANNEL_PARMS CAudioRecorder::GetChannelParms(void)
{
	CHANNEL_PARMS	Parms;

	if (IsInit())
	{
		ASSERT(m_pChannelFilter != NULL);
		Parms = m_pChannelFilter->GetChannelParms();
	}

	return Parms;
}

DWORD CAudioRecorder::GetDroppedFrames(void)
{
	DWORD	total = 0;
	CAudioFilter*	pFilter = NULL;

	if (IsInit())
	{
		for (pFilter = m_pCaptureFilter; pFilter != NULL; pFilter = pFilter->GetNextFilter())
		{
			total += pFilter->GetDroppedBufferCount();
		}
	}

	return total;
}

void CAudioRecorder::ResetDroppedFrames(void)
{
	CAudioFilter*	pFilter = NULL;

	if (IsInit())
	{
		for (pFilter = m_pCaptureFilter; pFilter != NULL; pFilter = pFilter->GetNextFilter())
		{
			pFilter->ResetDroppedBufferCount();
		}
	}
}

int CAudioRecorder::GetAllocatedBufferCount(void)
{
	int				total	= 0;
	CAudioFilter*	pFilter	= NULL;

	if (IsInit())
	{
		for (pFilter = m_pCaptureFilter; pFilter != NULL; pFilter = pFilter->GetNextFilter())
		{
			total += pFilter->GetAllocatedBufferCount();
		}
	}

	return total;
}

BOOL CAudioRecorder::GetWriteInhibit(void)
{
	BOOL	bResult = FALSE;

	if (IsInit()) bResult = m_pFileWriter->GetWriteInhibit();

	return bResult;
}

void CAudioRecorder::SetWriteInhibit(BOOL bInhibit)
{
	if (IsInit()) m_pFileWriter->SetWriteInhibit(bInhibit);
}

// Called by any filter's data-thread in case a checkpoint is needed
// from within. Can be called repeatedly, but will be ignored if
// checkpointing is already in progress. This method simplifies
// a situation where any filter can trigger a checkpoint without having
// a huge mess in the log file due to filters' stats getting out of sync
// with each other. Ex: The record gate and the vox filter both have their
// own stats and they must be kept in sync for the sake of the log entry.
void CAudioRecorder::SplitterNeedToSplit(void)
{
	if (IsInit())
	{
		CCS	Lock(&m_csSplitterLock);

		if (!m_bSplitStarted)
		{
			m_bSplitStarted = TRUE;

			_beginthread(SplitterProc, 0, (PVOID) this);
		}
	}
}

void __cdecl CAudioRecorder::SplitterProc( void * p)
{
	CAudioRecorder*	pThis = (CAudioRecorder*) p;

	pThis->SplitterHandler();

	{
		CCS	Lock(&(pThis->m_csSplitterLock));
		pThis->m_bSplitStarted = FALSE;
	}
}

// Close the current output file and begin recording to a new file.
void CAudioRecorder::SplitterHandler(void)
{

	//Beep(7000,50);
	//Beep(9000,50);

	if (m_bRolloverVoxSync && !m_pVoxFilter->IsForceGateOpen())
	{	// If vox mode and vox sync is on.
		m_pVoxFilter->SetRolloverOnce();
		m_pVoxFilter->WaitForRolloverSync();
	}
	else
	{
		if (1)
		{	// For temporary use until dropped frames can be looked into.
			if (m_State == Recording)
			{
				SetRecord(FALSE);
				SetRecord(TRUE);
			}
		}
		else
		{	// Use this when we fix the dropped frames problem.
			//if (m_State == Recording)
			//{
			//	m_pRecordGateFilter->Flush();
			//	m_pRecordGateFilter->StopStreaming();

			//	//m_pVoxFilter->ResetCounters();
			//	m_pRecordGateFilter->ResetSampleCount();

			//	m_pFileWriter->BeginNewFile();

			//	m_pRecordGateFilter->StartStreaming();
			//	m_pRecordGateFilter->EndFlush();
			//}
		}
	}
}

void CAudioRecorder::SetRolloverElapsedTime(int HH, int MM, int SS, BOOL bTODSync)
{
	if (IsInit())
	{
		m_pVoxFilter->SetRolloverMode(FALSE);
		m_pRecordGateFilter->SetTriggerSamples(0);

		// Add code to send parameter to the appropriate place.
		m_uRolloverElapsed.ll	= (HH * ONE_HOUR);
		m_uRolloverElapsed.ll	+= (MM * ONE_MINUTE);
		m_uRolloverElapsed.ll	+= (SS * ONE_SECOND);
		m_bRolloverTODSync		= bTODSync;
	}
}

void CAudioRecorder::SetRolloverRelativeTime(int HH, int MM, int SS)
{
	if (IsInit())
	{
		m_pRecordGateFilter->SetTriggerTime(HH, MM, SS);
		m_pVoxFilter->SetRolloverMode(FALSE);
		m_uRolloverElapsed.ll = 0;
	}
}

void CAudioRecorder::SetRolloverRelativeSamples(ULONGLONG nSamples)
{
	if (IsInit())
	{
		m_pRecordGateFilter->SetTriggerSamples(nSamples);
		m_pVoxFilter->SetRolloverMode(FALSE);
		m_uRolloverElapsed.ll = 0;
	}
}

BOOL __stdcall CAudioRecorder::AlarmCB(CAlarmClock* pThis, DWORD_PTR dwUserData)
{
	TFS;

	CAudioRecorder*	p = (CAudioRecorder*) dwUserData;

	p->SplitterNeedToSplit();

	return TRUE;
}

void CAudioRecorder::StartRolloverTimer(void)
{
	TF;

	UFT			uStartTime	= {0};
	SYSTEMTIME	tm			= {0};
	int			hh, mm, ss;

	if (IsInit())
	{
		if (m_uRolloverElapsed.ll > 0)
		{
			m_RolloverTimer.GetTime(&uStartTime.ft);	// Use current time for start.
			if (m_bRolloverTODSync)
			{
				FileTimeToSystemTime(&uStartTime.ft, &tm);
				tm.wHour = tm.wMinute = tm.wSecond = tm.wMilliseconds = 0;
				SystemTimeToFileTime(&tm, &uStartTime.ft);
			}

			hh = (int) (m_uRolloverElapsed.ll / ONE_HOUR);
			mm = (int) (m_uRolloverElapsed.ll / ONE_MINUTE % 60);
			ss = (int) (m_uRolloverElapsed.ll / ONE_SECOND % 60);

			m_RolloverTimer.SetRepeat(0, 0, hh, mm, ss, 0);
			uStartTime.ft  = m_RolloverTimer.WhenIsLatestAlarm(uStartTime.ft, m_RolloverTimer.GetRepeat());
			ASSERT(uStartTime.ll != 0);
			m_RolloverTimer.SetAlarm(uStartTime.ft, AlarmCB, (DWORD_PTR) this);
		}
	}
}


void CAudioRecorder::KillRolloverTimer(void)
{
	//TF;

	//m_RolloverTimer.ResetRepeats();
	m_RolloverTimer.KillAlarm();
}

RECORDER_STATE CAudioRecorder::GetRecorderState(void)
{
	return m_State;
}

void CAudioRecorder::SetRolloverVoxSync(BOOL bEnable)
{
	m_bRolloverVoxSync = bEnable;
}

BOOL CAudioRecorder::GetSplitterState(void)
{
	if (IsInit())
		return m_bSplitStarted;
	else
		return FALSE;
}

void CAudioRecorder::EnableLogfile(BOOL bEnable)
{
	m_LogFile.Enable(bEnable);
}

void CAudioRecorder::SetRadioSettings(CRadioSettings* pSettings)
{
	BOOL	rc;	

	ASSERT(pSettings != NULL);
	ASSERT(IsInit());	// Called before CAudioRecorder initialized.

	m_pRadioSettings = pSettings;

	// If the radio interface is enabled then start the mother fucker.
	if (m_pRadioSettings != NULL)
	{
		m_LogFile.SetRadioSettings(m_pRadioSettings);

		if (m_pRadioSettings->IsRadioEnabled())
		{
			rc = m_RadioInterface.Create(m_pRadioSettings);	// This activates the serial interface
			if (rc)
			{	// Radio port is online and ready to use.
				m_LogFile.SetRadioInterface(&m_RadioInterface);
			}
			else
			{	// Problem. Keep log from using the port.
				m_LogFile.SetRadioInterface(NULL);
			}
		}
	}

	// These settings will be used when CRadioInterface::Create is called.
	// Create will be called during SetRecord.
	// If the m_pRadioSettings pointer is NULL, there will be
	// no attempt to use the radio interface during recording.
}
