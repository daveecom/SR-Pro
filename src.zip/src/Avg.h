#pragma once

#include <afxtempl.h>

typedef CList<DWORD, DWORD> CDWordList;

class CAvg
{
public:
	CAvg(void);
	~CAvg(void);
protected:
	CDWordList	m_List;

public:
	void AddValue(DWORD dwValue);
protected:
	int m_Range;
public:
	void SetRange(int Range);
	void ForceValue(DWORD dwValue, BOOL bPurge=FALSE);
	DWORD GetAvg(int nCount = 0);
	int GetCount(void);
	DWORD m_Variance;
	DWORD GetVariance(void);
	DWORD m_Avg;
};
