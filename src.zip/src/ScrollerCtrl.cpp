// ScrollerCtrl.cpp : implementation file
//

#include "stdafx.h"

#include "resource.h"
#include ".\scrollerctrl.h"
#include "app.h"

#define SCROLL_DIVIDER (1)		// one out if N will invalidate display

// CScrollerCtrl

//IMPLEMENT_DYNAMIC(CScrollerCtrl, CStatic)
CScrollerCtrl::CScrollerCtrl()
: m_Range(100)
, m_colorBK(RGB(0,0,0))
, m_colorFG(RGB(255,255,255))
, m_colorGrid(RGB(000,255,255))
//, m_pRecorder(NULL)
, m_dwPercentCompressorLoad(0)
, m_strFreq(_T(""))
, m_nSMeter(0)
, m_fScrollFreq(15)		// Updates per second
, m_bGotRecorded(FALSE)
, m_pLogFile(NULL)
, m_cRefreshCounter(0)
{
}

CScrollerCtrl::~CScrollerCtrl()
{
}


BEGIN_MESSAGE_MAP(CScrollerCtrl, CStatic)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	ON_MESSAGE(UWM_ALARM, OnAlarmClockMsg)
	ON_WM_CREATE()
END_MESSAGE_MAP()

void CScrollerCtrl::PreSubclassWindow()
{
	//BOOL	rc;
	CRect	rect;
	CDC*	pDC;
	CBitmap	bmTemp;
	BITMAP	bm = {0};

	GetClientRect(&rect);
	pDC = GetDC();

	// Make the image bitmap the same size as the rect.
	m_bmImage.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	m_bmImage2.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());

	// Place a button on the screen for the user to clear the data.
	CRect statRect(5, 5, 25, 25);

	m_Button_Clear.Create(_T(""), WS_CHILD | WS_VISIBLE, 
		statRect, this, ID_BUTTON_CLEAR);

	// Set the status font
	if (m_Font.GetSafeHandle() == NULL)
	{
		m_Font.CreateFont(-14, 0, 0, 0, FW_NORMAL, 0, 0, 0,
			DEFAULT_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
			DEFAULT_PITCH || FF_DONTCARE, _T("Sans Serif"));

		m_Font2.CreateFont(-16, 0, 0, 0, FW_NORMAL, 0, 0, 0,
			DEFAULT_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
			DEFAULT_PITCH || FF_DONTCARE, _T("Sans Serif"));
	}

	SetTimer(0, (UINT) (1000.0 / m_fScrollFreq), NULL);	// Scroll Timer (approx 15 fps)
	//m_ScrollTimer.SetRepeat(0, 0, 0, 0, 0, (int) (1000 / m_fScrollFreq));
	//m_ScrollTimer.SetAlarm((int) 0, 0, 0, 0, 0, this->GetSafeHwnd());

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(&m_Button_Clear,	_T("Clear the scope display."));
}

void CScrollerCtrl::OnDestroy()
{
	KillTimer(0);

	__super::OnDestroy();
}

void CScrollerCtrl::OnTimer(UINT nIDEvent)
{
	BOOL	rc;
	DWORD	value = 0;
	CDC*	pDC;
	CDC		dc;
	CRgn	rgn1, rgn2, rgn3;
	CRect	rect1(0), rect2(0);

	switch(nIDEvent)
	{
		case 0:	// Scroll the graph
			pDC = GetDC();
			rc = dc.CreateCompatibleDC(pDC);
			ASSERT(rc);
			ReleaseDC(pDC);

			dc.SaveDC();
			dc.SelectObject(&m_bmImage);

			ScrollBitmap(&dc);

			DrawValue(&dc, FetchValue());

			dc.RestoreDC(-1);

			GetClientRect(&rect1);
			//m_Static_Overlay.GetWindowRect(&rect2);
			m_Button_Clear.GetWindowRect(&rect2);
			ScreenToClient(&rect2);

			rgn1.CreateRectRgnIndirect(&rect1);
			rgn2.CreateRectRgnIndirect(&rect2);
			rgn3.CreateRectRgnIndirect(&rect1);
			rgn3.CombineRgn(&rgn1, &rgn2, RGN_XOR);

			if (m_cRefreshCounter-- == 0)
			{
				InvalidateRgn(&rgn3, FALSE);
				m_cRefreshCounter = SCROLL_DIVIDER;
			}

			//Invalidate();
			break;
	}
}

void CScrollerCtrl::ScrollBitmap(CDC* pDC)
{
	CRect	clientRect;	// Our static rect.
	CSize	size;
	BOOL	rc;

	if (!m_bmImage.GetSafeHandle()) return;

	GetBitmapSize(size, m_bmImage);

	GetClientRect(&clientRect);

	pDC->SaveDC();

	// Shift the block to the left for width-1
	rc = pDC->BitBlt(0, 0, size.cx-1, size.cy, pDC, 1, 0, SRCCOPY);
	ASSERT(rc);

	pDC->RestoreDC(-1);

	// Remember to invalidate
}

void CScrollerCtrl::DrawValue(CDC* pDC, SCAN_INFO Scan)
{
	BITMAP	bm = {0};
	CPen	penBK(PS_SOLID, 1,	RGB(000, 000, 000));
	CPen	pen(PS_SOLID,	1,	RGB(255, 255, 255));
	CPen	pen1(PS_SOLID,	1,	RGB(200, 255, 255));
	CPen	pen2(PS_SOLID,	1,	RGB(255, 200, 200));
	CPen	pen1r(PS_SOLID,	1,	RGB(84, 255, 255));	// shows recorded color
	CPen	pen2r(PS_SOLID,	1,	RGB(255, 115, 115));	// "
	double	valueLeft	= Scan.wHighLeft;
	double	valueRight	= Scan.wHighRight;
	double	ratio;
	int		yCenter;

	if (m_bmImage.GetSafeHandle() != NULL)
	{
		m_bmImage.GetObject(sizeof(BITMAP), &bm);
		yCenter = bm.bmHeight / 2;

		pDC->SaveDC();

		// Scale the input values to fit the view screen
		ratio = valueLeft / 32768;
		valueLeft = (bm.bmHeight / 2) * ratio;
		ratio = valueRight / 32768;
		valueRight = (bm.bmHeight / 2) * ratio;


		// Clear the area first
		pDC->SelectObject(&penBK);
		pDC->MoveTo(bm.bmWidth-1, 0);
		pDC->LineTo(bm.bmWidth-1, bm.bmHeight);

		// Draw a center line
		pDC->SetPixelV(bm.bmWidth-1, yCenter, RGB(000,255,255));

		// Draw Left Data
		if (m_bGotRecorded)
			pDC->SelectObject(&pen1r);
		else
			pDC->SelectObject(&pen1);

		pDC->MoveTo(bm.bmWidth-1, yCenter);
		pDC->LineTo(bm.bmWidth-1, yCenter - ((int) valueLeft));

		if (Scan.bStereo)
		{
			// Draw Right Data
			if (m_bGotRecorded)
				pDC->SelectObject(&pen2r);
			else
				pDC->SelectObject(&pen2);

			pDC->MoveTo(bm.bmWidth-1, yCenter);
			pDC->LineTo(bm.bmWidth-1, yCenter + ((int) valueRight));
		}
		else
		{
			// Draw mono Right Data
			if (m_bGotRecorded)
				pDC->SelectObject(&pen1r);
			else
				pDC->SelectObject(&pen1);

			pDC->MoveTo(bm.bmWidth-1, yCenter);
			pDC->LineTo(bm.bmWidth-1, yCenter + ((int) valueLeft));
		}



		pDC->RestoreDC(-1);
	}
}


void CScrollerCtrl::SetRange(DWORD Range)
{
	m_Range = Range;
}

// Establishes a way to get the needed sensor values from the video engine.
// If NULL, break the logical connection by clearing the engine pointer.
//void CScrollerCtrl::SetVideoObject(CVideoEngine* pVideo)
//{
//	m_pVideo = pVideo;
//}

void CScrollerCtrl::GetBitmapSize(CSize& size, HBITMAP hBitmap)
{
	BITMAP	bm = {0};

	int result = ::GetObject(hBitmap, sizeof(BITMAP), &bm);
	ASSERT(result == sizeof(BITMAP));

	size.SetSize(bm.bmWidth, bm.bmHeight);
}

//BOOL CScrollerCtrl::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
//{
//	// TODO: Add your specialized code here and/or call the base class
//
//	Beep(800, 250);
//	return CStatic::OnNotify(wParam, lParam, pResult);
//}

BOOL CScrollerCtrl::OnCommand(WPARAM wParam, LPARAM lParam)
{
	WORD commandID	= LOWORD(wParam);
	DWORD controlID	= (DWORD) lParam;
	
	switch (commandID)
	{
		case ID_BUTTON_CLEAR:
			ClearButton();
			break;
	}

	return TRUE;
}

// Comes here when the button is pushed.
void CScrollerCtrl::ClearButton(void)
{
	CClientDC dcClient(this);
	CDC dc;
	BITMAP bm;

	if (m_bmImage.GetSafeHandle() != NULL)
	{
		dc.CreateCompatibleDC(&dcClient);
		m_bmImage.GetObject(sizeof(BITMAP), &bm);
		dc.SaveDC();
		dc.SelectObject(&m_bmImage);
		dc.FillSolidRect(0, 0, bm.bmWidth, bm.bmHeight, RGB(000, 000, 000));

		dc.RestoreDC(-1);
	}
}

BOOL CScrollerCtrl::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void CScrollerCtrl::OnPaint()
{
	CRect		rect;
	CPaintDC	dc(this); // device context for painting
	CDC			dcSrc, dcBfr;

	if (!IsWindowEnabled()) return;	// prevent drawing if disabled

	GetClientRect(&rect);

	dcSrc.CreateCompatibleDC(&dc);
	dcBfr.CreateCompatibleDC(&dc);

	dcSrc.SaveDC();
	dcBfr.SaveDC();

	dcSrc.SelectObject(&m_bmImage);
	dcBfr.SelectObject(&m_bmImage2);

	dcBfr.BitBlt(0, 0, rect.Width(), rect.Height(), &dcSrc, 0, 0, SRCCOPY);

	DrawGrid(&dcBfr);
	DrawStats(&dcBfr);

	dc.BitBlt(0, 0, rect.Width(), rect.Height(), &dcBfr, 0, 0, SRCCOPY);

	dcBfr.RestoreDC(-1);
	dcSrc.RestoreDC(-1);
}

void CScrollerCtrl::DrawGrid(CDC* pDC)
{
	int			x, y;
	double		divisionsX;
	int			divisionsY;
	double		incX;
	int			incY;
	COLORREF	color		= RGB(100,100,255);
	CRect		rect;
	CPen		penH1(PS_DOT,		1, color);
	CPen		penH2(PS_SOLID,		1, color);
	CPen		penV(PS_SOLID,		1, color);
	CPen		penLbl(PS_SOLID,	1, color);
	CBrush		brushLbl(color);
	CSize		size;

	GetClientRect(&rect);

	divisionsX = rect.Width() / m_fScrollFreq;
	divisionsY = 4;

	pDC->SaveDC();

	pDC->SetBkMode(TRANSPARENT);

	//pDC->SetROP2(R2_MERGEPEN);
	//pDC->SetROP2(R2_COPYPEN);
	//pDC->SetROP2(R2_NOTCOPYPEN);
	pDC->SetROP2(R2_MASKPENNOT);
	//pDC->SetROP2(R2_XORPEN);

	// Draw verticles
	pDC->SelectObject(&penV);
	//incX = rect.Width() / divisionsX;
	//for (x = 1; x < divisionsX ; x++)
	//{
	//	pDC->MoveTo(x*incX, rect.Height()/2 - 5);
	//	pDC->LineTo(x*incX, rect.Height()/2 + 5);
	//}
	incX = rect.Width() / divisionsX;
	for (x = rect.Width() /*- (int)incX*/; x > 0; x -= (int)incX)
	{
		pDC->MoveTo(x, rect.Height()/2 - 5);
		pDC->LineTo(x, rect.Height()/2 + 5);
	}

	// Draw horz
	incY = rect.Height() / divisionsY;
	for (y = 1; y < divisionsY; y++)
	{
		if (y == (divisionsY/2))
		{	// Draw center line.
			pDC->SelectObject(&penH2);
			pDC->MoveTo(rect.left, y*incY);
			pDC->LineTo(rect.right, y*incY);		
		}
		else
		{
			pDC->SelectObject(&penH1);
			pDC->MoveTo(rect.left, y*incY);
			pDC->LineTo(rect.right, y*incY);		
		}
	}

	// Draw the L and R labels.
	pDC->BeginPath();

	pDC->SelectObject(&m_Font2);

	pDC->SetTextAlign(TA_BOTTOM);
	pDC->ExtTextOut(2, (rect.Height()/2)-2, 0, NULL, _T("L"), NULL);
	size = pDC->GetTextExtent(_T("L"));
	//pDC->ExtTextOut(rect.Width()/2-(size.cx/2), (rect.Height()/2)-2, 0, NULL, _T("L"), NULL);
	pDC->ExtTextOut(rect.right-size.cx-2, (rect.Height()/2)-2, 0, NULL, _T("L"), NULL);

	pDC->SetTextAlign(TA_TOP);
	pDC->ExtTextOut(2, (rect.Height()/2)+2, 0, NULL, _T("R"), NULL);
	size = pDC->GetTextExtent(_T("R"));
	//pDC->ExtTextOut(rect.Width()/2-(size.cx/2), (rect.Height()/2)+2, 0, NULL, _T("R"), NULL);
	pDC->ExtTextOut(rect.right-size.cx-2, (rect.Height()/2)+2, 0, NULL, _T("R"), NULL);

	pDC->EndPath();

	pDC->SelectObject(&brushLbl);
	pDC->SelectObject(&penLbl);

	pDC->StrokeAndFillPath();
	//pDC->FillPath();

	pDC->RestoreDC(-1);
}

void CScrollerCtrl::DrawStats(CDC * pDC)
{
	CRect		rectClient;
	COLORREF	color = RGB(255,255,000);
	double		fPercent = 0, fBufferTime = 0, fMeasuredTime = 0;
	CString		str;
	CSize		sizeExtent;
	CPen		pen(PS_SOLID, 1, color);
	CBrush		brush(color);

	GetClientRect(&rectClient);

	pDC->SaveDC();

	pDC->SelectObject(&m_Font);
	pDC->SelectObject(&pen);
	pDC->SelectObject(&brush);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(color);
	pDC->SetBkColor(RGB(000,000,000));

	pDC->BeginPath();

	//if (m_strFreq.IsEmpty()) m_strFreq = _T("0000.000.00");

	if (!m_strFreq.IsEmpty())
	{
		pDC->SetTextAlign(TA_TOP);

		str.Format(_T("Frq: %s"), m_strFreq);

		sizeExtent = pDC->GetTextExtent(str);
		pDC->ExtTextOut(rectClient.right - sizeExtent.cx - 4, 4, 0, NULL, str, NULL);

		str.Format(_T("SMeter%: %3d%%"), m_nSMeter);

		sizeExtent = pDC->GetTextExtent(str);
		pDC->ExtTextOut(rectClient.right - sizeExtent.cx - 4, 18, 0, NULL, str, NULL);
	}

	if (m_dwTimePerBuffer > 0)
	{
		fPercent = ((double) m_dwTimePerBufferMeasured / (double) m_dwTimePerBuffer) * 100.0;

		pDC->SetTextAlign(TA_BASELINE);

		str.Format(_T("Cmp-Load: %4.1f%%"), fPercent);
		pDC->ExtTextOut(4, rectClient.bottom - 4, 0, NULL, str, NULL);

		str.Format(_T("BT: %ums,  MT: %ums"), m_dwTimePerBuffer, m_dwTimePerBufferMeasured);
		pDC->ExtTextOut(4, rectClient.bottom - 18, 0, NULL, str, NULL);
	}

	pDC->EndPath();

	//pDC->SetROP2(R2_COPYPEN);
	//pDC->SetROP2(R2_XORPEN);
	pDC->SetROP2(R2_MERGEPEN);
	//pDC->SetROP2(SRCINVERT);

	pDC->StrokeAndFillPath();
	//pDC->StrokePath();
	//pDC->FillPath();

	pDC->RestoreDC(-1);
}


SCAN_INFO CScrollerCtrl::FetchValue(void)
{
	SCAN_INFO	info = {0};
	BOOL		bInit = FALSE;

	bInit = DOC->GetRecorder()->IsInit();
	if (bInit)
	{
		DOC->GetScanInfo(&info);

		m_dwTimePerBuffer = DOC->GetRecorder()->GetBufferTimeMS();
		m_dwTimePerBufferMeasured = DOC->GetRecorder()->GetBufferTimeMeasuredMS();

		if (DOC->m_bVox1 && DOC->GetRecorder()->IsVoxGateOpen()
			/*&& DOC->GetRecorder()->GetRecorderState() == Recording*/)
		{
			m_bGotRecorded = FALSE;	// Disable this mechanism for now.
		}
		else
		{
			m_bGotRecorded = FALSE;
		}
	}

	if (m_pLogFile != NULL)
	{
		m_strFreq = m_pLogFile->GetGreq();
		m_nSMeter = m_pLogFile->GetSMeter();
	}

	return info;
}

// This connects this control to a data source, the capture filter.
//void CScrollerCtrl::ConnectToRecorder(CAudioRecorder* pRecorder)
//{
//	ASSERT(pRecorder != NULL);
//	m_pRecorder = pRecorder;
//}

LRESULT CScrollerCtrl::OnAlarmClockMsg( WPARAM wParam, LPARAM lParam)
{
	OnTimer(0);

	return LRESULT();
}


BOOL CScrollerCtrl::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
		m_ToolTip.RelayEvent(pMsg);

	return FALSE;
}

int CScrollerCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CStatic::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}
