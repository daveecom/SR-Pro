// FileSettings.cpp : implementation file
//

#include "stdafx.h"

#include "resource.h"
#include "FileSettings.h"
#include ".\app.h"
#include ".\doc.h"
#include ".\Mainfrm.h"
#include ".\filesettings.h"

// CFileSettings

IMPLEMENT_SERIAL(CFileSettings, CObject, 0)


CFileSettings::CFileSettings()
{
	SetDefaults();
}

CFileSettings::~CFileSettings()
{
}


// CDlgFileSettings dialog

IMPLEMENT_DYNAMIC(CDlgFileSettings, CDialog)
CDlgFileSettings::CDlgFileSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgFileSettings::IDD, pParent)
	, m_pParent(NULL)
	, m_bDirty(FALSE)
{
}

CDlgFileSettings::~CDlgFileSettings()
{
}

void CDlgFileSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SPIN_SEQDIGITS, m_Spin_SeqDigits);
	DDX_Control(pDX, IDC_SPIN_TIME_HH, m_Spin_HH);
	DDX_Control(pDX, IDC_SPIN_TIME_MM, m_Spin_MM);
	DDX_Control(pDX, IDC_EDIT_SEQDIGITS, m_Edit_SeqDigits);
	DDX_Control(pDX, IDC_EDIT_FILENAME, m_Edit_FilenameRoot);
	DDX_Control(pDX, IDC_EDIT_FOLDER, m_Edit_Folder);
	DDX_Control(pDX, IDC_EDIT_TIME_HH, m_Edit_HH);
	DDX_Control(pDX, IDC_EDIT_TIME_MM, m_Edit_MM);
	DDX_Control(pDX, IDC_CHECK_TODSYNC, m_Check_TODSync);
	DDX_Control(pDX, IDC_CHECK_SPLITTERVOXSYNC, m_Check_UseVoxSync);
}


BEGIN_MESSAGE_MAP(CDlgFileSettings, CDialog)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_RADIO_FILEAPPENDSEQ, OnBnClickedRadioFileappendseq)
	ON_BN_CLICKED(IDC_RADIO_FILEAPPENDDATE, OnBnClickedRadioFileappenddate)
	ON_BN_CLICKED(IDC_RADIO_WAV, OnBnClickedRadioWav)
	ON_BN_CLICKED(IDC_RADIO_RAW, OnBnClickedRadioRaw)
	ON_BN_CLICKED(IDC_RADIO_LIMITEROFF, OnBnClickedRadioLimiteroff)
	ON_BN_CLICKED(IDC_RADIO_LIMITBYEVENT, OnBnClickedRadioLimitbyevent)
	ON_BN_CLICKED(IDC_RADIO_LIMITRECTIME, OnBnClickedRadioLimitrectime)
	ON_BN_CLICKED(IDC_RADIO_LIMITTOD, OnBnClickedRadioLimittod)
	ON_EN_KILLFOCUS(IDC_EDIT_FILENAME, OnEnKillfocusEditFilename)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnBnClickedButtonBrowse)
	ON_BN_CLICKED(IDC_CHECK_TODSYNC, OnBnClickedCheckTodsync)
	ON_BN_CLICKED(IDC_CHECK_SPLITTERVOXSYNC, OnBnClickedCheckSplittervoxsync)
	ON_BN_CLICKED(IDC_BUTTON_RESETSEQ, OnBnClickedButtonResetseq)
END_MESSAGE_MAP()


// CDlgFileSettings message handlers

INT_PTR CFileSettings::DoModal(void)
{
	INT_PTR rc;

	m_Dlg.m_pParent = this;

	m_bNeedsRestart = FALSE;

	rc = m_Dlg.DoModal();

	if (rc == IDOK)
	{

	}

	return rc;
}

void CFileSettings::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_strFolder;
		ar << m_strFilenameRoot;
		ar << m_strExt;
		ar << m_nSeqDigits;
		ar.Write(&m_eSeqMode, sizeof(SEQ_MODE));
		ar.Write(&m_eLimMode, sizeof(LIM_MODE));
		ar << m_LimHH;
		ar << m_LimMM;
		ar << m_bLimSyncTOD;
		ar << m_bVoxSync;
	}
	else
	{	// loading code
		ar >> m_strFolder;
		ar >> m_strFilenameRoot;
		ar >> m_strExt;
		ar >> m_nSeqDigits;
		ar.Read(&m_eSeqMode, sizeof(SEQ_MODE));
		ar.Read(&m_eLimMode, sizeof(LIM_MODE));
		ar >> m_LimHH;
		ar >> m_LimMM;
		ar >> m_bLimSyncTOD;
		ar >> m_bVoxSync;
	}
}

void CFileSettings::SetDefaults(void)
{
	TCHAR path[MAX_PATH + 2] = {0};

	::GetCurrentDirectory(MAX_PATH, path);
	m_strFolder = path;

	m_strFilenameRoot	= _T("default");
	m_strExt			= _T("wav");
	m_nSeqDigits		= 4;
	m_eSeqMode			= seq_date;
	m_eLimMode			= lim_Off;
	m_LimHH				= 0;
	m_LimMM				= 0;
	m_bLimSyncTOD		= FALSE;
	m_bVoxSync			= FALSE;
}

BOOL CDlgFileSettings::OnInitDialog()
{
	CDialog::OnInitDialog();

	ASSERT(m_pParent != NULL);

	CWnd*	pParent = GetParent();
	CRect	rect1;
	pParent->GetWindowRect(rect1);
	//SetWindowPos(&CWnd::wndTop, rect1.left, rect1.bottom, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);

	// Obtain the initial settings from the parent object
	m_strFolder			= m_pParent->m_strFolder;
	m_strFilenameRoot	= m_pParent->m_strFilenameRoot;
	m_strExt			= m_pParent->m_strExt;
	m_nSeqDigits		= m_pParent->m_nSeqDigits;
	m_eSeqMode			= m_pParent->m_eSeqMode;
	m_eLimMode			= m_pParent->m_eLimMode;
	m_LimHH				= m_pParent->m_LimHH;
	m_LimMM				= m_pParent->m_LimMM;
	m_bLimSyncTOD		= m_pParent->m_bLimSyncTOD;
	m_bVoxSync			= m_pParent->m_bVoxSync;

	m_Spin_SeqDigits.SetRange(2, 6);
	m_Spin_HH.SetRange(0, 167);
	m_Spin_MM.SetRange(0, 59);

	Update();

	m_ToolTip.Create(this, TTS_ALWAYSTIP);

	m_ToolTip.AddTool(GetDlgItem(IDOK),						_T("Save changes and close this window."));
	m_ToolTip.AddTool(GetDlgItem(IDCANCEL),					_T("Cancel changes."));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_TIME_HH),			_T("Hours"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_TIME_HH),			_T("Hours"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_TIME_MM),			_T("Minutes"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_TIME_MM),			_T("Minutes"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_FILEAPPENDSEQ),	_T("Append sequence digits after the filename."));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_FILEAPPENDDATE), _T("Append date and time after the filename."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_SEQDIGITS),		_T("Number of sequence digits"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_SEQDIGITS),		_T("Number of sequence digits"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_FILENAME),		_T("Root filename"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_WAV),			_T("Create WAV file."));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_RAW),			_T("Create RAW file."));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_FOLDER),			_T("Output files folder"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_BROWSE),		_T("Browse for output files folder."));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_LIMITEROFF),		_T("Turn file splitter off."));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_LIMITRECTIME),	_T("Split files by duration."));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_LIMITBYEVENT),	_T("Split files using VOX."));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_LIMITTOD),		_T("Split files based on time of day."));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_TODSYNC),		_T("Sync TOD splitter with top-of-hour."));

	return TRUE;
}

void CDlgFileSettings::Update(void)
{
	TCHAR	string[256] = {0};

	if (m_strExt == _T("wav"))
		CheckDlgButton(IDC_RADIO_WAV, BST_CHECKED);
	if (m_strExt == _T("raw"))
		CheckDlgButton(IDC_RADIO_RAW, BST_CHECKED);

	_itot_s(m_nSeqDigits, string, (sizeof string / sizeof string[0]), 10);
	m_Edit_SeqDigits.SetWindowText(string);
	_itot_s(m_LimHH, string, (sizeof string / sizeof string[0]), 10);
	m_Edit_HH.SetWindowText(string);
	_itot_s(m_LimMM, string, (sizeof string / sizeof string[0]), 10);
	m_Edit_MM.SetWindowText(string);
	m_Check_TODSync.SetCheck(m_bLimSyncTOD ? BST_CHECKED:BST_UNCHECKED);

	m_Check_UseVoxSync.SetCheck(m_bVoxSync ? BST_CHECKED:BST_UNCHECKED);

#ifdef _LITE

	CheckDlgButton(IDC_RADIO_LIMITEROFF, BST_CHECKED);
	m_Edit_HH.EnableWindow(FALSE);
	m_Edit_MM.EnableWindow(FALSE);
	m_Spin_HH.EnableWindow(FALSE);
	m_Spin_MM.EnableWindow(FALSE);
	m_Check_TODSync.EnableWindow(FALSE);
	m_Check_UseVoxSync.EnableWindow(FALSE);

	GetDlgItem(IDC_RADIO_LIMITBYEVENT)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO_LIMITEROFF)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO_LIMITRECTIME)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO_LIMITTOD)->EnableWindow(FALSE);

#else

	switch (m_eLimMode)
	{
		case lim_Off:
			CheckDlgButton(IDC_RADIO_LIMITEROFF,	BST_CHECKED);
			CheckDlgButton(IDC_RADIO_LIMITBYEVENT,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITRECTIME,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITTOD,		BST_UNCHECKED);

			m_Edit_HH.EnableWindow(FALSE);
			m_Edit_MM.EnableWindow(FALSE);
			m_Spin_HH.EnableWindow(FALSE);
			m_Spin_MM.EnableWindow(FALSE);
			m_Check_TODSync.EnableWindow(FALSE);
			m_Check_UseVoxSync.EnableWindow(TRUE);	// Allows button to work.
			break;

		case lim_event:
			CheckDlgButton(IDC_RADIO_LIMITEROFF,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITBYEVENT,	BST_CHECKED);
			CheckDlgButton(IDC_RADIO_LIMITRECTIME,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITTOD,		BST_UNCHECKED);

			m_Edit_HH.EnableWindow(FALSE);
			m_Edit_MM.EnableWindow(FALSE);
			m_Spin_HH.EnableWindow(FALSE);
			m_Spin_MM.EnableWindow(FALSE);
			m_Check_TODSync.EnableWindow(FALSE);
			m_Check_UseVoxSync.EnableWindow(FALSE);

			m_bVoxSync = FALSE;
			m_Check_UseVoxSync.SetCheck(BST_UNCHECKED);
			break;

		case lim_duration:
			CheckDlgButton(IDC_RADIO_LIMITEROFF,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITBYEVENT,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITRECTIME,	BST_CHECKED);
			CheckDlgButton(IDC_RADIO_LIMITTOD,		BST_UNCHECKED);

			m_Edit_HH.EnableWindow(TRUE);
			m_Edit_MM.EnableWindow(TRUE);
			m_Spin_HH.EnableWindow(TRUE);
			m_Spin_MM.EnableWindow(TRUE);
			m_Check_TODSync.EnableWindow(FALSE);
			m_Check_UseVoxSync.EnableWindow(TRUE);
			break;

		case lim_clock:
			CheckDlgButton(IDC_RADIO_LIMITEROFF,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITBYEVENT,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITRECTIME,	BST_UNCHECKED);
			CheckDlgButton(IDC_RADIO_LIMITTOD,		BST_CHECKED);

			m_Edit_HH.EnableWindow(TRUE);
			m_Edit_MM.EnableWindow(TRUE);
			m_Spin_HH.EnableWindow(TRUE);
			m_Spin_MM.EnableWindow(TRUE);
			m_Check_TODSync.EnableWindow(TRUE);
			m_Check_UseVoxSync.EnableWindow(TRUE);
			break;
	}

#endif

	switch (m_eSeqMode)
	{
		case seq_counter:
			CheckDlgButton(IDC_RADIO_FILEAPPENDSEQ, BST_CHECKED);
			m_Edit_SeqDigits.EnableWindow(TRUE);
			m_Spin_SeqDigits.EnableWindow(TRUE);
			break;

		case seq_date:
			CheckDlgButton(IDC_RADIO_FILEAPPENDDATE, BST_CHECKED);
			m_Edit_SeqDigits.EnableWindow(FALSE);
			m_Spin_SeqDigits.EnableWindow(FALSE);
			break;
	}

	m_Edit_FilenameRoot.SetWindowText(m_strFilenameRoot);
	m_Edit_Folder.SetWindowText(m_strFolder);
}

void CDlgFileSettings::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString	text;

	m_LimHH			= m_Spin_HH.GetPos();
	m_LimMM			= m_Spin_MM.GetPos();
	m_nSeqDigits	= m_Spin_SeqDigits.GetPos();
	m_bDirty		= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioFileappendseq()
{
	m_eSeqMode	= seq_counter;
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioFileappenddate()
{
	m_eSeqMode	= seq_date;
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioWav()
{
	m_strExt	= _T("wav");
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioRaw()
{
	m_strExt	= _T("raw");
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioLimiteroff()
{
	m_eLimMode	= lim_Off;
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioLimitbyevent()
{
	m_eLimMode	= lim_event;
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioLimitrectime()
{
	m_eLimMode	= lim_duration;
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedRadioLimittod()
{
	m_eLimMode	= lim_clock;
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnEnKillfocusEditFilename()
{
	m_Edit_FilenameRoot.GetWindowText(m_strFilenameRoot);
	m_bDirty	= TRUE;
	Update();
}

void CDlgFileSettings::OnBnClickedButtonBrowse()
{
	CFileDialog cfd(TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, NULL, this);
	INT_PTR	rc;
	TCHAR fullPath[MAX_PATH] = _T("(file names will be ignored)");
	CString tmpFolder;

	cfd.m_pOFN->lpstrTitle = _T("Choose folder for output storage");
	cfd.m_pOFN->lpstrFile = fullPath;
	cfd.m_pOFN->nMaxFile	= sizeof fullPath / sizeof(TCHAR);
	cfd.m_pOFN->Flags |= OFN_NOVALIDATE|OFN_NOTESTFILECREATE|OFN_EXPLORER;

	for (;;)
	{
		rc = cfd.DoModal();
		if (rc == IDOK)
		{
			tmpFolder = cfd.m_pOFN->lpstrFile;
			tmpFolder = tmpFolder.Left(tmpFolder.ReverseFind('\\'));
			if (!tmpFolder.IsEmpty())
			{
				m_strFolder = tmpFolder;
				m_bDirty	= TRUE;
				Update();

				break;
			}
			else
			{
				AfxMessageBox(_T("Warning: Invalid folder. Please choose another."), MB_OK|MB_ICONEXCLAMATION);
				continue;
			}
		}
		else
			break;
	}
}


void CDlgFileSettings::OnOK()
{
	if (m_bDirty)
	{
		// If the extension has changed then the restart flag needs to be set to tell the owner.
		if (m_pParent->m_strExt != m_strExt)
			m_pParent->m_bNeedsRestart = TRUE;

		// Copy the dlg temp vars to the parent object's actual vars.
		m_pParent->m_strFolder			= m_strFolder;
		m_pParent->m_strFilenameRoot	= m_strFilenameRoot;
		m_pParent->m_strExt				= m_strExt;
		m_pParent->m_nSeqDigits			= m_nSeqDigits;
		m_pParent->m_eSeqMode			= m_eSeqMode;
		m_pParent->m_eLimMode			= m_eLimMode;
		m_pParent->m_LimHH				= m_LimHH;
		m_pParent->m_LimMM				= m_LimMM;
		m_pParent->m_bLimSyncTOD		= m_bLimSyncTOD;
		m_pParent->m_bVoxSync			= m_bVoxSync;

		m_bDirty = FALSE;
	}

	CDialog::OnOK();
}

BOOL CFileSettings::IsRestartNecessary()
{
	return m_bNeedsRestart;
}

void CDlgFileSettings::OnBnClickedCheckTodsync()
{
	m_bLimSyncTOD	= m_Check_TODSync.GetCheck() == BST_CHECKED;
	m_bDirty		= TRUE;
}

BOOL CDlgFileSettings::PreTranslateMessage(MSG* pMsg)
{
	m_ToolTip.RelayEvent(pMsg);

	return __super::PreTranslateMessage(pMsg);
}

void CDlgFileSettings::OnBnClickedCheckSplittervoxsync()
{
	m_bVoxSync	= m_Check_UseVoxSync.GetCheck() == BST_CHECKED;
	m_bDirty	= TRUE;
}

// Reset the sequence number.
void CDlgFileSettings::OnBnClickedButtonResetseq()
{
	DOC->m_FilenameServer1.SetSequenceNumber(0);
	DOC->SetModifiedFlag();
}
