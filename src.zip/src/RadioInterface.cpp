#include "StdAfx.h"
#include ".\radiosettings.h"
#include ".\radiointerface.h"

extern LPCTSTR	lpszCommandTbl[];

CRadioInterface::CRadioInterface(void)
: m_pRadioSettings(NULL)
, m_pComPort(NULL)
, m_hAsyncExecWorker(NULL)
, m_bAbortExecThread(FALSE)
{
	// Clear the cache pointer table.
	for (int i = 0; i < RadioCmd_NumCmds; i++)
	{
		m_pCache[i] = NULL;
		m_cCacheDataCount[i] = 0;
	}
}

CRadioInterface::~CRadioInterface(void)
{
	Destroy();
}

BOOL CRadioInterface::ExecuteCmd(CRadioCommand* pCommand, BOOL bForceRead)
{
	CString		strCmd;
	CStringA	strA;
	CString		strT;
	#define		NUMTOKENS 30
	CString		strTokens[NUMTOKENS];
	BOOL		rc;
	int			nResultSize;
	BYTE		result[CACHE_SIZE]	= {0};
	int			nCmdSize;
	BYTE		cmd[MAX_CMD_SIZE]	= {0};
	int			indx, nItems;
	RADIO_CMD	eCmd;
	CAlarmClock	clockDelay;

	ASSERT(m_pRadioSettings		!= NULL);
	ASSERT(m_pComPort			!= NULL);
	ASSERT(pCommand				!= NULL);

	//for (int i = 0; i < NUMTOKENS; i++) strTokens[i].Empty();

	eCmd	= pCommand->GetCmd();

	// Clear the result in case there are leftovers from a previous execution.
	//pCommand->SetResult(NULL, 0);

	// If bForceRead is TRUE then clear the current cache if it's not empty.
	if (bForceRead)
	{	// Purge the cache.
		ASSERT(m_pCache[eCmd] != NULL);

		ZeroMemory(m_pCache[eCmd], CACHE_SIZE);
		m_cCacheDataCount[eCmd] = 0;
	}

 	if (m_cCacheDataCount[eCmd] == 0)	// If cache is empty ...
	{
		// Cache empty. Need to perform I/O to get the Radio Data.
		try
		{
			if (!m_pComPort->IsPortOpen()) throw(_T("COM port is not open."));

			// Prepare the command message and the sync parms.
			switch(m_pRadioSettings->GetRadioType())
			{
				case RadioType_None:
					break;

				case RadioType_Icom:
					throw(_T("Icom support is under construction."));
					break;

				case RadioType_Uniden:
					strCmd	= lpszCommandTbl[eCmd];
					strA = strCmd;	// Unicode to mbcs so the radio can accept text.
					strA.AppendChar(0x0d);	// This model requires CR at the end.

					nCmdSize = strA.GetLength();
					CopyMemory(cmd, strA, nCmdSize);

					// Prepare the sync controls
					m_pComPort->SetSyncChar(0x0d, 1);

					// multi-line sync for certain cmds
					if (eCmd >= RadioCmd_LCD01 && eCmd <= RadioCmd_LCD40)
						m_pComPort->SetSyncChar(0x0d, 3);

					if	(eCmd == RadioCmd_LCDCHN)
						m_pComPort->SetSyncChar(0x0d, 2);

					break;
			}

			// Pre xmit delay here if needed.
			int nDelay = pCommand->GetDelay();
			if (nDelay != 0)
			{
				clockDelay.SetAlarmAndWait(0, 0, 0, 0, nDelay);
			}

			rc = m_pComPort->TransmitData(cmd, nCmdSize);
			if (!rc) throw(_T("Transmit to port failed."));

			rc = m_pComPort->WaitForSync(m_pRadioSettings->GetTimeout());
			if (!rc) throw(_T("Timeout waiting for serial port."));

			nResultSize = m_pComPort->GetRxData(NULL, 0);
			if (nResultSize == 0) throw(_T("Result from radio is null"));

			ZeroMemory(m_pCache[eCmd], CACHE_SIZE);

			m_pComPort->GetRxData(m_pCache[eCmd], nResultSize, TRUE);	// Note: last char is 0
			m_cCacheDataCount[eCmd] = nResultSize;

		}
		catch(LPCTSTR lpszMsg)
		{
			TRACE(lpszMsg);
			pCommand->SetResult(lpszMsg);
			return FALSE;
		}
	}	// If cache is empty ...
	else
	{	// Use the cache instead of serial I/O
		//Beep(8000,10);	// Not sure why but this beep deadlocked
	}

	// Serial I/o Complete.

	// Radio specific post I/O formatting:
	switch (m_pRadioSettings->GetRadioType())
	{
		case RadioType_None:
			break;

		case RadioType_Icom:
				// TODO Finish Icom
			break;

		case RadioType_Uniden:
			strT = (LPCSTR) m_pCache[eCmd];	// Convert mbcs to TCHAR (might not need this??

			// If this is a multi-line 898T LCD01 type reply, convert
			// the extra CR's into commas.
			for (int i = 0, j = strT.GetLength(); i < j; i++)
			{
				if (strT.Mid(i,1) == 0x0d)
				{
					strT.SetAt(i, ',');
				}
			}

			if (eCmd >= RadioCmd_GLG && eCmd <= RadioCmd_WIN)
			{	// Only Uniden XT and T series can parse comma delim text.
				nItems = m_pComPort->ParseRecord(strT, strTokens, NUMTOKENS);
				if (nItems > pCommand->GetIndex())
				{
					indx = pCommand->GetIndex();
					strT = strTokens[indx];
					pCommand->SetResult(strT);
				}
			}
			else
			{	// Not of the Uniden CSV types.
				pCommand->SetResult(strT);
			}

			break;
	}

	return TRUE;
}

BOOL CRadioInterface::Create(CRadioSettings* pSettings)
{
	BOOL	rc;

	ASSERT(pSettings != NULL);

	m_pRadioSettings = pSettings;

	InitCache();

	ASSERT(m_pComPort == NULL);		// Create must've been called twice w/o destroy

	m_pComPort = new CComPort;
	ASSERT(m_pComPort != NULL);

	rc = m_pComPort->Create(pSettings->GetPort(), pSettings->GetBaud());
	if (!rc)
	{
		AfxMessageBox
		(
			_T("Cannot open port.\r\n") \
			_T("Radio logging has been disabled.")
		);
	}

	return TRUE;
}

void CRadioInterface::InitCache(void)
{
	for (int i = 0; i < RadioCmd_NumCmds; i++)
	{
		if (m_pCache[i] == NULL)
		{
			m_pCache[i] = new BYTE[CACHE_SIZE];
			ASSERT(m_pCache[i] != NULL);
		}

		ZeroMemory(m_pCache[i], CACHE_SIZE);

		m_cCacheDataCount[i] = 0;
	}
}

void CRadioInterface::DestroyCache(void)
{
	for (int i = 0; i < RadioCmd_NumCmds; i++)
	{
		if (m_pCache[i] != NULL)
		{
			delete [] m_pCache[i];
			m_pCache[i] = NULL;
			m_cCacheDataCount[i] = 0;
		}
	}
}

void CRadioInterface::Destroy(void)
{
	KillAsyncWorker();

	if (m_pComPort != NULL)
	{
		m_pComPort->Destroy();
		delete m_pComPort;
		m_pComPort = NULL;
	}

	DestroyCache();

	m_pRadioSettings = NULL;
}

int CRadioInterface::GetCacheData(LPBYTE OUT pBuffer, DWORD dwBufferSize, RADIO_CMD eCmd)
{
	ASSERT(m_pCache[eCmd] != NULL);
	ASSERT(pBuffer != NULL);
	ASSERT(eCmd < RadioCmd_NumCmds);

	DWORD dwSize = min((int) dwBufferSize, m_cCacheDataCount[eCmd]);

	if (dwSize != 0)
		CopyMemory(pBuffer, m_pCache[eCmd], dwSize);

	return dwSize;
}

BOOL CRadioInterface::ExecuteJob(CRadioSettings* pRadioSettings)
{
	BOOL	bSuccess	= FALSE;
	BOOL	rc;
	int		nJobItems	= pRadioSettings->GetJobItemCount();
	int		i;

	ASSERT(pRadioSettings != NULL);

	// Job execution loop

	ClearCache();

	for (i = 0; i < nJobItems; i++)
	{
		//rc = ExecuteCmd(pRadioSettings->GetJobItem(i),	FALSE);
		rc = ExecuteCmd(pRadioSettings->GetJobItem(i),		TRUE);	// Don't use cache for now
		if (!rc) break;
	}
	if (rc) bSuccess = TRUE;// out of loop w/rc=1 means all of them worked.

	return bSuccess;
}

CRadioSettings* CRadioInterface::GetRadioSettings(void)
{
	ASSERT(m_pRadioSettings != NULL);

	return m_pRadioSettings;
}

void CRadioInterface::StartAsyncJob(void)
{
	UINT	threadID = 0;

	m_pComPort->AbortIO();

	KillAsyncWorker();

	m_hAsyncExecWorker = (HANDLE) _beginthreadex(NULL, 0, AsyncWorker, this, 0, &threadID);
}

unsigned  __stdcall CRadioInterface::AsyncWorker(void *arglist)
{
	((CRadioInterface*)arglist)->AsyncWorker();
	return 0;
}

void CRadioInterface::AsyncWorker(void)
{
	BOOL	rc;

	if (m_pRadioSettings->GetJobItemCount() != 0)
	{
		rc = ExecuteJob(m_pRadioSettings);
		if (!rc)
		{
			TRACE(_T("Radio job failed.\r\n"));
		}
	}
}

void CRadioInterface::PurgeReceiver(void)
{
	ASSERT(m_pComPort != NULL);
	ASSERT(m_pComPort->IsPortOpen());

	m_pComPort->PurgeRxBuffer();
}

void CRadioInterface::KillAsyncWorker(void)
{
	if (m_hAsyncExecWorker != NULL)
	{
		m_bAbortExecThread = TRUE;
		m_pComPort->AbortSyncWait();
		WaitForSingleObject(m_hAsyncExecWorker, INFINITE);
		CloseHandle(m_hAsyncExecWorker);
		m_hAsyncExecWorker = NULL;
	}
	m_bAbortExecThread = FALSE;
}

void CRadioInterface::ClearCache(void)
{
	for (int i = 0; i < RadioCmd_NumCmds; i++)
	{
		ASSERT(m_pCache[i] != NULL);

		ZeroMemory(m_pCache[i], CACHE_SIZE);
		m_cCacheDataCount[i] = 0;
	}
}
