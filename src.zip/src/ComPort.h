////////////////////////////////////////////////////////////////
//
// CComPort:    SR Pro win32 Comm Interface Module
//
// Copyright � 2005  Dave Jacobs. All rights reserved.
//
////////////////////////////////////////////////////////////////

#pragma once
#include "ccs.h"

#define RX_BUFFER_SIZE 4096
// CComPort command target

class CComPort : public CObject
{
public:
					CComPort();
					~CComPort();

	virtual BOOL	Create(int nPort, DWORD nBaudRate);
	virtual BOOL	Destroy();
	virtual DWORD	GetRxData(LPBYTE pBuffer, DWORD dwBufferSize, BOOL bPurge = FALSE);
	virtual BOOL	TransmitData(LPBYTE pBuffer, DWORD dwCount);
	virtual BOOL	IsPortOpen(void);
	virtual BOOL	WaitForSync(DWORD dwTimeout);
	virtual void	SetSyncChar(BYTE SyncValue, int nSyncNeeded = 1);
	virtual void	ResetSync();
	int				ParseRecord(LPCTSTR lpszInput, CString* lpstrToken, int nItems);
	int				GetHighestPortNumber(void);
	void			IcomGetDeviceNameFromID(BYTE nID, CString & strOut);

protected:
	static unsigned int __stdcall StartReaderThread(LPVOID pUser);
	virtual void	ReaderThread(void);
	void			CalculatePortCount(void);

	HANDLE			m_hFile;
	HANDLE			m_hReaderThread;
	DCB				m_dcb;
	OVERLAPPED		m_OverlappedRx;
	OVERLAPPED		m_OverlappedTx;
	OVERLAPPED		m_OverlappedStatus;
	BOOL			m_bAbort;
	DWORD			m_dwStatus;
	HANDLE			m_hEventAbort;

	HANDLE			m_hEventSync;	// Triggered when enough sync chars arrive.
	int				m_nSyncCount;	// Counts sync characters received since last reset.
	BYTE			m_SyncChar;		// Receiver looks for this char to end receive mode.
	int				m_nSyncNeeded;	// Tells reader thread how many syncs to count.

//---------------------------
	CSection		m_csRXBuffer;	// Protects the buffer and count.
	DWORD			m_cRxCount;
	PBYTE			m_pRxBuffer;
//---------------------------

	int				m_nPorts;
	int				m_nHighestPortNumber;
public:
	void AbortSyncWait(void);
	void PurgeRxBuffer(void);
	void AbortIO(void);
};

