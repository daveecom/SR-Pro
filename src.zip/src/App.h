// App.h : main header file for the Scanrec Pro application
//
#pragma once

#include "AudioFilter.h"
#include "AudioRecorder.h"
#include "doc.h"
#include "mainview.h"

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "filenameserver.h"
#include "afxwin.h"
#include "comport.h"
#include "armadillo.h"
#include "scheduler.h"


// App:
// See App.cpp for the implementation of this class
//

class App : public CWinApp
{
public:
	App();
	virtual ~App();

public:


	Armadillo				m_Armadillo;

	Doc*					GetDoc();
	CMainView*				GetView();
	//CScheduleController*	GetScheduler();
	//void					AutoLoadSchedule();
	//void					AutoSaveSchedule();
	void					ShowConsole(bool bShow = TRUE);
	BOOL					IsConsoleEnabled(void);
	void					ToggleConsole(void);

protected:

	DECLARE_MESSAGE_MAP()

	virtual BOOL			InitInstance();
	virtual int				ExitInstance();

	afx_msg void			OnAppAbout();
	afx_msg void			OnUpdateButtonRecord(CCmdUI *pCmdUI);
	afx_msg void			OnUpdateButtonPause(CCmdUI *pCmdUI);
	afx_msg void			OnUpdateButtonVox(CCmdUI *pCmdUI);
//	afx_msg void			OnUpdateHelpRegistration(CCmdUI *pCmdUI);
	afx_msg void			OnUpdateTestConverttext(CCmdUI *pCmdUI);
	afx_msg void			OnTestConverttext();
	afx_msg void			OnUpdateHelpEnterregistration(CCmdUI *pCmdUI);
	afx_msg void			OnHelpEnterregistration();

	Doc*					m_pDoc;
	HWND					m_hConsole;
	BOOL					m_bShowConsole;
public:
	virtual BOOL OnDDECommand(LPTSTR lpszCommand);
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Overrides to eliminate the need to use the section names.
    UINT GetProfileInt(LPCTSTR lpszEntry, int nDefault);

    BOOL WriteProfileInt(LPCTSTR lpszEntry, int nValue);

    CString GetProfileString(LPCTSTR lpszEntry, LPCTSTR lpszDefault = NULL);

    BOOL WriteProfileString(LPCTSTR lpszEntry, LPCTSTR lpszValue);

    BOOL GetProfileBinary(LPCTSTR lpszEntry, LPBYTE* ppData, UINT* pBytes);

    BOOL WriteProfileBinary(LPCTSTR lpszEntry, LPBYTE pData, UINT nBytes);
};

extern App theApp;
