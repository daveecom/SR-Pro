#pragma once

class CAcmFilter : public CAudioFilter
{
public:
	CAcmFilter(CAudioRecorder* pParent);
	~CAcmFilter(void);

	virtual BOOL		SetFormatC(LPWAVEFORMATEX pWFC, BOOL bUseHQ);
	virtual BOOL		Connect(CAudioFilter* pFilter);

protected:
	virtual void		ProcessDataBuffer(RECBUFF* pRB);
	//virtual void		Transmit(RECBUFF * pRB);
	virtual	BOOL		OnNewFormat();	// Called automatically when the format is set.
	virtual BOOL		SetFormat(LPWAVEFORMATEX lpWF);	// Informs us of the current data format.
	virtual BOOL		StartStreaming();
	virtual BOOL		StopStreaming();
	virtual BOOL		OnWorkerFlushComplete(void); // Used here to flush the compressor.
	
	BOOL				InitBuffers(DWORD dwSize);
	void				DeleteBuffers(void);

	LPWAVEFORMATEX		m_pFormatC;		// Compression format
	HACMSTREAM			m_hStream;		// handle for compressing the audio

	ACMSTREAMHEADER		m_Header;		// Used for the conversion.
	DWORD				m_nBufferSizeIn;
	DWORD				m_nBufferSizeOut;
	CSection			m_csBuffers;	// Locks the whole group above

	BOOL				m_bCompressorHasData;	// The next packet to arrive is the first.
	BOOL				IsLastBuffer(void);
	BOOL				m_bHQ;			// Use HQ (CPU) Compression mode.
};

