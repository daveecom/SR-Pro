#include "stdafx.h"

static char	ZZZZ[256] = {"SQUELCH"};



extern PVOID ZZZZ_EndOfModule(void)
{
	PVOID	EndAddress;


	__asm
	{
		ZZZZ_EndLabel:	nop;

						mov		eax,ZZZZ_EndLabel;
						mov		EndAddress, eax;
	}

	return EndAddress;
}
