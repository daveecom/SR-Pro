// DlgEnterKey.cpp : implementation file
//

#include "stdafx.h"
#include "app.h"
#include "DlgEnterKey.h"


// CDlgEnterKey dialog

IMPLEMENT_DYNAMIC(CDlgEnterKey, CDialog)
CDlgEnterKey::CDlgEnterKey(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgEnterKey::IDD, pParent)
{
}

CDlgEnterKey::~CDlgEnterKey()
{
}

void CDlgEnterKey::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_NAME, m_Edit_Name);
	DDX_Control(pDX, IDC_EDIT_KEY, m_Edit_Key);
}


BEGIN_MESSAGE_MAP(CDlgEnterKey, CDialog)
END_MESSAGE_MAP()


// CDlgEnterKey message handlers

BOOL CDlgEnterKey::OnInitDialog()
{
	CDialog::OnInitDialog();

	CWnd*	pParent = GetParent();
	CRect	rect1;
	pParent->GetWindowRect(rect1);
	//SetWindowPos(&CWnd::wndTop, rect1.left, rect1.bottom, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);

	m_Edit_Name.Clear();
	m_Edit_Key.Clear();

	return TRUE;
}

void CDlgEnterKey::OnOK()
{
	char name[1024] = {0};
	char key[1024]	= {0};
	WCHAR w[1024]	= {0};
	CString	str;

	//#ifdef _PROTECTED

		m_Edit_Key.GetWindowText(str);

		#ifdef _UNICODE
			WideCharToMultiByte(CP_ACP, 0, str, str.GetLength(), key, sizeof key - 2, NULL, NULL);
		#else
			strncpy(key, str, sizeof key);
		#endif

		m_Edit_Name.GetWindowText(str);

		#ifdef _UNICODE
			WideCharToMultiByte(CP_ACP, 0, str, str.GetLength(), name, sizeof name - 2, NULL, NULL);
		#else
			strncpy(name, str, sizeof name);
		#endif

		if (APP->m_Armadillo.IsProtected())
		{
			BOOL rc = APP->m_Armadillo.InstallKey(name, key);
			TRACE(_T("InstallKey returned '%d'.\r\n"), rc);
			if (!rc)
			{	// Bad key / name
				Beep(800, 1000);
				Sleep(3000);	// Delay to try to slow down a brute force attack.
				__super::OnCancel();
			}
			else
			{	// Key and name were accepted
				__super::OnOK();
			}
		}
		else
		{	// Not protected
			__super::OnCancel();
		}

	//#endif

	__super::OnOK();
}
