#pragma once
#include "audiofilter.h"
#include "audiodelay.h"
#include "logfile.h"
#include "comport.h"

typedef enum _vox_state
{
	Gate_Closed	= 0,	// Sound is being blocked.
	Gate_Open,			// Sound is passing.
	Hang_Wait,			// After sound is quiet but before gate closes.
	Anticlip_Wait		// After hang time ends, before gate closes.
}	VOX_STATE;

class CVoxFilter :
	public CAudioFilter
{
public:
	CVoxFilter(CAudioRecorder* pParent);
	~CVoxFilter(void);

	void			SetVox(float Left, float Right);
	void			ForceGateOpen(bool bForceOpen);
	BOOL			IsGateOpen(void);
	void			ResetCounters(void);
	//ULONGLONG		GetStoredSampleCount(void);
	void			SetLogFile(CLogFileWriter* pLogFile);
	FILETIME		GetEventStart(void);
	//FILETIME		GetEventEnd(void);
	FILETIME		GetEventDuration(void);
	void			SetComPort(CComPort* pPort);
	virtual BOOL	StartStreaming();
	virtual BOOL	StopStreaming();
	virtual void	RolloverFile();		// handles file split via vox
	void			SetHangTimeMS(DWORD dwHangtime);
	void			SetRolloverMode(bool bEnable);
	void			SetRolloverOnce(void);
	BOOL			GetRolloverMode(void);
	void			SetVoxState(VOX_STATE State);
	void			StoreLogDataManualStop(void);
	void			WaitForRolloverSync(void);
	BOOL			IsForceGateOpen(void);

protected:
	FILETIME		GetStoredTimeFromRecordGate(void);
	ULONGLONG		GetStoredSampleCountFromRecordGate(void);
	virtual void	ProcessDataBuffer(RECBUFF* pRB);
	void			ProcessVoxBuffer(RECBUFF* pRB);
	void			ProcessVoxSample(const USAMPLE Sample, const DWORD SampleIndex, const RECBUFF* pRBIn);
	virtual	BOOL	OnNewFormat();		// Called automatically when the format is set.
	static void		__cdecl	StartLogThread(void * pThis);

	BOOL			m_bForceGateOpen;	// Override trigger and force the gate to be open.
	WORD			m_VoxValue_L;		// Vox lvl in 16 bit signed format. 0 - 32k
	WORD			m_VoxValue_R;		// Vox lvl in 16 bit signed format. 0 - 32k

	CAudioDelay		m_DelayAntiClip;	// AntiClip delay line

	DWORD			m_nAntiClipTimeMS;	// Anti clip Time (ms) Used to init delay line
	DWORD			m_cAntiClipTimer;	// Anti clip timer/counter. (samples)
	DWORD			m_nHangTimeMS;		// Hang time. (ms)
	DWORD			m_cHangTimer;		// Hang timer/counter. (samples)
	
	VOX_STATE		m_VoxState;			// Vox state.....duh..?

	UFT				m_tStart;			// Event start time.

	UFT				m_tBuffer;			// Time span of one buffer.

	double			m_fSamplesPerMS;	// Samples per millisecond

	ULONGLONG		m_nSamplesScanned;	// # samples evaluated
	ULONGLONG		m_nSamplesStored;	// # samples passed downstream.

	ULONGLONG		m_nStart;			// Relative Sample # at gate opening.
	ULONGLONG		m_nEnd;				// Relative Sample # at gate closing.
	ULONGLONG		m_nDuration;		// Duration of event (in samples).

	CLogFileWriter*	m_pLogFile;			// Access to the log file
	CComPort*		m_pPort;			// Access to the serial port.
	HANDLE			m_hThreadLogger;	// Logger thread
	void			TryToGetFreq(void);
	void			LoggerThread(void);

	ULONGLONG		GetFileOffset(void);
	ULONGLONG		m_nFileOffset;

	BOOL			m_bRolloverMode;
	BOOL			m_bRolloverOnce;
	HANDLE			m_hEventRolloverSync;	// Used to sync with rollover event.
	CSection		m_csRolloverSyncLock;	// Keeps the flakyness out of
											// rollover timing.
};
