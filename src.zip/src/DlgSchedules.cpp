// DlgSchedules.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include ".\propsheetsched.h"
#include ".\Scheduler.h"
#include ".\dlgschedules.h"
#include ".\app.h"


IMPLEMENT_DYNAMIC(CScheduleListBox, CListBox)
CScheduleListBox::CScheduleListBox()
{
}

CScheduleListBox::~CScheduleListBox()
{
}


BEGIN_MESSAGE_MAP(CScheduleListBox, CListBox)
END_MESSAGE_MAP()

// CDlgSchedules dialog

IMPLEMENT_DYNAMIC(CDlgSchedules, CDialog)
CDlgSchedules::CDlgSchedules(CWnd* pParent, CScheduleController* pController)
	: CDialog(CDlgSchedules::IDD, pParent)
{
	ASSERT(pParent		!= NULL);
	ASSERT(pController	!= NULL);

	m_pController = pController;
}

void CDlgSchedules::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_SCHEDULES, m_lbSchedList);
}


BEGIN_MESSAGE_MAP(CDlgSchedules, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_NEW, OnBnClickedButtonNew)
	ON_BN_CLICKED(IDC_BUTTON_EDIT, OnBnClickedButtonEdit)
	ON_BN_CLICKED(IDC_BUTTON_ENABLE, OnBnClickedButtonEnable)
	ON_BN_CLICKED(IDC_BUTTON_DISABLE, OnBnClickedButtonDisable)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnBnClickedButtonDelete)
//	ON_WM_LBUTTONDBLCLK()
	ON_LBN_DBLCLK(IDC_LIST_SCHEDULES, OnLbnDblclkListSchedules)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CDlgSchedules message handlers

BOOL CDlgSchedules::OnInitDialog()
{
	CWnd*					pParent = GetParent();
	CRect					rect1;

	CScheduleController*	pCont = DOC->GetScheduler();

	__super::OnInitDialog();

	m_ToolTip.Create(this);
	m_ToolTip.AddTool(GetDlgItem(IDC_LIST_SCHEDULES),	_T("List of existing schedules"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_NEW),		_T("Create a new schedule"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_EDIT),		_T("Chenge the selected schedule"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_DELETE),	_T("Delete the selected schedule"));
	m_ToolTip.AddTool(GetDlgItem(IDOK),					_T("Keep schedules"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_ENABLE),	_T("Enable the selected schedule"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_DISABLE),	_T("Disable the selected schedule"));

	pParent->GetWindowRect(rect1);
	//SetWindowPos(&CWnd::wndTop, rect1.left, rect1.bottom, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);

	// Make sure all entries in the list are current.
	//pCont->BringListUpToDate();

	RebuildListbox();

	m_lbSchedList.SetCurSel(-1);

	return TRUE;
}

void CDlgSchedules::RebuildListbox(void)
{
	int				i, count, result;
	SYSTEMTIME		tm;
	CScheduleItem*	pItem;
	CString			strBuild;	// Used to build the listbox text strings
	CString			strID, strName, strStart, strEnd;

	m_lbSchedList.ResetContent();
	count = m_pController->GetCount();

	for (i = 0; i < count; i++)
	{
		pItem = (CScheduleItem*) m_pController->GetSchedule(i);
		strID	= pItem->GetID();
		strName = pItem->GetName();
		FileTimeToSystemTime(&pItem->GetStart().ft, &tm);
		strStart.Format(_T("%02d/%02d/%02d %02d:%02d"), (tm.wYear % 100), tm.wMonth, tm.wDay, tm.wHour, tm.wMinute);
		strBuild.Format(_T("%s - %s"), strStart, strName);
		result = m_lbSchedList.AddString(strBuild);
		m_lbSchedList.SetItemDataPtr(result, pItem);
	}
}

void CDlgSchedules::OnBnClickedButtonNew()
{
	CScheduleItem		*pItem = NULL;
	CPropSheetSched		propSched(_T("New Schedule"), this);
	INT_PTR				result;
	BOOL				rc;

	result = propSched.DoModal();
	if (result == ID_WIZFINISH )
	{
		pItem = new CScheduleItem;
		ASSERT(pItem);	// Storage

		rc = pItem->CreateStartStop(propSched.GetScheduleName(),propSched.GetStartDateTime(),
			propSched.GetDuration(), propSched.GetRepeatParms(), GetSafeHwnd());
		ASSERT(rc);

		m_pController->AddAlarm(pItem);
	}

	RebuildListbox();

	DOC->SetModifiedFlag();
}

void CDlgSchedules::OnBnClickedButtonEdit()
{
	CScheduleItem*	pItem, *pDup;
	CPropSheetSched	prop(_T("Edit Schedule"), this);
	CString			str1, str2;
	int				index, j;
	INT_PTR			result;

	index = m_lbSchedList.GetCurSel();
	j = m_lbSchedList.GetCount();
	RebuildListbox();

	if (j == m_lbSchedList.GetCount())
	{
		if (index >= 0)
		{
			pItem = (CScheduleItem*) m_lbSchedList.GetItemData(index);
			ASSERT(pItem != NULL);

			pItem->AbortSchedule();

			// Copy stored schedule into workspace.
			prop.SetSchedule(pItem);

			result = prop.DoModal();
			if (result == ID_WIZFINISH)
			{	// Editting has finished.
				prop.GetSchedule(pItem);	// Place the changed schedule back into the list.

				pItem->ReCreateStartStop();

				if (m_pController->IsOverlapped(pItem, &pDup))
				{
					pItem->EnableAlarm(FALSE);
					str1.Format(_T("This new schedule has a conflict with an existing schedule:"));
					str2.Format(_T("\nConflicting item name = '%s'."), pDup->GetName());
					str1 += str2;
					str1 += _T("\nNew schedule has been disabled.");
					AfxMessageBox(str1);
				}

				DOC->SetModifiedFlag();

				RebuildListbox();
			}
		}

		DOC->SetModifiedFlag();
		m_lbSchedList.SetCurSel(index);
	}
}

void CScheduleListBox::DrawItem(LPDRAWITEMSTRUCT lpDIS)
{
	BOOL			rc;
	CString			str;
	CScheduleItem*	pItem;
	CBrush			brushHatch1;
	CBrush			brushHatch2;
	CBrush			brushSelected;

	if (lpDIS->itemID < (UINT) GetCount())	// If there is valid text
	{
		brushHatch1.CreateHatchBrush(HS_FDIAGONAL, RGB(255, 000, 000));
		brushHatch2.CreateHatchBrush(HS_FDIAGONAL, RGB(128, 128, 128));
		brushSelected.CreateSolidBrush(RGB(128, 128, 128));

		SaveDC(lpDIS->hDC);
		SetBkMode(lpDIS->hDC, TRANSPARENT);

		GetText((int) lpDIS->itemID, str);

		pItem = (CScheduleItem*) lpDIS->itemData;

		if (lpDIS->itemState & ODS_SELECTED)
		{	// Selected & Enabled
			if (pItem->IsEnabled())
			{	// Enabled Color
				SetTextColor(lpDIS->hDC, RGB(255, 255, 255));
				FillRect(lpDIS->hDC, &lpDIS->rcItem, (HBRUSH) brushSelected.GetSafeHandle());
			}
			else
			{	// Selected & Disabled
				SetTextColor(lpDIS->hDC, RGB(000, 000, 000));
				FillRect(lpDIS->hDC, &lpDIS->rcItem, (HBRUSH) brushSelected.GetSafeHandle());
			}
		}
		else
		{	// Not selected & Enabled
			if (pItem->IsEnabled())
			{	// Enabled Color
				SetTextColor(lpDIS->hDC, RGB(000, 000, 000));
				FillRect(lpDIS->hDC, &lpDIS->rcItem, WHITE_BRUSH);
			}
			else
			{	// Not selected & Disabled
				SetTextColor(lpDIS->hDC, RGB(000, 000, 000));
				FillRect(lpDIS->hDC, &lpDIS->rcItem, (HBRUSH) brushHatch1.GetSafeHandle());
			}
		}

		switch (lpDIS->itemAction)
		{
			case ODA_DRAWENTIRE:

				rc = DrawText(lpDIS->hDC, str, str.GetLength(), &lpDIS->rcItem, DT_LEFT);

				break;

			case ODA_FOCUS:

				rc = DrawText(lpDIS->hDC, str, str.GetLength(), &lpDIS->rcItem, DT_LEFT);
				rc = DrawFocusRect(lpDIS->hDC, &lpDIS->rcItem);

				break;

			case ODA_SELECT:

				rc = DrawText(lpDIS->hDC, str, str.GetLength(), &lpDIS->rcItem, DT_LEFT);

				break;
		}

		RestoreDC(lpDIS->hDC, -1);
	}
}

void CScheduleListBox::PreSubclassWindow()
{
	DWORD	dwExStyle;

	dwExStyle = GetWindowLong(this->GetSafeHwnd(), GWL_EXSTYLE);
	//dwExStyle |= LBS_EXTENDEDSEL;
	//SetWindowLong(this->GetSafeHwnd(), GWL_EXSTYLE, dwExStyle);

	__super::PreSubclassWindow();
}

void CDlgSchedules::OnBnClickedButtonEnable()
{
	CScheduleItem*	pItem;
	int				index, j;

	index = m_lbSchedList.GetCurSel();
	j = m_lbSchedList.GetCount();
	RebuildListbox();

	if (j == m_lbSchedList.GetCount())
	{
		if (index >= 0)
		{
			pItem = (CScheduleItem*) m_lbSchedList.GetItemData(index);
			ASSERT(pItem != NULL);

			m_pController->EnableAlarm(index, TRUE);

			DOC->SetModifiedFlag();

			m_lbSchedList.Invalidate(FALSE);
		}

		m_lbSchedList.SetCurSel(index);
		DOC->SetModifiedFlag();
	}

}

void CDlgSchedules::OnBnClickedButtonDisable()
{
	CScheduleItem*	pItem;
	int				index, j;

	index = m_lbSchedList.GetCurSel();
	j = m_lbSchedList.GetCount();
	RebuildListbox();

	if (j == m_lbSchedList.GetCount())
	{
		if (index >= 0)
		{
			pItem = (CScheduleItem*) m_lbSchedList.GetItemData(index);
			ASSERT(pItem != NULL);

			pItem->EnableAlarm(FALSE);

			DOC->SetModifiedFlag();

			m_lbSchedList.Invalidate(FALSE);
		}

		m_lbSchedList.SetCurSel(index);
		DOC->SetModifiedFlag();
	}
}

void CDlgSchedules::OnBnClickedButtonDelete()
{
	CScheduleItem*	pItem;
	int				index, j;
	INT_PTR			result;

	index = m_lbSchedList.GetCurSel();
	j = m_lbSchedList.GetCount();
	RebuildListbox();

	if (j == m_lbSchedList.GetCount())
	{
		if (index >= 0)
		{
			result = AfxMessageBox(_T("Are you sure you want to delete this schedule?"), MB_YESNO);
			if (result == IDYES)
			{	// Yes - delete it
				pItem = (CScheduleItem*) m_lbSchedList.GetItemData(index);
				ASSERT(pItem != NULL);

				ASSERT(pItem->GetContainer() != NULL);
				pItem->GetContainer()->DeleteAlarm(index);

				RebuildListbox();
				m_lbSchedList.SetCurSel(min(index, m_lbSchedList.GetCount() - 1));
			}
		}

		DOC->SetModifiedFlag();
	}
}

void CDlgSchedules::OnLbnDblclkListSchedules()
{
	OnBnClickedButtonEdit();
}


BOOL CDlgSchedules::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class

	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	return CDialog::PreTranslateMessage(pMsg);
}
