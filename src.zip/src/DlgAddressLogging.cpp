// DlgAddressLogging.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "doc.h"
#include "DlgAddressLogging.h"
#include ".\dlgaddresslogging.h"

DWORD	dwBaudTbl[] = {CBR_110, CBR_300, CBR_1200, CBR_2400, CBR_4800, CBR_9600, CBR_19200};

IMPLEMENT_DYNAMIC(CDlgFrequencyLogging, CDialog)


CDlgFrequencyLogging::CDlgFrequencyLogging(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgFrequencyLogging::IDD, pParent)
	, m_pDoc(NULL)
	, m_bDirty(FALSE)
{
}

CDlgFrequencyLogging::~CDlgFrequencyLogging()
{
}

void CDlgFrequencyLogging::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_COMMPORT,			m_Edit_Port);
	DDX_Control(pDX, IDC_SPIN_COMMPORT,			m_Spin_Port);
	DDX_Control(pDX, IDC_COMBO_BAUD,			m_Combo_Baud);
	DDX_Control(pDX, IDC_CHECK_ENABLE,			m_Check_Enable);
	DDX_Control(pDX, IDC_EDIT_ICOMADDR,			m_Edit_IcomAddr);
	DDX_Control(pDX, IDC_SPIN_ICOMADDR,			m_Spin_IcomAddr);
	DDX_Control(pDX, IDC_EDIT_ICOMADDRNAME,		m_Edit_IcomType);
	DDX_Control(pDX, IDC_EDIT_TESTADDRESS,		m_Edit_TestAddress);
	DDX_Control(pDX, IDC_EDIT_TESTSMETER,		m_Edit_TestSMeter);
}


BEGIN_MESSAGE_MAP(CDlgFrequencyLogging, CDialog)
	ON_WM_VSCROLL()
	ON_CBN_SELCHANGE(IDC_COMBO_BAUD, OnCbnSelchangeComboBaud)
	ON_BN_CLICKED(IDC_CHECK_ENABLE, OnBnClickedCheckEnable)
	ON_BN_CLICKED(IDC_RADIO_RADIOTYPE_ICOM, OnBnClickedRadioRadiotypeIcom)
	ON_BN_CLICKED(IDC_RADIO_RADIOTYPE_AOR, OnBnClickedRadioRadiotypeAor)
	ON_BN_CLICKED(IDC_RADIO_RADIOTYPE_UNIDEN, OnBnClickedRadioRadiotypeUniden)
	ON_BN_CLICKED(IDC_RADIO_RADIOTYPE_RS, OnBnClickedRadioRadiotypeRs)
	ON_BN_CLICKED(IDC_BUTTON_TESTRECEIVER, OnBnClickedButtonTestreceiver)
END_MESSAGE_MAP()


// CDlgFrequencyLogging message handlers

BOOL CDlgFrequencyLogging::OnInitDialog()
{
	CDialog::OnInitDialog();

	ASSERT(m_pDoc != NULL);

	m_ToolTip.Create(this);

	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_COMMPORT),			_T("Serial port #"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_COMMPORT),			_T("Serial port #"));
	m_ToolTip.AddTool(GetDlgItem(IDC_COMBO_BAUD),				_T("Baud rate"));
	m_ToolTip.AddTool(GetDlgItem(IDC_CHECK_ENABLE),				_T("Activate serial interface"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_RADIOTYPE_ICOM),		_T("Select Icom radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_RADIOTYPE_AOR),		_T("Select AOR radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_RADIO_RADIOTYPE_UNIDEN),	_T("Select Uniden radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_ICOMADDR),			_T("Choose device ID for Icom radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_SPIN_ICOMADDR),			_T("Choose device ID for Icom radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_ICOMADDRNAME),		_T("Shows model name of icom based on device ID"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_TESTADDRESS),			_T("Shows the frequency from the radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_EDIT_TESTSMETER),			_T("Shows the S-Meter value from the radio"));
	m_ToolTip.AddTool(GetDlgItem(IDC_BUTTON_TESTRECEIVER),		_T("PRess this button to test the serial communication to the radio"));
	m_ToolTip.AddTool(GetDlgItem(IDOK),							_T("Keep radio settings"));
	m_ToolTip.AddTool(GetDlgItem(IDCANCEL),						_T("Exit without keeping the settings"));

	CWnd*	pParent = GetParent();
	CRect	rect1;
	pParent->GetWindowRect(rect1);
	//SetWindowPos(&CWnd::wndTop, rect1.left, rect1.bottom, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);

	m_Spin_IcomAddr.SetRange(0, 255);
	m_Spin_IcomAddr.SetPos(m_pDoc->m_IcomAddr);

	m_Spin_Port.SetRange(1, 16);
	m_Spin_Port.SetPos(m_pDoc->m_nPort);

	for (int i = 0; i < sizeof dwBaudTbl / sizeof(DWORD); i++)
	{
		if (dwBaudTbl[i] == m_pDoc->m_dwBaudRate)
		{
			m_Combo_Baud.SetCurSel(i);
			break;
		}
	}

	m_Check_Enable.SetCheck(m_pDoc->m_bRadioEnable ? BST_CHECKED:BST_UNCHECKED);

	switch (m_pDoc->m_eRadioType)
	{
		case aor:
			CheckDlgButton(IDC_RADIO_RADIOTYPE_AOR, BST_CHECKED);
			break;

		case icom:
			CheckDlgButton(IDC_RADIO_RADIOTYPE_ICOM, BST_CHECKED);
			break;

		case rs:
			CheckDlgButton(IDC_RADIO_RADIOTYPE_RS, BST_CHECKED);
			break;

		case uniden:
			CheckDlgButton(IDC_RADIO_RADIOTYPE_UNIDEN, BST_CHECKED);
			break;
	}

	Update();
	return TRUE;
}

void CDlgFrequencyLogging::Update(void)
{
	CString str;
	int	i;

	i = LOBYTE(m_Spin_IcomAddr.GetPos());
	str.Format(_T("%02X"), i);
	m_Edit_IcomAddr.SetWindowText(str);
	//CComPortIcom::IcomGetDeviceNameFromID(i, str);
	str = _T("To Do...");
	m_Edit_IcomType.SetWindowText(str);

	i = LOBYTE(m_Spin_Port.GetPos());
	str.Format(_T("COM%d"), i);
	m_Edit_Port.SetWindowText(str);

	GetDlgItem(IDC_BUTTON_TESTRECEIVER)->EnableWindow(m_pDoc->m_PortIcom.IsPortOpen());
}

void CDlgFrequencyLogging::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	Update();
	m_bDirty = TRUE;
}

void CDlgFrequencyLogging::OnCbnSelchangeComboBaud()
{
	m_bDirty = TRUE;
}

void CDlgFrequencyLogging::OnBnClickedCheckEnable()
{
	m_bDirty = TRUE;

	if (m_Check_Enable.GetCheck() == BST_CHECKED)
	{
		if (m_pDoc->m_PortIcom.IsPortOpen())
			m_pDoc->m_PortIcom.Destroy();

		m_pDoc->m_PortIcom.Create(LOBYTE(m_Spin_Port.GetPos()),
			dwBaudTbl[m_Combo_Baud.GetCurSel()],
			LOBYTE(m_Spin_IcomAddr.GetPos()) );

		m_pDoc->m_bRadioEnable = TRUE;
	}
	else
	{
		m_pDoc->m_PortIcom.Destroy();

		m_pDoc->m_bRadioEnable = FALSE;
	}

	Update();
}

void CDlgFrequencyLogging::OnBnClickedRadioRadiotypeIcom()
{
	m_bDirty = TRUE;
}

void CDlgFrequencyLogging::OnBnClickedRadioRadiotypeAor()
{
	m_bDirty = TRUE;
}

void CDlgFrequencyLogging::OnBnClickedRadioRadiotypeUniden()
{
	m_bDirty = TRUE;
}

void CDlgFrequencyLogging::OnBnClickedRadioRadiotypeRs()
{
	m_bDirty = TRUE;
}

void CDlgFrequencyLogging::OnOK()
{
	Doc* doc = m_pDoc;

	if (m_bDirty)
	{
		doc->m_nPort		= LOBYTE(m_Spin_Port.GetPos());
		doc->m_dwBaudRate	= dwBaudTbl[m_Combo_Baud.GetCurSel()];
		doc->m_bRadioEnable	= (m_Check_Enable.GetCheck() == BST_CHECKED);

		if (IsDlgButtonChecked(IDC_RADIO_RADIOTYPE_AOR))	doc->m_eRadioType = aor;
		if (IsDlgButtonChecked(IDC_RADIO_RADIOTYPE_ICOM))	doc->m_eRadioType = icom;
		if (IsDlgButtonChecked(IDC_RADIO_RADIOTYPE_RS))		doc->m_eRadioType = rs;
		if (IsDlgButtonChecked(IDC_RADIO_RADIOTYPE_UNIDEN))	doc->m_eRadioType = uniden;

		doc->m_IcomAddr	= LOBYTE(m_Spin_IcomAddr.GetPos());
		m_bDirty = FALSE;

		doc->SetModifiedFlag();
	}

	CDialog::OnOK();
}

// Try to get the current displayed frequency from the receiver.
void CDlgFrequencyLogging::OnBnClickedButtonTestreceiver()
{
	BOOL	rc;
	CString str;

	rc = m_pDoc->m_PortIcom.GetFrequency(str);
	m_Edit_TestAddress.SetWindowText(str);
}

BOOL CDlgFrequencyLogging::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_LBUTTONDOWN || pMsg->message == WM_LBUTTONUP || pMsg->message == WM_MOUSEMOVE)
	{
		m_ToolTip.RelayEvent(pMsg);
	}

	return CDialog::PreTranslateMessage(pMsg);
}
