// DlgAbout.cpp : implementation file
//

#include "stdafx.h"
#include "DlgAbout.h"


// CDlgAbout dialog

IMPLEMENT_DYNCREATE(CDlgAbout, CDHtmlDialog)

CDlgAbout::CDlgAbout(CWnd* pParent /*=NULL*/)
	: CDHtmlDialog(CDlgAbout::IDD, CDlgAbout::IDH, pParent)
{
}

CDlgAbout::~CDlgAbout()
{
}

void CDlgAbout::DoDataExchange(CDataExchange* pDX)
{
	CDHtmlDialog::DoDataExchange(pDX);
}

BOOL CDlgAbout::OnInitDialog()
{
	CDHtmlDialog::OnInitDialog();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

BEGIN_MESSAGE_MAP(CDlgAbout, CDHtmlDialog)
END_MESSAGE_MAP()

BEGIN_DHTML_EVENT_MAP(CDlgAbout)
END_DHTML_EVENT_MAP()



// CDlgAbout message handlers

