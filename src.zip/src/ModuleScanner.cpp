#include "StdAfx.h"
#include ".\modulescanner.h"
#include <winnt.h>

CModuleScanner::CModuleScanner(void)
{
	TCHAR	szModulePath[MAX_PATH + 10];
	GetModuleFileName(NULL, szModulePath, (sizeof szModulePath) / sizeof(TCHAR));

	m_strModulePath = szModulePath;
}

CModuleScanner::~CModuleScanner(void)
{
}

typedef union
{
	long	l;
	DWORD	dw;
	BYTE	bt[4];
	SHORT	sht[2];
} uDW;

DWORD CModuleScanner::CalculateModuleChecksum(void)
{
	static	DWORD				dwStatic = 0x00000000;
	DWORD						nChecksum;
	DWORD						nChecksumIntel;	// Byte order reversed
	DWORD						nChecksumFromHeader;
	uDW							uChecksum;	// For reversing byte order.
	BY_HANDLE_FILE_INFORMATION	fileInfo = {0};
	IMAGE_NT_HEADERS			*pHeader;
	BOOL						rc;
	ULONGLONG					fileSize;
	PVOID						pBuffer;
	#define						BufferSize (4096)
	DWORD						dwActual;
	BOOL						bEof;
	DWORD						dwStart, dwEnd, dwElapsed;

	dwStart = GetTickCount();

	ASSERT(!m_strModulePath.IsEmpty());

	m_hFile	= NULL;
	m_hFile	= CreateFile(m_strModulePath, GENERIC_READ, FILE_SHARE_READ,
		NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	ASSERT(m_hFile != NULL);

	rc = GetFileInformationByHandle(m_hFile, &fileInfo);
	ASSERT(rc);

	fileSize	= ((ULONGLONG) fileInfo.nFileSizeHigh) << 32;
	fileSize	+= fileInfo.nFileSizeLow;

	if (m_hFile != NULL)
	{
		nChecksum = 0;

		pBuffer	= new BYTE[BufferSize];

		// Loop for each file buffer

		BOOL	bFirst = TRUE;
		for (bEof = FALSE; !bEof;)
		{
			ZeroMemory(pBuffer, BufferSize);
			rc = ReadFile(m_hFile, pBuffer, BufferSize, &dwActual, NULL);
			ASSERT(rc);
			//Beep(10000,1);

			if (dwActual == 0) bEof = TRUE;

			if (dwActual > 0)
			{
				int	i;

				if (bFirst)
				{
					bFirst = FALSE;
					pHeader = (IMAGE_NT_HEADERS*) pBuffer;
					nChecksumFromHeader = pHeader->OptionalHeader.CheckSum;
				}

				for (i = 0; i < (BufferSize / 4); i++)
				{
					nChecksum += *(((LPDWORD) pBuffer)+i);
				}
			}
		}	// for (bEof = FALSE; !bEof;)

		uChecksum.l	= -((long) nChecksum);
		nChecksumIntel	= uChecksum.bt[3] + (uChecksum.bt[2] << 8) + (uChecksum.bt[1] << 16) + (uChecksum.bt[0] << 24);

		delete [] pBuffer;
		pBuffer = NULL;
	}


	CloseHandle(m_hFile);
	m_hFile	= NULL;

	dwEnd = GetTickCount();
	dwElapsed = dwEnd - dwStart;

	TRACE(_T("**** Checksum scan took %d ms. ****\r\n") \
		_T("**** File size is %d bytes. ****\r\n") \
		_T("**** File checksum = %08X. My scan was %08X, (intel: %08X).\r\n"),
		(DWORD) dwElapsed, (DWORD) fileSize, nChecksumFromHeader, nChecksum, nChecksumIntel);

	return nChecksum;
}
