#pragma once

#include "resource.h"
#include "channelfilter.h"
#include <afxwin.h>

// CDlgChannel dialog

class CDlgChannel : public CDialog
{
	DECLARE_DYNAMIC(CDlgChannel)

public:
	CDlgChannel(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgChannel();

// Dialog Data
	enum { IDD = IDD_DIALOG_CHANNELCVT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	int m_Radio_Mode;
public:
	virtual BOOL OnInitDialog();
protected:
	CButton m_Check_MuteCh1;
	CButton m_Check_MuteCh2;
	virtual void OnOK();
	void Update(void);
	CHANNEL_PARMS m_ChannelParms;
public:
	CHANNEL_PARMS GetChannelParms(void);
	void SetChannelParms(CHANNEL_PARMS Parms);
protected:
	LPWAVEFORMATEX m_lpwfCapture;

	CToolTipCtrl	m_ToolTip;
public:
	void SetWFCap(LPWAVEFORMATEX lpWFIn);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	CStatic m_Static_Diagram;
	CBitmap	m_BM_Channel;
public:
	afx_msg void OnBnClickedRadioMode();
	afx_msg void OnBnClickedCheckMute();
};
