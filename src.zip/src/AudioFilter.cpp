#include "StdAfx.h"
#include <process.h>
#include "audiorecorder.h"
#include "audiofilter.h"
#include ".\audiofilter.h"
#include "app.h"	// To access console

IMPLEMENT_DYNAMIC(CAudioFilter, CObject)

CAudioFilter::CAudioFilter(CAudioRecorder* pParent)
: m_nRBAllocCount(0)
, m_hThread(NULL)
, m_pNextFilter(NULL)
, m_pFormat(NULL)
, m_pOutputBuffer(NULL)
, m_fTimePerBuffer(.075)
, m_dwMaxAllocCount(500)
, m_strObjectName(_T("CAudioFilter"))
, m_timeMeasured(0)
, m_timePerBuffer(0)
, m_dwDroppedBuffers(0)
, m_bPaused(FALSE)
{
	unsigned int threadid;

	TF;

	m_pParent = pParent;

	{
		CCS ccs(&m_csInfo);

		ZeroMemory(&m_scanInfo, sizeof(SCAN_INFO));
	}

	m_hEventFlushSync			= CreateEvent(NULL, TRUE, FALSE, NULL);
	m_hEventWakeWorker			= CreateEvent(NULL, FALSE, FALSE, NULL);
	m_hEventSyncBuffersReturned	= CreateEvent(NULL, FALSE, FALSE, NULL);

	m_hThread = (HANDLE) _beginthreadex(0, 0, WorkerProc, this, 0, &threadid);

	SetFilterState(Ready);
}

CAudioFilter::~CAudioFilter(void)
{
	TF;

	//Flush();

	Shutdown();

	CloseHandle(m_hEventWakeWorker);
	CloseHandle(m_hEventFlushSync);
	CloseHandle(m_hEventSyncBuffersReturned);

	delete m_pFormat;
}

int CAudioFilter::GetBitsPerSample()
{
	ASSERT(m_pFormat != NULL);
	if (m_pFormat == NULL) return 0;
	return ((m_pFormat->nBlockAlign / m_pFormat->nChannels) == 1) ? 8 : 16;
}

BOOL CAudioFilter::IsStereo()
{
	ASSERT(m_pFormat != NULL);
	if (m_pFormat == NULL) return FALSE;
	return m_pFormat->nChannels == 2;
}

BOOL CAudioFilter::Is8Bit()
{
	ASSERT(m_pFormat != NULL);
	if (m_pFormat == NULL) return FALSE;
	return m_pFormat->wBitsPerSample == 8;
}

unsigned int CAudioFilter::WorkerProc(void * arg)
{
	CAudioFilter*	pThis = (CAudioFilter*) arg;

	pThis->WorkerProc();

	return 0;
}

void CAudioFilter::WorkerProc()
{
	//TF;

	RECBUFF*		pRB;
	DWORD			dwTimeStart, dwTimeEnd;
	DWORD			dwSamplesPerBuffer;
	double			fTimePerSample;
	BOOL			bAbort;

	// Loop until shutdown.
	for (bAbort = FALSE;!bAbort;)
	{
		if (OnPreQueueScan())
		{
			// Loop until the work queue is empty.
			for (;;)
			{
				pRB = NULL;

				{	///////////////// LOCKED //////////////
					CCS Lock(&m_csQueue);

					if (m_Queue.GetCount() > 0)
					{
						pRB = m_Queue.RemoveTail();
						ASSERT(pRB != NULL);	// Must not be locked properly.
					}
				}	///////////////// LOCKED //////////////

				if (pRB != NULL)
				{
					// Calculate the time / buffer based on the sample rate.
					fTimePerSample = 1000.0 / m_pFormat->nSamplesPerSec;
					dwSamplesPerBuffer = pRB->wavehdr.dwBytesRecorded / m_pFormat->nBlockAlign;
					m_timePerBuffer = ((DWORD) ((double)fTimePerSample * (double)dwSamplesPerBuffer));
					dwTimeStart = GetTickCount();

					ProcessDataBuffer(pRB);		// ProcessDataBuffer will own this buffer from now on.

					dwTimeEnd = GetTickCount();
					m_timeMeasured = dwTimeEnd - dwTimeStart;
				}


				{	///////////////// LOCKED //////////////
					CCS Lock(&m_csQueue);
					CCS Lock2(&m_csState);

					if (m_Queue.GetCount() == 0)
					{	// Work queue is now empty.
						//TRACE(_T("\\/\\/\\/\\/%s::WorkerProc() Work Queue is now empty.\r\n"), GetObjectName());

						if (m_State == Flushing)
						{
							if (OnWorkerFlushComplete())	// Dispatch callback fcn.
							{
								SetEvent(m_hEventFlushSync);
							}
						}

						break;	// ... out of loop since queue is empty now.
					}
				}	///////////////// LOCKED //////////////

			}	// Loop until the work queue is empty.
		}	// 	if (OnPreQueueScan())

		OnPostQueueScan();

		// Wait here until we receive an attention signal.
		if (m_State != ShuttingDown)
		{
			WaitForSingleObject(m_hEventWakeWorker, INFINITE);
		}
		else
			bAbort = TRUE;

	}	// for (bAbort = FALSE;!bAbort;)

	// Must be shutting down if here.
	TRACE(_T("%s::WorkerProc() Shutdown Occurred.\r\n"), GetObjectName());
}

// This is what this filter is all about. The buffer is processed here and then passed downstream
// to the next stage by a call to Transmit().
void CAudioFilter::ProcessDataBuffer(RECBUFF* pRB)
{
	BOOL	bForward;	// Pass the buffer to the next stage if set.

	//Beep(10000,10);

	// Scan the data here and update the scan info.
	ScanTheBuffer(&pRB->wavehdr, m_pFormat);

	bForward = OnPreForward(pRB);	// Ask for permission to forward. (default is yes).

	if (bForward)
	{
		Transmit(pRB);
	}
	else	// next stage is not connected or forwarding not wanted.
	{
		FreeRecbuff(pRB);
	}
}

// Called after ProcessDataBuffer before the buffer is sent to the next stage.
// Return TRUE to forward the buffer to the next stage. False prevents forwarding.
BOOL CAudioFilter::OnPreForward(RECBUFF* pRB)
{
	return TRUE;	// Default implementation: forward all processed buffers.
}

// Given a buffer of audio data, enqueue the buffer onto the input queue or
// make a copy of the buffer and enqueue the local copy, depending on the caller's
// wishes.
//
// The bGive flag tells Receive to own this buffer and it has to eventually be returned
// to the calling filter's allocator. Therefore, the caller can not access the buffer after
// calling receive unless the bGive flag is FALSE. bGive=TRUE means buffer now off limits
// to the caller.
//
// Return TRUE to tell the caller that the data was accepted. FALSE means the data
// was not accepted into this stage. Buffer is still owned by the caller filter if FALSE returned.
BOOL CAudioFilter::Receive(RECBUFF * pRB, BOOL bGive)
{
	CString str;
	RECBUFF* pNewRB;

	ASSERT(pRB != NULL);
	ASSERT(pRB->dataSize == pRB->wavehdr.dwBufferLength);

	if (IsPaused())
	{
		if (bGive) FreeRecbuff(pRB);	// Throw away the incoming packet. We're manually paused.
		return TRUE;					// Caller believes we accepted this packet.
	}

	if (!IsFormatSet())
	{
		ASSERT(0);		// Bug. Shouldn't have sent buffer until format is set.
		return FALSE;	// Can't accept this buffer. Sorry.
	}

	{
		CCS	lock(&m_csQueue);
		CCS Lock2(&m_csState);

		if (m_State == Flushing || m_State == ShuttingDown)
		{
			return FALSE;
		}

		if (bGive)
		{	// This incoming buffer belongs to us now.
			m_Queue.AddHead(pRB);	// Add caller's buffer into our work queue.
			SetEvent(m_hEventWakeWorker);

			return TRUE;	// We own this buffer from now on, until it's recycled.
		}
		else
		{	// Make a copy of the caller's buffer and enqueue it.

			ASSERT(pRB->dataSize == pRB->wavehdr.dwBufferLength);

			pNewRB = AllocRecbuff(pRB->dataSize); // Allocate another new buffer.
			if (pNewRB == NULL)
			{
				TRACE(_T("To many buffers have been allocated by: %s().\r\n"), __TFUNCTION__);
				m_pParent->Dump();

				ASSERT(0);

				return FALSE;
			}
			else
			{
				CopyMemory(&pNewRB->databuffer, &pRB->databuffer, pRB->wavehdr.dwBytesRecorded); // Copy data
				pNewRB->ftTime	= pRB->ftTime;
				pNewRB->nSample	= pRB->nSample;
				pNewRB->wavehdr.dwBytesRecorded = pRB->wavehdr.dwBytesRecorded;

				// Add the copy to our queue
				m_Queue.AddHead(pNewRB);
				SetEvent(m_hEventWakeWorker);

				return TRUE;	// Caller still owns his buffer.
			}
		}
	}

	return TRUE;
}

BOOL CAudioFilter::SetFormat(LPWAVEFORMATEX lpWF)
{
	BOOL	rc = TRUE;

	ASSERT(lpWF != NULL);

	if (m_pFormat != NULL) delete [] m_pFormat;
	m_pFormat = (LPWAVEFORMATEX) new BYTE[sizeof(WAVEFORMATEX) + lpWF->cbSize];
	ASSERT(m_pFormat != NULL);
	CopyMemory(m_pFormat, lpWF, sizeof(WAVEFORMATEX) + lpWF->cbSize);

	// Return all recycled buffers.
	PurgeBuffers();

	BOOL bRipple = OnNewFormat();
	if (bRipple)
	{
		//CCS Lock(&m_csNextFilter);

		// Ripple the new format throughout the entire audio chain.
		if (GetNextFilter() != NULL) rc = GetNextFilter()->SetFormat(lpWF);
	}

	return rc;
}

// Called automatically when the format is set. Return FALSE to prevent automatic
// ripple to next stage.
BOOL CAudioFilter::OnNewFormat()
{
	return TRUE;	// Default is to ripple our format to the next filter downstream.
}

void CAudioFilter::Shutdown()
{
	TF;

	ASSERT(m_State != ShuttingDown);	// Shutting down already? why?

	SetFilterState(ShuttingDown);
	SetEvent(m_hEventWakeWorker);

	// Worker knows we're shutting down. Wait for worker to close.
	WaitForSingleObject(m_hThread, INFINITE);
	CloseHandle(m_hThread);
	m_hThread = NULL;

	// Worker thread is gone.

	PurgeBuffers();	// Return our enqueued buffers to their allocators.

	// Wait for buffers to be returned from other filters.

	if (m_nRBAllocCount > 0) WaitForSingleObject(m_hEventSyncBuffersReturned, INFINITE);

	ASSERT(m_nRBAllocCount	== 0);
	ASSERT(m_Queue.IsEmpty());
}

// Flush tells this object to stop accepting new input,
// process and send all queued content then tell
// the next stage to flush. Block until all downstream
// stages finish their flush operation(s).
void CAudioFilter::Flush()
{
	//TRACE(_T("++++++++ %s::Flush() Entered.\r\n"), GetObjectName());
	
	if (m_State == Flushing)
	{
		TRACE(_T("******** %s::Flush() Already in Flushing State.\r\n"), GetObjectName());
		m_pParent->Dump();

		//DebugBreak();	// Ummmm.... should we already be in flush????
						// I don't think so...
		//Beep(9000,1);
	}

	{
		CCS	Lock(&m_csQueue);
		CCS	Lock2(&m_csState);

		//SetFilterState(Flushing);
		m_State = Flushing;				// Can't call SetFilterState because of the lock.
		ResetEvent(m_hEventFlushSync);	// Clear before we kick the worker.
		SetEvent(m_hEventWakeWorker);	// Wake up worker to process remaining data.
	}

	WaitForSingleObject(m_hEventFlushSync, INFINITE);	// Wait for worker to exhaust buffers.

	ASSERT(m_State == Flushing);	// Make sure state didn't change unexpectedly

	//TRACE(_T("/\\/\\/\\/\\ %s::Flush() Synced.\r\n"), GetObjectName());

	// Push any residual output now.
	FlushOutputBuffer();

	{
		//CCS Lock(&m_csNextFilter);

		if (GetNextFilter() != NULL)
		{
			GetNextFilter()->Flush();		// Block here until all downstream work is done.
		}
	}
	//TRACE(_T("+-+-+-+- %s::Flush() Exit.\r\n"), GetObjectName());
}

// Start data flow back up after a flush. Must be the same thread that calls Flush.
// The last filter in the chain is informed first then it propagates back upstream to the
// object that was called by the main thread in reverse-data-order.
void CAudioFilter::EndFlush()
{
	//TRACE(_T("-------- %s::EndFlush() Entered.\r\n"), GetObjectName());

	if (m_State == Flushing)
	{
		if (GetNextFilter() != NULL)
			GetNextFilter()->EndFlush();

		SetFilterState(Ready);
	}
}

BOOL CAudioFilter::IsFormatSet()
{
	if (m_pFormat == NULL)					return FALSE;
	if (m_pFormat->nChannels == 0)			return FALSE;
	if (m_pFormat->nBlockAlign == 0)		return FALSE;
	if (m_pFormat->nAvgBytesPerSec == 0)	return FALSE;
	if (m_pFormat->nSamplesPerSec == 0)		return FALSE;

	return TRUE;
}

RECBUFF* CAudioFilter::AllocRecbuff(DWORD dwDataSize)
{
	RECBUFF*	pNewRB		= NULL;
	DWORD		bps;						// bytes / sec
	DWORD		dataSize	= dwDataSize;
	FILETIME	ft			= {0};

	ft = GetTime();

	if (dwDataSize == 0)
	{
		// Compute the buffer size based on the volume of data that flows per second.
		bps = m_pFormat->nAvgBytesPerSec;
		dataSize = (DWORD) (bps * m_fTimePerBuffer);
	}

	dataSize = (dataSize + 3) & 0xfffffffc;		// Round up to nearest DWORD

	if (0)
	{
		;	// Insert logic here to get a recycled buffer.
	}
	else
	{	// Need to allocate a brand new buffer.
		CCS	Lock(&m_csRBAllocCount);

		if (m_nRBAllocCount >= m_dwMaxAllocCount)
		{
			// We've already allocated too many buffers. There must be
			// something causing a shortage of processor power needed to
			// service the audio data.

			if (1)
			{
				APP->ShowConsole(TRUE);
				m_pParent->Dump();
				DebugBreak();
			}

			return NULL;
		}

		pNewRB = (RECBUFF*) GlobalAlloc(GPTR, sizeof(RECBUFF) + dataSize);
		if (pNewRB == NULL)
		{
			ASSERT(0);	// Out of memory
			return NULL;
		}

		// Initialize the new buffer's fields. Note: buffer already zeroed by GlobalAlloc.
		pNewRB->ftTime						= ft;
		pNewRB->dataSize					= dataSize;
		pNewRB->pAllocator					= this;
		pNewRB->wavehdr.dwBufferLength		= dataSize;
		pNewRB->wavehdr.dwUser				= (DWORD_PTR) pNewRB;
		pNewRB->wavehdr.lpData				= (LPSTR) &pNewRB->databuffer;
		m_nRBAllocCount++;
		//TRACE(_T("%s::AllocRecbuff: count = %d.\r\n"), m_strObjectName, m_nRBAllocCount);
	}

	// Common reinit of reused fields, in case the buffer is from recycle pool.
	pNewRB->bFirstBuffer			= FALSE;
	pNewRB->bLastBuffer				= FALSE;
	pNewRB->wavehdr.dwBytesRecorded	= 0;
	pNewRB->ftLastUsed				= ft;

	return pNewRB;
}

void CAudioFilter::FreeRecbuff(RECBUFF* pRB)
{
	ASSERT(pRB != NULL);

	if (pRB->pAllocator == this)
	{
		CCS	Lock(&m_csRBAllocCount);

		ASSERT(m_nRBAllocCount > 0);
		GlobalFree(pRB);

		m_nRBAllocCount--;

		//TRACE(_T("%s::FreeRecbuff: count = %d.\r\n"), m_strObjectName, m_nRBAllocCount);

		if (m_nRBAllocCount == 0)
		{	// Shutdown has completed if here.
			SetEvent(m_hEventSyncBuffersReturned);
		}
	}
	else
	{	// Another filter allocated this buffer. Pass it back to their deallocator.
		ASSERT(pRB->pAllocator != NULL);

		//TRACE(_T("%s::FreeRecbuff: forwarding buffer: '%08X'.\r\n"), m_strObjectName, pRB);

		pRB->pAllocator->FreeRecbuff(pRB);
	}
}

// Called to connect us to our downstream filter.
// Our format must be set before this can be called. If we were connected by upstream then
// the format has been set by the upstream's Connect function calling our Setformat.
BOOL CAudioFilter::Connect(CAudioFilter* pFilter)
{
	BOOL	rc;

	ASSERT(GetNextFilter() == NULL);
	ASSERT(pFilter != NULL);
	ASSERT(m_pFormat != NULL);

	m_pNextFilter = pFilter;
	rc = m_pNextFilter->SetFormat(m_pFormat);

	return rc;
}

// Switch the filter between FilterPaused and Ready states. Paused blocks incoming packets.
void CAudioFilter::SetPause(BOOL bPause)
{
	//TF;

	ASSERT(m_State != ShuttingDown);

	m_bPaused = bPause;
}

void CAudioFilter::PurgeBuffers(void)
{
	RECBUFF*	pRB;

	CCS	Lock(&m_csOBufferLock);
	CCS lock3(&m_csQueue);

	TF;

	while (!m_Queue.IsEmpty())
	{
		pRB = m_Queue.RemoveTail();
		FreeRecbuff(pRB);
	}

	if (m_pOutputBuffer != NULL)
	{
		FreeRecbuff(m_pOutputBuffer);
		m_pOutputBuffer = NULL;
	}
}

BOOL CAudioFilter::StartStreaming()
{
	BOOL	rc = TRUE;

	//TF;

	//CCS Lock(&m_csNextFilter);

	//m_dwDroppedBuffers = 0;	// Reset dropped count.


	if (GetNextFilter() != NULL)
		rc = GetNextFilter()->StartStreaming();

	return rc;
}

BOOL CAudioFilter::StopStreaming()
{
	BOOL	rc = TRUE;

	//TF;

	m_timeMeasured	= 0;
	m_timePerBuffer	= 0;

	{
		CCS ccs(&m_csInfo);

		ZeroMemory(&m_scanInfo, sizeof(SCAN_INFO));
	}

	{
		//CCS Lock(&m_csNextFilter);

		if (GetNextFilter() != NULL) rc = GetNextFilter()->StopStreaming();
	}

	return rc;
}

void CAudioFilter::SetFilterState(FILTER_STATE eState)
{
	CString		str;

	CCS Lock(&m_csState);

	str.Format(_T("======== %s: State changed to "),
		GetObjectName());

	switch(eState)
	{
		case Ready:
			str += _T("Ready");
			break;

		case Flushing:
			str += _T("Flushing");
			break;

		case ShuttingDown:
			str += _T("ShuttingDown");
			break;

		default:
			ASSERT(0);
	}
	str += _T("\r\n");

	m_State = eState;
	//TRACE(str);

	return;
}

//FILTER_STATE CAudioFilter::GetFilterState()
//{
//	//CCS	Lock(&m_csState);
//
//	return m_State;
//}

void CAudioFilter::Disconnect(void)
{
	//CCS	Lock(&m_csNextFilter);

	ASSERT(m_State == Flushing || m_State == ShuttingDown);

	m_pNextFilter = NULL;
}

CAudioFilter* CAudioFilter::GetNextFilter(void)
{
	return m_pNextFilter;
}

void CAudioFilter::Transmit(RECBUFF * pRB, BOOL bGive)
{
	BOOL			rc;

	ASSERT(pRB != NULL);
	ASSERT(pRB->dataSize == pRB->wavehdr.dwBufferLength);

	pRB->ftLastUsed = GetTime();

	if (m_pNextFilter != NULL)
	{
		rc = m_pNextFilter->Receive(pRB, bGive);
		if (rc)
		{
			if (!bGive) FreeRecbuff(pRB);
		}
		else
		{	// Receive Failed.

			m_dwDroppedBuffers++;

			APP->ShowConsole(TRUE);

			TRACE(_T("%s::Transmit()->%s::Receive() failed to accept our buffer.\r\n"),
				GetObjectName(), m_pNextFilter->GetObjectName());

			m_pParent->Dump();

			//DebugBreak();

			if (bGive) FreeRecbuff(pRB);
		}
	}	// if (m_pNextFilter != NULL)
}

void CAudioFilter::SetMaxAllocCount(DWORD dwMax)
{
	ASSERT(dwMax > 0);

	m_dwMaxAllocCount = dwMax;
}

DWORD CAudioFilter::GetSampleRate(void)
{
	ASSERT(m_pFormat != NULL);
	
	return m_pFormat->nSamplesPerSec;
}

// Display the important info.
void CAudioFilter::Dump(void)
{
	CString	str;

	switch(m_State)
	{
		case Ready:
			str = _T("Ready");
			break;
		
		case Flushing:
			str = _T("Flushing");
			break;
		
		case ShuttingDown:
			str = _T("ShuttingDown");
			break;
	}

	TRACE(_T("Dumping object %s.\t\tState = %s.\tThis = %08X\r\n"),
		m_strObjectName, str, (DWORD_PTR) this);

	TRACE(_T("---Allocated %d.\r\n---Input Q: %d.\r\n---Dropped: %d.\r\n"),
		m_nRBAllocCount, m_Queue.GetCount(), m_dwDroppedBuffers);

	TRACE(_T("Time / buffer needed: %u MS. Actual: %u.\r\n"),
		GetBufferTimeMS(), GetBufferTimeMeasuredMS());
}

DWORD CAudioFilter::GetBufferTimeMS(void)
{
	return m_timePerBuffer;
}

DWORD CAudioFilter::GetBufferTimeMeasuredMS(void)
{
	return m_timeMeasured;
}

// Update the m_scanInfo structure
void CAudioFilter::ScanTheBuffer(LPWAVEHDR lpWH, LPWAVEFORMATEX lpWF)
{
	//TF;		// Trace this function

	DWORD		nSamples;
	BYTE*		pBuffer8;	// Used to scan the buffer
	SHORT*		pBuffer16;	// Used to scan the buffer
	BOOL		bStereo;
	BOOL		b16Bit;
	DWORD		i;
	SHORT		sample16;
	SCAN_INFO	scan = {0};
	long		avgLeft = 0, avgRight = 0, temp;

	ASSERT(lpWH != NULL && lpWF != NULL);

	bStereo		= (lpWF->nChannels		== 2);
	b16Bit		= (lpWF->wBitsPerSample	== 16);

	if (lpWH->dwBytesRecorded > 0)
	{
		nSamples	= lpWH->dwBytesRecorded / lpWF->nBlockAlign;
		if (bStereo) nSamples *= 2;	// dbl # samples for stereo

		pBuffer8	= (BYTE*)	lpWH->lpData;
		pBuffer16	= (SHORT*)	lpWH->lpData;

		for (i = 0; i < nSamples; i++)
		{
			if (!b16Bit)
				sample16 = _8To16(pBuffer8[i]);
			else
				sample16 = pBuffer16[i];

			avgLeft += (long) sample16;	// Accumulate the avg

			// Get the current lowest value
			scan.wLowLeft	= min(scan.wLowLeft, sample16);
			scan.wHighLeft	= max(scan.wHighLeft, sample16);

			if (bStereo)
			{
				if (!b16Bit)
					sample16 = _8To16(pBuffer8[i+1]);
				else
					sample16 = pBuffer16[i+1];

				avgRight += (long) sample16;	// Accumulate the avg

				// Get the current lowest value
				scan.wLowRight	= min(scan.wLowRight, sample16);
				scan.wHighRight	= max(scan.wHighRight, sample16);
				i++;
			}
		}

		// Get signed division(s) for the average(s).
		temp	= abs(avgLeft);
		temp	= temp / nSamples;

		if (avgLeft >= 0)
			avgLeft = temp;
		else
			avgLeft = -temp;

		if (bStereo)
		{
			temp	= abs(avgRight);
			temp	/= nSamples;

			if (avgRight >= 0)
				avgRight = temp;
			else
				avgRight = -temp;
		}

		scan.nAvgLeft	= (SHORT) avgLeft;
		scan.nAvgRight	= (SHORT) avgRight;

		// Now that we've scanned this buffer, update the protected global.
		{
			CCS ccs(&m_csInfo);

			m_scanInfo = scan;
		}
	}
	else
	{	// No data in buffer
		CCS ccs(&m_csInfo);

		ZeroMemory(&m_scanInfo, sizeof(SCAN_INFO));
	}

	m_scanInfo.bStereo = bStereo;	// Panel indicators like to know if the data is stereo
}

// Return the SCAN_INFO to the caller.
void CAudioFilter::GetScanInfo(SCAN_INFO* lpScanInfo)
{
	//TF;		// Trace this function

	CCS ccs(&m_csInfo);

	ASSERT(lpScanInfo != NULL);
	*lpScanInfo = m_scanInfo;
}

SHORT CAudioFilter::_8To16(BYTE In)
{
	return (((SHORT) In) - 128) << 8;
}

BYTE CAudioFilter::_16To8(SHORT In)
{
	return (In >> 8) + 128;
}

void CAudioFilter::ResetDroppedBufferCount(void)
{
	m_dwDroppedBuffers = 0;
}

DWORD CAudioFilter::GetDroppedBufferCount(void)
{
	return m_dwDroppedBuffers;
}

// Called by filter to send a byte at a time downstream to the next filter.
// The data is buffered here until full or a flush occurs.
BOOL CAudioFilter::AddByte(const BYTE Value, const DWORD dwSampleIndex, const RECBUFF* pRB)
{
	CCS		Lock(&m_csOBufferLock);

	ASSERT(pRB != NULL);

	if (m_pOutputBuffer == NULL)
	{	// Obtain and format a new output buffer.
		m_pOutputBuffer = AllocRecbuff(pRB->dataSize);	// Same size as input bfr.
		ASSERT(m_pOutputBuffer != NULL);

		m_pOutputBuffer->ftTime = GetTimeOfThisSample(dwSampleIndex, pRB).ft;
		m_pOutputBuffer->nSample = pRB->nSample + dwSampleIndex;
	}

	// Store the new sample into the buffer at the proper offset.
	*(m_pOutputBuffer->databuffer + (m_pOutputBuffer->wavehdr.dwBytesRecorded++)) = Value;

	// If buffer is full now then transmit it.
	if (m_pOutputBuffer->wavehdr.dwBytesRecorded == m_pOutputBuffer->dataSize)
	{
		Transmit(m_pOutputBuffer);
		m_pOutputBuffer = NULL;
	}

	return TRUE;
}

UFT CAudioFilter::GetTimeOfThisSample(const DWORD SampleIndex, const RECBUFF* pRB)
{
	UFT		u1 = {0};
	double	timePerSample;

	timePerSample = (1.0 / m_pFormat->nSamplesPerSec);
	u1.ft = pRB->ftTime;
	u1.ll += (ULONGLONG) (timePerSample * ONE_SECOND * SampleIndex);

	return u1;
}

BOOL CAudioFilter::IsPaused()
{
	return m_bPaused;
}

void CAudioFilter::FlushOutputBuffer(void)
{
	CCS		Lock(&m_csOBufferLock);

	if (m_pOutputBuffer != NULL)
	{
		if (m_pOutputBuffer->wavehdr.dwBytesRecorded > 0)
		{	// Transmit the remaining data downstream.
			Transmit(m_pOutputBuffer);
			m_pOutputBuffer = NULL;
		}
		else
		{	// Nothing in buffer. Delete it.
			FreeRecbuff(m_pOutputBuffer);
			m_pOutputBuffer = NULL;
		}
	}
}

int CAudioFilter::GetAllocatedBufferCount(void)
{
	return m_nRBAllocCount;
}

LPCTSTR CAudioFilter::GetObjectName(void)
{
	return LPCTSTR(m_strObjectName);
}

FILETIME CAudioFilter::GetTime(void)
{
	SYSTEMTIME	tm	= {0};
	FILETIME	ft	= {0};

	GetLocalTime(&tm);
	SystemTimeToFileTime(&tm, &ft);

	return ft;
}

// Called by worker proc before the queue is scanned for processing. Return
// TRUE to tell proc to perform the scan. FALSE causes scan to skip resulting
// in the proc going back into a wait state for a new signal.
BOOL CAudioFilter::OnPreQueueScan(void)
{
	return TRUE;
}

// Called when the queue is empty. Can be called many times very rapidly.
void CAudioFilter::OnPostQueueScan(void)
{
}

// Called after the flush has completed but before the flush (recorder) thread
// is signalled.
// Return TRUE = allow the flush complete signal to occur. False prevents the
// signal resulting in the main thread waiting forever for the flush to finish.
BOOL CAudioFilter::OnWorkerFlushComplete(void)
{
	return TRUE;
}
