#pragma once

class CModuleScanner
{
public:
	CModuleScanner(void);
	virtual ~CModuleScanner(void);
protected:
	HANDLE m_hFile;
public:
	DWORD CalculateModuleChecksum(void);
protected:
	CString m_strModulePath;
};
