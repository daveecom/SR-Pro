#include "StdAfx.h"
#include ".\filenameserver.h"

IMPLEMENT_SERIAL(CFilenameServer, CObject, 0)

CFilenameServer::CFilenameServer(void)
: m_strCurrentFilename(_T(""))
, m_nSequenceNumber(0)
, m_bSeqHex(FALSE)
{
}

CFilenameServer::~CFilenameServer(void)
{
}

void CFilenameServer::SetExt(LPCTSTR strExt)
{
	m_FileSettings.m_strExt = strExt;
}

void CFilenameServer::SetFolder(LPCTSTR lpszPath)
{
	m_FileSettings.m_strFolder = lpszPath;
}

LPCTSTR CFilenameServer::GetFolder()
{
	return m_FileSettings.m_strFolder;
}

void CFilenameServer::SetMode(SEQ_MODE eMode)
{
	m_FileSettings.m_eSeqMode = eMode;
}

SEQ_MODE CFilenameServer::GetMode()
{
	return m_FileSettings.m_eSeqMode;
}

LPCTSTR CFilenameServer::GetExt()
{
	return m_FileSettings.m_strExt;
}

void CFilenameServer::SetFilenameRoot(LPCTSTR lpszRoot)
{
	m_FileSettings.m_strFilenameRoot = lpszRoot;
}

LPCTSTR CFilenameServer::GetFilenameRoot()
{
	return m_FileSettings.m_strFilenameRoot;
}

// Return new full path with extension
LPCTSTR CFilenameServer::GetNewFilename(void)
{
	SYSTEMTIME	st = {0};
	CString strTestname;
	CString strSeqDigits;
	CString strTemplate;	// used to make the seq #
	DWORD	i;

	switch (m_FileSettings.m_eSeqMode)
	{
		case seq_counter:
			ASSERT(m_FileSettings.m_nSeqDigits > 0);

			// First, make the template.
			if (m_bSeqHex)
				strTemplate.Format(_T("%%0%dX"), m_FileSettings.m_nSeqDigits);	// hex
			else
				strTemplate.Format(_T("%%0%dd"), m_FileSettings.m_nSeqDigits);	// decimal

			// Loop until the name is unique
			for(i = m_nSequenceNumber;; i++)
			{
				strSeqDigits.Format(strTemplate, i);	// generate "nnnn"
				strTestname.Format(_T("%s_%s"), m_FileSettings.m_strFilenameRoot, strSeqDigits);
				m_strCurrentFilename = strTestname;
				m_strCurrentFilepath.Format(_T("%s\\%s.%s"),
					m_FileSettings.m_strFolder, strTestname, m_FileSettings.m_strExt);
				if (!IsFilePresent(m_strCurrentFilepath))
				{
					m_nSequenceNumber = i+1;	// Save the latest # for next time.
					break;	// Filename has been determined.
				}

			}
			break;

		case seq_date:
			GetLocalTime(&st);
			strTestname.Format(_T("%04d%02d%02d-%02d%02d%02d-%03d"),
				st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
			m_strCurrentFilename.Format(_T("%s_%s"), m_FileSettings.m_strFilenameRoot, strTestname);
			m_strCurrentFilepath.Format(_T("%s\\%s.%s"),
				m_FileSettings.m_strFolder, m_strCurrentFilename, m_FileSettings.m_strExt);
			break;
	}

	return m_strCurrentFilepath;
}

// Test for the existance of the file specified. Full path with extension required.
BOOL CFilenameServer::IsFilePresent(LPCTSTR lpszFilename)
{
	WIN32_FIND_DATA		fd = {0};
	HANDLE				hFile;
	BOOL				bFound = FALSE;

	hFile = FindFirstFile(lpszFilename, &fd);
	if (hFile != INVALID_HANDLE_VALUE) bFound = TRUE;
	FindClose(hFile);

	return bFound;
}

void CFilenameServer::SetHex(BOOL bHex)
{
	m_bSeqHex = bHex;
}

void CFilenameServer::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_strCurrentFilename;
		ar << m_strCurrentFilepath;
		ar << m_nSequenceNumber;
		ar << m_bSeqHex;
	}
	else
	{	// loading code
		ar >> m_strCurrentFilename;
		ar >> m_strCurrentFilepath;
		ar >> m_nSequenceNumber;
		ar >> m_bSeqHex;
	}

	m_FileSettings.Serialize(ar);
}

void CFilenameServer::SetSeqDigits(int nDigits)
{
	m_FileSettings.m_nSeqDigits = nDigits;
}

int CFilenameServer::GetSeqDigits(void)
{
	return m_FileSettings.m_nSeqDigits;
}

void CFilenameServer::SetDefaults(void)
{
	m_FileSettings.SetDefaults();
}

CFileSettings* CFilenameServer::GetFileSettings(void)
{
	return &m_FileSettings;
}

// Return the file name without the extension
LPCTSTR CFilenameServer::GetCurrentFilename(void)
{
	return m_strCurrentFilename;
}

void CFilenameServer::SetSequenceNumber(int nValue)
{
	m_nSequenceNumber = nValue;
}
