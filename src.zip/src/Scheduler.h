#pragma once


// The following states determine what type of schedule we're handling: normal on-off alarms
// or special one-time-only single alarms.
typedef	enum _alarmtype
{
	Alarm_Undefined = 0,	// Make sure it gets set by defaulting to undefined.
	Alarm_Single,			// Used for	events that have no off time.
	Alarm_StartStop			// Used for all events that have start and stop times.
}	ALARM_TYPE;

class CScheduleController;

class CScheduleItem : public CObject
{
	DECLARE_SERIAL(CScheduleItem)

public:

	BOOL					CreateStartStop(LPCTSTR lpszName, FILETIME tStart, FILETIME tDuration, REPEAT_PARMS RepeatParms, HWND hReceiver);
	BOOL					ReCreateStartStop();

							CScheduleItem();
	virtual					~CScheduleItem();

	virtual void			Serialize(CArchive& ar);

	void					EnableAlarm(BOOL bEnable);
	void					Delete(void);
	LPCTSTR					GetID(void) const;
	void					SetRepeat(REPEAT_PARMS Parms);
	void					SetStart(FILETIME tStart);
	void					SetDuration(FILETIME tDuration);
	void					SetName(LPCTSTR lpszName);
	void					SetContainer(CScheduleController* pContainer);
	LPCTSTR					GetName(void) const;
	REPEAT_PARMS			GetRepeat() const;
	UFT						GetStart(void) const;
	UFT						GetDuration(void) const;
	CScheduleController*	GetContainer(void);
	BOOL					IsEnabled(void) const;
	void					ArmSchedule(void);
	void					AbortSchedule(void);
	BOOL					IsArmed(void) const;
	BOOL					IsShowOnNow(void);
	void					SetControlHwnd(HWND hWnd);
	void					PostAlarmMessage(int AlarmIndex);

protected:

	static BOOL __stdcall	AlarmCB(CAlarmClock* pClock, DWORD_PTR dwUserData);
	BOOL					AlarmCB(CAlarmClock* pClock);
	BOOL					IsRepeatNecessary(void);

////////////////// ARCHIVE ///////////////////
	UFT						m_uStart;		// start date/time
	UFT						m_uDuration;	// length of time to keep recording.
	CString					m_strName;		// Alarm name
	CString					m_strID;		// Schedule ID
	BOOL					m_bEnabled;		// Enabled flag
	REPEAT_PARMS			m_RepeatParms;	// Repeat info
	ALARM_TYPE				m_eType;		// Alarm type (single, dual, etc).
////////////////// ARCHIVE ///////////////////

	CScheduleController*	m_pContainer;	// The container object contianing this.

	// Primary and secondary alarm handlers
	MSG						m_msg[2];			// Primary and secondary alarm messages
	CAlarmClock				m_clock[2];			// Clock controllers.

	BOOL					m_bArmed;

	BOOL					m_bShuttingDown;	// Indicates shutdown in progress

// Here are the control messages:
	#define UWM_CONTROL				(WM_USER + 50)
	#define UWM_CONTROL_RECORDSTART	(UWM_CONTROL + 0)	// hParam = this CScheduleItem, lParam = 0
	#define UWM_CONTROL_RECORDSTOP	(UWM_CONTROL + 1)	// hParam = this CScheduleItem, lParam = 0
public:
	BOOL IsExpired(void);
	// Bring this item to a proper state given the old alarm start and repeat parms.
	void BringUpToDate(void);
};

class CScheduleController : public CObject
{
public:

	DECLARE_SERIAL(CScheduleController)

							CScheduleController();
	virtual					~CScheduleController();


	int						AddAlarm(CScheduleItem * pItem, BOOL bQuiet = FALSE);
	void					DeleteAlarm(int Index);
	void					RemoveAlarm(int Index);

public:
	void					ClearArray(void);

public:
	int						GetCount();
	CScheduleItem*			GetSchedule(int Index);

	void					EnableAlarm(int Index, BOOL bEnable = TRUE);

	int						IndexFromID(LPCTSTR lpszID);

	//BOOL					SaveFile(LPCTSTR lpszFilePath);
	//BOOL					LoadFile(LPCTSTR lpszFilePath);

	//void					SetModifiedFlag(BOOL bValue = TRUE);
	//BOOL					IsModified(void);

	//BOOL					BringListUpToDate(void);
	void					ActivateSchedules(void);
	void					AbortSchedules(void);

	void					SetControlHwnd(HWND hWnd);

protected:
	CSimpleArray<class CScheduleItem *>	m_ArraySched;

	CSection				m_csController;	// Serialize all access to this class.

	//CString					m_strArchive;
	//BOOL					m_bIsDirty;

	BOOL					AskUserRecordingInProgress(const CScheduleItem* pItem);

	HWND					m_hControlHwnd;	// Save here and give to child whenever enqueued

public:
	CScheduleItem* GetNextScheduledItem(void);
	virtual void Serialize(CArchive& ar);
	CScheduleItem* GetCurrentShow(void);
	void PurgeJunk(void);
	BOOL IsOverlapped(const CScheduleItem* pNewItem, CScheduleItem** ppDuplicateItem);
	BOOL IsFutureOverlap(const CScheduleItem* pItem1, CScheduleItem* pItem2);
protected:
	CString m_strFile;
public:
	void SetFile(LPCTSTR lpFilepath);
	BOOL Save(void);
	BOOL Load(void);
	LPCTSTR GetFile(void);
};
#pragma once

