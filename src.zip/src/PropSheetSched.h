#pragma once

#include "resource.h"
#include "afxcmn.h"
#include "afxdtctl.h"
#include "staticcolor.h"
#include "scheduler.h"


// CPropPageSchedStart dialog

class CPropPageSchedStart : public CPropertyPage
{
	DECLARE_DYNAMIC(CPropPageSchedStart)

public:
	CPropPageSchedStart();
	virtual ~CPropPageSchedStart();

// Dialog Data
	enum { IDD = IDD_PROPPAGE_SCHEDULE_START };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnSetActive();
	virtual BOOL OnInitDialog();
protected:
	CDateTimeCtrl m_DateTime_Date;
	CDateTimeCtrl m_DateTime_Time;
	CEdit m_Edit_SchedComment;

public:
	virtual LRESULT OnWizardNext();
	afx_msg void OnBnClickedButtonReset();
protected:
	void ResetInputs(void);
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnBnClickedButtonSetnow();
protected:
	CToolTipCtrl	m_ToolTip;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

// CPropPageSchedStop dialog

class CPropPageSchedStop : public CPropertyPage
{
	friend class CPropPageSchedConfirm;

	DECLARE_DYNAMIC(CPropPageSchedStop)

public:
	CPropPageSchedStop();
	virtual ~CPropPageSchedStop();

// Dialog Data
	enum { IDD = IDD_PROPPAGE_SCHEDULE_STOP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	virtual BOOL OnSetActive();
	virtual BOOL OnInitDialog();
	CDateTimeCtrl m_DateTime_Date;
	CDateTimeCtrl m_DateTime_Time;
	virtual LRESULT OnWizardNext();
protected:
	CButton m_Check_Repeat;
//	afx_msg void OnBnClickedCheckRepeat();
	afx_msg void OnBnClickedCheckRepeat();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
protected:
	void ResetInputs(void);
	CSpinButtonCtrl m_Spin_Days;
	CSpinButtonCtrl m_Spin_Hours;
	CSpinButtonCtrl m_Spin_Mins;
	CSpinButtonCtrl m_Spin_Secs;
	afx_msg void OnBnClickedButtonReset();
	void Update(void);
	afx_msg void OnDatetimechange(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
protected:
	CToolTipCtrl	m_ToolTip;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

// CPropPageSchedRepeat dialog

class CPropPageSchedRepeat : public CPropertyPage
{
	DECLARE_DYNAMIC(CPropPageSchedRepeat)

public:
	CPropPageSchedRepeat();
	virtual ~CPropPageSchedRepeat();

// Dialog Data
	enum { IDD = IDD_PROPPAGE_SCHEDULE_REPEATS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnSetActive();
public:
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

protected:
	void Update(void);

	int				m_Radio_Types;
	CSpinButtonCtrl	m_Spin_DOM;
	CSpinButtonCtrl m_Spin_RepCount;
	CSpinButtonCtrl m_Spin_Days;
	CSpinButtonCtrl m_Spin_Hours;
	CSpinButtonCtrl m_Spin_Minutes;
	CSpinButtonCtrl m_Spin_Seconds;

	CButton			m_Check_Sun;
	CButton			m_Check_Mon;
	CButton			m_Check_Tue;
	CButton			m_Check_Wed;
	CButton			m_Check_Thu;
	CButton			m_Check_Fri;
	CButton			m_Check_Sat;
	int				m_Radio_EndType;
public:
	afx_msg void OnBnClickedRadioRepeatTypes();
	afx_msg void OnBnClickedRadioEndTypes();
protected:
	CDateTimeCtrl m_Date_Expires;
public:
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedCheckDOW();
	virtual LRESULT OnWizardNext();
	afx_msg void OnDtnDatetimechangeDateExpires(NMHDR *pNMHDR, LRESULT *pResult);

protected:
	CToolTipCtrl	m_ToolTip;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

// CPropPageSchedConfirm dialog

class CPropPageSchedConfirm : public CPropertyPage
{
	DECLARE_DYNAMIC(CPropPageSchedConfirm)

public:
	CPropPageSchedConfirm();
	virtual ~CPropPageSchedConfirm();

// Dialog Data
	enum { IDD = IDD_PROPPAGE_SCHEDULE_CONFIRM };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	virtual BOOL			OnSetActive();
	virtual LRESULT			OnWizardBack();
	afx_msg BOOL			OnEraseBkgnd(CDC* pDC);

	CFont					m_fontLarge;
	CStaticColor			m_Static_Duration;
	CStaticColor			m_Static_RepeatText;
	CStaticColor			m_Static_EventName;
	CStaticColor			m_Static_Start;
	CStaticColor			m_Static_Stop;
public:
	virtual BOOL OnInitDialog();
	virtual BOOL OnWizardFinish();

protected:
	CToolTipCtrl	m_ToolTip;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};


// CPropSheetSched

class CPropSheetSched : public CPropertySheet
{
	friend class CPropPageSchedStart;
	friend class CPropPageSchedStop;
	friend class CPropPageSchedRepeat;
	friend class CPropPageSchedConfirm;

	DECLARE_DYNAMIC(CPropSheetSched)

public:
	CPropSheetSched(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	virtual ~CPropSheetSched();
	virtual INT_PTR DoModal();

	void					SetSchedule(LPCTSTR lpszSchedName, FILETIME ftStart, FILETIME ftDuration, REPEAT_PARMS RepeatParms);
	void					SetSchedule(CScheduleItem* pItem);
	void					GetSchedule(CScheduleItem* pItem);
	LPCTSTR					GetScheduleName(void);
	FILETIME				GetStartDateTime(void);
	FILETIME				GetStopDateTime(void);
	REPEAT_PARMS 			GetRepeatParms(void);
	FILETIME				GetDuration(void);

protected:
	DECLARE_MESSAGE_MAP()
	UFT						m_uStart;
	UFT						m_uDuration;
	CPropPageSchedStart		m_pageStart;
	CPropPageSchedStop		m_pageStop;
	CPropPageSchedRepeat	m_pageRepeat;
	CPropPageSchedConfirm	m_pageConfirm;
	virtual BOOL			OnInitDialog();
	CString					m_strSchedComment;
	REPEAT_PARMS			m_RepeatParms;
	BOOL					m_bRepeats;
	afx_msg BOOL			OnEraseBkgnd(CDC* pDC);
public:
//	afx_msg void OnClose();
};

