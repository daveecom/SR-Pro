#pragma once
#include "audiofilter.h"

class CRecordGateFilter : public CAudioFilter
{

public:

	CRecordGateFilter(CAudioRecorder* pParent);
	~CRecordGateFilter(void);

	DECLARE_DYNAMIC(CRecordGateFilter)

	void			ResetSampleCount(void);
	ULONGLONG		GetSampleCount(void);
	FILETIME		GetStoredTime(void);
	void			SetTriggerSamples(ULONGLONG nCount);
	void			SetTriggerTime(int HH, int MM, int SS = 0);

protected:

	virtual void	ProcessDataBuffer(RECBUFF* pRB);
	virtual void	CRecordGateFilter::RolloverFile(void);
	ULONGLONG		m_nSampleNumber;
	ULONGLONG		m_nTriggerSamples;	// # samples to count before checkpointing.
										// Ignore if 0.
};
