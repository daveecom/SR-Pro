#pragma once

#include "resource.h"

// CDlgAbout dialog

class CDlgAbout : public CDHtmlDialog
{
	DECLARE_DYNCREATE(CDlgAbout)

public:
	CDlgAbout(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgAbout();

// Dialog Data
	enum { IDD = IDD_DIALOG_ABOUTBOX2, IDH = IDR_HTML_DLGABOUT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()
};
