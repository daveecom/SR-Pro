#include "StdAfx.h"
#include ".\wavefilewriterfilter.h"
#include "aviriff.h"

CWaveFileWriterFilter::CWaveFileWriterFilter(CAudioRecorder* pParent)
: CFileWriterFilter(pParent)
, m_eCheckpointMode(CHECKPOINT_MODE_OFF)
, m_bCkptInProgress(FALSE)
, m_bCkptTimerIdle(FALSE)
, m_nCkptIdleTime(5)	// seconds idle b4 ckpt.
, m_nFailSafeTime(30)	// seconds not idle, force time.
{
	TF;

	m_strObjectName = _T("CWaveFileWriterFilter");

}

CWaveFileWriterFilter::~CWaveFileWriterFilter(void)
{
	TF;
}

// Intercept to pre init the file before anything is written.
BOOL CWaveFileWriterFilter::BeginNewFile()
{
	BOOL	rc;
	DWORD	dwWritten;
	LPBYTE	pBuffer;

	CCS		lock(&m_csFileLock);

	ASSERT(IsFormatSet());

	rc = __super::BeginNewFile();
	if (!rc) ASSERT(0);	// unknown error from SetPathname

	// Compute the header size based on the current format.
	m_nHeaderSize = sizeof(RIFFLIST) + sizeof(RIFFCHUNK) +
		sizeof(WAVEFORMATEX) + m_pFormat->cbSize +
		sizeof(RIFFCHUNK);

	// Write the header's placeholder at the head of the new file. It'll be filled in
	// at the closing of the file.
	pBuffer = new BYTE[m_nHeaderSize];
	ZeroMemory(pBuffer, m_nHeaderSize);

	{
		//CCS lock(&m_csFileLock);

		dwWritten = 0;
		if (!m_bWriteInhibit)
		{
			rc = WriteFile(m_hFile, pBuffer, m_nHeaderSize, &dwWritten, NULL);
			ASSERT(rc && (dwWritten == m_nHeaderSize));
		}
	}

	delete [] pBuffer;

	// Arm the checkpointing system if necessary.
	//SetCheckpointMode(m_eCheckpointMode);	// Use default setting.

	return rc;
}

// Seek back and write the wav headers before closing the file.
void CWaveFileWriterFilter::CloseFile(void)
{
	BOOL			rc;
	LPBYTE			pBuffer;
	RIFFLIST*		pHeader;
	RIFFCHUNK*		pFmtChunk;
	RIFFCHUNK*		pDataChunk;
	DWORD			dwWritten;

	// Cancel checkpointing if active.
	CCS		Lock(&m_csCheckpoint);

	m_clockFailsafe.KillAlarm();
	m_clockIdle.KillAlarm();
	m_bCkptNeeded = m_bCkptTimerFailsafe = m_bCkptTimerIdle = FALSE;

	//ASSERT(m_hFile != NULL);
	ASSERT(m_nHeaderSize > 0);
	//ASSERT(m_nBytesWritten > 0);	// size of data

	ASSERT(m_State == Flushing);
	//Flush();

	CCS				lock(&m_csFileLock);

	{
		CCS		lock(&m_csFileLock);

		// Make sure we have an even number of bytes in the WAV file.
		if (m_nBytesWritten & 1)
		{	// it's odd. Need to write one more byte
			char zero = 0;	// Pad byte

			if (!m_bWriteInhibit)
			{
				rc = WriteFile(m_hFile, &zero, 1, &dwWritten, NULL);
				ASSERT(rc && (dwWritten == 1));
			}
		}

		// Format the header.
		pBuffer		= new BYTE[m_nHeaderSize];
		ZeroMemory(pBuffer, m_nHeaderSize);

		pHeader		= (RIFFLIST*)	pBuffer;
		pFmtChunk	= (RIFFCHUNK*)	(pHeader + 1);
        pDataChunk	= (RIFFCHUNK *)(((BYTE *)(pFmtChunk + 1)) +
			sizeof(WAVEFORMATEX) + m_pFormat->cbSize);

		// Set RIFF header
		pHeader->cb				= m_nHeaderSize + ((DWORD) m_nBytesWritten) - sizeof(RIFFCHUNK);
		pHeader->fcc			= FCC('RIFF');
		pHeader->fccListType	= FCC('WAVE');

		// Set format chunk
		pFmtChunk->cb			= sizeof(WAVEFORMATEX) + m_pFormat->cbSize;
		pFmtChunk->fcc			= FCC('fmt ');
		LPWAVEFORMATEX pFmtData	= (LPWAVEFORMATEX) (pFmtChunk + 1);
		CopyMemory(pFmtData, m_pFormat, sizeof(WAVEFORMATEX) + m_pFormat->cbSize);

		// Set data chunk
		pDataChunk->cb			= (DWORD) m_nBytesWritten;
		pDataChunk->fcc			= FCC('data');

		// Seek back to the beginning of the file and overlay the RIFF headers.	

		if (!m_bWriteInhibit)
		{
			rc = SetFilePointer(m_hFile, NULL, NULL, FILE_BEGIN);

			// Write the header to the file.
			rc = WriteFile(m_hFile, pBuffer, m_nHeaderSize, &dwWritten, NULL);
			ASSERT(rc && (dwWritten == m_nHeaderSize));
		}
	}

	__super::CloseFile();

	delete [] pBuffer;
}

BOOL CWaveFileWriterFilter::SetFormat(LPWAVEFORMATEX lpWF)
{
	return __super::SetFormat(lpWF);
}

// Called synchronously by worker thread to perform the file checkpoint.
// at intervals. m_csCheckpoint must already be locked.
BOOL CWaveFileWriterFilter::PerformCheckpoint(void)
{
	CCS		Lock(&m_csCheckpoint);

	{	// Look at the status and abort checkpoint if already in progress.

		if (m_bCkptInProgress) return FALSE;
		m_bCkptInProgress = TRUE;
	}

	UpdateHeaders();

	{
		m_bCkptInProgress = FALSE;
		m_bCkptNeeded = FALSE;

		return TRUE;
	}
}

BOOL CWaveFileWriterFilter::UpdateHeaders(void)
{
	//CAlarmClock	clock;
	//TF;

	//// Let's play a little song, shall we. It's called DAISY.
	//Beep(3000,100);
	//Beep(4000,100);
	//Beep(6000,100);
	//Beep(5000,100);

	////clock.SetAlarmAndWait(0, 0, 0, 0, 1000);

	//Beep(5000,100);
	//Beep(6000,100);
	//Beep(4000,100);
	//Beep(3000,100);

	return TRUE;
}

void CWaveFileWriterFilter::SetCheckpointMode(CHECKPOINT_MODE Mode)
{
	CCS		Lock(&m_csCheckpoint);

	m_clockFailsafe.KillAlarm();
	m_clockIdle.KillAlarm();

	m_eCheckpointMode = Mode;

	m_bCkptInProgress = m_bCkptTimerIdle = m_bCkptTimerFailsafe = FALSE;

	if (m_eCheckpointMode == CHECKPOINT_MODE_WAIT_IDLE)
		SetCheckpointAlarmIdle();

	if (m_eCheckpointMode == CHECKPOINT_MODE_WAIT_FORCE)
		SetCheckpointAlarmForce();
}

// Called by worker thread to check for and perform a checkpoint op.
void CWaveFileWriterFilter::OnPostQueueScan(void)
{
	// The work queue has just been exhausted. Check for conditions
	// that could lead to a checkpoint operation and perform the ckpt
	// if necessary.

	CCS	Lock(&m_csCheckpoint);

	if (m_eCheckpointMode != CHECKPOINT_MODE_OFF)
	{
		if (m_bCkptTimerIdle || m_bCkptTimerFailsafe)
		{
			m_clockIdle.KillAlarm();
			m_clockFailsafe.KillAlarm();

			if (m_bCkptNeeded) PerformCheckpoint();
		}

		m_bCkptTimerIdle = m_bCkptTimerFailsafe = FALSE;

		// Re-arm the timers.
		SetCheckpointAlarmIdle();	// Arm the idle timer

		if (m_eCheckpointMode == CHECKPOINT_MODE_WAIT_FORCE)
			SetCheckpointAlarmForce();	// And the failsafe in case
										// there is no idle period available.
	}
}

// Idle alarm handler. Drive the worker loop to call the checkpoint processor.
BOOL __stdcall CWaveFileWriterFilter::AlarmCB_Idle(CAlarmClock* pThis, DWORD_PTR dwUserData)
{
	CWaveFileWriterFilter* pFilter = (CWaveFileWriterFilter*) dwUserData;
	CCS Lock(&pFilter->m_csCheckpoint);

	pFilter->m_bCkptTimerIdle		= TRUE;
	SetEvent(pFilter->m_hEventWakeWorker);	// Wakeup.

	return TRUE;
}

// Failsafe alarm handler. Drive the worker loop to call the checkpoint processor.
BOOL __stdcall CWaveFileWriterFilter::AlarmCB_Force(CAlarmClock* pThis, DWORD_PTR dwUserData)
{
	CWaveFileWriterFilter* pFilter = (CWaveFileWriterFilter*) dwUserData;
	CCS Lock(&pFilter->m_csCheckpoint);

	pFilter->m_bCkptTimerFailsafe	= TRUE;
	SetEvent(pFilter->m_hEventWakeWorker);	// Wakeup.

	return TRUE;
}

void CWaveFileWriterFilter::ProcessDataBuffer(RECBUFF* pRB)
{
	int	nDataSize = pRB->wavehdr.dwBytesRecorded;

	__super::ProcessDataBuffer(pRB);

	if (nDataSize)
	{
		m_bCkptNeeded = TRUE;
	}
}

void CWaveFileWriterFilter::SetCheckpointAlarmIdle()
{
	CCS Lock(&m_csCheckpoint);

	// (Re)arm the timer unit(s).
	m_clockIdle.SetAlarm(0, 0, 0, m_nCkptIdleTime, 0, AlarmCB_Idle, (DWORD_PTR) this);
}

void CWaveFileWriterFilter::SetCheckpointAlarmForce()
{
	CCS Lock(&m_csCheckpoint);

	// (Re)arm the timer unit(s).
	m_clockFailsafe.SetAlarm(0, 0, 0, m_nFailSafeTime, 0, AlarmCB_Force, (DWORD_PTR) this);
}

