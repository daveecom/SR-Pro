// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifdef _DEBUG
//#define _CRTDBG_MAP_ALLOC 
#endif

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#endif

#undef WINVER 
#undef _WIN32_WINNT 
#undef _WIN32_WINDOWS 
#undef _WIN32_IE 

#define WINVER			0x0400
#define _WIN32_WINNT	0x0500
#define _WIN32_WINDOWS	0x0410
#define _WIN32_IE		0x0601

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit

// turns off MFC's hiding of some common and often safely ignored warning messages
#define _AFX_ALL_WARNINGS

#include <afx.h>

#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

// My stuff
#include <afxdhtml.h>
#include <process.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <msacm.h>
#include <afxcoll.h>
#include <afxtempl.h>
#include <atlcoll.h>
#include <uxtheme.h>
#include <atlbase.h>
#include <atlwin.h>

#ifndef ASSERTMMR
#define ASSERTMMR ASSERT(mmr == MMSYSERR_NOERROR)
#endif

#define _USE_MATH_DEFINES
#include <math.h>

#include "ccs.h"

// These are implemented in the app.cpp
void	trace(LPCTSTR lpszstring, ...);
void	traceDump(LPCTSTR lpszstring, ...);

////////////////////////////////////////////////////////
#ifdef _MYTRACE
#ifdef TRACE
#undef TRACE
#endif
#define TRACE trace	// Use ours instead of MS's
#endif // MYTRACE

#ifdef _NOTRACE
#undef TRACE
#define TRACE
#endif

#define APP ((App*) AfxGetApp())
#define DOC ((Doc*) APP->GetDoc())

#define MIN_HANGTIME 50
#define MAX_HANGTIME 20000
#define SECTION_NAME _T("Settings")

//#ifndef _BEEP
//#undef Beep
//#define Beep
//#endif
////////////////////////////////////////////////////////

#include "functiontrace.h"

#include "securedsections.h"

#include "alarmclock.h"
#include "autobutton.h"
#include "hasher.h"
#include <afxwin.h>
