#pragma once

#include "stdafx.h"

#include "audiofilter.h"

class CAudioDelay
{
public:
					CAudioDelay(void);
	virtual			~CAudioDelay(void);

	BOOL			NewExchangeSample(USAMPLE* pSample, BOOL bDrainBuffer = FALSE);
	void			Create(DWORD nSamples);
	void			Destroy();
	void			SetNewFormat(DWORD nSamples);

protected:
	int				m_Size;

	CSection		m_csArray;

	CList<USAMPLE>	m_Samples;		// New queue to replace m_Array
};
