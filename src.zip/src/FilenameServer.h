/********************************************************
********************************************************/

#pragma once

#include "filesettings.h"

class CFilenameServer : public CObject
{
	DECLARE_SERIAL(CFilenameServer)

public:
					CFilenameServer();
					~CFilenameServer();
	virtual void	Serialize(CArchive& ar);

	void			SetExt(LPCTSTR strExt);
	void 			SetFolder(LPCTSTR lpszPath);
	void			SetMode(SEQ_MODE eMode);
	void			SetFilenameRoot(LPCTSTR lpszRoot);
	void			SetHex(BOOL bHex);
	void			SetSeqDigits(int nDigits);

	BOOL			IsFilePresent(LPCTSTR lpszFilename);
	LPCTSTR			GetFolder();
	LPCTSTR			GetExt();
	SEQ_MODE		GetMode();
	LPCTSTR			GetFilenameRoot();
	LPCTSTR			GetNewFilename(void);
	int				GetSeqDigits(void);

protected:
	CString			m_strCurrentFilename;	// After calculating a new name, store it hear for -
											// easy access. No path and no extention.
	CString			m_strCurrentFilepath;	// Complete filename with path and extension.
	DWORD			m_nSequenceNumber;		// The current sequence number
	BOOL			m_bSeqHex;

	CFileSettings	m_FileSettings;	

public:
	void SetDefaults(void);
	CFileSettings* GetFileSettings(void);
	LPCTSTR GetCurrentFilename(void);
	void SetSequenceNumber(int nValue);
};
