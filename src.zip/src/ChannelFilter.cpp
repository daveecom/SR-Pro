#include "StdAfx.h"
#include ".\channelfilter.h"
#include ".\audiorecorder.h"


IMPLEMENT_SERIAL(CHANNEL_PARMS, CObject, VERSIONABLE_SCHEMA|1)

CChannelFilter::CChannelFilter(CAudioRecorder* pParent)
: CAudioFilter(pParent)
, m_pFormatOld(NULL)
{
	m_strObjectName = _T("CChannelFilter");
}

CChannelFilter::~CChannelFilter(void)
{
	if (m_pFormatOld != NULL)
	{
		delete [] m_pFormatOld;
		m_pFormatOld = NULL;
	}
}

void CChannelFilter::SetChannelParms(CHANNEL_PARMS Parms)
{
	m_ChannelParms = Parms;
}

CHANNEL_PARMS CChannelFilter::GetChannelParms(void)
{
	return CHANNEL_PARMS();
}

BOOL CChannelFilter::OnNewFormat(void)
{
	return FALSE;	// Prevent ripple.
}

BOOL CChannelFilter::SetFormat(LPWAVEFORMATEX lpWF)
{

	// Return all recycled buffers.
	PurgeBuffers();

	if (1)
	{
		// Copy the input format to a safe place in order to understand the old format stream.
		if (m_pFormatOld != NULL) delete [] m_pFormatOld;
		m_pFormatOld = (LPWAVEFORMATEX) new BYTE[sizeof(WAVEFORMATEX) + lpWF->cbSize];
		ASSERT(m_pFormatOld != NULL);
		CopyMemory(m_pFormatOld, lpWF, sizeof(WAVEFORMATEX) + lpWF->cbSize);

		// Make a template based on the input format.
		if (m_pFormat != NULL) delete [] m_pFormat;
		m_pFormat = (LPWAVEFORMATEX) new BYTE[sizeof(WAVEFORMATEX) + m_pFormatOld->cbSize];
		ASSERT(m_pFormat != NULL);
		CopyMemory(m_pFormat, m_pFormatOld, sizeof(WAVEFORMATEX) + m_pFormatOld->cbSize);



		// Given the conversion format, update the converted WF and pass it down the chain.
		m_ChannelParms.ConvertFormat(m_pFormat, m_pFormatOld);

		// Transmit the new converted format downstream.
		{
			//CCS Lock(&m_csNextFilter);

			// Ripple the new format throughout the entire audio chain.
			if (GetNextFilter() != NULL) GetNextFilter()->SetFormat(m_pFormat);
		}
	}

	return TRUE;
}

// TODO change opt to tgf
#pragma optimize( "t", on )

void CChannelFilter::ProcessDataBuffer(RECBUFF* pRBIn)
{
	ASSERT(m_pFormat	!= NULL);
	ASSERT(m_pFormatOld	!= NULL);
	USAMPLE		uIn, uOut;
	PBYTE		pBufferIn, pBufferOut;
	DWORD		i, j;
	double		mixLeft, mixRight;

	RECBUFF*	pRBOut = NULL;
	DWORD		nSamples = pRBIn->wavehdr.dwBytesRecorded / m_pFormatOld->nBlockAlign;
	int			bytesPerSampleIn	= m_pFormatOld->nBlockAlign;
	int			bytesPerSampleOut	= m_pFormat->nBlockAlign;

	if ((m_ChannelParms.m_Mode == Channel_Normal) && !m_ChannelParms.m_bMuteCh1 && !m_ChannelParms.m_bMuteCh2)
	{	// Nothing to convert, handle it the old way.
		__super::ProcessDataBuffer(pRBIn);
	}
	else
	{	// Convert the format or apply a channel mute.
		if (nSamples > 0)
		{
			// Allocate the output buffer based on the input buffer and the conversion data.
			switch (m_ChannelParms.m_Mode)
			{
				case Channel_Normal:

					pRBOut = pRBIn;	// Don't do anything, post same buffer
					break;

				case Channel_MonoToStereo:

					pRBOut = AllocRecbuff(nSamples * bytesPerSampleOut);
					pRBOut->ftTime	= pRBIn->ftTime;
					pRBOut->nSample	= pRBIn->nSample;
					break;

				case Channel_StereoToMono:

					pRBOut = AllocRecbuff(nSamples * bytesPerSampleOut);
					pRBOut->ftTime	= pRBIn->ftTime;
					pRBOut->nSample	= pRBIn->nSample;
					break;

				case Channel_Swap:

					pRBOut = pRBIn;	// Don't do anything, update in place.
					break;

				case Channel_LeftToStereo:

					pRBOut = pRBIn;	// Don't do anything, update in place.
					break;

				case Channel_RightToStereo:

					pRBOut = pRBIn;	// Don't do anything, update in place.
					break;
			}

			// Loop to copy and mask the samples

			pBufferIn		= (PBYTE) pRBIn->databuffer;
			pBufferOut		= (PBYTE) pRBOut->databuffer;

			for (i = 0; i < nSamples; i++)
			{
				// Load a sample to be converted.

				uIn.dw = 0;

				for (j = 0; j < (DWORD) bytesPerSampleIn; j++)
				{
					uIn.b[j] = *(pBufferIn + (i*bytesPerSampleIn) + j);
				}


				// Mute the old sample based on mute flags.
				if (m_ChannelParms.m_bMuteCh1)
				{	// Mute channel 1
					if (m_pFormatOld->wBitsPerSample == 8)
						uIn.b[0] = 0x80;	// Zero this sample's left channel
					else
						uIn.s[0] = 0;		// Ditto: 16 bit
				}

				if (m_ChannelParms.m_bMuteCh2)
				{	// Mute channel 2
					if (m_pFormatOld->wBitsPerSample == 8)
						uIn.b[1] = 0x80;	// Zero this sample's right channel
					else
						uIn.s[1] = 0;		// Ditto: 16 bit
				}

				// Convert sample to the new format now.

				uOut.dw = 0;

				switch(m_ChannelParms.m_Mode)
				{
					case Channel_Normal:

						uOut = uIn;		// Direct sample copy
						break;
			
					case Channel_MonoToStereo:

						if (m_pFormatOld->wBitsPerSample == 8)
						{
							uOut.b[0] = uIn.b[0];	// Copy left (mono) to left.
							uOut.b[1] = uIn.b[0];	// Copy left to right
						}
						else
						{
							uOut.s[0] = uIn.s[0];	// Copy left (mono) to left.
							uOut.s[1] = uIn.s[0];	// Copy left to right
						}
						break;
			
					case Channel_StereoToMono:

						if (m_pFormatOld->wBitsPerSample == 8)
						{
							mixLeft		= _8To16(uIn.b[0]);
							mixRight	= _8To16(uIn.b[1]);
						}
						else
						{
							mixLeft		= uIn.s[0];
							mixRight	= uIn.s[1];
						}

						// Mix the two channels here.
						mixLeft += mixRight;

						// attenuate the combined mono output since we
						// added the left and right channels.
						// Attenuation isn't needed if one is masked.
						if (!m_ChannelParms.m_bMuteCh1 && !m_ChannelParms.m_bMuteCh2)
							mixLeft *= .5;

						// Apply a limiter to prevent wrap
						mixLeft = min(max(mixLeft, -32768), 32767);

						if (m_pFormatOld->wBitsPerSample == 8)
							uOut.b[0] = _16To8((SHORT) mixLeft);
						else
							uOut.s[0] = (SHORT) mixLeft;

						break;
			
					case Channel_Swap:
			
						if (m_pFormatOld->wBitsPerSample == 8)
						{
							uOut.b[0] = uIn.b[1];
							uOut.b[1] = uIn.b[0];
						}
						else
						{
							uOut.s[0] = uIn.s[1];
							uOut.s[1] = uIn.s[0];
						}

						break;
			
					case Channel_LeftToStereo:
			
						if (m_pFormatOld->wBitsPerSample == 8)
						{
							uOut.b[0] = uIn.b[0];
							uOut.b[1] = uIn.b[0];
						}
						else
						{
							uOut.s[0] = uIn.s[0];
							uOut.s[1] = uIn.s[0];
						}

						break;
			
					case Channel_RightToStereo:
			
						if (m_pFormatOld->wBitsPerSample == 8)
						{
							uOut.b[0] = uIn.b[1];
							uOut.b[1] = uIn.b[1];
						}
						else
						{
							uOut.s[0] = uIn.s[1];
							uOut.s[1] = uIn.s[1];
						}

						break;
				}
				
				// Store the new converted sample into the output buffer.
				for (j = 0; j < (DWORD) bytesPerSampleOut; j++)
				{
					*(pBufferOut + (i*bytesPerSampleOut) + j) = uOut.b[j];
				}
			}

			// The new output buffer is full. Now make sure the counts are correct.
			pRBOut->wavehdr.dwBytesRecorded = nSamples * bytesPerSampleOut;

			// Scan the data now that we've converted it.
			ScanTheBuffer(&pRBOut->wavehdr, m_pFormat);

		}	// Samples > 0

		if (pRBIn != pRBOut) FreeRecbuff(pRBIn);
		if (pRBOut != NULL) Transmit(pRBOut);

	}	// Format was converted
}

#pragma optimize( "t", off )

// Copy input format to output, then convert output to channel-converted format.
// Both buffers must be exactly the same size.
void CHANNEL_PARMS::ConvertFormat(LPWAVEFORMATEX lpWFOut, LPWAVEFORMATEX lpWFIn)
{
	ASSERT(lpWFIn != NULL);
	ASSERT(lpWFOut != NULL);
	
	// Make duplicate of input
	CopyMemory(lpWFOut, lpWFIn, sizeof(WAVEFORMATEX) + lpWFIn->cbSize);

	// Change the fields to reflect the new format.
	switch(m_Mode)
	{
		case Channel_MonoToStereo:

			lpWFOut->nAvgBytesPerSec	<<= 1;
			lpWFOut->nBlockAlign		<<= 1;
			lpWFOut->nChannels			=	2;
			break;

		case Channel_StereoToMono:

			lpWFOut->nAvgBytesPerSec	>>= 1;
			lpWFOut->nBlockAlign		>>= 1;
			lpWFOut->nChannels			=	1;
			break;
	}
}

// Reset the parms to their initial states.
void CHANNEL_PARMS::Clear(void)
{
	m_Mode		= Channel_Normal;	// Default mode.
	m_bMuteCh1	= FALSE;
	m_bMuteCh2	= FALSE;
}
