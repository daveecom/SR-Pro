// Scheduler.cpp : implementation file
//

#include "stdafx.h"
#include ".\scheduler.h"

IMPLEMENT_SERIAL(CScheduleController,	CObject,	1)
IMPLEMENT_SERIAL(CScheduleItem,			CObject,	1)

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// CScheduleController
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

// Do not use this constructor except for serialize
CScheduleController::CScheduleController()
{
	TF;

	m_strFile.Empty();
}

CScheduleController::~CScheduleController()
{
	TF;

	AbortSchedules();

	if (m_ArraySched.GetSize() > 0)
		ClearArray();
}

// Enqueue the CScheduleItem
int CScheduleController::AddAlarm(CScheduleItem * pItem, BOOL bQuiet)
{
	TF;

	int				index;
	BOOL			rc;
	CScheduleItem*	pDup = NULL;
	CString			str1, str2;

	CCS	Lock(&m_csController);

	index = m_ArraySched.GetSize();	// Next free index = array size before add
	rc = m_ArraySched.Add(pItem);
	ASSERT(rc);					// Add failed.
	ASSERT(m_ArraySched.GetSize() == (index + 1));	// Verify that it got added.

	pItem->SetContainer(this);

	if (IsOverlapped(pItem, &pDup))
	{
		pItem->EnableAlarm(FALSE);
		if (!bQuiet)
		{
			str1.Format(_T("This new schedule has a conflict with an existing schedule:"));
			str2.Format(_T("\nConflicting item name = '%s'."), pDup->GetName());
			str1 += str2;
			str1 += _T("\nNew schedule has been disabled.");
			AfxMessageBox(str1);
		}
	}

	return index;
}

void CScheduleController::DeleteAlarm(int Index)
{
	TF;

	CScheduleItem*	pAlarm;
	ASSERT(Index < m_ArraySched.GetSize());

	CCS	Lock(&m_csController);

	pAlarm = m_ArraySched[Index];
	pAlarm->Delete();

	m_ArraySched.RemoveAt(Index);

	//SetModifiedFlag();
}

// Dequeue an alarm, but leave the CScheduleItem in storage.
void CScheduleController::RemoveAlarm(int Index)
{
	TF;

	CScheduleItem*	pAlarm;
	ASSERT(Index < m_ArraySched.GetSize());

	pAlarm = m_ArraySched[Index];
	pAlarm->SetContainer(NULL);

	m_ArraySched.RemoveAt(Index);

	//SetModifiedFlag();
}

int CScheduleController::GetCount()
{
	//TF;

	return m_ArraySched.GetSize();
}

CScheduleItem* CScheduleController::GetSchedule(int Index)
{
	//TF;

	ASSERT(Index < m_ArraySched.GetSize());

	return m_ArraySched[Index];
}

void CScheduleController::EnableAlarm(int Index, BOOL bEnable)
{
	CScheduleItem	*pDup;
	CString			str1, str2;

	TF;

	ASSERT(Index < m_ArraySched.GetSize());

	CCS	Lock(&m_csController);

	ASSERT(m_ArraySched.GetSize() > 0);
	ASSERT(Index < m_ArraySched.GetSize());

	if (bEnable)
	{
		if (IsOverlapped(m_ArraySched[Index], &pDup))
		{
			if (pDup->IsEnabled())
			{
				m_ArraySched[Index]->EnableAlarm(FALSE);

				str1.Format(_T("This schedule has a conflict with an existing schedule:"));
				str2.Format(_T("\nConflicting item name = '%s'."), pDup->GetName());
				str1 += str2;
				str1 += _T("\nThis schedule remains disabled.");

				AfxMessageBox(str1);
			}
			else
				m_ArraySched[Index]->EnableAlarm(TRUE);
		}	// if (IsOverlapped(m_ArraySched[Index], &pDup))
		else
		{	// Not overlapped.
			m_ArraySched[Index]->EnableAlarm(TRUE);
			//if (m_ArraySched[Index]->IsShowOnNow())
			//	AskUserRecordingInProgress(m_ArraySched[Index]);
		}
	}
	else
	{
		m_ArraySched[Index]->EnableAlarm(FALSE);
	}
		


}

// return index of item found. If not found, return -1.
int CScheduleController::IndexFromID(LPCTSTR lpszID)
{
	TF;

	int			i;
	int			index = -1;
	CString		str;

	for (i = 0; i < m_ArraySched.GetSize(); i++)
	{
		str = m_ArraySched[i]->GetID();
		if (str == lpszID)
		{
			index = i;
			break;
		}
	}

	return index;
}

void CScheduleController::ClearArray(void)
{
	TF;

	int				i;
	CScheduleItem*	pItem;

	for (i = 0; i < m_ArraySched.GetSize(); i++)
	{
		pItem = m_ArraySched[i];
		ASSERT(pItem != NULL);
		pItem->Delete();
	}

	m_ArraySched.RemoveAll();

}

void CScheduleController::ActivateSchedules(void)
{
	TF;

	CScheduleItem*	pItem = NULL;
	int				i, count;

	CCS	Lock(&m_csController);

	count = m_ArraySched.GetSize();
	for (i = 0; i < count; i++)
	{
		pItem = GetSchedule(i);

		pItem->SetControlHwnd(m_hControlHwnd);	// Connect the control window

		pItem->ArmSchedule();

		if (pItem->IsEnabled())
		{
			if (pItem->IsShowOnNow())
			{
				if (AskUserRecordingInProgress(pItem))
				{
					pItem->PostAlarmMessage(0);
				}
			}
		}
	}
}


void CScheduleController::AbortSchedules(void)
{
	TF;

	CScheduleItem*	pItem = NULL;
	int				i, count;

	CCS	Lock(&m_csController);

	count = m_ArraySched.GetSize();
	for (i = 0; i < count; i++)
	{
		pItem = GetSchedule(i);
		pItem->AbortSchedule();
	}
}


BOOL CScheduleController::AskUserRecordingInProgress(const CScheduleItem* pItem)
{
	TF;

	TCHAR	szAskMsg[]	= _T("The show: '%s' is already in progress.\nShould I start recording it now?\n(YES | NO)");
	CString	strMsg1, strMsg2;
	SYSTEMTIME	tm;
	INT_PTR		result;

	FileTimeToSystemTime(&pItem->GetStart().ft, &tm);

	strMsg1.Format(szAskMsg, pItem->GetName());
	strMsg2.Format(_T("(started at: %02d:%02d)\n%s"), tm.wHour, tm.wMinute, strMsg1);

	result = AfxMessageBox(strMsg2, MB_ICONEXCLAMATION|MB_YESNO);

	return (result == IDYES);
}

// Bandaid fix. Call before using schedules to connect main control panel to controller
void CScheduleController::SetControlHwnd(HWND hWnd)
{
	TF;

	int		count, i;

	CCS	Lock(&m_csController);

	m_hControlHwnd = hWnd;

	count = m_ArraySched.GetSize();

	for (i = 0; i < count; i++)
	{
		GetSchedule(i)->SetControlHwnd(hWnd);
	}
}

// Get the scheduled item that will start next.
CScheduleItem* CScheduleController::GetNextScheduledItem(void)
{
	//TF;

	int		i, count;
	CScheduleItem*	pItemSoonest = NULL;
	CScheduleItem*	pItem;

	CCS	Lock(&m_csController);

	PurgeJunk();

	count = m_ArraySched.GetSize();
	for (i = 0; i < count; i++)
	{
		pItem = GetSchedule(i);

		if (pItem->IsEnabled())
		{
			if (pItemSoonest == NULL) pItemSoonest = pItem;	// Load 1st time value

			if (pItem != pItemSoonest)
			{
				// Compare to see which item has an earlier dt.
				if (pItem->GetStart().ll < pItemSoonest->GetStart().ll)
				{
					pItemSoonest = pItem;
				}
			}
		}
	}

	return	pItemSoonest;
}

void CScheduleController::Serialize(CArchive& ar)
{
	TF;

	CScheduleItem*	pItem;
	DWORD			dwNumRecords = m_ArraySched.GetSize();
	int				i;

	CCS	Lock(&m_csController);

	if (ar.IsStoring())
	{	// storing code

		ar << dwNumRecords;	// File header must contain the number of records stored.

		for (i = 0; i < (int) dwNumRecords; i++)
		{
			m_ArraySched[i]->Serialize(ar);
		}
	}
	else
	{	// loading code
		ar >> dwNumRecords;	// File header contains the number of records stored.
		//ASSERT(dwNumRecords > 0);

		ClearArray();

		for (i = 0; i < (int) dwNumRecords; i++)
		{
			pItem = new CScheduleItem;
			ASSERT(pItem != NULL);

			pItem->Serialize(ar);
			AddAlarm(pItem, TRUE);
		}

		//SetModifiedFlag(FALSE);		// Clear mod flag since we just loaded fresh copy from R/O
	}
}

CScheduleItem* CScheduleController::GetCurrentShow(void)
{
	TF;

	int	i, count = m_ArraySched.GetSize();
	CScheduleItem *pItem = NULL, *pTemp = NULL;

	for (i = 0; i < count; i++)
	{
		pTemp = GetSchedule(i);
		if (pTemp->IsShowOnNow())
		{
			pItem = pTemp;
			break;
		}
	}

	return pItem;
}

// Remove expired items.
void CScheduleController::PurgeJunk(void)
{
	int	i;

	CCS	Lock(&m_csController);

	for (i = 0; i < m_ArraySched.GetSize(); i++)
	{
		if (m_ArraySched[i]->IsExpired())
		{
			DeleteAlarm(i);
			--i;	// Just deleted N. Set ptr to access N+1 next time
					// through loop.
		}
	}
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// CScheduleItem
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////


CScheduleItem::CScheduleItem()
: m_bShuttingDown(FALSE)
{
	TF;


	////// Set up initial values (invalid for now until file read)
	m_uStart.ll		= 0;
	m_uDuration.ll	= 0;
	m_strName.Empty();
	m_strID.Empty();
	m_bEnabled		= FALSE;
	ZeroMemory(&m_RepeatParms, sizeof(REPEAT_PARMS));
	m_eType			= Alarm_Undefined;
	//////

	m_pContainer	= NULL;			// CScheduleController that we're in.
	m_bArmed		= FALSE;		// Indicate not armed yet.

	ZeroMemory(&m_msg[0], sizeof(m_msg));

	// For now, just set up the start-stop control messages. Will clean up this mess later.
	m_msg[0].message	= UWM_CONTROL_RECORDSTART;
	m_msg[0].wParam		= (WPARAM) this;
	m_msg[0].lParam		= 0;

	m_msg[1].message	= UWM_CONTROL_RECORDSTOP;
	m_msg[1].wParam		= (WPARAM) this;
	m_msg[1].lParam		= 0;

}

CScheduleItem::~CScheduleItem()
{
	TF;

	m_bShuttingDown = TRUE;

	for (int i = 0; i < ((sizeof m_clock) / (sizeof m_clock[0])); i++)
	{
		m_clock[i].KillAlarm();
		m_clock[i].ResetRepeats();
	}
}

BOOL CScheduleItem::CreateStartStop(LPCTSTR lpszName, FILETIME tStart, FILETIME tDuration,
			REPEAT_PARMS RepeatParms, HWND hReceiver)
{
	TF;

	SYSTEMTIME	tm;
	UFT			u1;

	m_strName		= lpszName;
	m_uStart.ft		= tStart;
	m_uDuration.ft	= tDuration;
	m_RepeatParms	= RepeatParms;

	m_bEnabled		= TRUE;
	m_eType			= Alarm_StartStop;
	m_bArmed		= FALSE;		// Indicate not armed yet.

	ASSERT(_tcslen(lpszName));		// Name not provided
	ASSERT(m_uStart.ll);			// start date/time is !null, already created.
	ASSERT(m_uDuration.ll);			// duration is zero. Invalid for start-stop

	////// Set the alarm ID to YYMMDDHHMMSSMMM = time of creation
	GetLocalTime(&tm);
	m_strID.Format(_T("%02d%02d%02d%02d%02d%02d%03d"),
		tm.wYear % 100, tm.wMonth, tm.wDay,
		tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);
	//////

	if (IsShowOnNow())
	{
		// Set stop alarm.
		u1.ll = m_uStart.ll + m_uDuration.ll;
		m_clock[1].SetAlarm(u1.ft, AlarmCB, (DWORD_PTR) this);
	}
	else
	{	// Show is not on now. When is the next scheduled airing?
		BringUpToDate();

		if (m_uStart.ll != 0)
		{
			// Set start alarm.
			m_clock[0].SetAlarm(m_uStart.ft, AlarmCB, (DWORD_PTR) this);
		}
		else
		{	// Show is over and not re-scheduled.
			return FALSE;
		}
	}

	return TRUE;
}

// Call this function after changing the schedule to re-initialize the
// schedule clocks.
BOOL CScheduleItem::ReCreateStartStop()
{
	TF;

	UFT			u1;

	if (IsShowOnNow())
	{
		// Set stop alarm.
		u1.ll = m_uStart.ll + m_uDuration.ll;
		m_clock[1].SetAlarm(u1.ft, AlarmCB, (DWORD_PTR) this);
	}
	else
	{	// Show is not on now. When is the next scheduled airing?
		BringUpToDate();

		if (m_uStart.ll != 0)
		{
			// Set start alarm.
			m_clock[0].SetAlarm(m_uStart.ft, AlarmCB, (DWORD_PTR) this);
		}
		else
		{	// Show is over and not re-scheduled.
			return FALSE;
		}
	}

	return TRUE;
}

LPCTSTR CScheduleItem::GetID(void) const
{
	TF;

	return (LPCTSTR) m_strID;
}

void CScheduleItem::EnableAlarm(BOOL bEnable)
{
	TF;

	m_bEnabled = bEnable;
}

void CScheduleItem::Delete(void)
{
	TF;

	delete this;
}

void CScheduleItem::Serialize(CArchive& ar)
{
	TF;

	UFT				uLocal;
	UFT				uStart, uDuration;
	REPEAT_PARMS	RepeatParms;
	CString			strName, strID;
	BOOL			bEnabled;

	if (ar.IsStoring())
	{	// storing code
		ar << m_uStart.ll;
		ar << m_uDuration.ll;
		ar << m_strName;
		ar << m_strID;
		ar << m_bEnabled;
		ar.Write(&m_RepeatParms, sizeof(REPEAT_PARMS));
		ar.Write(&m_eType, sizeof(m_eType));
	}
	else
	{	// loading code

		ar >> uStart.ll;
		ar >> uDuration.ll;
		ar >> strName;
		ar >> strID;
		ar >> bEnabled;
		ar.Read(&RepeatParms, sizeof(REPEAT_PARMS));
		ar.Read(&m_eType, sizeof(m_eType));

		// Need to bring this alarm into a normal state since loading is done.
		m_bArmed = FALSE;		// Indicate not armed yet.

		m_clock[0].GetTime(&uLocal);

		switch (m_eType)
		{
			case Alarm_Undefined:
				ASSERT(0);
				break;

			case Alarm_Single:
				ASSERT(0);	// Need to write the re-init after serialization code
				break;

			case Alarm_StartStop:
				CreateStartStop(strName, uStart.ft, uDuration.ft, RepeatParms, NULL);
				m_strID = strID;	// Restore the previous ID from the archive,
				m_bEnabled = bEnabled;

				break;
		}
	}
}

void CScheduleItem::SetRepeat(REPEAT_PARMS Parms)
{
	TF;

	m_RepeatParms = Parms;
}

void CScheduleItem::SetStart(FILETIME tStart)
{
	TF;

	m_uStart.ft = tStart;
}

void CScheduleItem::SetDuration(FILETIME tDuration)
{
	TF;

	m_uDuration.ft = tDuration;
}

void CScheduleItem::SetName(LPCTSTR lpszName)
{
	TF;

	m_strName = lpszName;
}

// If parm == NULL, clear the container ptr, otherwise set it to pContainer.
void CScheduleItem::SetContainer(CScheduleController* pContainer)
{
	TF;

	if (pContainer != NULL) ASSERT(m_pContainer == NULL);	// Shouldn't be attached to a container yet.

	m_pContainer = pContainer;
}

LPCTSTR CScheduleItem::GetName(void) const
{
	//TF;

	return (LPCTSTR) m_strName;
}


REPEAT_PARMS CScheduleItem::GetRepeat() const
{
	//TF;

	return m_RepeatParms;
}

UFT CScheduleItem::GetStart(void) const
{
	//TF;

	return m_uStart;
}

UFT CScheduleItem::GetDuration(void) const
{
	//TF;

	return m_uDuration;
}

BOOL CScheduleItem::IsEnabled(void) const
{
	//TF;

	return m_bEnabled;
}

void CScheduleItem::ArmSchedule(void)
{
	TF;

	m_bArmed = TRUE;	// Schedule is now armed for recording.
}

void CScheduleItem::AbortSchedule(void)
{
	TF;

	m_bArmed = FALSE;

	if (IsShowOnNow())
	{
		// Cancel the timer recording in progress.

		if (m_msg[1].hwnd != 0 && m_msg[1].message != 0)
		{
			::PostMessage(m_msg[1].hwnd, m_msg[1].message,
				m_msg[1].wParam, m_msg[1].lParam);	// Stop the recording now.
		}
	}
}

BOOL CScheduleItem::IsArmed(void) const
{
	TF;

	return m_bArmed == TRUE;
}

// This is THE alarm clock alert callback. All alarms come to here to be handled.
// Most likely a window message will be sent to control a recorder.
BOOL CScheduleItem::AlarmCB(CAlarmClock* pClock, DWORD_PTR dwUserData)
{
	CScheduleItem*	pThis = (CScheduleItem*) dwUserData;
	ASSERT(pThis != NULL);

	return pThis->AlarmCB(pClock);
}

BOOL CScheduleItem::AlarmCB(CAlarmClock* pClock)
{
	TFS;

	UFT				u1, uNext;
	ASSERT(m_eType != Alarm_Undefined);

	if (m_bShuttingDown) return FALSE;

	if (pClock == &m_clock[0])	// Alert from clock 0 ?
	{	// State 0: Show start alarm received.
		if (m_msg[0].hwnd != NULL) PostAlarmMessage(0);

		u1.ll = m_uStart.ll + m_uDuration.ll;

		// Schedule the show-stop alarm and this will call-us-back when the show ends.
		m_clock[1].KillAlarm();
		m_clock[1].SetAlarm(u1.ft, AlarmCB, (DWORD_PTR) this);
	}
	else if (pClock == &m_clock[1])	// Alert from clock 1 ?
	{	// State 1: Show stop alarm received.

		if (m_msg[1].hwnd != NULL) PostAlarmMessage(1);

		// Set alarm time to the next opertunity since the show has just ended.
		uNext.ft = pClock->WhenIsLatestAlarm(m_uStart.ft, m_RepeatParms);

		if (uNext.ll != 0)
		{	// Show is over. Set next start timer.

			// In case repeat count is used, decrement it here.
			if (!m_RepeatParms.bRepeatForever &&
				m_RepeatParms.tRepeatUntil.ll == 0)
			{	// Repeat parms is not using forever or exp dt.
				if (m_RepeatParms.nRepeatCount > 0)
					m_RepeatParms.nRepeatCount--;
			}

			if (IsRepeatNecessary())
			{
				m_uStart = uNext;
				m_clock[0].SetAlarm(m_uStart.ft, AlarmCB, (DWORD_PTR) this);
			}
		}
		else
		{	// The show is over now and the alarm is not set to repeat.
			m_uStart.ll = 0;	// This tells outside controller we're expired.
			m_clock[0].KillAlarm();	// Just in case.... Oh this crappy code!?!?

			//Beep(1000,100);
			//Beep(2000,100);
		}
	}

	return TRUE;	// (actually this return value's meaning is still unknown :-)
}

BOOL CScheduleItem::IsShowOnNow(void)
{
	//TF;

	UFT			uCurrentTime, uEndTime;

	uCurrentTime	= m_clock[0].GetTime();
	uEndTime.ll		= m_uStart.ll + m_uDuration.ll;

	if (m_uStart.ll < uCurrentTime.ll && uCurrentTime.ll < uEndTime.ll)
		return TRUE;
	else
		return FALSE;

}

void CScheduleItem::SetControlHwnd(HWND hWnd)
{
	TF;

	ASSERT(hWnd != NULL);

	m_msg[0].hwnd = hWnd;
	m_msg[1].hwnd = hWnd;
}

// Used to submit the alarm message to the window message handler.
void CScheduleItem::PostAlarmMessage(int AlarmIndex)
{
	TF;

	if (IsArmed())
	if (IsEnabled())
	{
		TRACE(_T("Posting the alarm message [%d]\r\n"), AlarmIndex);

		::PostMessage(m_msg[AlarmIndex].hwnd,
						m_msg[AlarmIndex].message,
						m_msg[AlarmIndex].wParam,
						m_msg[AlarmIndex].lParam);
	}
}

CScheduleController* CScheduleItem::GetContainer(void)
{
	TF;

	return m_pContainer;
}

BOOL CScheduleItem::IsExpired(void)
{
	BOOL		bExpired = FALSE;
	UFT			u1;

	if (!IsShowOnNow())
	{
		if (m_uStart.ll < m_clock[0].GetTime().ll)
		{	// Schedule has already occurred
			u1.ft = m_clock[0].WhenIsLatestAlarm(m_uStart.ft, m_RepeatParms);
			if (u1.ll == 0) bExpired = TRUE;
		}
	}

	return bExpired;
}

// Check the repeat parms to see if a repeat is due. Return FALSE if not.
BOOL CScheduleItem::IsRepeatNecessary(void)
{
	BOOL	bResult = FALSE;

	// Follow proper precedence order: exp dt, rep forever then count.
	if (m_RepeatParms.tRepeatUntil.ll != 0)
		bResult	=	m_RepeatParms.tRepeatUntil.ll > m_clock[0].GetTime().ll;
	else
	if (m_RepeatParms.bRepeatForever || m_RepeatParms.nRepeatCount > 0)
		bResult = TRUE;

	return bResult;
}

// Bring this item to a proper state given the old alarm start and repeat parms.
void CScheduleItem::BringUpToDate(void)
{
	UFT		uTest, u1, uNext;
	UFT		uCurrent;	// Current DT

	uCurrent = m_clock[0].GetTime();

	if (m_uStart.ll != 0)
	{
		// Start with the stored start DT and find out when the show was last on before the current time.
		for(uTest = m_uStart;uTest.ll < uCurrent.ll;)
		{
			uNext.ft = m_clock[0].WhenIsNextAlarm(uTest.ft, m_RepeatParms);
			if (uNext.ll == 0)
			{	// Alarm has expired
				m_uStart.ll = 0;
				return;
			}

			if (uNext.ll > uCurrent.ll)
			{	// The next schedule is in the future. Use the uTest value we have now.
				u1.ll = uTest.ll + m_uDuration.ll;	// Get end time for this schedule.
				if (u1.ll >= uCurrent.ll)
				{	// Show is on right now.
					m_uStart = uTest;	// Alarm time is our current show.
					return;
				}
				else
				{	// The show is over.
					m_uStart = uNext;
					return;
				}
			}

			uTest = uNext;	// Increment
		}
	}

	// If we fell out of the loop (or never entered it) then the current alarm DT
	// is already in the future and we can't backtrack, so just give up and do 
	// nothing.
}

BOOL CScheduleController::IsOverlapped(const CScheduleItem* pNewItem, CScheduleItem** ppDuplicateItem)
{
	const CScheduleItem	*pItem1;
	CScheduleItem	*pItem2;
	BOOL			bIsOverlapped	= FALSE;
	UFT				uStart1, uStart2, uEnd1, uEnd2;
	int				i;

	CCS				Lock(&m_csController);

	ASSERT(ppDuplicateItem != NULL);

	pItem1 = pNewItem;
	for (i = 0; i < m_ArraySched.GetSize(); i++)
	{
		pItem2 = m_ArraySched[i];
		if (pItem2 != pItem1)
		{	// Not the same item
			uStart1 = pItem1->GetStart();
			uStart2 = pItem2->GetStart();

			uEnd1.ll = uStart1.ll + pItem1->GetDuration().ll;
			uEnd2.ll = uStart2.ll + pItem2->GetDuration().ll;

			//if ((uStart1.ll <= uStart2.ll && uEnd1.ll >= uStart2.ll) ||
			//	(uStart1.ll <= uEnd2.ll && uEnd1.ll >= uEnd2.ll))
			if (IsFutureOverlap(pItem1, pItem2))
			{
				bIsOverlapped = TRUE;
				*ppDuplicateItem = pItem2;
			}
		}
	}

	return bIsOverlapped;
}

BOOL CScheduleController::IsFutureOverlap(const CScheduleItem* pItem1, CScheduleItem* pItem2)
{
	REPEAT_PARMS		repeat1, repeat2;
	CSimpleArray<UFT>	array1;
	CSimpleArray<UFT>	array2;
	UFT					uStart1, uEnd1, uStart2, uEnd2;
	UFT					u1;
	CAlarmClock			clock;
	BOOL				bOverlapped = FALSE;
	int					i;
	int					i1, j1, i2, j2;

	ASSERT(pItem1 != NULL);
	ASSERT(pItem2 != NULL);

	repeat1 = pItem1->GetRepeat();
	repeat2 = pItem2->GetRepeat();

	// Build 1st array of future DTs.
	array1.RemoveAll();
	for (i = 0, u1 = pItem1->GetStart(); i < 100; i++)
	{
		if (u1.ll == 0) break;	// Break if no more future items.

		// Save current schedule into table.
		array1.Add(u1);

		// Check for other repeat end conditions to end the loop.
		if (repeat1.tRepeatUntil.ll != 0)
		{	// Check for repeat until DT
			if (repeat1.tRepeatUntil.ll >= clock.GetTime().ll) break;	// Expired DT
		}
		else if (!repeat1.bRepeatForever && repeat1.nRepeatCount == 0)
		{
			break;
		}

		// Compute next repeat event
		u1.ft = clock.WhenIsNextAlarm(u1.ft, repeat1);
		if (u1.ll == 0) break;

		// Update repeat counter if used.
		if (repeat1.tRepeatUntil.ll == 0 && repeat1.bRepeatForever == FALSE &&
			repeat1.nRepeatCount > 0)
		{
			repeat1.nRepeatCount--;
		}
	}

	// Build 2nd array of future DTs.
	array2.RemoveAll();
	for (i = 0, u1 = pItem2->GetStart(); i < 100; i++)
	{
		if (u1.ll == 0) break;	// Break if no more future items.

		// Save current schedule into table.
		array2.Add(u1);

		// Check for other repeat end conditions to end the loop.
		if (repeat2.tRepeatUntil.ll != 0)
		{	// Check for repeat until DT
			if (repeat2.tRepeatUntil.ll >= clock.GetTime().ll) break;	// Expired DT
		}
		else if (!repeat2.bRepeatForever && repeat2.nRepeatCount == 0)
		{
			break;
		}

		// Compute next repeat event
		u1.ft = clock.WhenIsNextAlarm(u1.ft, repeat2);
		if (u1.ll == 0) break;

		// Update repeat counter if used.
		if (repeat2.tRepeatUntil.ll == 0 && repeat2.bRepeatForever == FALSE &&
			repeat2.nRepeatCount > 0)
		{
			repeat2.nRepeatCount--;
		}
	}

	// Scan both arrays and look for an overlap.
	for (i1 = 0, j1 = array1.GetSize(); i1 < j1; i1++)
	{
		uStart1		= array1[i1];
		uEnd1.ll	= uStart1.ll + pItem1->GetDuration().ll;

		for (i2 = 0, j2 = array2.GetSize(); i2 < j2; i2++)
		{
			uStart2		= array2[i2];
			uEnd2.ll	= uStart2.ll + pItem2->GetDuration().ll;

			if ((uStart1.ll <= uStart2.ll && uEnd1.ll >= uStart2.ll) ||
				(uStart1.ll <= uEnd2.ll && uEnd1.ll >= uEnd2.ll))
			{
				bOverlapped = TRUE;
			}
		}
	}

	return bOverlapped;
}

void CScheduleController::SetFile(LPCTSTR lpFilepath)
{
	m_strFile = lpFilepath;
}

// Save the schedule file.
BOOL CScheduleController::Save(void)
{
	CFileException		cfe;
	CArchiveException	cae;
	TCHAR				msg[256] = {0};

	ASSERT(!m_strFile.IsEmpty());

	TRY
	{
		CFile		file((LPCTSTR) m_strFile, CFile::modeCreate|CFile::modeWrite|CFile::shareDenyWrite);
		CArchive	archive(&file, CArchive::store);
	
		Serialize(archive);
		archive.Close();

		return TRUE;
	}
	CATCH (CFileException, e)
	{
		e->GetErrorMessage(msg, (sizeof msg * sizeof(TCHAR)));
		AfxMessageBox(msg);
		return FALSE;
	}
	AND_CATCH (CArchiveException, e)
	{
		e->GetErrorMessage(msg, e->m_cause);
		AfxMessageBox(msg);
		return FALSE;
	}
	END_CATCH
}

// Load the schedule file.
BOOL CScheduleController::Load(void)
{
	CFileException		cfe;
	CArchiveException	cae;
	TCHAR				msg[256] = {0};

	ASSERT(!m_strFile.IsEmpty());	// Let's look into this. Unknown why this happened yet.

	if(!m_strFile.IsEmpty())
	{
		TRY
		{
			CFile		file((LPCTSTR) m_strFile, CFile::modeRead|CFile::shareDenyWrite);
			CArchive	archive(&file, CArchive::load);
		
			Serialize(archive);
			archive.Close();

			return TRUE;
		}
		CATCH (CFileException, e)
		{
			e->GetErrorMessage(msg, (sizeof msg * sizeof(TCHAR)));
			TRACE(_T("%s\r\n"), msg);
			//AfxMessageBox(msg);
			return FALSE;
		}
		AND_CATCH (CArchiveException, e)
		{
			e->GetErrorMessage(msg, e->m_cause);
			TRACE(_T("%s\r\n"), msg);
			//AfxMessageBox(msg);
			return FALSE;
		}
		END_CATCH
	}

	return FALSE;
}

LPCTSTR CScheduleController::GetFile(void)
{
	return m_strFile;
}
