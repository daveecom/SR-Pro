#include <atlstr.h>

#ifdef _UNICODE
// UNICODE strings to use in messages.
#define WIDEN2(x)		L ## x
#define WIDEN(x)		WIDEN2(x)
#define __TFILE__		WIDEN(__FILE__)
#define __TDATE__		WIDEN(__DATE__)
#define __TFUNCTION__	WIDEN(__FUNCTION__)
#define __TFUNCDNAME__	WIDEN(__FUNCDNAME__)
#define __TFUNCSIG__	WIDEN(__FUNCSIG__)
#else
#define __TFILE__		__FILE__
#define __TDATE__		__DATE__
#define __TFUNCTION__	__FUNCTION__
#define __TFUNCDNAME__	__FUNCDNAME__
#define __TFUNCSIG__	__FUNCSIG__
#endif

// Class to automatically trace the entry and exit of a function when declared in the
// scope of the function. Only used with the TF macro below.
class CTF
{
public:
	__forceinline CTF(LPCTSTR lpszFuncName, PVOID pThis)	// Use with member functs
	{
		// Trace the function entry
		m_Fn	= lpszFuncName;
		m_pThis	= (DWORD_PTR) pThis;

		TRACE(_T("Function: %s(Entry)\t\t this->0x%08x\r\n"), m_Fn, pThis);
	}

	__forceinline CTF(LPCTSTR lpszFuncName)			// Use with static and global functs
	{
		// Trace the function entry
		m_Fn	= lpszFuncName;
		m_pThis	= (DWORD_PTR) 0xffffffff;

		TRACE(_T("Function: %s(Entry)\r\n"), m_Fn);

	}

	__forceinline ~CTF()
	{
		// Trace the function exit
		if (m_pThis != 0xffffffff)
			TRACE(_T("Function: %s(Exit)\t\t this->0x%08x\r\n"), m_Fn, m_pThis);
		else
			TRACE(_T("Function: %s(Exit)\r\n"), m_Fn);
	}

	CString			m_Fn;
	DWORD_PTR		m_pThis;
};

// Declare this macro in each function that should be traced. The debug log will show the
// entry and exit messages of the funciton traced.
#define TF	CTF	_FunctionTrace(__TFUNCTION__, (PVOID) this)	// Used with all object members
#define TFS	CTF	_FunctionTrace(__TFUNCTION__)		// Used with static or global functions
