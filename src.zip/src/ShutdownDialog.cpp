// ShutdownDialog.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "ShutdownDialog.h"
#include ".\shutdowndialog.h"

// CShutdownDialog dialog

IMPLEMENT_DYNAMIC(CShutdownDialog, CDialog)
CShutdownDialog::CShutdownDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CShutdownDialog::IDD, pParent)
	, m_nCountdownValue(10)
{
}

CShutdownDialog::~CShutdownDialog()
{
}

void CShutdownDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_CLOCK, m_Static_Clock);
	DDX_Control(pDX, IDC_STATIC_TEXT, m_Static_Text);
}


BEGIN_MESSAGE_MAP(CShutdownDialog, CDialog)

	//ON_MESSAGE(UWM_ALARM, OnAlarm)

	ON_WM_TIMER()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_PREVENT, OnPreventButton)
	ON_BN_CLICKED(IDC_BUTTON_ALLOW, OnAllowButton)
END_MESSAGE_MAP()


// CShutdownDialog message handlers

BOOL CShutdownDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_Font_Clock.CreateFont(-24, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
		OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
		_T("Sans Serif"));

	m_Font_Text.CreateFont(-18, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
		OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
		_T("Sans Serif"));

	m_Static_Clock.SetFont(&m_Font_Clock);
	m_Static_Text.SetFont(&m_Font_Text);

	UpdateClock();

	SetTimer(0, 1000, NULL);

	::SetFocus(GetDlgItem(IDC_BUTTON_ALLOW)->GetSafeHwnd());
	return FALSE;
}

// Prevent escape button from closing this dlg.
void CShutdownDialog::OnCancel()
{
}


void CShutdownDialog::OnTimer(UINT nIDEvent)
{
	--m_nCountdownValue;

	UpdateClock();

	if (m_nCountdownValue == 0)
	{	// Allow the shutdown to continue.

		OnOK();
	}
}

void CShutdownDialog::UpdateClock(void)
{
	CString str;

	str.Format(_T("%d"), m_nCountdownValue);
	m_Static_Clock.SetWindowText(str);
}

void CShutdownDialog::OnClose()
{
	KillTimer(0);

	CDialog::OnClose();
}

void CShutdownDialog::OnPreventButton()
{
	__super::OnCancel();	// Prevent the system from shutting down.
}

void CShutdownDialog::OnAllowButton()
{
	OnOK();	// Allow the shutdown to continue.
}
