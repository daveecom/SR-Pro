#pragma once
#include "afxwin.h"
#include "resource.h"


// CDlgEnterKey dialog

class CDlgEnterKey : public CDialog
{
	DECLARE_DYNAMIC(CDlgEnterKey)

public:
	CDlgEnterKey(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgEnterKey();

// Dialog Data
	enum { IDD = IDD_DIALOG_ENTERKEY };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	CEdit m_Edit_Name;
	CEdit m_Edit_Key;
public:
	virtual BOOL OnInitDialog();
protected:
	virtual void OnOK();
};
