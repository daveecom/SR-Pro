// ProgressStatic.cpp : implementation file
//

#include "stdafx.h"
#include "ProgressStatic.h"
#include ".\progressstatic.h"


// CProgressStatic

IMPLEMENT_DYNAMIC(CProgressStatic, CStatic)

CProgressStatic::CProgressStatic()
: m_bVert(FALSE)
, m_RangeLow(0)
, m_RangeHigh(100)
, m_Pos(0)
, m_bScaleDB(FALSE)
{
	m_bkColor		= RGB(000,000,000);
	m_color			= RGB(255,000,000);

	unsigned short linearVal = 0;

	for (linearVal = 1; linearVal < 1000; linearVal ++)
	{
		double a = linearVal / 65536.0;
		double b = LinearToDb(a);
		//TRACE(_T("%f converts to %f db.\r\n"), a, b);
	}
}

CProgressStatic::~CProgressStatic()
{
}


BEGIN_MESSAGE_MAP(CProgressStatic, CStatic)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
END_MESSAGE_MAP()


void CProgressStatic::SetVert(BOOL bVert)
{
	m_bVert = bVert;
}

void CProgressStatic::SetRange(double low, double high)
{
	m_RangeLow	= low;
	m_RangeHigh	= high;
}


void CProgressStatic::SetPos(double Pos)
{
	double	fPos, fRatio;
	// Force the pos to stay within the given range.
	fPos = max(min(Pos, m_RangeHigh), m_RangeLow);

	if (m_bScaleDB)
	{	// db
		fRatio = fPos / (m_RangeHigh - m_RangeLow);
		fPos = LinearToDb(fRatio);

		m_Pos = abs(fPos) / 100;		// 0 - 1

		m_Pos = (m_RangeHigh - m_RangeLow) - (m_Pos * (m_RangeHigh - m_RangeLow));
	}
	else
	{	// Linear
		m_Pos = fPos;
	}

	Invalidate(FALSE);
}

BOOL CProgressStatic::OnEraseBkgnd(CDC* pDC)
{
	CRect	rect;

	GetWindowRect(rect);

	if (!IsWindowEnabled())
		pDC->FillSolidRect(rect, RGB(255,255,000));

	return TRUE;
}

void CProgressStatic::OnPaint()
{
	CRect		rect;
	CRect		rectBarH;	// This is the movable part of the bar. (horiz bar
	CRect		rectBarV;	// This is the movable part of the bar. (vert bar
	double		hLen, vLen;
	double		ratio;
	CPaintDC	dc(this); // device context for painting

	if (!IsWindowEnabled()) return;	// prevent drawing if disabled

	GetClientRect(&rect);

	// Calculate the new rect based on the input value.
	ratio = (double) m_Pos / (double) (m_RangeHigh - m_RangeLow);
	vLen = (DWORD) (((double) rect.Height() * ratio) + .5);
	hLen = (DWORD) (((double) rect.Width() * ratio) + .5);
	rectBarH		= rect;
	rectBarV		= rect;
	rectBarH.right	= (LONG) hLen;
	rectBarV.top	= (LONG) rectBarV.bottom - (LONG) vLen;

	// Draw the background
	dc.FillSolidRect(rect, m_bkColor);

	if (m_bVert)
		dc.FillSolidRect(rectBarV, m_color);
	else
		dc.FillSolidRect(rectBarH, m_color);
}

CProgressVU::CProgressVU(void)
{
	m_MaxMarker.SetRange(40);
	for(int i = 0; i < 40; i++) m_MaxMarker.AddValue(0);
	m_MaxMarker.ForceValue(32767);
	m_color				= RGB(000,000,255);
	m_ColorTick			= RGB(000,000,000);
	m_VoxPos			= 0;
	m_bMouseButtonDown	= FALSE;
	m_bMousePosIsValid	= FALSE;
}

CProgressVU::~CProgressVU(void) {}

BEGIN_MESSAGE_MAP(CProgressVU, CProgressStatic)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

void CProgressVU::OnPaint()
{
	CRect		rect;
	CRect		rectBarH;	// This is the movable part of the bar. (horiz bar
	CRect		rectBarV;	// This is the movable part of the bar. (vert bar
	CRect		rectTick;	// Used to draw the max level tickmark
	int			hLen, vLen;
	double		ratio/*, ratioTick*/;
	COLORREF	amber	= RGB(255, 128, 000);
	COLORREF	red		= RGB(255, 000, 000);
	COLORREF	color;	// changes while drawing depending on level
	double		a = .80;	// Threshhold from Low level to medium-high (green-amber)
	double		c, n, nOut;

	CPaintDC	dc(this); // device context for painting
	CDC			dcBfr;	// dbl bfr dc

	if (!IsWindowEnabled()) return;	// prevent drawing if disabled

	dcBfr.CreateCompatibleDC(&dc);
	dcBfr.SaveDC();

	GetClientRect(&rect);

	if (m_bmBuffer.GetSafeHandle() == NULL)
		m_bmBuffer.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height());

	dcBfr.SelectObject(&m_bmBuffer);

	dcBfr.FillSolidRect(rect, m_bkColor);		// Draw the background

	// Calculate and draw the new rect based on the input value.
	ratio = (double) m_Pos / (double) (m_RangeHigh - m_RangeLow);
	vLen = (DWORD) (((double) rect.Height()	* ratio) + .5);
	hLen = (DWORD) (((double) rect.Width()	* ratio) + .5);
	rectBarH		= rect;
	rectBarV		= rect;
	rectBarH.right	= hLen;
	rectBarV.top	= rectBarV.bottom-vLen;

	// Adjust the bar color depending on the audio level
	if (ratio < a)
	{
		color = RGB(000,255,000);
	}
	else
	{
		c = 1 - a;
		n = ratio;
		nOut = 1 / c * (n - a);
		color = GetBlendedColor(nOut, RGB(255,255,000), RGB(255,000,000));
	}

	// Draw the bar
	if (m_bVert)
		dcBfr.FillSolidRect(rectBarV, color);
	else
		dcBfr.FillSolidRect(rectBarH, color);

	DrawVoxSetting(&dcBfr);

	// Calc the max tickmark.
	DWORD avg = m_MaxMarker.GetAvg(30);
	if (m_bVert)
	{	// Vert
		if ((DWORD) rectBarV.top <= avg)
		{
			m_ColorTick = color;
			m_MaxMarker.ForceValue(rectBarV.top);
		}
		else
		{
			m_MaxMarker.AddValue(rectBarV.top);
		}

		// Move the tickmark
		rectTick.SetRect(rectBarV.left, avg-2, rectBarV.right, avg);
		if (rectTick.top < 0) rectTick.top = 0;

		//ratioTick = ((double) (rect.Height() - avg) / (double) rect.Height());

		// Draw the tickmark
		dcBfr.FillSolidRect(&rectTick, m_ColorTick);
	}
	else
	{	// Horiz
		if ((DWORD) rectBarH.right >= avg)
		{
			m_ColorTick = color;
			m_MaxMarker.ForceValue(rectBarH.right);
		}
		else
			m_MaxMarker.AddValue(rectBarH.right);

		dcBfr.MoveTo(rectBarH.top,		avg);
		dcBfr.LineTo(rectBarH.bottom,	avg);
	}

	DrawGrid(&dcBfr);

	dc.BitBlt(0, 0, rect.Width(), rect.Height(), &dcBfr, 0, 0, SRCCOPY);

	dcBfr.RestoreDC(-1);
}

COLORREF CProgressVU::GetBlendedColor(double fRatio, COLORREF clrLow, COLORREF clrHigh)
{
	int			r, g, b;

	r = Interpolate(fRatio, GetRValue(clrLow), GetRValue(clrHigh));
	g = Interpolate(fRatio, GetGValue(clrLow), GetGValue(clrHigh));
	b = Interpolate(fRatio, GetBValue(clrLow), GetBValue(clrHigh));

	return RGB(r, g, b);
}

int CProgressVU::Interpolate(double fRatio, int LowVal, int HiVal)
{
	int	range;
	int newVal;

	range = HiVal - LowVal;

	if (range >= 0)
		newVal	= (int) ((double) abs(range) * fRatio) + min(LowVal, HiVal);
	else
		newVal	= -((int) ((double) abs(range) * fRatio) - max(LowVal, HiVal));

	return newVal;
}

void CProgressStatic::SetColor(COLORREF Color)
{
	m_color = Color;
}

double CProgressStatic::LinearToDb(double fRatio)
{
	double dbVal = 0;

	//dbVal = log10(fRatio) * 50;
	//if (dbVal < -100) dbVal = -100;

	dbVal = log10(fRatio);
	dbVal *= 20.0;

	return dbVal;
}

void CProgressVU::DrawGrid(CDC* pDC)
{
	CRect	rect;
	CPen	pen1, pen2;
	int		y;
	int		divisionsY = 12;
	int		incY;

	pen1.CreatePen(PS_SOLID, 1, RGB(000, 255, 255));
	pen2.CreatePen(PS_SOLID, 1, RGB(000, 255, 255));

	GetClientRect(&rect);

	pDC->SaveDC();
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetROP2(R2_XORPEN);

	incY = (rect.Height() / divisionsY);
	for (y = 1; y < divisionsY; y++)
	{
		if (y % 2 != 0)
		{
			pDC->SelectObject(&pen2);

			pDC->MoveTo(rect.left	+ (rect.Width() / 3), y*incY);
			pDC->LineTo(rect.right	- (rect.Width() / 3), y*incY);
		}
		else
		{
			pDC->SelectObject(&pen1);

			pDC->MoveTo(rect.left, y*incY);
			pDC->LineTo(rect.right, y*incY);
		}
	}

	pDC->RestoreDC(-1);
}

void CProgressVU::SetVoxPos(double Pos)
{
	double	fPos, fRatio;
	// Force the pos to stay within the given range.
	fPos = max(min(Pos, m_RangeHigh), m_RangeLow);

	if (m_bScaleDB)
	{	// db
		fRatio = fPos / (m_RangeHigh - m_RangeLow);
		fPos = LinearToDb(fRatio);

		m_VoxPos = abs(fPos) / 100;		// 0 - 1

		m_VoxPos = (m_RangeHigh - m_RangeLow) - (m_VoxPos * (m_RangeHigh - m_RangeLow));
	}
	else
	{	// Linear
		m_VoxPos = fPos;
	}

	m_bMousePosIsValid = FALSE;

	Invalidate(FALSE);
}

void CProgressVU::DrawVoxSetting(CDC* pDC)
{
	CRect		rect;
	CRect		rectBarH;	// This is the movable part of the bar. (horiz bar
	CRect		rectBarV;	// This is the movable part of the bar. (vert bar
	int			hLen, vLen;
	double		ratio;
	COLORREF	color = RGB(255, 000, 000);
	CBrush		brush(color);
	CPen		pen(PS_SOLID, 1, color);

	GetClientRect(&rect);

	// Calculate and draw the new rect based on the input value.
	ratio = (double) m_VoxPos / (double) (m_RangeHigh - m_RangeLow);
	vLen = (DWORD) (((double) rect.Height()	* ratio) + .5);
	hLen = (DWORD) (((double) rect.Width()	* ratio) + .5);

	rectBarH		= rect;
	rectBarH.right	= hLen;
	rectBarH.top	+=	(rect.Height() / 3);
	rectBarH.bottom	-=	(rect.Height() / 3);

	rectBarV		= rect;
	rectBarV.top	= rectBarV.bottom-vLen;
	rectBarV.left	+=	(rect.Width() / 3);
	rectBarV.right	-=	(rect.Width() / 3);

	pDC->SaveDC();

	pDC->SelectObject(&brush);
	pDC->SelectObject(&pen);
	//pDC->SetROP2(R2_XORPEN);
	pDC->SetROP2(R2_NOTXORPEN);
	//pDC->SetROP2(R2_MERGEPEN);

	// Draw the vox bar
	if (m_bVert)
		pDC->Rectangle(&rectBarV);
		//pDC->FillSolidRect(&rectBarV, color);
	else
		pDC->FillSolidRect(&rectBarH, color);

	pDC->RestoreDC(-1);
}

void CProgressVU::OnMouseMove(UINT nFlags, CPoint point)
{
	if (GetCapture() != NULL)
	{
		m_VoxPos	= ConvertMousePosToVoxPos(point.y);
		m_bMousePosIsValid = TRUE;
	}
}

void CProgressVU::OnLButtonDown(UINT nFlags, CPoint point)
{
	SetCapture();
	m_bMousePosIsValid = TRUE;
	m_VoxPos	= ConvertMousePosToVoxPos(point.y);
	SetFocus();
}

void CProgressVU::OnLButtonUp(UINT nFlags, CPoint point)
{
	m_VoxPos	= ConvertMousePosToVoxPos(point.y);
	m_bMousePosIsValid = TRUE;
	ReleaseCapture();
}

double CProgressVU::ConvertMousePosToVoxPos(int nMousePos)
{
	int		nCorrectedPos;
	double	fPos, ratio;
	CRect	rect;

	GetClientRect(&rect);

	nCorrectedPos = max(0, nMousePos);

	ratio = ((double) (rect.bottom - nCorrectedPos)) / rect.Height();
	fPos = ((m_RangeHigh - m_RangeLow) * ratio) + m_RangeLow;
	fPos = max(0, fPos);	// Prevent negative value.

	//TRACE(_T("Mouse ratio = %f. fPos = %f.\r\n"), ratio, fPos);

	return fPos;
}

BOOL CProgressVU::IsMousePosValid(void)
{
	return m_bMousePosIsValid;
}

double CProgressVU::GetNewVoxPos(void)
{
	return m_VoxPos;
}
