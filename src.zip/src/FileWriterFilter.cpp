#include "StdAfx.h"
#include ".\filewriterfilter.h"
#include "app.h"

IMPLEMENT_DYNAMIC(CFileWriterFilter, CObject)

CFileWriterFilter::CFileWriterFilter(CAudioRecorder* pParent)
: CAudioFilter(pParent)
, m_PathName(_T(""))
, m_nBytesWritten(0)
, m_hFile(NULL)
, m_bAppend(FALSE)
, m_pLogFile(NULL)
, m_pServer(NULL)
, m_bWriteInhibit(FALSE)
{
	TF;	// Trace

	m_strObjectName = _T("CFileWriterFilter");

	SetPause(TRUE);	// Don't allow incoming data until we have a valid filename.
}

CFileWriterFilter::~CFileWriterFilter(void)
{
	TF;	// Trace
}

// Set the output file pathname.
BOOL CFileWriterFilter::BeginNewFile()
{
	CString strLogName;
	CString	strPathname;
	DWORD	dwAccess;

	TF;	// Trace

	CCS		lock(&m_csFileLock);

	// Create the log file pathname based on the path to the audio output file.
	strPathname = m_pServer->GetNewFilename();
	strLogName = strPathname;
	strLogName = strLogName.Left(strLogName.ReverseFind('.'));
	strLogName += _T(".log");

	try
	{
		if (m_hFile != NULL)
		{
			CloseFile();
		}

		if (m_bAppend)
		{
			ASSERT(0);	// code (below) disabled temporarily until append mode needed.
						// This is to ensure that this code is not entered inadvertantly.

			//if (!m_bWriteInhibit)
			//{
			//	m_hFile = CreateFile(strPathname, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			//	if (m_hFile == INVALID_HANDLE_VALUE)
			//	{
			//		m_hFile = NULL;
			//		throw _T("Unable to create file");
			//	}

			//	SetFilePointer(m_hFile, 0, 0, FILE_END);	// Seek to end of file.
			//}

			//m_nBytesWritten	= 0;
		}
		else
		{
			if (!m_bWriteInhibit)
			{
				dwAccess = FILE_APPEND_DATA|FILE_WRITE_DATA;

				//m_hFile = CreateFile(strPathname, dwAccess, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
				m_hFile = CreateFile(strPathname, dwAccess, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
				if (m_hFile == INVALID_HANDLE_VALUE)
				{
					m_hFile = NULL;
					throw _T("Unable to create file");
				}
			}

			m_nBytesWritten	= 0;

			if (m_pLogFile != NULL) m_pLogFile->CreateLog(strLogName);
		}
	}
	catch (LPCTSTR string)
	{
		AfxMessageBox(string, MB_OK|MB_ICONERROR);
		return FALSE;
	}

	m_PathName	= strPathname;
	SetPause(FALSE);

	return TRUE;
}

void CFileWriterFilter::ProcessDataBuffer(RECBUFF* pRB)
{
	//TF;	// Trace

	BOOL			rc;
	DWORD			dwWritten;

	//CCS		lock(&m_csFileLock);	// File is protected.

	//Beep(8000,10);

	if (!m_PathName.IsEmpty())
	{	// File write is in effect. The filename's valid.
		try
		{
			if (!m_bWriteInhibit)
			{
				rc = WriteFile(m_hFile, pRB->databuffer, pRB->wavehdr.dwBytesRecorded, &dwWritten, NULL);
				if (!rc) throw _T("File cannot be written");
				//TRACE(_T("."));	// Dot means that we wrote to the file for REAL.
			}
			else
			{
				//TRACE(_T("!"));	// Test mode write symbol
				dwWritten = pRB->wavehdr.dwBytesRecorded;
			}

			m_nBytesWritten += dwWritten;	// Increment total file size

			//TRACE(_T("@@@@@@@@@@@@@@@@@@@@@@@@@@@@ File Output Bytes = %06d, Total = %010ld.\r\n"),
			//	dwWritten, m_nBytesWritten);
		}
		catch (LPCTSTR String)
		{
			ASSERT(0);
			AfxMessageBox(String, MB_OK|MB_ICONERROR);
		}
	}

	FreeRecbuff(pRB);
}

// It's best to flush before calling this unless you don't need the stuff that's queued.
void CFileWriterFilter::CloseFile(void)
{
	TF;	// Trace

	CCS		lock(&m_csFileLock);

	if (m_hFile == NULL) return;

	//Flush();
	if (m_State != Flushing)
	{
		APP->ShowConsole(TRUE);
		m_pParent->Dump();
		ASSERT(0);
	}

	if (!m_bWriteInhibit)
	{
		CloseHandle(m_hFile);
	}

	m_hFile			= NULL;
	m_PathName.Empty();

	m_timePerBuffer = m_timeMeasured = 0;

	if (m_pLogFile != NULL) m_pLogFile->CloseLog();
}


void CFileWriterFilter::SetLogFile(CLogFileWriter* pLogfile)
{
	if (!m_bWriteInhibit)
		m_pLogFile = pLogfile;
}

ULONGLONG CFileWriterFilter::GetBytesWritten(void)
{
	return m_nBytesWritten;
}

void CFileWriterFilter::SetWriteInhibit(BOOL bInhibit)
{
	m_bWriteInhibit = bInhibit;
}

BOOL CFileWriterFilter::GetWriteInhibit(void)
{
	return m_bWriteInhibit;
}

void CFileWriterFilter::SetServer(CFilenameServer* lpServer)
{
	TF;

	ASSERT(lpServer != NULL);

	m_pServer = lpServer;
}

CFilenameServer * CFileWriterFilter::GetServer(void)
{
	return m_pServer;
}

