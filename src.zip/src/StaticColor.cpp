// StaticColor.cpp : implementation file
//

#include "stdafx.h"
#include "StaticColor.h"
#include ".\staticcolor.h"


// CStaticColor

//IMPLEMENT_DYNAMIC(CStaticColor, CStatic)
CStaticColor::CStaticColor()
: m_ColorIndex(0)
{
	ResetColors();
	m_strOldText.Empty();
}

CStaticColor::~CStaticColor()
{
}


BEGIN_MESSAGE_MAP(CStaticColor, CStatic)
ON_WM_CTLCOLOR_REFLECT()
ON_WM_TIMER()
ON_WM_ERASEBKGND()
ON_WM_PAINT()
//ON_WM_DRAWITEM()
END_MESSAGE_MAP()



HBRUSH CStaticColor::CtlColor(CDC* pDC, UINT nCtlColor)
{
	pDC->SetTextColor(m_TextColor[m_ColorIndex]);
	pDC->SetBkMode(TRANSPARENT);

	if (m_bTransparent[m_ColorIndex])
		return (HBRUSH) GetStockObject(HOLLOW_BRUSH);
	else
		return (HBRUSH) m_Brush[m_ColorIndex];
}

void CStaticColor::OnTimer(UINT nIDEvent)
{
	switch(nIDEvent)
	{
		case 0:
			if (m_ColorIndex == 0)
			{
				m_ColorIndex = 1;
			}
			else
			{
				m_ColorIndex = 0;
			}
				
			//if ((m_BkColor[0] != m_BkColor[1]) || (m_TextColor[0] != m_TextColor[1])
			//	|| (m_bTransparent[0] != m_bTransparent[1]))
			//	Invalidate(FALSE);
			break;
	}
}

void CStaticColor::PreSubclassWindow()
{
	__super::PreSubclassWindow();

	SetTimer(0, 400, NULL);
}

void CStaticColor::SetTextColor(COLORREF Color0, COLORREF Color1, BOOL bRedraw)
{
	m_TextColor[0] = Color0;
	m_TextColor[1] = Color1;
	if (bRedraw) Invalidate(FALSE);
}

void CStaticColor::SetBkColor(COLORREF Color0, COLORREF Color1, BOOL bRedraw)
{
	if (m_BkColor[0] == Color0 && m_BkColor[1] == Color1)
		return;	// Colors did not change.

	m_BkColor[0] = Color0;
	m_BkColor[1] = Color1;
	m_Brush[0].DeleteObject();
	m_Brush[0].CreateSolidBrush(m_BkColor[0]);
	m_Brush[1].DeleteObject();
	m_Brush[1].CreateSolidBrush(m_BkColor[1]);
	if (bRedraw) Invalidate(FALSE);
}

void CStaticColor::SetTextColor(COLORREF Color, BOOL bRedraw)
{
	SetTextColor(Color, Color, bRedraw);
}

void CStaticColor::SetBkColor(COLORREF Color, BOOL bRedraw)
{
	SetBkColor(Color, Color, bRedraw);
}

// Set the colors back to their defalt values
void CStaticColor::ResetColors(void)
{
	static COLORREF colorF = (COLORREF) GetSysColor(COLOR_WINDOWTEXT);
	static COLORREF colorB = (COLORREF) GetSysColor(COLOR_3DFACE);

	for (int i = 0; i < 2; i++)
	{
		m_TextColor[i]	= colorF;
		m_BkColor[i]	= colorB;
		if (m_Brush[i].m_hObject != NULL)
			m_Brush[i].DeleteObject();

		m_Brush[i].CreateSolidBrush(m_BkColor[i]);
		
		m_bTransparent[i] = FALSE;
	}
}

void CStaticColor::SetWindowText(LPCTSTR lpszString, BOOL bRedraw)
{
	if (m_strOldText != lpszString)
	{
		m_strOldText = lpszString;

		__super::SetWindowText(lpszString);
		if (bRedraw) Invalidate(TRUE);
	}
}

// TRUE means turn background off for that part of the blink cycle.
void CStaticColor::SetTransparent(BOOL bTrans1, BOOL bTrans2)
{
	m_bTransparent[0] = bTrans1;
	m_bTransparent[1] = bTrans2;
}

BOOL CStaticColor::OnEraseBkgnd(CDC* pDC)
{
	return __super::OnEraseBkgnd(pDC);
}

void CStaticColor::OnPaint()
{
	if (0)
	{
		CRect		rect;
		CDC*		pDC;
		CPaintDC	dc(this);
		CString		str;
		CFont*		pFont;

		if (!IsWindowEnabled()) return;	// prevent drawing if disabled

		pDC = GetDC();
		pFont = pDC->GetCurrentFont();

		dc.SaveDC();
		GetClientRect(rect);
		GetWindowText(str);
		//dc.FillSolidRect(rect, RGB(255,255,255));
		dc.SetTextColor(m_TextColor[m_ColorIndex]);
		dc.SetBkColor(m_BkColor[m_ColorIndex]);

		dc.SelectObject(pFont);

		::DrawText(pDC->GetSafeHdc(), str, str.GetLength(), rect, DT_CENTER);
		dc.RestoreDC(-1);

		ReleaseDC(pDC);
		pDC	= NULL;
	}
	else
	{
		__super::OnPaint();
	}
}

// CEditColor

IMPLEMENT_DYNAMIC(CEditColor, CEdit)
CEditColor::CEditColor()
{
	m_colorBk	= (COLORREF) GetSysColor(COLOR_3DFACE);
	m_colorText	= (COLORREF) GetSysColor(COLOR_WINDOWTEXT);
	m_brushBk.CreateSolidBrush(m_colorBk);
}

CEditColor::~CEditColor()
{
}


BEGIN_MESSAGE_MAP(CEditColor, CEdit)
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CEditColor message handlers


HBRUSH CEditColor::CtlColor(CDC* pDC, UINT nCtlColor)
{
	pDC->SetTextColor(m_colorText);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetBkColor(m_colorBk);

	if (m_brushBk.GetSafeHandle())
	{
		m_brushBk.DeleteObject();
		m_brushBk.CreateSolidBrush(m_colorBk);
	}

	return (HBRUSH) m_brushBk.GetSafeHandle();
	//return (HBRUSH) GetStockObject(NULL_BRUSH);
}


void CEditColor::SetTextColor(COLORREF Color)
{
	m_colorText = Color;
}

void CEditColor::SetBkColor(COLORREF Color)
{
	m_colorBk = Color;
}

void CEditColor::OnPaint()
{
	__super::OnPaint();
}

BOOL CEditColor::OnEraseBkgnd(CDC* pDC)
{
	//CRect	rect;

	//GetClientRect(&rect);

	//ClientToScreen(&rect);
	//GetParent()->ScreenToClient(&rect);
	//GetParent()->InvalidateRect(&rect, FALSE);

	//return TRUE;
	return __super::OnEraseBkgnd(pDC);
}

//void CStaticColor::DrawItem(LPDRAWITEMSTRUCT /*lpDrawItemStruct*/)
//{
//}
