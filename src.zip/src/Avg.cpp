#include "StdAfx.h"
#include ".\avg.h"

CAvg::CAvg()
: m_Variance(0)
, m_Avg(0)
{
	m_Range = 25;
}

CAvg::~CAvg(void)
{
	if (m_List.GetCount() > 0) m_List.RemoveAll();
}

void CAvg::AddValue(DWORD dwValue)
{
	if (m_List.GetCount() >= m_Range)
		m_List.RemoveTail();	// List full. Discard oldest value.

	// Add the new value.
	m_List.AddHead(dwValue);
}

void CAvg::SetRange(int Range)
{
	m_Range = Range;
}

// Sets the history to the current value. This forces the avg to start at value.
void CAvg::ForceValue(DWORD dwValue, BOOL bPurge)
{
	POSITION	pos;

	if (bPurge)
	{
		m_List.RemoveAll();	// Purge the old values.
		m_List.AddHead(dwValue);
	}
	else
	{
		for (pos = m_List.GetHeadPosition(); pos != NULL;)
		{
			m_List.SetAt(pos, dwValue);
			m_List.GetNext(pos);
		}
	}

	m_Variance = 0;
}

DWORD CAvg::GetAvg(int nCount)
{
	int					count, i, j;
	POSITION			pos;
	DWORD				vTemp;
	unsigned __int64	oldAvg			= 0;	// partial avg (oldest n)
	unsigned __int64	totAvg			= 0;	// complete avg

	count = (int) m_List.GetCount();

	if (count == 0) return 0;	// Nothing in the buffer yet.

	// Loop to scan entire list and accumulate the total average
	for (i = 0, j = count, pos = m_List.GetTailPosition(); i < j; i++, m_List.GetPrev(pos))
	{
		ASSERT(pos != NULL);
		vTemp = m_List.GetAt(pos);
		totAvg += vTemp;

		// If this is the last nCount items then accumulate "oldAvg" too
		if (i < nCount)
		{
			oldAvg += vTemp;
		}
	}

	totAvg	/= count;			// average of entire list
	if (nCount > 0)
		oldAvg	/= nCount;			// average of oldest n items in list.
	else
		oldAvg	/= count;

	m_Avg	= (DWORD) totAvg;	// Need to keep avg for variance calulation.

	if (nCount > 0)
		return (DWORD) oldAvg;
	else
		return (DWORD) totAvg;
}

int CAvg::GetCount(void)
{
	return (int) m_List.GetCount();
}

DWORD CAvg::GetVariance(void)
{
	int					count, i, j;
	POSITION			pos;
	DWORD				vTemp;
	DWORD				vWork;
	unsigned __int64	totVar			= 0;	// complete avg

	count = (int) m_List.GetCount();

	// Loop to scan entire list and accumulate the total variance
	for (i = 0, j = count, pos = m_List.GetHeadPosition(); i < j; i++, m_List.GetNext(pos))
	{
		ASSERT(pos != NULL);
		vTemp = m_List.GetAt(pos);

		vWork = m_Avg - vTemp;	// deviation from the average
		vWork = abs((long) vWork);
		vWork *= vWork;
		totVar += vWork;	// accumulate the variance
	}
	m_Variance = (DWORD) totVar / count;
	return m_Variance;
}
