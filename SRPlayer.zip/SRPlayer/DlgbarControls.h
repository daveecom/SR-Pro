#pragma once

#include "..\autobutton.h"
#include "playerview.h"

// CDlgbarControls

class CDlgbarControls : public CDialogBar
{
	friend class CPlayerView;
	DECLARE_DYNAMIC(CDlgbarControls)

public:
	CDlgbarControls();
	virtual ~CDlgbarControls();

protected:
	DECLARE_MESSAGE_MAP()

	afx_msg void	OnUpdateButtonGotostart(CCmdUI *pCmdUI);
	afx_msg void	OnUpdateButtonGotoprev(CCmdUI *pCmdUI);
	afx_msg void	OnUpdateButtonPlay(CCmdUI *pCmdUI);
	afx_msg void	OnUpdateButtonGotonext(CCmdUI *pCmdUI);
	afx_msg void	OnUpdateButtonGotoend(CCmdUI *pCmdUI);
	afx_msg void	OnUpdateButtonStop(CCmdUI *pCmdUI);
	afx_msg void	OnUpdateButtonSearchtime(CCmdUI *pCmdUI);
	afx_msg void	OnUpdateButtonSearchfreq(CCmdUI *pCmdUI);

	CAutoButton		m_Button_Start;
	CAutoButton		m_Button_Prev;
	CAutoButton		m_Button_Play;
	CAutoButton		m_Button_Stop;
	CAutoButton		m_Button_Next;
	CAutoButton		m_Button_End;
	CAutoButton		m_Button_TSearch;


public:
	virtual BOOL Create(CWnd* pParentWnd, UINT nIDTemplate, UINT nStyle, UINT nID);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
protected:
	BOOL IsFileOpen(void);
public:
	CButton* GetPlayButton(void);
};

