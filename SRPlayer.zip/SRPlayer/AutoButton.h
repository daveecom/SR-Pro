#pragma once


// CAutoButton

class CAutoButton : public CBitmapButton
{
	DECLARE_DYNAMIC(CAutoButton)

public:
	CAutoButton();
	virtual ~CAutoButton();

	BOOL	LoadBitmaps(LPCTSTR lpszBitmapResource);
	BOOL	LoadBitmaps(UINT nIDBitmapResource);
	BOOL	LoadBitmaps(UINT nIDBitmapResource1, UINT nIDBitmapResource2);
	BOOL	AutoLoad(UINT nID, CWnd* pParent);
	BOOL	IsCheckButton(void);
	void	SetToggleMode(bool bCheckBtn);
	void	SizeToContent();

protected:
	DECLARE_MESSAGE_MAP()

	virtual void PreSubclassWindow();
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg LRESULT OnSetCheck( WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGetCheck( WPARAM wParam, LPARAM lParam);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);

	BOOL m_bCheckButton;
	LONG m_CheckState;

	CBitmap	m_bm[2];	// place to store normal and pushed images.

	CRgn	m_Rgn;
	CRgn	m_RgnC;

public:
	void DrawButtonEdge(CDC* pDC, LPDRAWITEMSTRUCT lpDis, BOOL bDown = FALSE);
	void DrawFocus(CDC* pDC,	LPDRAWITEMSTRUCT lpDis);
	void DrawDisabled(CDC* pDC,	LPDRAWITEMSTRUCT lpDis);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

