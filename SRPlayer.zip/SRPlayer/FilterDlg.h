#pragma once
#include "afxwin.h"

// CFilterDlg dialog

class CFilterDlg : public CDialog
{
	DECLARE_DYNAMIC(CFilterDlg)

public:
	CFilterDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CFilterDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG_FREQFILTER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	CListBox m_List_Include;
	CListBox m_List_Exclude;
public:
	virtual BOOL OnInitDialog();
	void LoadFilters(void);
	void SaveFilters(void);

protected:
	CButton m_Check_Enable;
public:
//	afx_msg void OnBnClickedCheckEnable();
protected:
	virtual void OnOK();
public:
	BOOL IsFilterEnabled(void);
	afx_msg void OnBnClickedButtonDefaults();
protected:
	BOOL m_bDirty;
	virtual void OnCancel();
	LONGLONG		StrToFP(LPCTSTR lpszString);
	void			FPToStr(CString& strOut, LONGLONG nValue);
	void			FPToStr2(CString& strOut, LONGLONG nValue);
	CString			FPToStr(LONGLONG nValue);
	CString			FPToStr2(LONGLONG nValue);
public:
	afx_msg void OnBnClickedCheckEnable();
	afx_msg void OnBnClickedButtonAddinclude();
	afx_msg void OnBnClickedButtonAddexclude();
	afx_msg void OnBnClickedButtonDeleteinc();
	afx_msg void OnBnClickedButtonDeleteexc();
protected:
	CEdit m_Edit_Freq;
};
