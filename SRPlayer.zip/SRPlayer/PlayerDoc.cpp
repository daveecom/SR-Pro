// PlayerDoc.cpp : implementation of the PlayerDoc class
//

#include "stdafx.h"
#include "SRPlayer.h"

#include "PlayerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// PlayerDoc

IMPLEMENT_DYNCREATE(PlayerDoc, CDocument)

BEGIN_MESSAGE_MAP(PlayerDoc, CDocument)
END_MESSAGE_MAP()


// PlayerDoc construction/destruction

PlayerDoc::PlayerDoc()
: m_strWaveFile(_T(""))
, m_strIndexFile(_T(""))
, m_pPlayer(NULL)
, m_pReader(NULL)
{
}

PlayerDoc::~PlayerDoc()
{
}

BOOL PlayerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	m_strWaveFile.Empty();
	m_strIndexFile.Empty();

	return TRUE;
}

BOOL PlayerDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	BOOL		rc;
	CString		str;

	str = lpszPathName;
	str = str.Left(str.ReverseFind('.'));

	m_strWaveFile	= str + _T(".wav");
	m_strIndexFile	= str + _T(".log");

	rc = OpenPlayerAndReader();

	return		rc;
}

void PlayerDoc::OnCloseDocument()
{
	ClosePlayerAndReader();

	m_strWaveFile.Empty();
	m_strIndexFile.Empty();

	__super::OnCloseDocument();
}


BOOL PlayerDoc::OpenPlayerAndReader(void)
{
	BOOL	rc;
	//m_nIndexCount = 0;

	ASSERT(!m_strWaveFile.IsEmpty());
	ASSERT(!m_strIndexFile.IsEmpty());

	if (m_strWaveFile.IsEmpty() || m_strIndexFile.IsEmpty())
	{
		AfxMessageBox(_T("Wave file or Log file is missing.\rBoth files are required."));
		return FALSE;
	}

	if (m_pPlayer != NULL || m_pReader != NULL)
	{
		ClosePlayerAndReader();
	}

	m_pPlayer = new CPlayer;
	m_pReader = new CLogFileReader;

	rc = m_pPlayer->Create(m_strWaveFile);
	if (!rc)
	{	// Player could not render this audio input file. Silently exit after cleaning up.
		ClosePlayerAndReader();
		return FALSE;
	}
	//ASSERT(rc);
	rc = m_pReader->Open(m_strIndexFile);
	//ASSERT(rc);
	if (!rc)
	{	// Player could not render this audio input file. Silently exit after cleaning up.
		ClosePlayerAndReader();
		return FALSE;
	}

	//m_nIndexCount = m_pReader->GetCount();

	GetView()->PostMessage(UWM_NEWFILEISOPEN, 0, 0);

	return TRUE;
}

BOOL PlayerDoc::ClosePlayerAndReader(void)
{
	delete m_pReader;
	m_pReader = NULL;

	delete m_pPlayer;
	m_pPlayer = NULL;

	return TRUE;
}

BOOL PlayerDoc::IsFileOpen(void)
{
	if (m_pPlayer == NULL || m_pReader == NULL)	return FALSE;
	if (m_pReader->GetCount() == 0)				return FALSE;

	return TRUE;
}

CView* PlayerDoc::GetView(void)
{
	POSITION	pos;
	CView*		view;

	pos = GetFirstViewPosition();
	view = GetNextView(pos);

	return view;
}
