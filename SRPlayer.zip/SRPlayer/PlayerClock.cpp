// PlayerClock.cpp : implementation file
//

#include "stdafx.h"
#include "SRPlayer.h"
#include "PlayerClock.h"
#include ".\playerclock.h"

#define TIMER_REFRESH 0

// CPlayerClock

IMPLEMENT_DYNAMIC(CPlayerClock, CStatic)
CPlayerClock::CPlayerClock()
: m_bRun(FALSE)
{
}

CPlayerClock::~CPlayerClock()
{
}


BEGIN_MESSAGE_MAP(CPlayerClock, CStatic)
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CPlayerClock message handlers

HBRUSH CPlayerClock::CtlColor ( CDC* pDC, UINT nCtlColor )
{
	pDC->SetBkColor(COLORBK);
	pDC->SetTextColor(COLOR);

	return m_BkBrush;
}

void CPlayerClock::PreSubclassWindow()
{
	m_BkBrush.CreateSolidBrush(COLORBK);

	m_uSimTime.ll = 0;
	GetSystemTimeAsFileTime(&m_uCurrent.ft);

	SetTimer(TIMER_REFRESH, 50, NULL);

	__super::PreSubclassWindow();
}

void CPlayerClock::OnClose()
{
	KillTimer(TIMER_REFRESH);

	__super::OnClose();
}

void CPlayerClock::OnTimer(UINT nIDEvent)
{
	UpdateClock();
}

void CPlayerClock::UpdateClock(void)
{
	SYSTEMTIME	tm2;
	UFT			uNewTime, uDelta;
	CString		str, str2;

	CCS	lock(&m_csSimLock);

	GetSystemTimeAsFileTime(&uNewTime.ft);
	uDelta.ll = uNewTime.ll - m_uCurrent.ll;
	m_uCurrent.ll = uNewTime.ll;

	// Now update the simulated clock by using the same delta as the actual clock
	if (m_bRun) m_uSimTime.ll += uDelta.ll;

	// Convert the filetime to the clock string and send it to the static.
	FileTimeToSystemTime(&m_uSimTime.ft, &tm2);

	if (0)
	{	// Display in 12h am/pm format.
		BOOL	bPM = FALSE;
		if (tm2.wHour >= 12) bPM = TRUE;
		if (tm2.wHour == 0) tm2.wHour = 12;
		if (bPM && tm2.wHour > 12) tm2.wHour -= 12;

		str.Format(_T("%04d/%02d/%02d %02d:%02d:%02d.%1d %s"),
			tm2.wYear, tm2.wMonth, tm2.wDay, tm2.wHour, tm2.wMinute, tm2.wSecond, tm2.wMilliseconds / 100,
			bPM ? _T("Pm"):_T("Am"));
	}
	else
	{	// Display in 24h format.
		str.Format(_T("%04d/%02d/%02d %02d:%02d:%02d.%1d"),
			tm2.wYear, tm2.wMonth, tm2.wDay, tm2.wHour, tm2.wMinute, tm2.wSecond, tm2.wMilliseconds / 100);
	}

	GetWindowText(str2);
	if (str != str2) SetWindowText(str);
}

void CPlayerClock::SetTime(LPFILETIME pFT)
{
	CCS	lock(&m_csSimLock);

	m_uSimTime.ft = *pFT;
}

BOOL CPlayerClock::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
	//return CStatic::OnEraseBkgnd(pDC);
}

void CPlayerClock::SetRun(bool bRun)
{
	m_bRun = bRun;
}

