#pragma once


class CParserOutputPin : public CSourceStream, public CSourceSeeking
{
};

class CParserInputPin : public CPullPin
{
};

class CAbsParserFilter : public CSource
{
public:
    CAbsParserFilter(TCHAR * lpName, LPUNKNOWN lpunk, CLSID clsid);
    ~CAbsParserFilter();
};
