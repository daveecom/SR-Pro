// ColorEdit.cpp : implementation file
//

#include "stdafx.h"
#include "SRPlayer.h"
#include "ColorEdit.h"

// CColorEdit

IMPLEMENT_DYNAMIC(CColorEdit, CEdit)
CColorEdit::CColorEdit()
{
}

CColorEdit::~CColorEdit()
{
}


BEGIN_MESSAGE_MAP(CColorEdit, CEdit)
	ON_WM_CTLCOLOR_REFLECT()
END_MESSAGE_MAP()

HBRUSH CColorEdit::CtlColor ( CDC* pDC, UINT nCtlColor )
{
	pDC->SetBkColor(COLORBK);
	pDC->SetTextColor(COLOR);

	return m_BkBrush;
}

void CColorEdit::PreSubclassWindow()
{
	m_BkBrush.CreateSolidBrush(COLORBK);

	__super::PreSubclassWindow();
}

