// PlayerView.cpp : implementation of the PlayerView class
//

#include "stdafx.h"
#include "SRPlayer.h"

#include "PlayerDoc.h"
#include "PlayerView.h"
#include "logfilereader.h"
#include "player.h"
#include "filterdlg.h"
#include ".\playerview.h"
#include "dlgbarcontrols.h"
#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define TIMER_REFRESH 0

// PlayerView

IMPLEMENT_DYNCREATE(PlayerView, CFormView)

BEGIN_MESSAGE_MAP(PlayerView, CFormView)
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_CLOSE()
	ON_COMMAND(IDC_BUTTON_PLAY, OnButtonPlay)
	ON_MESSAGE(UWM_PLAYER_DONE, OnSegmentComplete)
	ON_MESSAGE(UWM_NEWFILEISOPEN, OnNewFileOpen)
	ON_COMMAND(IDC_BUTTON_STOP, OnButtonStop)
	ON_WM_VSCROLL()
	ON_UPDATE_COMMAND_UI(ID_TOOLS_FREQUENCYFILTER, OnUpdateToolsFrequencyfilter)
	ON_COMMAND(ID_TOOLS_FREQUENCYFILTER, OnToolsFrequencyfilter)
	ON_BN_CLICKED(IDC_BUTTON_GOTOSTART, OnBnClickedButtonGotostart)
	ON_BN_CLICKED(IDC_BUTTON_GOTONEXT, OnBnClickedButtonGotonext)
	ON_BN_CLICKED(IDC_BUTTON_GOTOEND, OnBnClickedButtonGotoend)
	ON_BN_CLICKED(IDC_BUTTON_GOTOPREV, OnBnClickedButtonGotoprev)
	ON_WM_HSCROLL()
	ON_EN_KILLFOCUS(IDC_EDIT_CORRECTION, OnEnKillfocusEditCorrection)
END_MESSAGE_MAP()

// PlayerView construction/destruction

PlayerView::PlayerView()
	: CFormView(PlayerView::IDD)
	, m_dwEventID(0)
	, m_dwEventCount(0)
	, m_bAutoIncrement(TRUE)
	, m_bContinuePlaying(TRUE)
	, m_bFilterEnabled(FALSE)
	, m_nSampleOffsetAtLastRecord(0)
	, m_nTimeOffsetAtLastRecord(0)
{
	// TODO: add construction code here

}

PlayerView::~PlayerView()
{
}

void PlayerView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//DDX_Control(pDX, IDC_STATIC_FREQ, m_Static_Freq);
	DDX_Control(pDX, IDC_STATIC_CLOCK2, m_Clock);
	DDX_Control(pDX, IDC_EDIT_EVENTID, m_Edit_EventID);
	DDX_Control(pDX, IDC_SPIN_EVENTID, m_SpinEventID);
	DDX_Control(pDX, IDC_STATIC_LABEL1, m_Static_Label1);
	DDX_Control(pDX, IDC_STATIC_LABEL2, m_Static_Label2);
	DDX_Control(pDX, IDC_STATIC_LABEL3, m_Static_Label3);
	//DDX_Control(pDX, IDC_STATIC_MAXEVENTS, m_Static_MaxEvents);
	DDX_Control(pDX, IDC_STATIC_LABEL7, m_Static_Label7);
	//DDX_Control(pDX, IDC_STATIC_FILTERSTAT, m_Static_FilterStat);
	DDX_Control(pDX, IDC_STATIC_LABEL5, m_Static_Label5);
	//DDX_Control(pDX, IDC_STATIC_SMETER, m_Static_Smeter);
	DDX_Control(pDX, IDC_STATIC_RADIO1, m_Static_Radio1);
	DDX_Control(pDX, IDC_STATIC_RADIO2, m_Static_Radio2);
	DDX_Control(pDX, IDC_STATIC_RADIO3, m_Static_Radio3);
	DDX_Control(pDX, IDC_STATIC_RADIO4, m_Static_Radio4);
	DDX_Control(pDX, IDC_STATIC_RADIO5, m_Static_Radio5);
	DDX_Control(pDX, IDC_STATIC_RADIO6, m_Static_Radio6);
	DDX_Control(pDX, IDC_STATIC_EVENTID, m_Static_EventID);
	DDX_Control(pDX, IDC_STATIC_LABEL4, m_Static_Label4);
	DDX_Control(pDX, IDC_STATIC_LASTPOSITION, m_Static_Lastpos);
	DDX_Control(pDX, IDC_EDIT_CORRECTION, m_Edit_Correction);
}

BOOL PlayerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void PlayerView::OnInitialUpdate()
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	CString			str;

	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	m_SpinEventID.SetRange32(0, 65535);

	// (large) clock
	if (m_Font0.GetSafeHandle() == NULL)
	m_Font0.CreateFont(-29, 0, 0, 0, FW_BOLD, 0, 0, 0,
		DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		PROOF_QUALITY, FIXED_PITCH | FF_DONTCARE, _T(""));

	// (medium) text
	if (m_Font1.GetSafeHandle() == NULL)
	m_Font1.CreateFont(-24, 0, 0, 0, FW_BOLD, 0, 0, 0,
		DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		PROOF_QUALITY, VARIABLE_PITCH | FF_DONTCARE, _T(""));

	// (small) Labels
	if (m_Font2.GetSafeHandle() == NULL)
	m_Font2.CreateFont(-12, 0, 0, 0, FW_BOLD, 0, 0, 0,
		DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		PROOF_QUALITY, VARIABLE_PITCH | FF_DONTCARE, _T(""));

	// First... send global small font to all controls.
	SendMessageToDescendants(WM_SETFONT, (WPARAM) m_Font2.GetSafeHandle(), TRUE);

	m_Clock.SetFont(&m_Font0);

	m_Static_Label1.SetBkColor(COLORBK);
	m_Static_Label1.SetTextColor(COLOR, TRUE);

	m_Static_Label2.SetBkColor(COLORBK);
	m_Static_Label2.SetTextColor(COLOR, TRUE);

	m_Static_Label3.SetBkColor(COLORBK);
	m_Static_Label3.SetTextColor(COLOR, TRUE);

	m_Static_Label4.SetBkColor(COLORBK);
	m_Static_Label4.SetTextColor(COLOR, TRUE);

	m_Static_Label5.SetBkColor(COLORBK);
	m_Static_Label5.SetTextColor(COLOR, TRUE);

	m_Static_Label7.SetBkColor(COLORBK);
	m_Static_Label7.SetTextColor(COLOR, TRUE);

	//m_Static_FilterStat.SetBkColor(COLORBK);
	//m_Static_FilterStat.SetTextColor(COLOR, TRUE);

	m_Static_EventID.SetBkColor(COLORBK);
	m_Static_EventID.SetTextColor(COLOR, TRUE);

	m_Static_Lastpos.SetBkColor(COLORBK);
	m_Static_Lastpos.SetTextColor(COLOR, TRUE);

	m_Static_Radio1.SetFont(&m_Font1);
	m_Static_Radio1.SetBkColor(COLORBK);
	m_Static_Radio1.SetTextColor(COLOR, TRUE);

	m_Static_Radio2.SetFont(&m_Font1);
	m_Static_Radio2.SetBkColor(COLORBK);
	m_Static_Radio2.SetTextColor(COLOR, TRUE);

	m_Static_Radio3.SetFont(&m_Font1);
	m_Static_Radio3.SetBkColor(COLORBK);
	m_Static_Radio3.SetTextColor(COLOR, TRUE);

	m_Static_Radio4.SetFont(&m_Font1);
	m_Static_Radio4.SetBkColor(COLORBK);
	m_Static_Radio4.SetTextColor(COLOR, TRUE);

	m_Static_Radio5.SetFont(&m_Font1);
	m_Static_Radio5.SetBkColor(COLORBK);
	m_Static_Radio5.SetTextColor(COLOR, TRUE);

	m_Static_Radio6.SetFont(&m_Font1);
	m_Static_Radio6.SetBkColor(COLORBK);
	m_Static_Radio6.SetTextColor(COLOR, TRUE);

	KillTimer(TIMER_REFRESH);
	SetTimer(TIMER_REFRESH, 50, NULL);

	//m_bFilterEnabled = (app->GetProfileInt(_T("Filter_Enabled"), 0) != 0);

	//str.Format(_T("Filter %s"), m_bFilterEnabled ? _T("Enabled"):_T("Disabled"));
	//m_Static_FilterStat.SetWindowText(str);

	LoadFilters();
}

PlayerDoc* PlayerView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(PlayerDoc)));
	return (PlayerDoc*)m_pDocument;
}

// PlayerView message handlers

BOOL PlayerView::OnEraseBkgnd(CDC* pDC)
{
	CRect		rect;

	GetClientRect(&rect);
	pDC->FillSolidRect(&rect, COLORBK);

	return TRUE;
}

void PlayerView::OnTimer(UINT nIDEvent)
{
	static	bOldState = FALSE;
	CString str;

	switch (nIDEvent)
	{
		case TIMER_REFRESH:
			Update();
			break;

		default:
			ASSERT(0);
	}
}

void PlayerView::OnClose()
{
	KillTimer(TIMER_REFRESH);

	m_arInclude.RemoveAll();
	m_arExclude.RemoveAll();

	CFormView::OnClose();
}

void PlayerView::OnButtonPlay()
{
	CString			strFreq;
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	UFT				uStart, uDur, uCorrection;
	ULONGLONG		nSampleAtLastIndex;	// Sample offset at last index.
	ULONGLONG		nSampleOffset;	// Sample offset
	double			fCorrection, ratio;

	SelectEvent(m_dwEventID);

	uStart.ll		= doc->m_pReader->GetTimeOffset();
	uDur.ll			= doc->m_pReader->GetDuration();

	// Apply time offset correction if needed.
	fCorrection = app->m_fCorrection;
	nSampleAtLastIndex	= m_nSampleOffsetAtLastRecord;
	nSampleOffset		= doc->m_pReader->GetSampleOffset();
	ratio				= (double) nSampleOffset / (double) nSampleAtLastIndex;
	fCorrection			= fCorrection * ratio;
	uCorrection.ll		= (ULONGLONG) (fCorrection * ONE_SECOND);

	uStart.ll += uCorrection.ll;

	TRACE(_T("Play Segment \tEvt: %06d\tStart: %016I64d\tDur%016I64d\r\n"),
		m_dwEventID, uStart.ll, uDur.ll);

	doc->m_pPlayer->PlaySegment(uStart.ll, uDur.ll, this->GetSafeHwnd());
	m_Clock.SetRun(TRUE);
}

LRESULT PlayerView::OnSegmentComplete( WPARAM, LPARAM )
{
	BOOL	rc;

	m_Clock.SetRun(FALSE);

	if (m_bAutoIncrement)
	{
		//if (m_dwEventID < m_dwEventCount - 1)
		//{
		//	m_dwEventID++;
		//	m_SpinEventID.SetPos32(m_dwEventID);
		//	SelectEvent(m_dwEventID);
		//}

		rc = SelectNextEvent();
		if (!rc)	// Did we reach the end of the list?
		{
			return TRUE;	// Reached end of list
		}
	}

	if (m_bContinuePlaying) OnButtonPlay();

	return TRUE;
}

LRESULT PlayerView::OnNewFileOpen( WPARAM, LPARAM )
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();

	m_Clock.SetRun(FALSE);
	m_dwEventID		= 0;	// Select 1st event
	m_dwEventCount	= doc->m_pReader->GetCount();

	SelectLastEvent();
	m_nSampleOffsetAtLastRecord = doc->m_pReader->GetSampleOffset();
	m_nTimeOffsetAtLastRecord	= doc->m_pReader->GetTimeOffset();

	SelectFirstEvent();

	return TRUE;
}

void PlayerView::OnButtonStop()
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();

	doc->m_pPlayer->StopPlaying();
	m_Clock.SetRun(FALSE);
}

void PlayerView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString		str;
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	PlayerDoc*	doc = GetDocument();
	BOOL		bPlaying;
	
	if (doc->m_pPlayer != NULL)
	{
		bPlaying = doc->m_pPlayer->IsPlaying();

		m_dwEventID = m_SpinEventID.GetPos32();
		if (m_dwEventID > m_dwEventCount - 1)
		{
			m_dwEventID = m_dwEventCount - 1;
			m_SpinEventID.SetPos(m_dwEventID);
		}

		SelectEvent(m_dwEventID);

		// If filter is off then it's ok to keep playng. If the filter is on then
		// we have a complication: The filter causes skipping but this code doesn't
		// know which way the progress is moving, forwards or backwards. Maybe I'll
		// add that logic eventually. Until then, the player will stop when scrolling
		// and the filter is on.
		if (bPlaying && !m_bFilterEnabled)
		{
			//doc->m_pPlayer->PlaySegment(doc->m_pReader->GetRelativeTime(), doc->m_pReader->GetDuration(), this->GetSafeHwnd());
			//m_Clock.SetRun(TRUE);
			OnButtonPlay();
		}
	}
}

void PlayerView::SelectEvent(DWORD dwEventID, BOOL bUpdate)
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	CString			str;
	UFT				u;
	SYSTEMTIME		tm;
	//int				nSMeter;

	m_SpinEventID.SetPos(dwEventID);	// Keep the control in sync.

	doc->m_pReader->GetEventRecord(str, dwEventID);
	doc->m_pReader->ParseRecord(str);

	if (bUpdate)	// We might choose to prevent update for speed.
	{
		//doc->m_pReader->GetFreq(str);
		str = doc->m_pReader->GetUserField(0);
		m_Static_Radio1.SetWindowText(str);
		str = doc->m_pReader->GetUserField(1);
		m_Static_Radio2.SetWindowText(str);
		str = doc->m_pReader->GetUserField(2);
		m_Static_Radio3.SetWindowText(str);
		str = doc->m_pReader->GetUserField(3);
		m_Static_Radio4.SetWindowText(str);
		str = doc->m_pReader->GetUserField(4);
		m_Static_Radio5.SetWindowText(str);
		str = doc->m_pReader->GetUserField(5);
		m_Static_Radio6.SetWindowText(str);

		u.ll = doc->m_pReader->GetEventTime();
		FileTimeToSystemTime(&u.ft, &tm);
		m_Clock.SetTime(&u.ft);

		str.Format(_T("%d"), dwEventID+1);
		m_Edit_EventID.SetWindowText(str);

		str.Format(_T("%d"), doc->m_pReader->GetCount());
		m_Static_Lastpos.SetWindowText(str);

		str.Format(_T("%06d"), doc->m_pReader->GetEventID());
		m_Static_EventID.SetWindowText(str);
	}
}

void PlayerView::OnUpdateToolsFrequencyfilter(CCmdUI *pCmdUI)
{
	pCmdUI->Enable();
}

// Unreachable code (as of bld 0.96 11/22/09)
void PlayerView::OnToolsFrequencyfilter()
{
	CFilterDlg	dlg(this);
	INT_PTR		result;
	CString		str;

	PlayerApp*	app = (PlayerApp*) AfxGetApp();

	result = dlg.DoModal();
	if (result == IDOK)
	{	// Filters changed.
		// Update the boolean to indicate if filter is on or off.
		m_bFilterEnabled = (app->GetProfileInt(_T("Filter_Enabled"), 0) != 0);

		str.Format(_T("Filter %s"), m_bFilterEnabled ? _T("Enabled"):_T("Disabled"));
		//m_Static_FilterStat.SetWindowText(str);

		LoadFilters();
	}
}

void PlayerView::LoadFilters(void)
{
	CString		str, str1;
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	int			i, j;
	LONGLONG	val;

	m_arInclude.RemoveAll();
	m_arExclude.RemoveAll();

	str = app->GetProfileString(_T("Filter_Include"), _T(""));

	// Loop to populate the include array
	if (!str.IsEmpty())
	for (i = 0, j = 0;; j++)
	{
		str1 = str.Tokenize(_T(" "), i);
		if (str1.IsEmpty()) break;
		str1.Trim();
		
		val = StrToFP(str1);

		m_arInclude.SetAtGrow(j, val);
	}

	str = app->GetProfileString(_T("Filter_Exclude"), _T(""));

	// Loop to populate the exclude array
	if (!str.IsEmpty())
	for (i = 0, j = 0;; j++)
	{
		str1 = str.Tokenize(_T(" "), i);
		if (str1.IsEmpty()) break;
		str1.Trim();

		val = StrToFP(str1);

		m_arExclude.SetAtGrow(j, val);
	}
}

// Convert a frequency string to fixed point integer in hz.
// The string can have 0, 1 or 2 decimals. The 2nd decimal is ignored before converting.
LONGLONG PlayerView::StrToFP(LPCTSTR lpszString)
{
	CString	strMant, strFrac, str;
	int	nDecimals, i;
	LONGLONG	result;

	str = lpszString;

	// Count decimals
	i = str.Find(_T("."));
	for (nDecimals = 0;;)
	{
		if (i >= 0)
		{
			nDecimals++;
		}
		else break;

		i = str.Find(_T("."), i+1);
	}

	switch(nDecimals)
	{
		case 0:
			strMant = str;
			break;

		case 1:
			i = str.Find(_T("."));
			strMant = str.Mid(0, i);
			strFrac = str.Mid(i+1);
			break;

		case 2:
			i = str.Find(_T("."));
			strMant = str.Left(i);

			str = str.Mid(i+1);	// Trim off mantissa and decimal

			i = str.Find(_T("."));	// Locate 2nd decimal
			strFrac = str.Left(i);
			strFrac += str.Mid(i+1);
			break;
	}

	result = _tstoi64(strMant) * 1000000;

	// Calculate the fraction part.
	strFrac += _T("00000000");	// Pad with zeros on right side
	strFrac = strFrac.Left(6);	// Truncate fraction to n digits
	result += _tstoi64(strFrac);

	return result;
}

// Convert fixed integer in hz to string with a single decimal
void PlayerView::FPToStr(CString& strOut, LONGLONG nValue)
{
	DWORD	hi, lo;

	hi = (DWORD) nValue / 1000000;
	lo = (DWORD) nValue % 1000000;

	strOut.Format(_T("%05d.%06d"), hi, lo);
}

// Convert fixed integer in hz to string with a double decimal
void PlayerView::FPToStr2(CString& strOut, LONGLONG nValue)
{
	DWORD	hi, lo;
	DWORD	khz, hz;

	hi = (DWORD) nValue / 1000000;
	lo = (DWORD) nValue % 1000000;

	khz = lo / 1000;
	hz	= lo % 1000;

	strOut.Format(_T("%05d.%03d.%02d"), hi, khz, hz);
}

CString PlayerView::FPToStr(LONGLONG nValue)
{
	CString str;

	FPToStr(str, nValue);

	return str;
}


BOOL PlayerView::IsFreqAllowed(LPCTSTR lpszFreq)
{
	LONGLONG	newFreq, tblFreq;
	INT_PTR		i, j;

	if (!m_bFilterEnabled) return TRUE;

	newFreq = StrToFP(lpszFreq);	

	// If it's in the exclude list then the search is complete.
	for (i = 0, j = m_arExclude.GetCount(); i < j; i++)
	{
		tblFreq = m_arExclude[i];
		if (newFreq == tblFreq)
		{
			return FALSE;	// Found in exclude list.
		}
	}

	if (m_arInclude.GetCount() == 0)
	{
		return TRUE;	// Include list empty. Allow it.
	}
	else
	{	// Include list not empty
		for (i = 0, j = m_arInclude.GetCount(); i < j; i++)
		{
			tblFreq = m_arInclude[i];
			if (newFreq == tblFreq)
			{
				return TRUE;	// Found in include list.
			}
		}
		return FALSE;	// Not found in include list.
	}

	return TRUE;
}

BOOL PlayerView::SelectFirstEvent(void)
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	int				i, j;
	CString			strFreq;
	BOOL			bFound;

	if (doc->IsFileOpen())
	{
		m_dwEventID = 0;

		if (m_bFilterEnabled)
		{
			app->DoWaitCursor(1);

			// If filter is enabled then scan forwards until we get a good entry.
			for (i = 0, j = doc->m_pReader->GetCount(), bFound = FALSE; i < j; i++)
			{
				SelectEvent(i, FALSE);	// Parse the current event record
				doc->m_pReader->GetFreq(strFreq);
				if (IsFreqAllowed(strFreq))
				{
					bFound = TRUE;
					break;	// Found an allowed entry.
				}
			}
			// We have either found a valid entry or we've skipped to the last record.
			if (bFound)
				m_dwEventID = i;
			else
				m_dwEventID = 0;	// Not found. Stay on 1st record.
		}

		SelectEvent(m_dwEventID);
	}

	app->DoWaitCursor(-1);

	return ((!m_bFilterEnabled) || bFound);	// TRUE = search successful or filter off
}

BOOL PlayerView::SelectLastEvent(void)
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	int				i;
	CString			strFreq;
	BOOL			bFound;

	if (doc->IsFileOpen())
	{
		m_dwEventID = m_dwEventCount - 1;	// Start at the end.

		// If we're filtering then back up to previous allowed frequency.
		if (m_bFilterEnabled)
		{
			app->DoWaitCursor(1);

			// If filter is enabled then scan backwards until we get a good entry.
			for (i = m_dwEventID, bFound = FALSE; i >= 0 ; i--)
			{
				SelectEvent(i, FALSE);	// Parse the current event record
				doc->m_pReader->GetFreq(strFreq);
				if (IsFreqAllowed(strFreq))
				{
					bFound = TRUE;
					break;	// Found an allowed entry.
				}
			}
			// We have either found a valid entry or we've skipped before the 1st record.
			if (bFound)
				m_dwEventID = i;
			else
				m_dwEventID = m_dwEventCount - 1;	// Not found. Stay on last record.
		}

		SelectEvent(m_dwEventID);
	}

	app->DoWaitCursor(-1);

	return ((!m_bFilterEnabled) || bFound);	// TRUE = search successful or filter off
}

BOOL PlayerView::SelectNextEvent(void)
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	int				i, j;
	CString			strFreq;
	BOOL			bFound, bEnd;


	if (doc->IsFileOpen())
	{
		bEnd = FALSE;	// Have not detected the end of the list yet.
		if (m_bFilterEnabled)
		{
			if (m_dwEventID < m_dwEventCount - 1)
			{	// We still have room to move forward.
				app->DoWaitCursor(1);

				// If filter is enabled then scan forwards until we get a good entry.
				for (i = m_dwEventID + 1, j = m_dwEventCount, bFound = FALSE; i < j; i++)
				{
					SelectEvent(i, FALSE);	// Parse the current event record
					doc->m_pReader->GetFreq(strFreq);
					if (IsFreqAllowed(strFreq))
					{
						bFound = TRUE;
						break;	// Found an allowed entry.
					}
				}

				// We have either found a valid entry or we've reached the last record.
				if (bFound) m_dwEventID = i;	// Seek to the record we found.
				else
				{	// else (not found) stay on current record
					bEnd = TRUE;	// We reached the end.
				}
			}
			else
			{	// No more records left.
				bEnd = TRUE;
			}
		}
		else
		{	// Filter disabled
			if (m_dwEventID < m_dwEventCount - 1)
				m_dwEventID++;
			else
				bEnd = TRUE;	// We reached the end.
		}

		SelectEvent(m_dwEventID);
	}

	app->DoWaitCursor(-1);

	// return TRUE if more events to be played.
	if (m_bFilterEnabled)
	{	// Filter on
		return (bFound && !bEnd);
	}
	else
	{	// Filter off
		return !bEnd;	// TRUE if end not yet reached.
	}
}

BOOL PlayerView::SelectPreviousEvent(void)
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	int				i;
	CString			strFreq;
	BOOL			bFound, bEnd;

	if (doc->IsFileOpen())
	{
		bEnd = FALSE;	// Have not detected the end of the list yet.
		if (m_bFilterEnabled)
		{
			if (m_dwEventID > 0)
			{	// We still have room to move forward.
				app->DoWaitCursor(1);

				// If filter is enabled then scan backwards until we get a good entry.
				for (i = m_dwEventID - 1, bFound = FALSE; i >= 0; i--)
				{
					SelectEvent(i, FALSE);	// Parse the current event record
					doc->m_pReader->GetFreq(strFreq);
					if (IsFreqAllowed(strFreq))
					{
						bFound = TRUE;
						break;	// Found an allowed entry.
					}
				}

				// We have either found a valid entry or we've reached the last record.
				if (bFound) m_dwEventID = i;	// Seek to the record we found.
				else
				{	// else (not found) stay on current record
					bEnd = TRUE;	// We reached the beginning.
				}
			}
			else
			{	// No more records left.
				bEnd = TRUE;
			}
		}
		else
		{	// Filter disabled
			if (m_dwEventID > 0)
				m_dwEventID--;
			else
				bEnd = TRUE;	// We reached the end.
		}

		SelectEvent(m_dwEventID);
	}

	app->DoWaitCursor(-1);

	// return TRUE if more events to be played.
	if (m_bFilterEnabled)
	{	// Filter on
		return (bFound && !bEnd);
	}
	else
	{	// Filter off
		return !bEnd;	// TRUE if end not yet reached.
	}
}


void PlayerView::OnBnClickedButtonGotostart()
{
	PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	BOOL			bPlaying = doc->m_pPlayer->IsPlaying();

	SelectFirstEvent();

	if (bPlaying)	OnButtonPlay();
}

void PlayerView::OnBnClickedButtonGotonext()
{
	//PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	BOOL			bPlaying = doc->m_pPlayer->IsPlaying();

	SelectNextEvent();

	if (bPlaying)	OnButtonPlay();
}

void PlayerView::OnBnClickedButtonGotoend()
{
	//PlayerApp*		app = (PlayerApp*) AfxGetApp();
	PlayerDoc*		doc = GetDocument();
	BOOL			bPlaying = doc->m_pPlayer->IsPlaying();

	SelectLastEvent();

	if (bPlaying)	OnButtonPlay();
}

void PlayerView::OnBnClickedButtonGotoprev()
{
	PlayerDoc*		doc = GetDocument();
	BOOL			bPlaying = doc->m_pPlayer->IsPlaying();

	SelectPreviousEvent();

	if (bPlaying)	OnButtonPlay();
}

void PlayerView::Update(void)
{
	CString				str;
	PlayerApp*			app		= (PlayerApp*) AfxGetApp();
	PlayerDoc*			doc		= GetDocument();
	CDlgbarControls*	pDlg	= ((CMainFrame*) GetParentFrame())->GetDlgBar();

	ASSERT(pDlg);

	pDlg->GetPlayButton()->SetCheck(doc->m_pPlayer->IsPlaying() ? BST_CHECKED:BST_UNCHECKED);

	if (GetFocus() != &m_Edit_Correction)
		UpdateCorrectionControl(app->m_fCorrection);
}

void PlayerView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CString		str;
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	PlayerDoc*	doc = GetDocument();
	BOOL		bPlaying;
	
	if (doc->m_pPlayer != NULL)
	{
		bPlaying = doc->m_pPlayer->IsPlaying();

		m_dwEventID = m_SpinEventID.GetPos32();
		if (m_dwEventID > m_dwEventCount - 1)
		{
			m_dwEventID = m_dwEventCount - 1;
			m_SpinEventID.SetPos(m_dwEventID);
		}

		SelectEvent(m_dwEventID);

		// If filter is off then it's ok to keep playng. If the filter is on then
		// we have a complication: The filter causes skipping but this code doesn't
		// know which way the progress is moving, forwards or backwards. Maybe I'll
		// add that logic eventually. Until then, the player will stop when scrolling
		// and the filter is on.
		if (bPlaying && !m_bFilterEnabled)
		{
			//doc->m_pPlayer->PlaySegment(doc->m_pReader->GetRelativeTime(), doc->m_pReader->GetDuration(), this->GetSafeHwnd());
			//m_Clock.SetRun(TRUE);
			OnButtonPlay();
		}
	}
}

BOOL PlayerView::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN &&
		GetFocus() == GetDlgItem(IDC_EDIT_CORRECTION))
	{	// Enter key pressed in edit control.
		OnEnKillfocusEditCorrection();
	}

	return CFormView::PreTranslateMessage(pMsg);
}

void PlayerView::OnEnKillfocusEditCorrection()
{
	CString		str;
	PlayerApp*	app		= (PlayerApp*) AfxGetApp();
	double		fCorrection;

	m_Edit_Correction.GetWindowText(str);

	// Validate length
	if (str.IsEmpty())
	{
		fCorrection = app->m_fCorrection;	// Restore previous value
	}
	else
	{
		fCorrection = StrToDouble(str);
	}

	app->m_fCorrection = fCorrection;

	UpdateCorrectionControl(fCorrection);
}

void PlayerView::UpdateCorrectionControl(double fCorrection)
{
	CString	str;

	DoubleToStr(fCorrection, str);
	m_Edit_Correction.SetWindowText(str);
}
