// SRPlayer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "SRPlayer.h"
#include "MainFrm.h"

#include "PlayerDoc.h"
#include "PlayerView.h"
#include ".\srplayer.h"
#include "o:\program files\microsoft platform sdk\include\mfc\afxwin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// PlayerApp

BEGIN_MESSAGE_MAP(PlayerApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()



PlayerApp::PlayerApp()
: m_pDoc(NULL)
{
}

PlayerApp::~PlayerApp()
{
}

PlayerApp theApp;

BOOL PlayerApp::InitInstance()
{
	CVersion	version;
	CString		str;
	double		fCorrection;

	InitCommonControls();

	CWinApp::InitInstance();

	CMyDocTemplate* pDocTemplate;
	pDocTemplate = new CMyDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(PlayerDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(PlayerView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);

	// Enable DDE Execute open
	//EnableShellOpen();

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

// HKEY_CURRENT_USER\Software\SR Pro Player\SR Pro Player\Settings
	//str.Format(_T("HKEY_CURRENT_USER\\Software\\%s"), version.GetProductName());
	SetRegistryKey(version.GetCompanyName());
	LoadStdProfileSettings(16);  // Load standard INI file options (including MRU)

	// Read the correction factor from the registry.
	str = GetProfileString(_T("Correction"));

	if (str.IsEmpty())
		fCorrection = 0;	// nothing is saved yet.
	else
		fCorrection = StrToDouble(str);

	m_fCorrection = fCorrection;

	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	m_pMainWnd->DragAcceptFiles();

	return TRUE;
}


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
protected:
	CStatic m_Static_About;
	CStatic m_Static_Copyright;
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_ABOUT, m_Static_About);
	DDX_Control(pDX, IDC_STATIC_COPYRT, m_Static_Copyright);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// App command to run the dialog
void PlayerApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

int PlayerApp::ExitInstance()
{
	CString	str;
	double	fCorrection;
	
	fCorrection = m_fCorrection;

	// Save the correction factor
	DoubleToStr(fCorrection, str);

	WriteProfileString(_T("Correction"), str);
	return CWinApp::ExitInstance();
}

PlayerDoc* PlayerApp::GetDoc(void)
{
	POSITION		pos;
	CDocTemplate*	pTemplate;
	PlayerDoc*		pDoc;

	if (m_pDoc != NULL) return m_pDoc;

	pos = GetFirstDocTemplatePosition();
	pTemplate = GetNextDocTemplate(pos);
	pos = pTemplate->GetFirstDocPosition();
	pDoc = (PlayerDoc*) pTemplate->GetNextDoc(pos);
	m_pDoc = pDoc;

	return pDoc;
}

// Overrides to eliminate the need to use the section names.
UINT PlayerApp::GetProfileInt(LPCTSTR lpszEntry, int nDefault)
{
	return __super::GetProfileInt(SECTION_NAME, lpszEntry, nDefault);
}

BOOL PlayerApp::WriteProfileInt(LPCTSTR lpszEntry, int nValue)
{
	return __super::WriteProfileInt(SECTION_NAME, lpszEntry, nValue);
}

CString PlayerApp::GetProfileString(LPCTSTR lpszEntry, LPCTSTR lpszDefault)
{
	return __super::GetProfileString(SECTION_NAME, lpszEntry, lpszDefault);
}

BOOL PlayerApp::WriteProfileString(LPCTSTR lpszEntry, LPCTSTR lpszValue)
{
	return __super::WriteProfileString(SECTION_NAME, lpszEntry, lpszValue);
}

BOOL PlayerApp::GetProfileBinary(LPCTSTR lpszEntry, LPBYTE* ppData, UINT* pBytes)
{
	return __super::GetProfileBinary(SECTION_NAME, lpszEntry, ppData, pBytes);
}

BOOL PlayerApp::WriteProfileBinary(LPCTSTR lpszEntry, LPBYTE pData, UINT nBytes)
{
	return __super::WriteProfileBinary(SECTION_NAME, lpszEntry, pData, nBytes);
}

BOOL CAboutDlg::OnInitDialog()
{
	CVersion	v;
	CString		str;

	CDialog::OnInitDialog();

	str.Format(_T("%s Version %s"), v.GetProductName(), v.GetProductVersion());
	m_Static_About.SetWindowText(str);
	m_Static_Copyright.SetWindowText(v.GetLegalCopyright());


	return TRUE;
}

double StrToDouble(LPCTSTR lpszIn)
{
	return _tstof(lpszIn);
}

void DoubleToStr(double fIn, CString& strOut)
{
	CString	str;
	int		a, b;
	double	fValue = fIn;
	BOOL	bSign;

	bSign = (fValue < 0);

	if (bSign) fValue = -fValue;	// Get abs

	// Mantissa
	a = (int) fValue;

	// fraction
	fValue -= a;	// Remove mantissa.

	fValue *= 100;	// Shift left 2 decimal places.
	b = ((int)(fValue + .5)) % 100;

	str.Format(_T("%s%d.%02d"),
		bSign ? _T("-"):_T(""), a, b);

	strOut = str;
}
