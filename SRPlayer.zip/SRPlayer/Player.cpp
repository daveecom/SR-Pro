#include "StdAfx.h"
#include <uuids.h>
#include <process.h>

#include ".\player.h"


CPlayer::CPlayer(void)
: m_bInit(FALSE)
, m_hThread(NULL)
, m_bPlaying(FALSE)
, m_dwGraphRegister(0)
{
	CoInitialize(NULL);
}

CPlayer::~CPlayer(void)
{
	StopPlaying();

#ifdef _DEBUG
    if (m_dwGraphRegister)
    {
        RemoveGraphFromRot(m_dwGraphRegister);
        m_dwGraphRegister = 0;
    }
#endif

	m_iME		= NULL;
	m_iMS		= NULL;
	m_iMC		= NULL;
	m_iGraph	= NULL;
	m_iBuilder	= NULL;

	CoUninitialize();
}

BOOL CPlayer::Create(const LPCTSTR lpszFilePath)
{
	CString					str;
	HRESULT	hr;
	CComPtr<IPin>			iPinWP	= NULL;
	CComPtr<IBaseFilter>	iParser = NULL;
	DWORD					dwCaps;
	WCHAR					wStr[MAX_PATH] = {0};

	ASSERT(lpszFilePath != NULL);

	#ifndef _UNICODE
		mbstowcs(wStr, lpszFilePath, _tcslen(lpszFilePath));
	#else
		wcsncpy(wStr, lpszFilePath, sizeof wStr / 2);
	#endif

	try
	{
		// Create the dshow objects we need
		hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IFilterGraph, (void**) &m_iGraph);
		if (hr != S_OK) throw(_T("Error: Check to make sure DirectShow is installed.\nFailed to create Filter Graph object."));

		hr = m_iGraph->QueryInterface(IID_IGraphBuilder, (void**) &m_iBuilder);
		if (hr != S_OK) throw(_T("Error: Failure while building DirectShow player."));

		hr = m_iGraph->QueryInterface(IID_IMediaControl, (void**) &m_iMC);
		if (hr != S_OK) throw(_T("Error: Failure while building DirectShow player."));

		// Try to build the graph using the filename path we were given.
		hr = m_iBuilder->RenderFile(wStr, NULL);
		if (hr != S_OK) throw(_T("Unable to render audio file. Could be corrupt or in use."));

		// We need the wave parser output pin.
		hr = m_iGraph->FindFilterByName(L"Wave Parser", &iParser);
		if (hr != S_OK) throw(_T("Error: Failure while building DirectShow player."));
		hr = iParser->FindPin(L"output", &iPinWP);
		if (hr != S_OK) throw(_T("Error: Failure while building DirectShow player."));

		// Get the media seeking interface now.
		hr = iPinWP->QueryInterface(IID_IMediaSeeking, (void**) &m_iMS);
		if (hr != S_OK) throw(_T("Error: Failure while building DirectShow player."));

		// And IMediaEvent
		hr = m_iGraph->QueryInterface(IID_IMediaEvent, (void**) &m_iME);
		if (hr != S_OK) throw(_T("Error: Failure while building DirectShow player."));

		hr = m_iMS->GetCapabilities(&dwCaps);
		ASSERT(hr == S_OK);
		ASSERT(dwCaps & AM_SEEKING_CanSeekAbsolute);

		hr = m_iMS->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
		//hr = m_iMS->SetTimeFormat(&TIME_FORMAT_SAMPLE);	// doesn't work
		if (hr != S_OK) throw(_T("Error: Failure while building DirectShow player."));

		m_bInit		= TRUE;
		m_bPlaying	= FALSE;
	}
	catch(LPCTSTR lpszMessage)
	{
		CString str(lpszMessage);	// local string
		str.Format(_T("Unable to play audio file:\n\n%s\n\n Reason: '%s'.\n"),
			lpszFilePath, lpszMessage);

		INT_PTR result = AfxMessageBox(str, MB_OK | MB_ICONEXCLAMATION);

		m_iME		= NULL;
		m_iMS		= NULL;
		m_iMC		= NULL;
		m_iGraph	= NULL;
		m_iBuilder	= NULL;

		return		FALSE;
	}

#ifdef _DEBUG
        hr = AddGraphToRot(m_iBuilder, &m_dwGraphRegister);
        if (FAILED(hr))
        {
			CString str;
            str.Format(_T("Failed to register filter graph with ROT!  hr=0x%x"), hr);
			AfxMessageBox(str, MB_OK|MB_ICONERROR);
            m_dwGraphRegister = 0;
        }
#endif

	return TRUE;
}

BOOL CPlayer::PlaySegment(REFERENCE_TIME tStart, REFERENCE_TIME tDuration, HWND hAlert)
{
	HRESULT	hr;
	FILTER_STATE			state;

	ASSERT(m_bInit);
	ASSERT(m_iGraph != NULL);

	if (m_hThread != NULL)
	{
		TerminateThread(m_hThread, 0);
		m_hThread = NULL;
		//Beep(10000,10);	// For now, I want to know if this happens...
	}

	hr = m_iMC->Pause();

	hr = m_iMC->GetState(INFINITE, (OAFilterState *) &state);
	while (state != State_Paused)
	{
		hr = m_iMC->GetState(50, (OAFilterState *) &state);
	}

	//hr = m_iMC->Stop();

	hr = m_iMS->SetPositions(&tStart, AM_SEEKING_AbsolutePositioning,
		&tDuration, AM_SEEKING_IncrementalPositioning);
	ASSERT(hr == S_OK);

	m_bPlaying = TRUE;
	hr = m_iMC->Run();

	m_hAlert = hAlert;

	m_hThread = (HANDLE) _beginthread(StartWorker, 0, this);

	return TRUE;
}

void CPlayer::StartWorker( void * pThis)
{
	((CPlayer*) pThis)->WorkerProc();
	((CPlayer*) pThis)->m_hThread = NULL;
}

void	CPlayer::WorkerProc()
{
	HRESULT	hr;
	long	evCode;

	hr = m_iME->WaitForCompletion(INFINITE, &evCode);
	hr = m_iMC->Stop();

	m_bPlaying = FALSE;

	PostMessage(m_hAlert, UWM_PLAYER_DONE, 0, 0);	// Tell the app we're done.
	m_hAlert = NULL;
}

BOOL CPlayer::StopPlaying(void)
{
	HRESULT			hr;
	FILTER_STATE	state;

	if (m_bPlaying)
	{
		hr = m_iMC->GetState(INFINITE, (OAFilterState *) &state);
		if (state == State_Running || state == State_Paused)
		{
			if (m_hThread != NULL)
			{
				TerminateThread(m_hThread, 0);
			}
			hr = m_iMC->Stop();
			hr = m_iMC->GetState(INFINITE, (OAFilterState *) &state);
			ASSERT(state == State_Stopped);
		}

		m_bPlaying = FALSE;

		return TRUE;
	}

	return FALSE;	// FALSE means nothing was playing
}

BOOL CPlayer::IsPlaying(void)
{
	if (this == NULL) return FALSE;
	return m_bPlaying;
}

#ifdef _DEBUG

HRESULT CPlayer::AddGraphToRot(IUnknown *pUnkGraph, DWORD *pdwRegister)
{
    IMoniker * pMoniker;
    IRunningObjectTable *pROT;
    if (FAILED(GetRunningObjectTable(0, &pROT)))
    {
        return E_FAIL;
    }

    WCHAR wsz[128];
    HRESULT hr = StringCchPrintfW(wsz, NUMELMS(wsz), L"FilterGraph %08x pid %08x", (DWORD_PTR)pUnkGraph,
              GetCurrentProcessId());

    hr = CreateItemMoniker(L"!", wsz, &pMoniker);
    if (SUCCEEDED(hr))
    {
        // Use the ROTFLAGS_REGISTRATIONKEEPSALIVE to ensure a strong reference
        // to the object.  Using this flag will cause the object to remain
        // registered until it is explicitly revoked with the Revoke() method.
        //
        // Not using this flag means that if GraphEdit remotely connects
        // to this graph and then GraphEdit exits, this object registration
        // will be deleted, causing future attempts by GraphEdit to fail until
        // this application is restarted or until the graph is registered again.
        hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph,
                            pMoniker, pdwRegister);
        pMoniker->Release();
    }

    pROT->Release();
    return hr;
}

void CPlayer::RemoveGraphFromRot(DWORD pdwRegister)
{
    IRunningObjectTable *pROT;

    if (SUCCEEDED(GetRunningObjectTable(0, &pROT)))
    {
        pROT->Revoke(pdwRegister);
        pROT->Release();
    }
}

#endif
