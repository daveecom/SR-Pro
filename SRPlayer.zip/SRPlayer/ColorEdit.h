#pragma once
#include "afxwin.h"


// CColorEdit

class CColorEdit : public CEdit
{
	DECLARE_DYNAMIC(CColorEdit)

public:
	CColorEdit();
	virtual ~CColorEdit();

protected:
	DECLARE_MESSAGE_MAP()
	CBrush m_BkBrush;
	afx_msg HBRUSH CtlColor ( CDC* pDC, UINT nCtlColor ); 
	virtual void PreSubclassWindow();
};


