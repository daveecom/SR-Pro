#include "stdafx.h"

#include <Pullpin.h>
#include <amfilter.h>

#include "absparserfilter.h"

CAbsParserFilter::CAbsParserFilter(TCHAR * lpName, LPUNKNOWN lpunk, CLSID clsid)
: CSource(lpName, lpunk, clsid)
{
}

CAbsParserFilter::~CAbsParserFilter(void)
{
}
