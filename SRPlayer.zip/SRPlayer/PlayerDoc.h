// PlayerDoc.h : interface of the PlayerDoc class
#pragma once

#include "LogFileReader.h"
#include "Player.h"
//#include "playerview.h"


class PlayerDoc : public CDocument
{
protected: // create from serialization only
	PlayerDoc();
	DECLARE_DYNCREATE(PlayerDoc)

// Attributes
public:

// Operations
public:

// Overrides
	virtual BOOL	OnNewDocument();
	virtual BOOL	OnOpenDocument(LPCTSTR lpszPathName);
	virtual void	OnCloseDocument();

	virtual			~PlayerDoc();
	BOOL			IsFileOpen(void);

	CPlayer*		m_pPlayer;
	CLogFileReader*	m_pReader;

protected:
	DECLARE_MESSAGE_MAP()
	CString			m_strWaveFile;
	CString			m_strIndexFile;

	BOOL			OpenPlayerAndReader(void);
	BOOL			ClosePlayerAndReader(void);
	//DWORD			m_nIndexCount;
	CView*			GetView(void);
};

class CMyDocTemplate : public CSingleDocTemplate
{
public:
	CMyDocTemplate(UINT nIDResource, CRuntimeClass* pDocClass, CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass)
	: CSingleDocTemplate(nIDResource, pDocClass, pFrameClass, pViewClass) {}

	~CMyDocTemplate(void) {}

	virtual enum CDocTemplate::Confidence CMyDocTemplate::MatchDocType(LPCTSTR lpszPathName, CDocument*& rpDocMatch)
	{
		rpDocMatch = NULL;
		return yesAttemptForeign;
	}
};

