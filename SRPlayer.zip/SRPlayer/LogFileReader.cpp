#include "StdAfx.h"
#include ".\logfilereader.h"

#define TOKENS_REQUIRED 8

CLogFileReader::CLogFileReader(void)
: m_nDataOffset(0)
, m_nFileSize(0)
{
	ULONGLONG	nResult;
	CString		strHex = _T("AAAABBBBCCCCDDDD");
	nResult = HexToULL(strHex);
}

CLogFileReader::~CLogFileReader(void)
{
	Close();
}

BOOL CLogFileReader::Open(LPCTSTR lpszFilePath)
{
	BOOL			rc;
	CFileException	e;
	CString			str;
	CIndexEntry		indx(0, 0);
	int				i;
	ULONGLONG		pos1, pos2;
	CString			strToken0;

	ASSERT(lpszFilePath != NULL);

	try
	{
		m_hFile = CreateFile(lpszFilePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (m_hFile == INVALID_HANDLE_VALUE)
		{
			CString str;

			//ASSERT(0);

			str.Format(_T("Error %d while trying to open the log file:\r\n%s.\r\n"),
				e.m_cause, lpszFilePath);
			TRACE(str);

			throw(str);
		}

		////// File is open. //////

		// Skip past the header lines.

		for (;;)
		{
			m_nDataOffset = GetFilePosition();
			rc = ReadLine(str);
			if (!rc) throw(_T("Log file seems to be empty."));
			int result = ParseCSVRecord(str, &strToken0, 1);
			if (result == 0) throw(_T("Log file seems to be empty."));

			if (IsNumber(strToken0))
			{	// Beginning of log data found.
				break;
			}
		}

		// Move to the end of the file.
		rc = SeekToEnd();
		if (!rc) throw(_T("Log file I/O error. Seek Failed."));
		m_nFileSize = GetFilePosition();

		rc = Seek(m_nDataOffset);
		if (!rc) throw(_T("Log file I/O error. Seek Failed."));

		// Count records and store the offsets and lengths of each.
		pos1 = m_nDataOffset;
		for (i = 0; ; i++)
		{
			rc = ReadLine(str);						
			if (str.IsEmpty())	break;	// Must be all done.

			pos2 = GetFilePosition();
			if (pos2 == pos1)	break;	// Must be all done.

			indx.m_nOffset	= pos1;
			indx.m_nLength	= (int) (pos2 - pos1);
			m_Index.Add(indx);

			pos1 = pos2;
		}

		// The index is built. We are done opening the file.
		Seek(m_nDataOffset);
	}
	catch(LPCTSTR lpszMsg)
	{
		AfxMessageBox(lpszMsg, MB_OK|MB_ICONERROR);
		return FALSE;
	}

	return TRUE;
}

BOOL CLogFileReader::ReadLine(CString& strLine)
{
	#define		MAX_LINESIZE 2048
	CStringA	strA;
	CString		str;
	char		newChar;
	BOOL		bLineEnd, rc;
	int			i;
	DWORD		dwBytesRead = 0;

	ASSERT(m_hFile != NULL);
	ASSERT(m_hFile != INVALID_HANDLE_VALUE);

	for (i = 0, bLineEnd = FALSE; i < MAX_LINESIZE; i++)
	{
		rc = ReadFile(m_hFile, &newChar, 1, &dwBytesRead, NULL);
		if (rc					== FALSE)	return FALSE;	// Format error
		if (dwBytesRead			== 0)		return FALSE;	// "

		if (newChar				== 0x0A)	break;			// Line received.

		if (strA.GetLength()	< MAX_LINESIZE)
		{
			if (newChar != 0x0D)
			{
				strA.AppendChar(newChar);
			}
		}
		else
		{
			break;
			// Line too long. Stop reading here. Of course next
			// line will be the remainder of this one.
			// Too bad for the dumb user if they
			// choose to put this much on one line.
		}
	}

	if (strA.GetLength() != 0)
	{
		strLine = strA;
		return TRUE;
	}
	else
	{
		strLine.Empty();
		return FALSE;
	}
}

void CLogFileReader::Close(void)
{
	if (m_hFile != INVALID_HANDLE_VALUE) CloseHandle(m_hFile);
}

BOOL CLogFileReader::GetEventRecord(CString& strEvent, DWORD dwEvent)
{
	CString	str;
	BOOL	rc;

	ASSERT(dwEvent < (DWORD) m_Index.GetSize());

	rc = Seek(m_Index[dwEvent].m_nOffset);
	ASSERT(rc);

	rc = ReadLine(str);
	ASSERT(rc);

	strEvent.Empty();
	if (rc)
	{
		strEvent = str;
	}

	return TRUE;
}

DWORD CLogFileReader::GetCount(void)
{
	ASSERT(m_hFile != INVALID_HANDLE_VALUE);

	return DWORD(m_Index.GetSize());
}


// Convert "000:00:01:02.003" to media time. Options source length = # chars.
//          0123456789ABCDEF
//          DDD:HH:MM:SS:mmm
BOOL CLogFileReader::ConvertLogTime(LONGLONG* pFT, LPCTSTR lpszInput, DWORD dwLength)
{
	CString		strIn(lpszInput);
	LONGLONG	time;

	ASSERT(pFT != NULL);
	ASSERT(lpszInput != NULL);

	if (dwLength > 0) strIn = strIn.Left(dwLength);	// Truncate input

//	00000000001111111111
//	01234567890123456789
//	HH:MM:SS.mmm
//	00:00:12.181

	time	=	_ttol(strIn.Mid(0, 2)) * ONE_HOUR;
	time	+=	_ttol(strIn.Mid(3, 2)) * ONE_MINUTE;
	time	+=	_ttol(strIn.Mid(6, 2)) * ONE_SECOND;
	time	+=	_ttol(strIn.Mid(9, 3)) * ONE_MILLISECOND;
	*pFT	= time;

	return TRUE;
}

BOOL CLogFileReader::ParseRecord(LPCTSTR lpszInput)
{
	CString		str, str1, str2;
	SYSTEMTIME	tm = {0};
	UFT			u1;
	int			nTokens, i, j;

	try
	{
		nTokens = ParseCSVRecord(lpszInput, m_strTokens, MAX_TOKENS);
		ASSERT(nTokens >= TOKENS_REQUIRED);	// Minimum or format error.
		if (nTokens < TOKENS_REQUIRED) throw(_T("Not enough tokens."));

		for (i = 0; i < nTokens; i++) m_strTokens[i].Trim();

		// Event number
		str					= m_strTokens[0];
		m_nEventID			= _ttoi(str);

		// Event Date
		str					= m_strTokens[1];
		tm.wYear			= _ttoi(str.Mid(0, 4));
		tm.wMonth			= _ttoi(str.Mid(5, 2));
		tm.wDay				= _ttoi(str.Mid(8, 2));

		// Event time
		str					= m_strTokens[2];
		tm.wHour			= _ttoi(str.Mid(0,2));
		tm.wMinute			= _ttoi(str.Mid(3,2));
		tm.wSecond			= _ttoi(str.Mid(6,2));
		tm.wMilliseconds	= _ttoi(str.Mid(9,3));
		SystemTimeToFileTime(&tm, &m_tEventStamp.ft);

		// Event Duration
		str					= m_strTokens[3];
		i					= str.Find('.');
		if (i == 0)			throw(_T("Bad duration"));
		str1				= str.Mid(0, i);	// seperate integer
		str2				= str.Mid(i+1);		// fraction
		if (str1.IsEmpty()) throw(_T("Bad duration"));
		if (str2.IsEmpty()) throw(_T("Bad duration"));
		i					= _ttoi(str1);
		j					= _ttoi(str2);
		u1.ll				= ((LONGLONG) i) * ONE_SECOND;
		u1.ll				+= ((LONGLONG) j) * ONE_MILLISECOND;
		m_tDur				= u1.ll;

		// Relative time
		str					= m_strTokens[4];
		ConvertLogTime(&m_tRelative, str);

		// Trigger channel
		str					= m_strTokens[5];
		m_strTrigCh			= str;

		// Byte offset
		str					= m_strTokens[6];
		m_nByteOffset		= HexToULL(str);

		// Sample offset
		str					= m_strTokens[7];
		m_nSampleOffset		= HexToULL(str);

		// Time offset
		str					= m_strTokens[8];
		m_nTimeOffset		= HexToULL(str);
	}
	catch(LPCTSTR lpszMsg)
	{
		str.Format(_T("Error: Log file record is corrupt.\r\n") \
			_T("%s"), lpszMsg);
		AfxMessageBox(str, MB_OK|MB_ICONERROR);
		return FALSE;
	}
	
	return TRUE;
}

REFERENCE_TIME CLogFileReader::GetEventTime(void)
{
	return m_tEventStamp.ll;
}

REFERENCE_TIME CLogFileReader::GetDuration(void)
{
	return m_tDur;
}

REFERENCE_TIME CLogFileReader::GetRelativeTime(void)
{
	return m_tRelative;
}

void CLogFileReader::GetFreq(CString& strOut)
{
	strOut = m_strFreq;
}

// Convert a frequency string to fixed point integer in hz.
// The string can have 0, 1 or 2 decimals. The 2nd decimal is ignored before converting.
LONGLONG CLogFileReader::StrToFP(LPCTSTR lpszString)
{
	CString	strMant, strFrac, str;
	int	nDecimals, i;
	LONGLONG	result;

	str = lpszString;

	// Count decimals
	i = str.Find(_T("."));
	for (nDecimals = 0;;)
	{
		if (i >= 0)
		{
			nDecimals++;
		}
		else break;

		i = str.Find(_T("."), i+1);
	}

	switch(nDecimals)
	{
		case 0:
			strMant = str;
			break;

		case 1:
			i = str.Find(_T("."));
			strMant = str.Mid(0, i);
			strFrac = str.Mid(i+1);
			break;

		case 2:
			i = str.Find(_T("."));
			strMant = str.Left(i);

			str = str.Mid(i+1);	// Trim off mantissa and decimal

			i = str.Find(_T("."));	// Locate 2nd decimal
			strFrac = str.Left(i);
			strFrac += str.Mid(i+1);
			break;
	}

	result = _tstoi64(strMant) * 1000000;

	// Calculate the fraction part.
	strFrac += _T("00000000");	// Pad with zeros on right side
	strFrac = strFrac.Left(6);	// Truncate fraction to n digits
	result += _tstoi64(strFrac);

	return result;
}

// Convert fixed integer in hz to string with a single decimal
void CLogFileReader::FPToStr(CString& strOut, LONGLONG nValue)
{
	DWORD	hi, lo;

	hi = (DWORD) nValue / 1000000;
	lo = (DWORD) nValue % 1000000;

	strOut.Format(_T("%05d.%06d"), hi, lo);
}

// Convert fixed integer in hz to string with a double decimal
void CLogFileReader::FPToStr2(CString& strOut, LONGLONG nValue)
{
	DWORD	hi, lo;
	DWORD	khz, hz;

	hi = (DWORD) nValue / 1000000;
	lo = (DWORD) nValue % 1000000;

	khz = lo / 1000;
	hz	= lo % 1000;

	strOut.Format(_T("%05d.%03d.%02d"), hi, khz, hz);
}

CString CLogFileReader::FPToStr(LONGLONG nValue)
{
	CString str;

	FPToStr(str, nValue);

	return str;
}


int CLogFileReader::GetSMeter(void)
{
	return m_nSmeter;
}

ULONGLONG CLogFileReader::GetFilePosition(void)
{
	UFT		u1, u2;
	BOOL	rc;

	u2.ll = 0;
	rc = SetFilePointerEx(m_hFile, u2.i, &u1.i, FILE_CURRENT);
	if (!rc) throw(_T("Error trying to get the log file position."));

	return u1.ll;
}

BOOL CLogFileReader::Seek(ULONGLONG Pos)
{
	UFT		u1, u2;
	BOOL	rc;

	u2.ll = Pos;
	rc = SetFilePointerEx(m_hFile, u2.i, &u1.i, FILE_BEGIN);

	return rc;
}

BOOL CLogFileReader::SeekToEnd(void)
{
	UFT		u1, u2;
	BOOL	rc;

	u2.ll = 0;
	rc = SetFilePointerEx(m_hFile, u2.i, &u1.i, FILE_END);

	return rc;
}

// nItems must be # items in your empty CString array.
// returns # of tokens read from input string.
int CLogFileReader::ParseCSVRecord(LPCTSTR lpszInput, CString* pstrToken, int nItems)
{
	int			cTokens = 0;
	CString		strInput, strToken;
	int			index;	// Keeps track of scan position.
	int			len;	// # of chars in input line

	// Clear the caller's token array.
	for (int i = 0; i < nItems; i++)
		pstrToken[i].Empty();

	len = (int) _tcslen(lpszInput);

	if (len > 0)
	{	// Parse the input
		strInput = lpszInput;

		// Scan string until eol reached.
		for (index = 0, cTokens = 0; index < len;)
		{
			int	i = strInput.Find(',', index);
			if (i == -1)
			{	// No more commas found



				// Strip the line end character if present.
				if ((strInput[len-1] == 0x0D) ||
					(strInput[len-1] == 0x0A))
				{
					strInput = strInput.Left(len-1);
					len--;
				}



				strToken = strInput.Mid(index, len-index);

				if (cTokens >= nItems) break;	// Array count exceeded.
				
				pstrToken[cTokens++] = strToken;
				break;
			}
			if (i > 0)
			{
				strToken = strInput.Mid(index, i - index);
				index = i+1;	// 1st char past comma

				if (cTokens >= nItems) break;	// Array count exceeded.
				
				pstrToken[cTokens++] = strToken;
			}
		}
	}

	return cTokens;
}

CString& CLogFileReader::GetUserField(int nIndex)
{
	return m_strTokens[nIndex + TOKENS_REQUIRED + 1];
}

int CLogFileReader::GetEventID(void)
{
	return m_nEventID;
}

BOOL CLogFileReader::IsNumber(LPCTSTR lpszInput)
{
	CString	str, str2;
	int		len, i;

	str = lpszInput;
	len		= str.GetLength();

	if (len == 0) return FALSE;	// string empty. Can't be a number.

	for (i = 0; i < len; i++)
	{
		str2 = str.Mid(0,1);
		if (str2.FindOneOf(_T("0123456789")) == -1)	// If nth char is not #
			return FALSE;
		str = str.Mid(1);	// Remove leftmost char.
	}

	return TRUE;
}

ULONGLONG CLogFileReader::HexToULL(LPCTSTR lpszInput)
{
	ULONGLONG	result;
	CString		strInput = lpszInput;
	CString		strHex = _T("0123456789ABCDEF");

	strInput.Trim();
	strInput.MakeUpper();

	// remove the "0X" prefix.
	if (strInput.Left(2) == _T("0X"))
	{
		strInput = strInput.Right(strInput.GetLength() - 2);
	}

	result = 0;
	while (!strInput.IsEmpty())
	{
		result <<= 4;	// Move result to make room for next hex digit.
		result += strHex.Find(strInput.Left(1));
		strInput = strInput.Right(strInput.GetLength() - 1);	// Trim off L digit.
	}

	return result;;
}

ULONGLONG CLogFileReader::GetTimeOffset(void)
{
	return m_nTimeOffset;
}

ULONGLONG CLogFileReader::GetFileOffset(void)
{
	return m_nByteOffset;
}

ULONGLONG CLogFileReader::GetSampleOffset(void)
{
	return m_nSampleOffset;
}
