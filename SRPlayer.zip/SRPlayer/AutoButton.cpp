// AutoButton.cpp : implementation file
//

#include "stdafx.h"
#include "AutoButton.h"
#include ".\autobutton.h"


// CAutoButton

IMPLEMENT_DYNAMIC(CAutoButton, CBitmapButton)
CAutoButton::CAutoButton()
: m_bCheckButton(FALSE)
, m_CheckState(BST_UNCHECKED)
{
}

CAutoButton::~CAutoButton()
{
}


BEGIN_MESSAGE_MAP(CAutoButton, CBitmapButton)
	ON_MESSAGE(BM_SETCHECK, OnSetCheck)
	ON_MESSAGE(BM_GETCHECK, OnGetCheck)
	ON_WM_LBUTTONUP()
	ON_WM_KEYUP()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CAutoButton message handlers


BOOL CAutoButton::LoadBitmaps(LPCTSTR lpszBitmapResource)
{
	BOOL	rc;

	ASSERT(m_bm[0].GetSafeHandle() == NULL);	// only allowed once

	rc = m_bm[0].LoadBitmap(lpszBitmapResource);
	ASSERT(rc);	// Can't load?
	rc = m_bm[1].LoadBitmap(lpszBitmapResource);
	ASSERT(rc);	// Can't load?

	return rc;
}

BOOL CAutoButton::LoadBitmaps(UINT nIDBitmapResource)
{
	BOOL	rc;

	ASSERT(m_bm[0].GetSafeHandle() == NULL);	// only allowed once

	rc = m_bm[0].LoadBitmap(nIDBitmapResource);
	ASSERT(rc);	// Can't load?
	rc = m_bm[1].LoadBitmap(nIDBitmapResource);
	ASSERT(rc);	// Can't load?

	return rc;
}

BOOL CAutoButton::LoadBitmaps(UINT nIDBitmapResource1, UINT nIDBitmapResource2)
{
	BOOL	rc;

	ASSERT(m_bm[0].GetSafeHandle() == NULL);	// only allowed once

	rc = m_bm[0].LoadBitmap(nIDBitmapResource1);
	ASSERT(rc);	// Can't load?
	rc = m_bm[1].LoadBitmap(nIDBitmapResource2);
	ASSERT(rc);	// Can't load?

	return rc;
}

BOOL CAutoButton::AutoLoad(UINT nID, CWnd* pParent)
{
	BOOL	rc;
	CString	str;

	if (!SubclassDlgItem(nID, pParent)) return FALSE;

	GetWindowText(str);
	if (str.IsEmpty())
	{
		ASSERT(0);	// No caption in the button resource
		return FALSE;
	}
	
	rc = LoadBitmaps(str);
	ASSERT(rc);

	SizeToContent();

	return TRUE;
}

void CAutoButton::DrawItem(LPDRAWITEMSTRUCT lpDis)
{
	UINT	action	= lpDis->itemAction;
	UINT	state	= lpDis->itemState;
	CDC*	pDC		= CDC::FromHandle(lpDis->hDC);
	CDC		dcSrc[2];
	CRect	bmRect, edgeRect;

	GetClientRect(&bmRect);

	dcSrc[0].CreateCompatibleDC(pDC);
	dcSrc[1].CreateCompatibleDC(pDC);
	dcSrc[0].SaveDC();
	dcSrc[1].SaveDC();
	pDC->SaveDC();

	//pDC->SelectClipRgn(&m_RgnC);

	dcSrc[0].SelectObject(&m_bm[0]);
	dcSrc[1].SelectObject(&m_bm[1]);

	// Draw button image and frame
	if (state & ODS_SELECTED || (m_bCheckButton && m_CheckState == BST_CHECKED))
	{	// Draw the button image and it's edge
		pDC->BitBlt(1, 1, bmRect.Width()-1, bmRect.Height()-1, &dcSrc[1], 0, 0, SRCCOPY);
		//DrawButtonEdge(pDC, lpDis, TRUE);
	}
	else
	{
		pDC->BitBlt(0, 0, bmRect.Width(), bmRect.Height(), &dcSrc[0], 0, 0, SRCCOPY);
		//DrawButtonEdge(pDC, lpDis, FALSE);
	}

	if (state & ODS_FOCUS)
	{
		DrawFocus(pDC, lpDis);
	}

	if (state & ODS_DISABLED)
	{
		DrawDisabled(pDC, lpDis);
	}


	pDC->RestoreDC(-1);	
	dcSrc[1].RestoreDC(-1);
	dcSrc[0].RestoreDC(-1);

	//__super::DrawItem(lpDis);
}

void CAutoButton::PreSubclassWindow()
{
	CRect	rect;

	__super::PreSubclassWindow();

	// Disable double click sensitivity
	SetClassLong(GetSafeHwnd(), GCL_STYLE, GetClassLong(GetSafeHwnd(), GCL_STYLE) & ~CS_DBLCLKS);

	//GetClientRect(&rect);

	//// Set the window rgn
	//m_Rgn.CreateEllipticRgn(rect.left, rect.top, rect.right, rect.bottom);

	//// Then the clip rgn.
	////InflateRect(&rect, 1, 1);
	//m_RgnC.CreateEllipticRgn(rect.left, rect.top, rect.right, rect.bottom);

	//SetWindowRgn(m_Rgn, TRUE);
}

afx_msg LRESULT CAutoButton::OnSetCheck( WPARAM wParam, LPARAM lParam)
{
	ASSERT(wParam == BST_CHECKED || wParam == BST_UNCHECKED);

	m_CheckState = (LONG) wParam;

	Invalidate(FALSE);
	return TRUE;
}

afx_msg LRESULT CAutoButton::OnGetCheck( WPARAM wParam, LPARAM lParam)
{
	return m_CheckState;
}

BOOL CAutoButton::IsCheckButton(void)
{
	return m_bCheckButton;
}

void CAutoButton::SetToggleMode(bool bCheckBtn)
{
	m_bCheckButton = bCheckBtn;
}

void CAutoButton::OnLButtonUp(UINT nFlags, CPoint point)
{
	CRect	rect;
	GetClientRect(&rect);

	if (rect.PtInRect(point))
	{
		if (m_bCheckButton)
		{
			SetCheck((GetCheck() == BST_CHECKED) ? BST_UNCHECKED:BST_CHECKED);
		}
	}

	__super::OnLButtonUp(nFlags, point);
}

void CAutoButton::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == VK_SPACE || nChar == VK_RETURN)
	{
		if (m_bCheckButton)
		{
			SetCheck((GetCheck() == BST_CHECKED) ? BST_UNCHECKED:BST_CHECKED);
		}
	}

	__super::OnKeyUp(nChar, nRepCnt, nFlags);
}

// Overlay a shadow and highlight based on the button state.
void CAutoButton::DrawButtonEdge(CDC* pDC, LPDRAWITEMSTRUCT lpDis, BOOL bDown)
{
	CRect	rect;

	CPen	penS(PS_SOLID, 1, RGB(064, 064, 064));
	CPen	penH(PS_SOLID, 1, RGB(220, 255, 220));

	pDC->SaveDC();


	if (!bDown)	// button is up
	{
		rect = lpDis->rcItem;
		for (int i = 1; i <= 3; i++)
		{
			// Upper left highlight
			//pDC->SelectObject(&penH);
			//pDC->MoveTo(rect.left, rect.bottom-1);
			//pDC->LineTo(rect.left, rect.top);
			//pDC->LineTo(rect.right-1, rect.top);

			// Lower right shadow
			pDC->SelectObject(&penS);
			pDC->MoveTo(rect.right-1, rect.top);
			pDC->LineTo(rect.right-1, rect.bottom-1);
			pDC->LineTo(rect.left, rect.bottom-1);

			rect.DeflateRect(1,1);
		}

	}
	else	// Button is down
	{
		rect = lpDis->rcItem;
		for (int i = 1; i <= 3; i++)
		{
			// Upper left shadow
			pDC->SelectObject(&penS);
			pDC->MoveTo(rect.left, rect.bottom-1);
			pDC->LineTo(rect.left, rect.top);
			pDC->LineTo(rect.right-1, rect.top);

			rect.DeflateRect(1,1);
		}

		// Lower right hilight
		rect = lpDis->rcItem;
		pDC->SelectObject(&penH);
		pDC->MoveTo(rect.right-1, rect.top);
		pDC->LineTo(rect.right-1, rect.bottom-1);
		pDC->LineTo(rect.left, rect.bottom-1);
	}


	pDC->RestoreDC(-1);
}

void CAutoButton::DrawFocus(CDC* pDC, LPDRAWITEMSTRUCT lpDis)
{
	CPen	pen(PS_DOT, 1, RGB(255, 255, 255));	// for focus rect
	CRect	fRect(lpDis->rcItem);

	fRect.DeflateRect(5, 5);

	pDC->SaveDC();

	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	pDC->SelectObject(&pen);
	pDC->SetBkMode(TRANSPARENT);

	pDC->SetROP2(SRCINVERT);
	pDC->Rectangle(&fRect);

	pDC->RestoreDC(-1);
}

void CAutoButton::DrawDisabled(CDC* pDC, LPDRAWITEMSTRUCT lpDis)
{
	CBrush	brush1(HS_FDIAGONAL, RGB(255, 255, 255));
	CRect	edgeRect(lpDis->rcItem);

	pDC->SaveDC();

	pDC->SetBkColor(RGB(000, 000, 000));
	pDC->SelectObject(&brush1);
	//pDC->PatBlt(lpDis->rcItem.left, edgeRect.top, edgeRect.Width(), edgeRect.Height(), 0x00FA0089);
	pDC->PatBlt(lpDis->rcItem.left, edgeRect.top, edgeRect.Width(), edgeRect.Height(), PATINVERT);

	pDC->RestoreDC(-1);
}

void CAutoButton::SizeToContent()
{
	CSize bitmapSize;
	BITMAP bmInfo;

	ASSERT(m_bm[0].m_hObject != NULL);

	VERIFY(m_bm[0].GetObject(sizeof(bmInfo), &bmInfo) == sizeof(bmInfo));
	VERIFY(SetWindowPos(NULL, -1, -1, bmInfo.bmWidth, bmInfo.bmHeight,
		SWP_NOMOVE|SWP_NOZORDER|SWP_NOREDRAW|SWP_NOACTIVATE));
}


BOOL CAutoButton::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

BOOL CAutoButton::PreTranslateMessage(MSG* pMsg)
{
	//CRect	rect;
	//CRgn	rgn;
	//POINTS	pts = MAKEPOINTS(pMsg->lParam);
	//POINT	pnt = {pts.x, pts.y};

	//if (pMsg->message == WM_LBUTTONDOWN ||
	//	pMsg->message == WM_LBUTTONDOWN ||
	//	pMsg->message == WM_LBUTTONDBLCLK)
	//{
	//	GetClientRect(&rect);
	//	rgn.CreateEllipticRgn(rect.left, rect.top, rect.right, rect.bottom);
	//	if (!PtInRegion((HRGN) rgn.GetSafeHandle(), pts.x, pts.y)) return TRUE;
	//}

	return CBitmapButton::PreTranslateMessage(pMsg);
}
