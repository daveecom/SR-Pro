#pragma once
#include "afxwin.h"


// CPlayerClock

class CPlayerClock : public CStatic
{
	DECLARE_DYNAMIC(CPlayerClock)

public:
	CPlayerClock();
	virtual ~CPlayerClock();

protected:
	DECLARE_MESSAGE_MAP()
	virtual void PreSubclassWindow();
	UFT m_uCurrent;		// stored local time (used to calc delta)
	UFT m_uSimTime;		// Simulated clock time (from log)
	CSection	m_csSimLock;
	afx_msg HBRUSH CtlColor ( CDC* pDC, UINT nCtlColor ); 
	CBrush m_BkBrush;
public:
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT nIDEvent);
protected:
	void UpdateClock(void);
public:
	void SetTime(LPFILETIME pFT);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
protected:
	BOOL m_bRun;
public:
	void SetRun(bool bRun);
//	afx_msg void OnPaint();
};

