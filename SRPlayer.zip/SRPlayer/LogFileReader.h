#pragma once
#include <afx.h>
#include <atlcoll.h>

#define		MAX_TOKENS 100

class CIndexEntry
{
	public:
	CIndexEntry(ULONGLONG nOffset, int nLength)
	{
		m_nOffset	= nOffset;
		m_nLength	= nLength;
	};

	~CIndexEntry() {};

	ULONGLONG	m_nOffset;		// In bytes from start of log file.
	int			m_nLength;		// In bytes
};

class CLogFileReader
{
public:
	CLogFileReader(void);
	~CLogFileReader(void);

	virtual BOOL	Open(LPCTSTR lpszFilePath);
	void			GetFreq(CString& strOut);
	REFERENCE_TIME	GetRelativeTime(void);
	REFERENCE_TIME	GetDuration(void);
	DWORD			GetCount(void);
	BOOL			GetEventRecord(CString& strEvent, DWORD dwEvent);
	BOOL			ParseRecord(LPCTSTR lpszInput);
	int				GetSMeter(void);
	REFERENCE_TIME	GetEventTime(void);
	ULONGLONG		GetTimeOffset(void);
	ULONGLONG		GetFileOffset(void);

protected:
	BOOL			ReadLine(CString& strLine);
	void			Close(void);
	//BOOL			SeekToOffset(ULONGLONG nOffset);
	BOOL			ConvertLogTime(LONGLONG* pFT, LPCTSTR lpszInput, DWORD dwLength = 0);
	LONGLONG		StrToFP(LPCTSTR lpszString);
	void			FPToStr(CString& strOut, LONGLONG nValue);
	void			FPToStr2(CString& strOut, LONGLONG nValue);
	CString			FPToStr(LONGLONG nValue);
	ULONGLONG		GetFilePosition(void);
	BOOL			Seek(ULONGLONG Pos);
	BOOL			SeekToEnd(void);
	int				ParseCSVRecord(LPCTSTR lpszInput, CString* pstrToken, int nItems);

	ULONGLONG		m_nFileSize;
	//DWORD			m_nRecords;	// # event records in this file. (From Getcount)
	//CFile			m_hFile;
	HANDLE			m_hFile;
	ULONGLONG		m_nDataOffset;
	TCHAR*			ScanToken(LPCTSTR lpszInput);
	TCHAR*			ScanBlank(LPCTSTR lpszInput);

	// The extracted variables from the log record.
	int				m_nEventID;
	UFT				m_tEventStamp;	// From Event Date + Event Time
	REFERENCE_TIME	m_tDur;
	REFERENCE_TIME	m_tRelative;
	CString			m_strTrigCh;
	CString			m_strFreq;
	int				m_nSmeter;
	ULONGLONG		m_nByteOffset;
	ULONGLONG		m_nSampleOffset;
	ULONGLONG		m_nTimeOffset;
	CString			m_strTokens[MAX_TOKENS];

	// New as of build 0.95 - needed for CSV style log file.
	CSimpleArray<CIndexEntry>	m_Index;

public:
	CString& GetUserField(int nIndex);
	int GetEventID(void);
	BOOL IsNumber(LPCTSTR lpszInput);
	ULONGLONG HexToULL(LPCTSTR lpszInput);
	ULONGLONG GetSampleOffset(void);
};

/*
Obsolete after bld 0.93
000000000011111111112222222222333333333344444444445555555555666666666677777777778888888888999999999900000000001
012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
Event  Event       Event         Event         Relative      Tr  Freq             SMeter  File
ID     Date        Time          Duration      Time          Ch                   %       Offset
=====  ==========  ============  ============  ============  ==  ===============  ======  ==================
00000  2005/11/06  02:47:54.938  00:00:03.616  00:00:00.000  LE  0042.620.00 Mhz  039     0x0000000000000000
*/
