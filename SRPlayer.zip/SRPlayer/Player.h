// This is the main player object. It's controlled by commands from the CDocument
// and is only usable if you provide a path to a .wav file first. Therefore the path
// is part of the create parms.

#pragma once

#define UWM_PLAYER_DONE		(WM_USER + 10)	// Message from player to view.
#define UWM_NEWFILEISOPEN	(WM_USER + 11)	// Message from doc to view

class CPlayer
{
public:
	CPlayer(void);
	~CPlayer(void);

	virtual BOOL Create(const LPCTSTR lpszFilePath);
	BOOL PlaySegment(REFERENCE_TIME tStart, REFERENCE_TIME tDuration, HWND hAlert);

protected:
	CString		m_strFilePath;		// Main file path to the audio content.

	CComPtr<IGraphBuilder>		m_iBuilder;			// Graph builder.
	CComPtr<IFilterGraph2>		m_iGraph;			// Filter graph manager.
	CComPtr<IMediaControl>		m_iMC;				// Media control
	CComPtr<IMediaSeeking>		m_iMS;				// Media seeking
	CComPtr<IMediaEvent>		m_iME;				// For sync to playing segment
	BOOL						m_bInit;
	HWND						m_hAlert;

	static void	__cdecl			StartWorker( void * );
	void						WorkerProc();
	HANDLE						m_hThread;

	DWORD						m_dwGraphRegister;
	HRESULT					AddGraphToRot(IUnknown *pUnkGraph, DWORD *pdwRegister);
	void					RemoveGraphFromRot(DWORD pdwRegister);

public:
	BOOL StopPlaying(void);
protected:
	BOOL m_bPlaying;
public:
	BOOL IsPlaying(void);
};
