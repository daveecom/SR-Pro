// MainFrm.h : interface of the CMainFrame class
#pragma once
#include "dlgbarcontrols.h"
#include "playerview.h"

class CMainFrame : public CFrameWnd
{
	friend class CPlayerView;
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
	CDlgbarControls m_DlgbarControls;
public:
	CDlgbarControls* GetDlgBar(void);
};

