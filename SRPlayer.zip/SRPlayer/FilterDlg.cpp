// FilterDlg.cpp : implementation file
//

#include "stdafx.h"
#include <float.h>
#include "SRPlayer.h"
#include "FilterDlg.h"
#include ".\filterdlg.h"


// CFilterDlg dialog

IMPLEMENT_DYNAMIC(CFilterDlg, CDialog)
CFilterDlg::CFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFilterDlg::IDD, pParent)
	, m_bDirty(FALSE)
{
}

CFilterDlg::~CFilterDlg()
{
}

void CFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_INCLUDE, m_List_Include);
	DDX_Control(pDX, IDC_LIST_EXCLUDE, m_List_Exclude);
	DDX_Control(pDX, IDC_CHECK_ENABLE, m_Check_Enable);
	DDX_Control(pDX, IDC_EDIT_ENTERFREQ, m_Edit_Freq);
}

BEGIN_MESSAGE_MAP(CFilterDlg, CDialog)
//	ON_BN_CLICKED(IDC_CHECK_ENABLE, OnBnClickedCheckEnable)
ON_BN_CLICKED(IDC_BUTTON_DEFAULTS, OnBnClickedButtonDefaults)
ON_BN_CLICKED(IDC_CHECK_ENABLE, OnBnClickedCheckEnable)
ON_BN_CLICKED(IDC_BUTTON_ADDINCLUDE, OnBnClickedButtonAddinclude)
ON_BN_CLICKED(IDC_BUTTON_ADDEXCLUDE, OnBnClickedButtonAddexclude)
ON_BN_CLICKED(IDC_BUTTON_DELETEINC, OnBnClickedButtonDeleteinc)
ON_BN_CLICKED(IDC_BUTTON_DELETEEXC, OnBnClickedButtonDeleteexc)
END_MESSAGE_MAP()


BOOL CFilterDlg::OnInitDialog()
{
	PlayerApp*	app = (PlayerApp*) AfxGetApp();

	CDialog::OnInitDialog();

	LoadFilters();

	BOOL	bEnabled = (app->GetProfileInt(_T("Filter_Enabled"), FALSE) != 0);
	m_Check_Enable.SetCheck(bEnabled ? BST_CHECKED:BST_UNCHECKED);

	m_bDirty = FALSE;

	m_Edit_Freq.SetFocus();
	return FALSE;
}

void CFilterDlg::LoadFilters(void)
{
	CString	str, str1;
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	int i;

	str = app->GetProfileString(_T("Filter_Include"), _T(""));

	// Loop to populate the include listbox
	if (!str.IsEmpty())
	for (i = 0;;)
	{
		str1 = str.Tokenize(_T(" "), i);
		if (str1.IsEmpty()) break;
		str1.Trim();
		m_List_Include.AddString(str1);
	}

	str = app->GetProfileString(_T("Filter_Exclude"), _T(""));

	// Loop to populate the exclude listbox
	if (!str.IsEmpty())
	for (i = 0;;)
	{
		str1 = str.Tokenize(_T(" "), i);
		if (str1.IsEmpty()) break;
		str1.Trim();
		m_List_Exclude.AddString(str1);
	}
}

void CFilterDlg::SaveFilters(void)
{
	CString	strInclude, strExclude, str;
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	int	nInclude, nExclude;
	int	i, j;

	nInclude = m_List_Include.GetCount();
	nExclude = m_List_Exclude.GetCount();

	for (i = 0, j = nInclude; i < j; i++)
	{
		m_List_Include.GetText(i, str);
		strInclude += str;
		if (i < j-1) strInclude += _T(" ");
	}

	app->WriteProfileString(_T("Filter_Include"), strInclude);

	for (i = 0, j = nExclude; i < j; i++)
	{
		m_List_Exclude.GetText(i, str);
		strExclude += str;
		if (i < j-1) strExclude += _T(" ");
	}

	app->WriteProfileString(_T("Filter_Exclude"), strExclude);
}

void CFilterDlg::OnOK()
{
	PlayerApp*	app = (PlayerApp*) AfxGetApp();

	if (m_bDirty)
	{
		BOOL bEnabled = m_Check_Enable.GetCheck() == BST_CHECKED;

		app->WriteProfileInt(_T("Filter_Enabled"), bEnabled ? 1:0);

		SaveFilters();

		m_bDirty = FALSE;
	}

	CDialog::OnOK();
}

BOOL CFilterDlg::IsFilterEnabled(void)
{
	BOOL bEnabled = m_Check_Enable.GetCheck() == BST_CHECKED;

	return bEnabled;
}

// Restore dialog defaults.
void CFilterDlg::OnBnClickedButtonDefaults()
{
	m_List_Exclude.ResetContent();
	m_List_Include.ResetContent();

	m_Check_Enable.SetCheck(BST_UNCHECKED);
	m_bDirty = TRUE;
}

void CFilterDlg::OnCancel()
{
	if (m_bDirty)
	{
		INT_PTR result = AfxMessageBox(_T("Changes have been made. Are you sure\n")
			_T("you want to cancel them?"),
			MB_OKCANCEL);
		if (result == IDOK)
		{
			m_bDirty = FALSE;
			__super::OnCancel();
		}
		else
			return;
	}
	__super::OnCancel();
}

// Convert a frequency string to fixed point integer in hz.
// The string can have 0, 1 or 2 decimals. The 2nd decimal is ignored before converting.
LONGLONG CFilterDlg::StrToFP(LPCTSTR lpszString)
{
	CString	strMant, strFrac, str;
	int	nDecimals, i;
	LONGLONG	result;

	str = lpszString;

	// Count decimals
	i = str.Find(_T("."));
	for (nDecimals = 0;;)
	{
		if (i >= 0)
		{
			nDecimals++;
		}
		else break;

		i = str.Find(_T("."), i+1);
	}

	switch(nDecimals)
	{
		case 0:
			strMant = str;
			break;

		case 1:
			i = str.Find(_T("."));
			strMant = str.Mid(0, i);
			strFrac = str.Mid(i+1);
			break;

		case 2:
			i = str.Find(_T("."));
			strMant = str.Left(i);

			str = str.Mid(i+1);	// Trim off mantissa and decimal

			i = str.Find(_T("."));	// Locate 2nd decimal
			strFrac = str.Left(i);
			strFrac += str.Mid(i+1);
			break;
	}

	result = _tstoi64(strMant) * 1000000;

	// Calculate the fraction part.
	strFrac += _T("00000000");	// Pad with zeros on right side
	strFrac = strFrac.Left(6);	// Truncate fraction to n digits
	result += _tstoi64(strFrac);

	return result;
}

// Convert fixed integer in hz to string with a single decimal
void CFilterDlg::FPToStr(CString& strOut, LONGLONG nValue)
{
	DWORD	hi, lo;

	hi = (DWORD) (nValue / (LONGLONG) 1000000l);
	lo = (DWORD) (nValue % (LONGLONG) 1000000l);

	strOut.Format(_T("%04d.%06d"), hi, lo);
}

// Convert fixed integer in hz to string with a double decimal
void CFilterDlg::FPToStr2(CString& strOut, LONGLONG nValue)
{
	CString	str;

	FPToStr(str, nValue);

	str.Insert(8, _T("."));
	int n = str.GetLength();
	strOut = str.Left(n-1);
}

CString CFilterDlg::FPToStr(LONGLONG nValue)
{
	CString str;

	FPToStr(str, nValue);

	return str;
}

CString CFilterDlg::FPToStr2(LONGLONG nValue)
{
	CString str;

	FPToStr2(str, nValue);

	return str;
}


void CFilterDlg::OnBnClickedCheckEnable()
{
	m_bDirty = TRUE;	// Check state will be read by OnOk handler.
}

void CFilterDlg::OnBnClickedButtonAddinclude()
{
	int			i, j;
	BOOL		bFound = FALSE;
	CString		str;
	LONGLONG	freq, freqFrmList;

	try
	{
		m_Edit_Freq.GetWindowText(str);
		if (str.IsEmpty()) throw(0);
		freq = StrToFP(str);

		if (freq == 0) throw(0);

		for (i = 0, j = m_List_Include.GetCount(); i < j; i++)
		{
			m_List_Include.GetText(i, str);
			freqFrmList = StrToFP(str);
			if (freqFrmList == freq)
			{
				m_List_Include.SetCurSel(i);
				throw(0);	// Already have matching freq in table.
			}
		}
		for (i = 0, j = m_List_Exclude.GetCount(); i < j; i++)
		{
			m_List_Exclude.GetText(i, str);
			freqFrmList = StrToFP(str);
			if (freqFrmList == freq)
			{
				m_List_Exclude.SetCurSel(i);
				throw(0);	// Already have matching freq in table.
			}
		}
		str = FPToStr2(freq);
		m_List_Include.AddString(str);
		m_bDirty = TRUE;
	}
	catch(int)
	{
		Beep(1500,250);
		return;
	}
}

void CFilterDlg::OnBnClickedButtonAddexclude()
{
	int			i, j;
	BOOL		bFound = FALSE;
	CString		str;
	LONGLONG	freq, freqFrmList;

	try
	{
		m_Edit_Freq.GetWindowText(str);
		if (str.IsEmpty()) throw(0);
		freq = StrToFP(str);

		if (freq == 0) throw(0);

		for (i = 0, j = m_List_Include.GetCount(); i < j; i++)
		{
			m_List_Include.GetText(i, str);
			freqFrmList = StrToFP(str);
			if (freqFrmList == freq)
			{
				m_List_Include.SetCurSel(i);
				throw(0);	// Already have matching freq in table.
			}
		}
		for (i = 0, j = m_List_Exclude.GetCount(); i < j; i++)
		{
			m_List_Exclude.GetText(i, str);
			freqFrmList = StrToFP(str);
			if (freqFrmList == freq)
			{
				m_List_Exclude.SetCurSel(i);
				throw(0);	// Already have matching freq in table.
			}
		}
		str = FPToStr2(freq);
		m_List_Exclude.AddString(str);
		m_bDirty = TRUE;
	}
	catch(int)
	{
		Beep(1500,250);
		return;
	}
}

void CFilterDlg::OnBnClickedButtonDeleteinc()
{
	int	i;

	if (m_List_Include.GetCount() > 0)
	{
		i = m_List_Include.GetCurSel();
		if (i != LB_ERR)
		{
			m_List_Include.DeleteString(i);
			m_List_Include.SetCurSel(i);
		}
	
		m_bDirty = TRUE;
	}
}

void CFilterDlg::OnBnClickedButtonDeleteexc()
{
	int	i;

	if (m_List_Exclude.GetCount() > 0)
	{
		i = m_List_Exclude.GetCurSel();
		if (i != LB_ERR)
		{
			m_List_Exclude.DeleteString(i);
			m_List_Exclude.SetCurSel(i);
		}
	
		m_bDirty = TRUE;
	}
}
