// SRPlayer.h : main header file for the SRPlayer application
//
#pragma once

#include "player.h"
#include "playerdoc.h"

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "logfilereader.h"


// PlayerApp:
// See SRPlayer.cpp for the implementation of this class
//

class PlayerApp : public CWinApp
{
public:
	PlayerApp();
	~PlayerApp();

	//CPlayer			m_Player;
	//CLogFileReader	m_Reader;

	PlayerDoc* m_pDoc;

	virtual BOOL InitInstance();
	PlayerDoc* GetDoc(void);

	double	m_fCorrection;	// Player time correction bias.

	// Overrides to eliminate the need to use the section names.
    UINT GetProfileInt(LPCTSTR lpszEntry, int nDefault);
    BOOL WriteProfileInt(LPCTSTR lpszEntry, int nValue);
    CString GetProfileString(LPCTSTR lpszEntry, LPCTSTR lpszDefault = NULL);
    BOOL WriteProfileString(LPCTSTR lpszEntry, LPCTSTR lpszValue);
    BOOL GetProfileBinary(LPCTSTR lpszEntry, LPBYTE* ppData, UINT* pBytes);
    BOOL WriteProfileBinary(LPCTSTR lpszEntry, LPBYTE pData, UINT nBytes);


// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
	afx_msg void OnTestPlay();
	virtual int ExitInstance();
};

extern PlayerApp theApp;

double StrToDouble(LPCTSTR lpszIn);
void DoubleToStr(double fIn, CString& strOut);
