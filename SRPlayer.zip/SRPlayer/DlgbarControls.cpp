// DlgbarControls.cpp : implementation file
//

#include "stdafx.h"
#include "SRPlayer.h"
#include "DlgbarControls.h"
#include ".\dlgbarcontrols.h"

// CDlgbarControls

IMPLEMENT_DYNAMIC(CDlgbarControls, CDialogBar)
CDlgbarControls::CDlgbarControls()
{
}

CDlgbarControls::~CDlgbarControls()
{
}


BEGIN_MESSAGE_MAP(CDlgbarControls, CDialogBar)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_GOTOSTART, OnUpdateButtonGotostart)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_GOTOPREV, OnUpdateButtonGotoprev)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_PLAY, OnUpdateButtonPlay)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_GOTONEXT, OnUpdateButtonGotonext)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_GOTOEND, OnUpdateButtonGotoend)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_STOP, OnUpdateButtonStop)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_SEARCHTIME, OnUpdateButtonSearchtime)
	ON_UPDATE_COMMAND_UI(IDC_BUTTON_SEARCHFREQ, OnUpdateButtonSearchfreq)
END_MESSAGE_MAP()



void CDlgbarControls::DoDataExchange(CDataExchange* pDX)
{
	DDX_Control(pDX, IDC_BUTTON_GOTOSTART, m_Button_Start);
}

void CDlgbarControls::OnUpdateButtonGotostart(CCmdUI *pCmdUI)	{pCmdUI->Enable(IsFileOpen());}
void CDlgbarControls::OnUpdateButtonGotoprev(CCmdUI *pCmdUI)	{pCmdUI->Enable(IsFileOpen());}

void CDlgbarControls::OnUpdateButtonPlay(CCmdUI *pCmdUI)
{
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	PlayerDoc*	doc = app->GetDoc();

	pCmdUI->Enable(IsFileOpen() /*&& !doc->m_pPlayer->IsPlaying()*/);
}

void CDlgbarControls::OnUpdateButtonGotonext(CCmdUI *pCmdUI)	{pCmdUI->Enable(IsFileOpen());}
void CDlgbarControls::OnUpdateButtonGotoend(CCmdUI *pCmdUI)		{pCmdUI->Enable(IsFileOpen());}
void CDlgbarControls::OnUpdateButtonStop(CCmdUI *pCmdUI)
{
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	PlayerDoc*	doc = app->GetDoc();

	pCmdUI->Enable(IsFileOpen() /*&& doc->m_pPlayer->IsPlaying()*/);
}

void CDlgbarControls::OnUpdateButtonSearchtime(CCmdUI *pCmdUI)	{pCmdUI->Enable(IsFileOpen());}
void CDlgbarControls::OnUpdateButtonSearchfreq(CCmdUI *pCmdUI)	{pCmdUI->Enable(IsFileOpen());}

BOOL CDlgbarControls::Create(CWnd* pParentWnd, UINT nIDTemplate, UINT nStyle, UINT nID)
{
	CDialogBar::Create(pParentWnd, nIDTemplate, nStyle, nID);

	m_Button_Start.AutoLoad(IDC_BUTTON_GOTOSTART, this);
	m_Button_Prev.AutoLoad(IDC_BUTTON_GOTOPREV, this);
	m_Button_Stop.AutoLoad(IDC_BUTTON_STOP, this);
	m_Button_Play.AutoLoad(IDC_BUTTON_PLAY, this);
	m_Button_Next.AutoLoad(IDC_BUTTON_GOTONEXT, this);
	m_Button_End.AutoLoad(IDC_BUTTON_GOTOEND, this);
	m_Button_TSearch.AutoLoad(IDC_BUTTON_SEARCHTIME, this);

	m_Button_Play.SetToggleMode(TRUE);
	//m_Button_Stop.SetToggleMode(TRUE);

	return TRUE;
}

BOOL CDlgbarControls::IsFileOpen(void)
{
	PlayerApp*	app = (PlayerApp*) AfxGetApp();
	PlayerDoc*	doc = app->GetDoc();

	return doc->IsFileOpen();
}

CButton* CDlgbarControls::GetPlayButton(void)
{
	return &m_Button_Play;
}
