// PlayerView.h : interface of the PlayerView class
//
#pragma once

#include <atlcoll.h>
#include "..\staticcolor.h"
#include "playerclock.h"
#include "afxcmn.h"
#include "coloredit.h"
#include "resource.h"
#include "i:\src\scanrec pro\staticcolor.h"
#include "afxwin.h"


class PlayerView : public CFormView
{
protected: // create from serialization only
	PlayerView();
	DECLARE_DYNCREATE(PlayerView)

public:
	enum{ IDD = IDD_SRPLAYER_FORM };
	PlayerDoc* GetDocument() const;
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual ~PlayerView();

protected:
	DECLARE_MESSAGE_MAP()

	void				SelectEvent(DWORD dwEventID, BOOL bUpdate=TRUE);
	virtual void		DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void		OnInitialUpdate(); // called first time after construct

protected:
	CAtlArray<LONGLONG>	m_arInclude;	// The include list
	CAtlArray<LONGLONG>	m_arExclude;	// The exclude list. Exclude takes precedence.

	CFont				m_Font0;
	CFont				m_Font1;
	CFont				m_Font2;

	DWORD				m_dwEventID;
	DWORD				m_dwEventCount;
	BOOL				m_bAutoIncrement;
	CColorEdit			m_Edit_EventID;
	BOOL				m_bContinuePlaying;
	BOOL				m_bFilterEnabled;
	CSpinButtonCtrl		m_SpinEventID;
	//CStaticColor		m_Static_Freq;
	CPlayerClock		m_Clock;
	CStaticColor		m_Static_Label1;
	CStaticColor		m_Static_Label2;
	CStaticColor		m_Static_Label7;
	CStaticColor		m_Static_Label3;
	CStaticColor		m_Static_Label4;
	//CStaticColor		m_Static_MaxEvents;
	//CStaticColor		m_Static_FilterStat;
	CStaticColor		m_Static_Label5;
	//CStaticColor		m_Static_Smeter;
	CStaticColor		m_Static_Radio1;
	CStaticColor		m_Static_Radio2;
	CStaticColor		m_Static_Radio3;
	CStaticColor		m_Static_Radio4;
	CStaticColor		m_Static_Radio5;
	CStaticColor		m_Static_Radio6;
	CStaticColor		m_Static_EventID;
	CStaticColor		m_Static_Lastpos;
	CColorEdit			m_Edit_Correction;

	// Used for offset correction.
	ULONGLONG			m_nSampleOffsetAtLastRecord;
	ULONGLONG			m_nTimeOffsetAtLastRecord;

	void				Update(void);
	afx_msg void		OnUpdateToolsFrequencyfilter(CCmdUI *pCmdUI);
	afx_msg void		OnToolsFrequencyfilter();
	void				LoadFilters(void);
	afx_msg BOOL		OnEraseBkgnd(CDC* pDC);
	afx_msg void		OnTimer(UINT nIDEvent);
	afx_msg void		OnClose();
	afx_msg void		OnButtonPlay();
	afx_msg LRESULT		OnSegmentComplete( WPARAM, LPARAM );
	afx_msg LRESULT		OnNewFileOpen( WPARAM, LPARAM );
	afx_msg void		OnButtonStop();
	afx_msg void		OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void		OnBnClickedButtonGotostart();
	afx_msg void		OnBnClickedButtonGotonext();
	afx_msg void		OnBnClickedButtonGotoend();
	afx_msg void		OnBnClickedButtonGotoprev();
	afx_msg void		OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	virtual BOOL		PreTranslateMessage(MSG* pMsg);
	afx_msg void		OnEnKillfocusEditCorrection();

	LONGLONG			StrToFP(LPCTSTR lpszString);
	void				FPToStr(CString& strOut, LONGLONG nValue);
	void				FPToStr2(CString& strOut, LONGLONG nValue);
	CString				FPToStr(LONGLONG nValue);
	BOOL				IsFreqAllowed(LPCTSTR lpszFreq);
	BOOL				SelectFirstEvent(void);
	BOOL				SelectLastEvent(void);
	BOOL				SelectNextEvent(void);
	BOOL				SelectPreviousEvent(void);

	void UpdateCorrectionControl(double fCorrection);
};
