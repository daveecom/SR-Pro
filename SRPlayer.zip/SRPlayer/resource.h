//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SRPlayer.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SRPLAYER_FORM               101
#define IDD_DIALOGBAR_CONTROLS          103
#define IDR_MAINFRAME                   128
#define IDR_SRPlayerTYPE                129
#define IDR_MAINFRAME_BKP               129
#define IDD_DIALOG_FREQFILTER           138
#define IDD_DIALOG_CALIBRATE            139
#define IDC_STATIC_CLOCK                1000
#define IDC_STATIC_FREQ                 1001
#define IDC_STATIC_CLOCK2               1002
#define IDC_BUTTON_GOTOSTART            1003
#define IDC_STATIC_SMETER               1003
#define IDC_BUTTON_GOTOPREV             1004
#define IDC_BUTTON_GOTONEXT             1005
#define IDC_BUTTON_PLAY                 1006
#define IDC_BUTTON_STOP                 1007
#define IDC_BUTTON_SEARCHTIME           1008
#define IDC_BUTTON_SEARCHTIME2          1009
#define IDC_BUTTON_GOTOEND              1010
#define IDC_BUTTON_SEARCHFREQ           1012
#define IDC_SPIN_EVENTID                1013
#define IDC_EDIT_EVENTID                1014
#define IDC_STATIC_LABEL1               1016
#define IDC_STATIC_LABEL2               1017
#define IDC_STATIC_LABEL3               1018
#define IDC_STATIC_MAXEVENTS            1019
#define IDC_STATIC_LABEL4               1020
#define IDC_EDIT_ENTERFREQ              1021
#define IDC_BUTTON_ADDEXCLUDE           1022
#define IDC_BUTTON_ADDINCLUDE           1023
#define IDC_BUTTON_DELETEINC            1024
#define IDC_BUTTON_DELETEEXC            1025
#define IDC_BUTTON_DEFAULTS             1026
#define IDC_LIST_INCLUDE                1027
#define IDC_LIST_EXCLUDE                1028
#define IDC_CHECK_ENABLE                1030
#define IDC_STATIC_FILTERSTAT           1031
#define IDC_STATIC_LABEL6               1032
#define IDC_STATIC_LABEL5               1032
#define IDC_STATIC_ABOUT                1033
#define IDC_STATIC_COPYRT               1034
#define IDC_STATIC_RADIO1               1035
#define IDC_STATIC_RADIO2               1036
#define IDC_STATIC_RADIO3               1037
#define IDC_STATIC_RADIO4               1038
#define IDC_STATIC_LABEL7               1039
#define IDC_STATIC_EVENTID              1040
#define IDC_STATIC_LASTPOSITION         1041
#define IDC_STATIC_RADIO5               1042
#define IDC_EDIT1                       1043
#define IDC_EDIT_CORRECTION             1043
#define IDC_STATIC_RADIO6               1044
#define ID_TRANSPORT_IDC                32771
#define ID_TRANSPORT_IDC32772           32772
#define ID_TOOLS_FREQUENCYFILTER        32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
